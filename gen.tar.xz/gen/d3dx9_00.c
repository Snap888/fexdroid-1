#include "funcs_d3dx9.h"
#include "lift_prelude.h"

void f_8001034(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001034:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0xD2u);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    esp += 6870; SPILL(); return;
}

void f_8001038(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001038:
    esp += 6870; SPILL(); return;
}

void f_8001327(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001327:
    TS8((uint32_t)(ebx + 0xB7081AA3u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx + 0xB7081AA3u)) | ((uint8_t)edx)), &f)));
    TS32((uint32_t)(0xA3DB081Au), (uint32_t)(eax));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    { jt_ = TL32((uint32_t)(ebx + 0xA418081Au)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x8001327u: goto L_8001327; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80014FE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80014FE:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    esp += 3503; SPILL(); return;
}

void f_800151E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800151E:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    esp += 3503; SPILL(); return;
}

void f_800154A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800154A:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    esp += 3503; SPILL(); return;
}

void f_8001736(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001736:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    SPILL(); rt_int3(c, 0x8001738u);
    { SPILL(); rt_call(c, 0x8001739u); return; }
}

void f_80019E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80019E0:
    { jt_ = TL32((uint32_t)(edi)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x80019E0u: goto L_80019E0; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80019F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80019F0:
    esp -= 4; M32(esp) = 0x80019F5u; SPILL(); rt_call(c, 0xDA081C3Cu); RELOAD();
    ebp = (uint32_t)(dec32(ebp, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    { SPILL(); rt_call(c, 0x80019F8u); return; }
}

void f_8001A72(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001A72:
    esp += 4; SPILL(); return;
}

void f_8001A7C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001A7C:
    esp += 4; SPILL(); return;
}

void f_8001AD9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001AD9:
    esp += 21251; SPILL(); return;
}

void f_8001B90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001B90:
    esp += 8425; SPILL(); return;
}

void f_8001B9B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001B9B:
    esp -= 4; M32(esp) = 0x8001BA0u; SPILL(); rt_call(c, 0x9DC215E9u); RELOAD();
}

void f_8001BCD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001BCD:
    (void)logic32((uint32_t)(M32((uint32_t)(esp + eax*8)) & (uint32_t)0x3CE6CC22u), &f);
    { double a_ = ST(0), b_ = ST(4); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    esp = (uint32_t)(inc32(esp, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFF9u), (uint32_t)(ecx));
    esp += 4; SPILL(); return;
}

void f_8001C60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001C60:
    SPILL(); rt_int3(c, 0x8001C60u);
    { SPILL(); rt_call(c, 0x8001C61u); return; }
}

void f_8001C82(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001C82:
    esp += 4; SPILL(); return;
}

void f_8001D46(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001D46:
    esp += 36432; SPILL(); return;
}

void f_8001DE1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001DE1:
    eax = (uint32_t)(dec32(eax, &f));
    esp += 2160; SPILL(); return;
}

void f_8001E0E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001E0E:
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
}

void f_8001ECA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001ECA:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    SPILL(); rt_int3(c, 0x8001ECCu);
    { SPILL(); rt_call(c, 0x8001ECDu); return; }
}

void f_8001F0E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001F0E:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x82u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp += 4; SPILL(); return;
}

void f_8001F4E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8001F4E:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x82u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp += 4; SPILL(); return;
}

void f_800344E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800344E:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_80035A2(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80035A2:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8003686(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003686:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8003716(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003716:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_80037CA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80037CA:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax)) & (uint32_t)0x310000u), &f);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x80037D4u);
    { SPILL(); rt_call(c, 0x80037D5u); return; }
}

void f_800384E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800384E:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_80039A2(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80039A2:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8003A86(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003A86:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8003B16(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003B16:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8003BCA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003BCA:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax)) & (uint32_t)0x310000u), &f);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x8003BD4u);
    { SPILL(); rt_call(c, 0x8003BD5u); return; }
}

void f_8003C2A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003C2A:
    esp += 4; SPILL(); return;
}

void f_8003C34(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003C34:
    ebx = (uint32_t)(inc32(ebx, &f));
    esp += 4; SPILL(); return;
}

void f_8003D9C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003D9C:
    ebp = (uint32_t)(logic32((uint32_t)(ebp | ebp), &f));
    SPILL(); rt_int3(c, 0x8003D9Eu);
    { SPILL(); rt_call(c, 0x8003D9Fu); return; }
}

void f_8003E1C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003E1C:
    esp += 4; SPILL(); return;
}

void f_8003E2C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003E2C:
    esp += 30550; SPILL(); return;
}

void f_8003F4D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8003F4D:
    esp += 16059; SPILL(); return;
}

void f_800400A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800400A:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)eax), (uint8_t)0x3Fu, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    SPILL(); rt_int3(c, 0x800400Du);
    { SPILL(); rt_call(c, 0x800400Eu); return; }
}

void f_800409D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800409D:
    { jt_ = TL32((uint32_t)(ebx + 0xFFFFFFBFu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x800409Du: goto L_800409D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80040AC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80040AC:
    esp -= 4; M32(esp) = 0x80040B1u; SPILL(); rt_call(c, 0xE43F7B71u); RELOAD();
}

void f_80040E5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80040E5:
    SPILL(); rt_unimpl(c, 0x80040E5u, "int");
    esi = (uint32_t)((uint32_t)0x3F17C4E3u);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x8Du);
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)((uint32_t)0xBF29F3E9u);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0x75u) << 8);
    TS8((uint32_t)(esi + 0x3F3C029Fu), (uint8_t)(adc8(TL8((uint32_t)(esi + 0x3F3C029Fu)), ((uint8_t)(ebx >> 8)), &f)));
    esp += 4; SPILL(); return;
}

void f_8004179(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004179:
    esp += 4; SPILL(); return;
}

void f_80041B5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80041B5:
    esp += 48770; SPILL(); return;
}

void f_8004208(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004208:
    eax = (uint32_t)(inc32(eax, &f));
    esp += 16028; SPILL(); return;
}

void f_800428D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800428D:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)eax), (uint8_t)0x98u, &f));
    esi = (uint32_t)((uint32_t)0x3F5D25FFu);
    ebx = (uint32_t)((uint32_t)0x2B3F0CD4u);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_8004351(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004351:
    esp += 4; SPILL(); return;
}

void f_8004397(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004397:
    esi = (uint32_t)((uint32_t)0xBF7C3BE6u);
    eax = (uint32_t)(logic32((uint32_t)(eax & ecx), &f));
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esi = (uint32_t)((uint32_t)0xBE3A46E1u);
    esp += 4; SPILL(); return;
}

void f_80043BC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80043BC:
    esp -= 4; M32(esp) = 0x80043C1u; SPILL(); rt_call(c, 0xA8BF5361u); RELOAD();
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) ^ (uint8_t)0x54u), &f));
    (void)sub32(eax, (uint32_t)0x3EB18506u, &f);
    { SPILL(); rt_call(c, 0x80043C8u); return; }
}

void f_80043D4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80043D4:
    esp += 4; SPILL(); return;
}

void f_80043DE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80043DE:
    { uint32_t h_ = (eax >> 8) & 0xFF; f.cf = h_ & 1; f.pf = (h_ >> 2) & 1; f.zf = (h_ >> 6) & 1; f.sf = (h_ >> 7) & 1; }
    esi = (uint32_t)((uint32_t)0xBEBA6890u);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)eax), (uint8_t)0xA0u, &f));
    TS8((uint32_t)(edi + 0x3EDEC3FCu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x3EDEC3FCu)) & ((uint8_t)(ebx >> 8))), &f)));
    esp += 9556; SPILL(); return;
}

void f_8004419(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004419:
    esp += 4; SPILL(); return;
}

void f_8004463(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004463:
    ebp = (uint32_t)((uint32_t)0x3EFF9F88u);
    TS8((uint32_t)(edx + 0xBCD3BF5Fu), (uint8_t)(ror8(TL8((uint32_t)(edx + 0xBCD3BF5Fu)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
}

void f_80044AD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80044AD:
    (void)sub32(TL32((uint32_t)(edx)), edi, &f);
    edi = (uint32_t)((uint32_t)0x3F6D6CB5u);
    { uint32_t v_ = 0x13u; esp -= 4; M32(esp) = v_; }
    (void)sub32(M32(esi), M32(edi), &f); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4);
    ebp = (uint32_t)((uint32_t)0x3EBADCB1u);
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(edi), (uint8_t)(sbb8(TL8((uint32_t)(edi)), ((uint8_t)(ebx >> 8)), &f)));
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    SPILL(); rt_int3(c, 0x80044C1u);
    { SPILL(); rt_call(c, 0x80044C2u); return; }
}

void f_80044FF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80044FF:
    esi = (uint32_t)((uint32_t)0x3EFCE4A8u);
    esi = (uint32_t)(logic32((uint32_t)(esi | eax), &f));
    (void)sub32(eax, (uint32_t)0x48FB123Eu, &f);
    edi = (uint32_t)((uint32_t)0xBF1749AEu);
    esp += 4; SPILL(); return;
}

void f_8004665(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004665:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x330D3F49u), &f));
    { uint32_t v_ = esp; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_80046E9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80046E9:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_80046F1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80046F1:
    TS8((uint32_t)(edi + 0xFFFFFFBFu), (uint8_t)(rol8(TL8((uint32_t)(edi + 0xFFFFFFBFu)), (uint8_t)0x35u, &f)));
    edi = M32(esp); esi = M32(esp + 4); ebp = M32(esp + 8); ebx = M32(esp + 16); edx = M32(esp + 20); ecx = M32(esp + 24); eax = M32(esp + 28); esp += 32;
    esp += 4; SPILL(); return;
}

void f_80047A5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80047A5:
    { jt_ = TL32((uint32_t)(ebp + 0x65BB49BEu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x80047A5u: goto L_80047A5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80047C9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80047C9:
    esp += 48977; SPILL(); return;
}

void f_80047D1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80047D1:
    esp += 15569; SPILL(); return;
}

void f_800482A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800482A:
    esp += 4; SPILL(); return;
}

void f_8004834(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004834:
    ebx = (uint32_t)(inc32(ebx, &f));
    esp += 4; SPILL(); return;
}

void f_800499C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800499C:
    ebp = (uint32_t)(logic32((uint32_t)(ebp | ebp), &f));
    SPILL(); rt_int3(c, 0x800499Eu);
    { SPILL(); rt_call(c, 0x800499Fu); return; }
}

void f_8004A1C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004A1C:
    esp += 4; SPILL(); return;
}

void f_8004A2C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004A2C:
    esp += 30550; SPILL(); return;
}

void f_8004B4D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004B4D:
    esp += 16059; SPILL(); return;
}

void f_8004C0A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004C0A:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)eax), (uint8_t)0x3Fu, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    SPILL(); rt_int3(c, 0x8004C0Du);
    { SPILL(); rt_call(c, 0x8004C0Eu); return; }
}

void f_8004C9D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004C9D:
    { jt_ = TL32((uint32_t)(ebx + 0xFFFFFFBFu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x8004C9Du: goto L_8004C9D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_8004CAC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004CAC:
    esp -= 4; M32(esp) = 0x8004CB1u; SPILL(); rt_call(c, 0xE43F8771u); RELOAD();
}

void f_8004CE5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004CE5:
    SPILL(); rt_unimpl(c, 0x8004CE5u, "int");
    esi = (uint32_t)((uint32_t)0x3F17C4E3u);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x8Du);
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)((uint32_t)0xBF29F3E9u);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0x75u) << 8);
    TS8((uint32_t)(esi + 0x3F3C029Fu), (uint8_t)(adc8(TL8((uint32_t)(esi + 0x3F3C029Fu)), ((uint8_t)(ebx >> 8)), &f)));
    esp += 4; SPILL(); return;
}

void f_8004D79(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004D79:
    esp += 4; SPILL(); return;
}

void f_8004DB5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004DB5:
    esp += 48770; SPILL(); return;
}

void f_8004E08(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004E08:
    eax = (uint32_t)(inc32(eax, &f));
    esp += 16028; SPILL(); return;
}

void f_8004E8D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004E8D:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)eax), (uint8_t)0x98u, &f));
    esi = (uint32_t)((uint32_t)0x3F5D25FFu);
    ebx = (uint32_t)((uint32_t)0x2B3F0CD4u);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_8004F51(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004F51:
    esp += 4; SPILL(); return;
}

void f_8004F97(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004F97:
    esi = (uint32_t)((uint32_t)0xBF7C3BE6u);
    eax = (uint32_t)(logic32((uint32_t)(eax & ecx), &f));
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esi = (uint32_t)((uint32_t)0xBE3A46E1u);
    esp += 4; SPILL(); return;
}

void f_8004FBC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004FBC:
    esp -= 4; M32(esp) = 0x8004FC1u; SPILL(); rt_call(c, 0xA8BF5F61u); RELOAD();
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) ^ (uint8_t)0x54u), &f));
    (void)sub32(eax, (uint32_t)0x3EB18506u, &f);
    { SPILL(); rt_call(c, 0x8004FC8u); return; }
}

void f_8004FD4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004FD4:
    esp += 4; SPILL(); return;
}

void f_8004FDE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8004FDE:
    { uint32_t h_ = (eax >> 8) & 0xFF; f.cf = h_ & 1; f.pf = (h_ >> 2) & 1; f.zf = (h_ >> 6) & 1; f.sf = (h_ >> 7) & 1; }
    esi = (uint32_t)((uint32_t)0xBEBA6890u);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)eax), (uint8_t)0xA0u, &f));
    TS8((uint32_t)(edi + 0x3EDEC3FCu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x3EDEC3FCu)) & ((uint8_t)(ebx >> 8))), &f)));
    esp += 9556; SPILL(); return;
}

void f_8005019(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005019:
    esp += 4; SPILL(); return;
}

void f_8005063(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005063:
    ebp = (uint32_t)((uint32_t)0x3EFF9F88u);
    TS8((uint32_t)(edx + 0xBCD3BF5Fu), (uint8_t)(ror8(TL8((uint32_t)(edx + 0xBCD3BF5Fu)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
}

void f_80050AD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80050AD:
    (void)sub32(TL32((uint32_t)(edx)), edi, &f);
    edi = (uint32_t)((uint32_t)0x3F6D6CB5u);
    { uint32_t v_ = 0x13u; esp -= 4; M32(esp) = v_; }
    (void)sub32(M32(esi), M32(edi), &f); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4);
    ebp = (uint32_t)((uint32_t)0x3EBADCB1u);
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(edi), (uint8_t)(sbb8(TL8((uint32_t)(edi)), ((uint8_t)(ebx >> 8)), &f)));
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    SPILL(); rt_int3(c, 0x80050C1u);
    { SPILL(); rt_call(c, 0x80050C2u); return; }
}

void f_80050FF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80050FF:
    esi = (uint32_t)((uint32_t)0x3EFCE4A8u);
    esi = (uint32_t)(logic32((uint32_t)(esi | eax), &f));
    (void)sub32(eax, (uint32_t)0x48FB123Eu, &f);
    edi = (uint32_t)((uint32_t)0xBF1749AEu);
    esp += 4; SPILL(); return;
}

void f_8005265(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005265:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x330D3F49u), &f));
    { uint32_t v_ = esp; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_80052E9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80052E9:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_80052F1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80052F1:
    TS8((uint32_t)(edi + 0xFFFFFFBFu), (uint8_t)(rol8(TL8((uint32_t)(edi + 0xFFFFFFBFu)), (uint8_t)0x35u, &f)));
    edi = M32(esp); esi = M32(esp + 4); ebp = M32(esp + 8); ebx = M32(esp + 16); edx = M32(esp + 20); ecx = M32(esp + 24); eax = M32(esp + 28); esp += 32;
    esp += 4; SPILL(); return;
}

void f_80053A5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80053A5:
    { jt_ = TL32((uint32_t)(ebp + 0x65BB49BEu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x80053A5u: goto L_80053A5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80053C9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80053C9:
    esp += 48977; SPILL(); return;
}

void f_80053D1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80053D1:
    esp += 15569; SPILL(); return;
}

void f_8005451(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005451:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (uint32_t)(inc32(eax, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi ^ TL32((uint32_t)(ebx))), &f));
    esp += 4; SPILL(); return;
}

void f_8005466(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005466:
    esp += 4; SPILL(); return;
}

void f_8005598(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005598:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    { uint32_t t_ = esp; esp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)eax), (uint8_t)0x3u, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFFDFu), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFFDFu)), ((uint8_t)(eax >> 8)), &f)));
    esp += 16416; SPILL(); return;
}

void f_80055A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055A0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFFDFu), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFFDFu)), ((uint8_t)(eax >> 8)), &f)));
    esp += 16416; SPILL(); return;
}

void f_80055C8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055C8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)eax), ((uint8_t)eax), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(sbb8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(ebx + (uint8_t)eax));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x3FD2u), &f));
    TS8((uint32_t)(eax + 0x3FC71192u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC71192u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_80055D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055D0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)eax), ((uint8_t)eax), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(sbb8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(ebx + (uint8_t)eax));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x3FD2u), &f));
    TS8((uint32_t)(eax + 0x3FC71192u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC71192u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_80055D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055D8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(sbb8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(ebx + (uint8_t)eax));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x3FD2u), &f));
    TS8((uint32_t)(eax + 0x3FC71192u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC71192u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_80055E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055E0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFFD7u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFFD7u)), ((uint8_t)(eax >> 8)), &f)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x3FD2u), &f));
    TS8((uint32_t)(eax + 0x3FC71192u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC71192u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_80055E8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055E8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC71192u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC71192u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_80055F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80055F0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFF92u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF92u)), ((uint8_t)(eax >> 8)), &f)));
    TS32((uint32_t)(edi + 0x3Fu), (uint32_t)(adc32(TL32((uint32_t)(edi + 0x3Fu)), esi, &f)));
    TS8((uint32_t)(eax + 0xFFFFFFFAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFFAu)) & ((uint8_t)(eax >> 8))), &f)));
    esp += 4; SPILL(); return;
}

void f_8005608(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005608:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FD025E6u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FD025E6u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)(ebx >> 8))), &f));
    esp += 4; SPILL(); return;
}

void f_8005610(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005610:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)(ebx >> 8))), &f));
    esp += 4; SPILL(); return;
}

void f_8005618(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005618:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xBFC025E6u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xBFC025E6u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)(ebx >> 8))), &f));
    esp += 4; SPILL(); return;
}

void f_8005620(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005620:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)(ebx >> 8))), &f));
    esp += 4; SPILL(); return;
}

void f_8005639(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005639:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(adc8(((uint8_t)(ecx >> 8)), (uint8_t)0xE9u, &f)) << 8);
    esp += 67; SPILL(); return;
}

void f_8005660(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005660:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    fpush(c, (double)MF32((uint32_t)(edi)));
    esp += 4; SPILL(); return;
}

void f_8005668(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005668:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)eax), &f));
    { uint32_t v_ = 0xFFFFFFA5u; esp -= 4; M32(esp) = v_; }
    esp += 67; SPILL(); return;
}

void f_8005690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005690:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(ebx + 0xBFC7u)) * (int32_t)(uint32_t)0x4F670000u; esp = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esp += 195; SPILL(); return;
}

void f_8005698(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005698:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    edi = (uint32_t)(dec32(edi, &f));
    esp += 195; SPILL(); return;
}

void f_80056A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80056A0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(ebx + 0x3FC7u)) * (int32_t)(uint32_t)0x4F670000u; esp = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esp += 67; SPILL(); return;
}

void f_80056A8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80056A8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    edi = (uint32_t)(dec32(edi, &f));
    esp += 67; SPILL(); return;
}

void f_80056B1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80056B1:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edi + 0xFFFFFFF3u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0xFFFFFFF3u)) & ((uint8_t)(ecx >> 8))), &f)));
    SPILL(); rt_int3(c, 0x80056B6u);
    { SPILL(); rt_call(c, 0x80056B7u); return; }
}

void f_80056C1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80056C1:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edi + 0xFFFFFFF3u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0xFFFFFFF3u)) & ((uint8_t)(ecx >> 8))), &f)));
    SPILL(); rt_int3(c, 0x80056C6u);
    { SPILL(); rt_call(c, 0x80056C7u); return; }
}

void f_8005796(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005796:
    esp += 67; SPILL(); return;
}

void f_80057A4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80057A4:
    esp += 4; SPILL(); return;
}

void f_80057D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80057D0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FCC40D1u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FCC40D1u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)eax), &f));
    esp += 46881; SPILL(); return;
}

void f_80057D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80057D8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)eax), &f));
    esp += 46881; SPILL(); return;
}

void f_8005838(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005838:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    ebx = (uint32_t)(dec32(ebx, &f));
    esp += 4; SPILL(); return;
}

void f_8005840(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005840:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    edi = (uint32_t)((uint32_t)0x3FC8EAu);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(shl8(((uint8_t)(eax >> 8)), (uint8_t)0x4Cu, &f)) << 8);
    esp += 4; SPILL(); return;
}

void f_800584F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800584F:
    edi = (uint32_t)((uint32_t)0x20000000u);
    TS8((uint32_t)(ebp + eax*8 + 0x3Fu), (uint8_t)(sub8(TL8((uint32_t)(ebp + eax*8 + 0x3Fu)), ((uint8_t)edx), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(shl8(((uint8_t)(eax >> 8)), (uint8_t)0x4Cu, &f)) << 8);
    esp += 4; SPILL(); return;
}

void f_8005850(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005850:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(ebp + eax*8 + 0x3Fu), (uint8_t)(sub8(TL8((uint32_t)(ebp + eax*8 + 0x3Fu)), ((uint8_t)edx), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(shl8(((uint8_t)(eax >> 8)), (uint8_t)0x4Cu, &f)) << 8);
    esp += 4; SPILL(); return;
}

void f_80058A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80058A0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC4B3DFu), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC4B3DFu)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1);
    TS8((uint32_t)(edi), (uint8_t)(sar8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0xA1u), &f));
    esp += 67; SPILL(); return;
}

void f_80058A8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80058A8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1);
    TS8((uint32_t)(edi), (uint8_t)(sar8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0xA1u), &f));
    esp += 67; SPILL(); return;
}

void f_80058D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80058D8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint8_t t_ = ((uint8_t)edx); edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx)); ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(t_); }
    TS8((uint32_t)(edi + 0xE0000000u), (uint8_t)(sar8(TL8((uint32_t)(edi + 0xE0000000u)), (uint8_t)0x9u, &f)));
    esp += 4; SPILL(); return;
}

void f_8005948(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005948:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F9EB3AEu), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F9EB3AEu)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFFE9u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFFE9u)), ((uint8_t)(eax >> 8)), &f)));
    M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1);
    esp += 67; SPILL(); return;
}

void f_8005950(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005950:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xFFFFFFE9u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFFE9u)), ((uint8_t)(eax >> 8)), &f)));
    M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1);
    esp += 67; SPILL(); return;
}

void f_8005960(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005960:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FBE6D30u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FBE6D30u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    esp -= 4; M16(esp) = ((uint16_t)0x23);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    TS8((uint32_t)(0x3Fu), (uint8_t)(((uint8_t)eax)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x3FC06EA4u)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC0AA50u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC0AA50u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esp += 67; SPILL(); return;
}

void f_8005968(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005968:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    esp -= 4; M16(esp) = ((uint16_t)0x23);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    TS8((uint32_t)(0x3Fu), (uint8_t)(((uint8_t)eax)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x3FC06EA4u)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC0AA50u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC0AA50u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esp += 67; SPILL(); return;
}

void f_8005970(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005970:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC06EA4u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC06EA4u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC0AA50u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC0AA50u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esp += 67; SPILL(); return;
}

void f_8005978(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005978:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FC0AA50u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FC0AA50u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esp += 67; SPILL(); return;
}

void f_8005980(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005980:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    { uint32_t t_ = esi; esi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    esp += 67; SPILL(); return;
}

void f_8005989(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005989:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebx + 0xFFFFFFDBu), (uint8_t)(add8(TL8((uint32_t)(ebx + 0xFFFFFFDBu)), ((uint8_t)ebx), &f)));
    esp += 67; SPILL(); return;
}

void f_8005998(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005998:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    goto L_800599C;
L_800599B:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)(ecx >> 8)), &f));
    goto L_800599D;
L_800599C:
    goto L_800599B;
L_800599D:
    c->df = 1;
    esp += 67; SPILL(); return;
}

void f_8005A09(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005A09:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebp + 0x30u), (uint8_t)(add8(TL8((uint32_t)(ebp + 0x30u)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
}

void f_8005A56(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005A56:
    esp += 4; SPILL(); return;
}

void f_8005AD6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005AD6:
    esp += 67; SPILL(); return;
}

void f_8005B1E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005B1E:
    esp += 4; SPILL(); return;
}

void f_8005B2E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8005B2E:
    esp += 4; SPILL(); return;
}

void f_8006163(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8006163:
    TS8((uint32_t)(edi), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi)) | ((uint8_t)(ecx >> 8))), &f)));
    esp -= 4; M32(esp) = 0x800616Au; SPILL(); rt_call(c, 0x9551696Eu); RELOAD();
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x8u, &f));
    { uint32_t v_ = 0x8908048Du; esp -= 4; M32(esp) = v_; }
    { SPILL(); rt_call(c, 0x8006171u); return; }
}

void f_8006210(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8006210:
    esp += 4; SPILL(); return;
}

void f_8006274(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8006274:
    esp += 1312; SPILL(); return;
}

void f_8006374(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8006374:
    esp += 1312; SPILL(); return;
}

void f_8006422(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8006422:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x8u, &f));
    edx = (edx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(edx >> 8)) ^ M8((uint32_t)(esp + eax + 0x8u))), &f)) << 8);
    esp += 4; SPILL(); return;
}

void f_800745A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800745A:
    { uint32_t t_ = edx; edx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    (void)sub32(eax, (uint32_t)0x3D9C6B70u, &f);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & ((uint8_t)(ebx >> 8))), &f));
    M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4);
    (void)sub32(eax, (uint32_t)0x3DAF451Bu, &f);
    { uint32_t h_ = (eax >> 8) & 0xFF; f.cf = h_ & 1; f.pf = (h_ >> 2) & 1; f.zf = (h_ >> 6) & 1; f.sf = (h_ >> 7) & 1; }
    eax = (uint32_t)((uint32_t)0xC1EB503Du);
    (void)sub32(eax, (uint32_t)0x3DCB2D04u, &f);
    { uint64_t r_ = (uint64_t)eax * TL32((uint32_t)(ebx + 0xFFFFFFD4u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    (void)sub32(eax, (uint32_t)0x3DDD90B9u, &f);
    esp += 59063; SPILL(); return;
}

void f_8007592(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007592:
    esp += 4; SPILL(); return;
}

void f_80076A9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80076A9:
    esp -= 4; M16(esp) = ((uint16_t)0x2B);
    ebx = (ebx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(sub8(((uint8_t)(ebx >> 8)), TL8((uint32_t)(edi)), &f)) << 8);
    TS32((uint32_t)(ebx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx)) ^ ecx), &f)));
    edi = (uint32_t)(sub32(edi, TL32((uint32_t)(edi)), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { jt_ = TL32((uint32_t)(ebx)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x80076A9u: goto L_80076A9; default: SPILL(); rt_call(c, jt_); return; }
}

void f_80076C5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80076C5:
    esp += 16180; SPILL(); return;
}

void f_8007789(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007789:
    esp += 16226; SPILL(); return;
}

void f_80077C1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80077C1:
    esp += 16239; SPILL(); return;
}

void f_8007848(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007848:
    esp = (uint32_t)(TL32((uint32_t)(edx + 0xFFFFFFE9u)));
    (void)sub8(((uint8_t)eax), (uint8_t)0x4Bu, &f);
    { uint32_t t_ = edi; edi = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS32((uint32_t)(0x3D0E9B82u), (uint32_t)(add32(TL32((uint32_t)(0x3D0E9B82u)), edi, &f)));
    TS32((uint32_t)(0xBC3D1BBBu), (uint32_t)(eax));
    f.cf = !f.cf;
    TS8((uint32_t)(0x3D364822u), (uint8_t)(sub8(TL8((uint32_t)(0x3D364822u)), ((uint8_t)(ebx >> 8)), &f)));
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x43u);
    (void)sub32(eax, (uint32_t)0x3D51301Du, &f);
    esp = (uint32_t)(inc32(esp, &f));
    esp += 4; SPILL(); return;
}

void f_800787E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800787E:
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    (void)sub32(eax, (uint32_t)0x3D98D7C7u, &f);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(rcr8(((uint8_t)(eax >> 8)), ((uint8_t)ecx), &f)) << 8);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)sub32(eax, (uint32_t)0x3DA6E914u, &f);
    edi = (uint32_t)(inc32(edi, &f));
    c->df = 0;
    eax = (uint32_t)(M32(esi)); esi += (c->df ? -4 : 4);
    (void)sub32(eax, (uint32_t)0x3DB51635u, &f);
    TS32((uint32_t)(0x623DBC36u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_800789E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800789E:
    esp += 577; SPILL(); return;
}

void f_8007921(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007921:
    esp += 15972; SPILL(); return;
}

void f_800797A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800797A:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(ebp + 0x9F8B933Eu));
    { uint32_t v_ = 0xFFFFFF8Au; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0xA389D23Eu)));
    esp += 4; SPILL(); return;
}

void f_80079C8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80079C8:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), ((uint8_t)edx), &f));
    esp += 4; SPILL(); return;
}

void f_80079CD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80079CD:
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(rol8(((uint8_t)(ecx >> 8)), ((uint8_t)ecx), &f)) << 8);
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    if (!f.cf) ST(0) = ST(7);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0xE4u) << 8);
    esp = ebp; ebp = M32(esp); esp += 4;
    (void)logic32((uint32_t)(esi & ebp), &f);
    esp += 4; SPILL(); return;
}

void f_8007A09(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007A09:
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)(eax >> 8))) << 8);
    TS32((uint32_t)(eax + 0xA8453EE6u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0xA8453EE6u)) & ebx), &f)));
    esp -= 4; M32(esp) = 0x8007A17u; SPILL(); rt_call(c, 0xF2B95255u); RELOAD();
}

void f_8007AC2(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007AC2:
    ebx = (ebx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(ebx >> 8)) & TL8((uint32_t)(edi))), &f)) << 8);
    esp += 9099; SPILL(); return;
}

void f_8007AD5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007AD5:
    esp += 16171; SPILL(); return;
}

void f_8007AE1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007AE1:
    { jt_ = TL32((uint32_t)(edx)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x8007AE1u: goto L_8007AE1; default: SPILL(); rt_call(c, jt_); return; }
}

void f_8007C60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C60:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)(eax >> 8)), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x11u);
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F80337Du), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F80337Du)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F6A1DF3u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F6A1DF3u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8007C68(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C68:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F80337Du), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F80337Du)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F6A1DF3u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F6A1DF3u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8007C70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C70:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F6A1DF3u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F6A1DF3u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8007C78(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C78:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_8007C80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C80:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)eax), &f));
    { uint32_t r_ = (uint8_t)eax * (uint32_t)TL8((uint32_t)(edx + 0x3F79u)); eax = (eax & 0xFFFF0000u) | (uint16_t)(r_); f.cf = f.of = (r_ >> 8) != 0; }
    TS8((uint32_t)(eax + 0x3F72B404u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F72B404u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (uint32_t)(inc32(eax, &f));
    esp += 4; SPILL(); return;
}

void f_8007C88(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C88:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3F72B404u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3F72B404u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (uint32_t)(inc32(eax, &f));
    esp += 4; SPILL(); return;
}

void f_8007C90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C90:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    { uint32_t s_ = esp; esp -= 32; M32(esp + 28) = eax; M32(esp + 24) = ecx; M32(esp + 20) = edx; M32(esp + 16) = ebx; M32(esp + 12) = s_; M32(esp + 8) = ebp; M32(esp + 4) = esi; M32(esp) = edi; }
    eax = (uint32_t)(inc32(eax, &f));
    esp += 4; SPILL(); return;
}

void f_8007C98(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007C98:
    esp += 4; SPILL(); return;
}

void f_8007D81(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007D81:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + ecx)));
    esp += 4; SPILL(); return;
}

void f_8007E31(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007E31:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + ecx)));
    SPILL(); rt_int3(c, 0x8007E34u);
    { SPILL(); rt_call(c, 0x8007E35u); return; }
}

void f_8007E51(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007E51:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + ecx)));
    { uint32_t t_ = TL32((uint32_t)(ebp + 0x5AF7080Cu)); esp -= 4; M32(esp) = 0x8007E5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) | (uint8_t)0x8u), &f));
    { SPILL(); rt_call(c, 0x8007E5Cu); return; }
}

void f_8007F59(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007F59:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + ecx)));
    esp += 3236; SPILL(); return;
}

void f_8007F8C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8007F8C:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x49u), &f));
    esp += 67; SPILL(); return;
}

void f_80080F9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80080F9:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_8008150(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8008150:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_unimpl(c, 0x8008154u, "int");
    esp = (uint32_t)(dec32(esp, &f));
    SPILL(); rt_unimpl(c, 0x8008157u, "int");
    SPILL(); rt_int3(c, 0x800815Au);
    { SPILL(); rt_call(c, 0x800815Bu); return; }
}

void f_8008168(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8008168:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub8(TL8((uint32_t)(edi)), (uint8_t)0xCDu, &f);
    SPILL(); rt_int3(c, 0x800816Du);
    { SPILL(); rt_call(c, 0x800816Eu); return; }
}

void f_8008171(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8008171:
    edx = (uint32_t)((int32_t)eax >> 31);
    TS32((uint32_t)(edi), (uint32_t)(sbb32(TL32((uint32_t)(edi)), edi, &f)));
    SPILL(); rt_unimpl(c, 0x8008174u, "int");
    SPILL(); rt_int3(c, 0x8008176u);
    { SPILL(); rt_call(c, 0x8008177u); return; }
}

void f_80089F4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80089F4:
    esp += 3503; SPILL(); return;
}

void f_8008A9C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8008A9C:
    esp += 3564; SPILL(); return;
}

void f_8009743(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8009743:
    TS8((uint32_t)(ecx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ecx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(edx >> 8)), &f));
    { uint32_t t_ = ebp; ebp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp -= 4; M32(esp) = 0x800975Du; SPILL(); rt_call(c, 0xA0897F2u); RELOAD();
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)(eax >> 8)), &f));
    { uint32_t t_ = ebp; ebp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    fcompare(c, ST(0), (double)MF32((uint32_t)(ebp + 0x10800u)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x8009778u);
    { SPILL(); rt_call(c, 0x8009779u); return; }
}

void f_8009893(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8009893:
    TS8((uint32_t)(ecx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ecx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)edx), &f));
    { uint32_t t_ = esp; esp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x80098A0u);
    { SPILL(); rt_call(c, 0x80098A1u); return; }
}

void f_800A08C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800A08C:
    esp += 4; SPILL(); return;
}

void f_800A0D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800A0D8:
    esp += 3681; SPILL(); return;
}

void f_800AC98(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800AC98:
    fcompare(c, ST(0), (double)MF32((uint32_t)(ebp + 0x10800u)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800ACA0u);
    { SPILL(); rt_call(c, 0x800ACA1u); return; }
}

void f_800ADBB(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800ADBB:
    TS8((uint32_t)(ecx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ecx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)edx), &f));
    { uint32_t t_ = esp; esp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800ADC8u);
    { SPILL(); rt_call(c, 0x800ADC9u); return; }
}

void f_800BAD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800BAD0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800BAF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800BAF0:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800BB10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800BB10:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800BB20u);
    { SPILL(); rt_call(c, 0x800BB21u); return; }
}

void f_800BD87(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800BD87:
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(eax >> 8)) | ((uint8_t)(edx >> 8))), &f)) << 8);
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(ebx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(esi + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(esi + 0x10000u)), ((uint8_t)ebx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(add8(((uint8_t)(eax >> 8)), ((uint8_t)(eax >> 8)), &f)) << 8);
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(ebx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edi + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(edi + 0x10000u)), ((uint8_t)ebx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(add8(((uint8_t)(eax >> 8)), ((uint8_t)edx), &f)) << 8);
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(ebx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x10000u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + ebp*4 + 0x800u), (uint8_t)(add8(TL8((uint32_t)(eax + ebp*4 + 0x800u)), ((uint8_t)(ebx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx + 0x60010000u), (uint8_t)(add8(TL8((uint32_t)(ecx + 0x60010000u)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(esi)); esi += (c->df ? -1 : 1);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(esi)); esi += (c->df ? -1 : 1);
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(eax), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax)) | ((uint8_t)eax)), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(edx >> 8)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edx + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(edx + 0x10000u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + ebp*4 + 0x800u), (uint8_t)(add8(TL8((uint32_t)(eax + ebp*4 + 0x800u)), ((uint8_t)ebx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebx + 0x60010000u), (uint8_t)(add8(TL8((uint32_t)(ebx + 0x60010000u)), ((uint8_t)(eax >> 8)), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax + 0x800u), (uint8_t)(((uint8_t)(ecx >> 8))));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebp + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(ebp + 0x10000u)), ((uint8_t)(eax >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + ebp*4), (uint8_t)(add8(TL8((uint32_t)(eax + ebp*4)), ((uint8_t)(ecx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax)) | ((uint8_t)eax)), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(edx >> 8)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edi + 0x60010000u), (uint8_t)(add8(TL8((uint32_t)(edi + 0x60010000u)), ((uint8_t)(eax >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(esi)); esi += (c->df ? -1 : 1);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(eax), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax)) | ((uint8_t)eax)), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(edx >> 8)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x10010000u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x10010000u)), ((uint8_t)(ecx >> 8)), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    esp = (uint32_t)(dec32(esp, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x0u), &f);
    TS8((uint32_t)(ebx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edx + 0x10000u), (uint8_t)(add8(TL8((uint32_t)(edx + 0x10000u)), ((uint8_t)(ecx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + ebp*4), (uint8_t)(add8(TL8((uint32_t)(eax + ebp*4)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax)) | ((uint8_t)eax)), &f)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(edx >> 8)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebx + 0xE8010000u), (uint8_t)(add8(TL8((uint32_t)(ebx + 0xE8010000u)), ((uint8_t)(ecx >> 8)), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) ^ (uint8_t)0xA8u), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + eax + 0xAF380100u), (uint8_t)(add8(TL8((uint32_t)(eax + eax + 0xAF380100u)), ((uint8_t)(ecx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xA8u), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebp + 0x38010000u), (uint8_t)(add8(TL8((uint32_t)(ebp + 0x38010000u)), ((uint8_t)(ecx >> 8)), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax + 0x800u), (uint8_t)(adc8(TL8((uint32_t)(eax + 0x800u)), ((uint8_t)(ecx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(esi + 0x60010000u), (uint8_t)(add8(TL8((uint32_t)(esi + 0x60010000u)), ((uint8_t)(ecx >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(esi)); esi += (c->df ? -1 : 1);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    c->df = 0;
    (void)sub32(M32(esi), M32(edi), &f); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    (void)sub32((uint32_t)eax, M32(edi), &f); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(add8(((uint8_t)(eax >> 8)), ((uint8_t)(eax >> 8)), &f)) << 8);
    (void)sub32(M32(esi), M32(edi), &f); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x60010000u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x60010000u)), ((uint8_t)(edx >> 8)), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8(esi)); esi += (c->df ? -1 : 1);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    SPILL(); rt_int3(c, 0x800BF88u);
    { SPILL(); rt_call(c, 0x800BF89u); return; }
}

void f_800CB1E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CB1E:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) | eax), &f)));
    TS8((uint32_t)(ebx), (uint8_t)(add8(TL8((uint32_t)(ebx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800CB28u);
    { SPILL(); rt_call(c, 0x800CB29u); return; }
}

void f_800CD77(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CD77:
    TS8((uint32_t)(ebp + 0xFFFFFFDEu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFFDEu)) | ((uint8_t)(ecx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800CD7Au, "invd");
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M64((uint32_t)(edi)) = (uint64_t)fistt64(ST(0)); fpop(c);
    TS8((uint32_t)(ebx + esi*8), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx + esi*8)) | ((uint8_t)ecx)), &f)));
    esp -= 4; M16(esp) = ((uint16_t)0x23);
    TS8((uint32_t)(ebp + 0x51080FA1u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebp + 0x51080FA1u)) | ((uint8_t)ebx)), &f)));
    esp += 4; SPILL(); return;
}

void f_800CDA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CDA0:
    (void)sub32(TL32((uint32_t)(esi + 0xFu)), ebp, &f);
    TS8((uint32_t)(ebp + 0xFFFFFFCAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFFCAu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800CDA6u, "invd");
    edx = (uint32_t)((int32_t)eax >> 31);
    esp += 2067; SPILL(); return;
}

void f_800CDAC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CDAC:
    c->df = 0;
    ST(0) = ST(0) * MF64((uint32_t)(edi));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) | ((uint8_t)eax)), &f));
    esp += 2067; SPILL(); return;
}

void f_800CE30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CE30:
    fcompare(c, ST(0), (double)MF32((uint32_t)(ebp + 0x10800u)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800CE38u);
    { SPILL(); rt_call(c, 0x800CE39u); return; }
}

void f_800CF53(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800CF53:
    TS8((uint32_t)(ecx), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ecx)) | ((uint8_t)eax)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)edx), &f));
    { uint32_t t_ = esp; esp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800CF60u);
    { SPILL(); rt_call(c, 0x800CF61u); return; }
}

void f_800DC68(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800DC68:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800DC88(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800DC88:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800DCA8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800DCA8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800DCB8u);
    { SPILL(); rt_call(c, 0x800DCB9u); return; }
}

void f_800E11E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800E11E:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    SPILL(); rt_int3(c, 0x800E120u);
    { SPILL(); rt_call(c, 0x800E121u); return; }
}

void f_800E328(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800E328:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800E33E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800E33E:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xA6u), &f);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(eax)), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 4; SPILL(); return;
}

void f_800ECB6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800ECB6:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) | eax), &f)));
    TS8((uint32_t)(ebx), (uint8_t)(add8(TL8((uint32_t)(ebx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800ECC0u);
    { SPILL(); rt_call(c, 0x800ECC1u); return; }
}

void f_800EF58(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800EF58:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), eax, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) | eax), &f)));
    TS8((uint32_t)(ebx), (uint8_t)(add8(TL8((uint32_t)(ebx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0x800EF70u);
    { SPILL(); rt_call(c, 0x800EF71u); return; }
}

void f_800F056(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F056:
    SPILL(); rt_unimpl(c, 0x800F056u, "invd");
    (void)sub32(TL32((uint32_t)(esi + 0xFu)), ebp, &f);
    TS8((uint32_t)(esi + 0xFFFFFFCAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0xFFFFFFCAu)) | ((uint8_t)ecx)), &f)));
    SPILL(); rt_unimpl(c, 0x800F05Eu, "invd");
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F064(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F064:
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F06F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F06F:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F072u, "invd");
    TS32((uint32_t)(0x70080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F07C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F07C:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 2067; SPILL(); return;
}

void f_800F09B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F09B:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F09Eu, "invd");
    TS32((uint32_t)(0x5B080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F0B9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0B9:
    esp += 2067; SPILL(); return;
}

void f_800F0BD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0BD:
    esp += 2067; SPILL(); return;
}

void f_800F0DD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0DD:
    esp += 2067; SPILL(); return;
}

void f_800F0E1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0E1:
    esp += 2067; SPILL(); return;
}

void f_800F0EE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0EE:
    SPILL(); rt_unimpl(c, 0x800F0EEu, "invd");
    TS32((uint32_t)(0x4E080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F0F8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0F8:
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F0FD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F0FD:
    esp += 2067; SPILL(); return;
}

void f_800F13B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F13B:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F13Eu, "invd");
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F159(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F159:
    esp += 2067; SPILL(); return;
}

void f_800F161(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F161:
    esp += 2067; SPILL(); return;
}

void f_800F195(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F195:
    esp += 2067; SPILL(); return;
}

void f_800F199(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F199:
    esp += 2067; SPILL(); return;
}

void f_800F19F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F19F:
    TS8((uint32_t)(esi + 0x63080F6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0x63080F6Eu)) | ((uint8_t)edx)), &f)));
    esp += 2067; SPILL(); return;
}

void f_800F1C7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F1C7:
    TS8((uint32_t)(eax + 0x70080F6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x70080F6Eu)) | ((uint8_t)(edx >> 8))), &f)));
    esp += 2067; SPILL(); return;
}

void f_800F1D5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F1D5:
    esp += 2067; SPILL(); return;
}

void f_800F1DD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F1DD:
    esp += 2067; SPILL(); return;
}

void f_800F203(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F203:
    TS8((uint32_t)(eax + 0x70080F6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x70080F6Eu)) | ((uint8_t)(edx >> 8))), &f)));
    esp += 2067; SPILL(); return;
}

void f_800F211(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F211:
    esp += 2067; SPILL(); return;
}

void f_800F219(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F219:
    esp += 2067; SPILL(); return;
}

void f_800F21D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F21D:
    esp += 2067; SPILL(); return;
}

void f_800F221(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F221:
    esp += 2067; SPILL(); return;
}

void f_800F236(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F236:
    SPILL(); rt_unimpl(c, 0x800F236u, "invd");
    (void)sub32(TL32((uint32_t)(esi + 0xFu)), ebp, &f);
    TS8((uint32_t)(esi + 0xFFFFFFCAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0xFFFFFFCAu)) | ((uint8_t)ecx)), &f)));
    SPILL(); rt_unimpl(c, 0x800F23Eu, "invd");
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F244(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F244:
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F24F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F24F:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F252u, "invd");
    TS32((uint32_t)(0x70080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F25C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F25C:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 2067; SPILL(); return;
}

void f_800F27B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F27B:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F27Eu, "invd");
    TS32((uint32_t)(0x5B080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F299(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F299:
    esp += 2067; SPILL(); return;
}

void f_800F29D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F29D:
    esp += 2067; SPILL(); return;
}

void f_800F2BD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2BD:
    esp += 2067; SPILL(); return;
}

void f_800F2C1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2C1:
    esp += 2067; SPILL(); return;
}

void f_800F2CE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2CE:
    SPILL(); rt_unimpl(c, 0x800F2CEu, "invd");
    TS32((uint32_t)(0x4E080F6Eu), (uint32_t)(eax));
    esp += 2067; SPILL(); return;
}

void f_800F2D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2D8:
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F2DD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2DD:
    esp += 2067; SPILL(); return;
}

void f_800F2FA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F2FA:
    SPILL(); rt_unimpl(c, 0x800F2FAu, "invd");
    SPILL(); rt_int3(c, 0x800F2FCu);
    { SPILL(); rt_call(c, 0x800F2FDu); return; }
}

void f_800F31B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F31B:
    TS8((uint32_t)(edi + 0x6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(edi + 0x6Eu)) | ((uint8_t)(ebx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F31Eu, "invd");
    esi = (uint32_t)(dec32(esi, &f));
    esp += 2067; SPILL(); return;
}

void f_800F339(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F339:
    esp += 2067; SPILL(); return;
}

void f_800F341(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F341:
    esp += 2067; SPILL(); return;
}

void f_800F375(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F375:
    esp += 2067; SPILL(); return;
}

void f_800F379(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F379:
    esp += 2067; SPILL(); return;
}

void f_800F37F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F37F:
    TS8((uint32_t)(esi + 0x63080F6Eu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0x63080F6Eu)) | ((uint8_t)edx)), &f)));
    esp += 2067; SPILL(); return;
}

void f_800F3AB(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F3AB:
    TS8((uint32_t)(eax + 0xFFFFFFCAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFCAu)) | ((uint8_t)(edx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F3AEu, "invd");
    eax = (uint32_t)(sub32(eax, (uint32_t)0x70080FC7u, &f));
    esp += 2067; SPILL(); return;
}

void f_800F3BD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F3BD:
    esp += 2067; SPILL(); return;
}

void f_800F3E9(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F3E9:
    esp += 2067; SPILL(); return;
}

void f_800F3EF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F3EF:
    TS8((uint32_t)(eax + 0xFFFFFFCAu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0xFFFFFFCAu)) | ((uint8_t)(edx >> 8))), &f)));
    SPILL(); rt_unimpl(c, 0x800F3F2u, "invd");
    ecx = (uint32_t)((uint32_t)0x70080FC7u);
    esp += 2067; SPILL(); return;
}

void f_800F3FD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F3FD:
    esp += 2067; SPILL(); return;
}

void f_800F401(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F401:
    esp += 2067; SPILL(); return;
}

void f_800F5F5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F5F5:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebx), (uint8_t)(add8(TL8((uint32_t)(ebx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)edx), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(add8(((uint8_t)(ecx >> 8)), ((uint8_t)ecx), &f)) << 8);
    SPILL(); rt_int3(c, 0x800F621u);
    { SPILL(); rt_call(c, 0x800F622u); return; }
}

void f_800F628(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F628:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), ((uint8_t)eax), &f));
    SPILL(); rt_int3(c, 0x800F62Cu);
    { SPILL(); rt_call(c, 0x800F62Du); return; }
}

void f_800F6EE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F6EE:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    ebx = (ebx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0x25u) << 8);
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
}

void f_800F728(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F728;
L_800F6BA:
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(adc8(((uint8_t)(eax >> 8)), TL8((uint32_t)(edx)), &f)) << 8);
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    esp += 4; SPILL(); return;
L_800F728:
    goto L_800F6BA;
}

void f_800F7A7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F7A7:
    TS8((uint32_t)(esi + 0xA308106Cu), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0xA308106Cu)) | ((uint8_t)(eax >> 8))), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x6E390810u)));
    SPILL(); rt_unimpl(c, 0x800F7B2u, "invd");
    esp += 4260; SPILL(); return;
}

void f_800F7D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F7D0:
    esp += 4; SPILL(); return;
}

void f_800F8A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F8A0:
    M32((uint32_t)(edi)) = (uint32_t)fistt32(ST(0)); fpop(c);
    ecx = (uint32_t)(dec32(ecx, &f));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(ror8(((uint8_t)(ecx >> 8)), (uint8_t)0xCCu, &f)) << 8);
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
}

void f_800F8A4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800F8A4:
    SPILL(); rt_unimpl(c, 0x800F8A4u, "int");
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
}

void f_800F8D8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F8D8;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F8D8:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) | TL8((uint32_t)(eax))), &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x6C253A64u), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)eax), (uint8_t)0x0u, &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FE99999u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FE99999u)), ((uint8_t)(eax >> 8)), &f)));
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    edi = (uint32_t)((uint32_t)0xD2081191u);
    TS32((uint32_t)(0x66400811u), (uint32_t)(eax));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F8DC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F8DC;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F8DC:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x6C253A64u), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)eax), (uint8_t)0x0u, &f));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FE99999u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FE99999u)), ((uint8_t)(eax >> 8)), &f)));
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    edi = (uint32_t)((uint32_t)0xD2081191u);
    TS32((uint32_t)(0x66400811u), (uint32_t)(eax));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F8E8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F8E8;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F8E8:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0x3FE99999u), (uint8_t)(add8(TL8((uint32_t)(eax + 0x3FE99999u)), ((uint8_t)(eax >> 8)), &f)));
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    edi = (uint32_t)((uint32_t)0xD2081191u);
    TS32((uint32_t)(0x66400811u), (uint32_t)(eax));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F8F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F8F0;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F8F0:
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    { uint32_t t_ = ecx; ecx = (uint32_t)(eax); eax = (uint32_t)(t_); }
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    edi = (uint32_t)((uint32_t)0xD2081191u);
    TS32((uint32_t)(0x66400811u), (uint32_t)(eax));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F8F8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F8F8;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F8F8:
    TS8((uint32_t)(ebx + 0x66400811u), (uint8_t)(shl8(TL8((uint32_t)(ebx + 0x66400811u)), ((uint8_t)ecx), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F900(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F900;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F900:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x9Du), &f);
    TS32((uint32_t)(eax), (uint32_t)(adc32(TL32((uint32_t)(eax)), ecx, &f)));
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax + 0x95DC0811u)) * (int32_t)(uint32_t)0x11u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS8((uint32_t)(eax + 0x66u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + 0x66u)) | ((uint8_t)eax)), &f)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sbb8(((uint8_t)ecx), TL8((uint32_t)(eax)), &f));
    esp = (uint32_t)(inc32(esp, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(eax), (uint8_t)(adc8(TL8((uint32_t)(eax)), ((uint8_t)ecx), &f)));
    goto L_800F8A6;
}

void f_800F914(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_800F914;
L_800F8A6:
    SPILL(); rt_int3(c, 0x800F8A6u);
    { SPILL(); rt_call(c, 0x800F8A7u); return; }
L_800F914:
    goto L_800F8A6;
}

void f_800FC8D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800FC8D:
    { jt_ = TL32((uint32_t)(ecx)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x800FC8Du: goto L_800FC8D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_800FFA5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_800FFA5:
    { jt_ = TL32((uint32_t)(ecx)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x800FFA5u: goto L_800FFA5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_801094D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_801094D:
    { jt_ = TL32((uint32_t)(eax)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x801094Du: goto L_801094D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_801109A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_801109A:
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    SPILL(); rt_int3(c, 0x801109Cu);
    { SPILL(); rt_call(c, 0x801109Du); return; }
}

void f_801126C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_801126C:
    esp += 4; SPILL(); return;
}

void f_80112E6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80112E6:
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    fcompare(c, ST(0), (double)MF32((uint32_t)(ebx + 0x13u)));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(ecx >> 8)) | ((uint8_t)(eax >> 8))), &f)) << 8);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    esp += 4954; SPILL(); return;
}

void f_801133B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_801133B:
    TS8((uint32_t)(esi + 0x55u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(esi + 0x55u)) | ((uint8_t)(ecx >> 8))), &f)));
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0x13u) << 8);
    TS8((uint32_t)(ebx + 0xD9081356u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx + 0xD9081356u)) | ((uint8_t)(eax >> 8))), &f)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    esp += 4954; SPILL(); return;
}

void f_8011392(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8011392:
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & TL32((uint32_t)(ecx + 0x13u))), &f));
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(ecx >> 8)) | ((uint8_t)(eax >> 8))), &f)) << 8);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(adc32(ecx, TL32((uint32_t)(eax)), &f));
    esp += 4954; SPILL(); return;
}

void f_80113AF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_80113AF:
    TS8((uint32_t)(ebx + 0x4E081359u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(ebx + 0x4E081359u)) | ((uint8_t)ecx)), &f)));
    esp += 2067; SPILL(); return;
}

void f_8012A53(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8012A53:
    TS8((uint32_t)(0x24F00801u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(0x24F00801u)) | ((uint8_t)eax)), &f)));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    SPILL(); rt_int3(c, 0x8012A5Cu);
    { SPILL(); rt_call(c, 0x8012A5Du); return; }
}

void f_8012B62(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8012B62:
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    fcompare(c, ST(0), MF64((uint32_t)(edx))); fpop(c);
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), ecx, &f)));
    SPILL(); rt_int3(c, 0x8012B68u);
    { SPILL(); rt_call(c, 0x8012B69u); return; }
}

void f_8012E5D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_8012E5D:
    edx = (uint32_t)((uint32_t)0xC5C4C3C2u);
    ebx = (ebx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((uint8_t)0xC8u) << 8);
    esp = ebp; ebp = M32(esp); esp += 4;
    esp += 54230; SPILL(); return;
}

