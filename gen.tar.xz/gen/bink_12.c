#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9014510(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014510:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90145B1;
    goto L_9014523;
L_9014523:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    (void)sub32(ebx, (uint32_t)0x7FFFu, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    if ((f.zf || f.sf != f.of)) goto L_9014541;
    goto L_9014539;
L_9014539:
    ebx = (uint32_t)((uint32_t)0x7FFFu);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
L_9014541:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x44u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901454Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(edi, (uint32_t)0x10000u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9014557;
    goto L_9014552;
L_9014552:
    edi = (uint32_t)((uint32_t)0x10000u);
L_9014557:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)((uint32_t)(edi + 0xFFFF8000u));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x2710u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7FFFu), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0xFu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x40u)));
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x901457Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(ebx & ebx), &f);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    if (f.zf) goto L_90145A1;
    goto L_9014580;
L_9014580:
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ST(0) = ST(0) * (double)MF32((uint32_t)(0x9031328u));
    fpush(c, 0.301029995663981195214);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(1) = ST(1) * log2(ST(0)); fpop(c);
    ST(0) = ST(0) * (double)MF32((uint32_t)(0x9031334u));
    esp -= 4; M32(esp) = 0x901459Au; SPILL(); f_9001EA0(c); RELOAD();
    (void)sub32(eax, (uint32_t)0xFFFFD8F0u, &f);
    if ((f.sf == f.of)) goto L_90145A6;
    goto L_90145A1;
L_90145A1:
    eax = (uint32_t)((uint32_t)0xFFFFD8F0u);
L_90145A6:
    esi = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x3Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90145B1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90145B1:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90145C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90145C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(esi + 0x60u));
    ebx = (uint32_t)((uint32_t)(esi + 0x5Cu));
    TS32((uint32_t)(edi), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x0u));
L_90145D7:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x2Cu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x64u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x68u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90145F5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, (uint32_t)0x88780096u, &f);
    if (!f.zf) goto L_9014610;
    goto L_90145FC;
L_90145FC:
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x9014604u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x50u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901460Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_90145D7;
L_9014610:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9014620(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014620:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901462Fu; SPILL(); f_90145C0(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x10u, &f));
    edi = (uint32_t)(neg32(edi, &f));
    edi = (uint32_t)(sbb32(edi, edi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x80808080u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901464Du; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9014665;
    goto L_9014657;
L_9014657:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014662u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9014665:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901467Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9014690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014690:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014698u; SPILL(); f_90159C0(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(0x90310B4u)));
    ebx = (uint32_t)(eax);
L_90146A0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90146B0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, (uint32_t)0x88780096u, &f);
    if (!f.zf) goto L_90146D1;
    goto L_90146B7;
L_90146B7:
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x90146BBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x50u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90146C5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp -= 4; M32(esp) = 0x90146CAu; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, ebx, &f));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if ((f.cf || f.zf)) goto L_90146A0;
    goto L_90146D1;
L_90146D1:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x24u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90146E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90146E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90146EDu; SPILL(); f_90159C0(c); RELOAD();
    ebx = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
L_90146F1:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x10u)));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901470Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x901471Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901472Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    (void)sub32(ecx, (uint32_t)0x400u, &f);
    if (!f.cf) goto L_901474D;
    goto L_901473D;
L_901473D:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    (void)sub32(edx, (uint32_t)0x400u, &f);
    if (f.cf) goto L_901476F;
    goto L_901474D;
L_901474D:
    esp -= 4; M32(esp) = 0x9014752u; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, ebx, &f));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if ((f.cf || f.zf)) goto L_90146F1;
    goto L_9014759;
L_9014759:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901476F:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(edx), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9014780(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014780:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edi + 0x7Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014967;
    goto L_9014799;
L_9014799:
    (void)sub32(TL32((uint32_t)(edi + 0x34u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014967;
    goto L_90147A3;
L_90147A3:
    (void)sub32(TL32((uint32_t)(edi + 0x78u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014959;
    goto L_90147AD;
L_90147AD:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8Cu)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0x90u)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x90147C6u; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(edi + 0x98u)), &f));
    (void)sub32(eax, (uint32_t)0xCu, &f);
    if ((!f.cf && !f.zf)) goto L_9014887;
    goto L_90147D5;
L_90147D5:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x80u)));
    ecx = (uint32_t)(edx);
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_90147E4;
    goto L_90147E1;
L_90147E1:
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(edi + 0x5Cu)), &f));
L_90147E4:
    eax = (uint32_t)(esi);
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_90147EF;
    goto L_90147EA;
L_90147EA:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    eax = (uint32_t)(add32(eax, esi, &f));
L_90147EF:
    (void)sub32(ecx, ebx, &f);
    if ((f.cf || f.zf)) goto L_90147FF;
    goto L_90147F3;
L_90147F3:
    (void)sub32(ecx, eax, &f);
    if (!f.cf) goto L_90147FF;
    goto L_90147F7;
L_90147F7:
    TS32((uint32_t)(edi + 0x80u), (uint32_t)(esi));
    goto L_9014849;
L_90147FF:
    (void)sub32(ebx, edx, &f);
    if (!f.cf) goto L_901480C;
    goto L_9014803;
L_9014803:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    eax = (uint32_t)(add32(eax, ebx, &f));
    goto L_9014810;
L_901480C:
    ebx = (uint32_t)(sub32(ebx, edx, &f));
    eax = (uint32_t)(ebx);
L_9014810:
    (void)sub32(eax, (uint32_t)0x400u, &f);
    if (!f.cf) goto L_901481B;
    goto L_9014817;
L_9014817:
    eax = (uint32_t)(logic32(0, &f));
    goto L_9014823;
L_901481B:
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFC00u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
L_9014823:
    (void)sub32(eax, TL32((uint32_t)(edi + 0x60u)), &f);
    if (!f.cf) goto L_901483D;
    goto L_9014828;
L_9014828:
    (void)sub32(TL32((uint32_t)(edi + 0x84u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014967;
    goto L_9014835;
L_9014835:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9014967;
    goto L_901483D;
L_901483D:
    (void)sub32(eax, TL32((uint32_t)(edi + 0x94u)), &f);
    if (f.cf) goto L_9014953;
    goto L_9014849;
L_9014849:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x60u)));
    ecx = (uint32_t)((uint32_t)(edi + 0x58u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x80u)));
    eax = (uint32_t)(add32(eax, eax, &f));
    TS32((uint32_t)(edi + 0x50u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x9014864u; SPILL(); f_9014620(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x60u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(edi + 0x80u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x80u)), edx, &f)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x80u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_9014887;
    goto L_901487F;
L_901487F:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(edi + 0x80u), (uint32_t)(eax));
L_9014887:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x58u)));
    eax = (uint32_t)((uint32_t)(esp + 0xCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x14u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014899u; SPILL(); f_90146E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    esp -= 4; M32(esp) = 0x90148A1u; SPILL(); f_90159C0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x8Cu)));
    (void)sub32(eax, edx, &f);
    if ((!f.cf && !f.zf)) goto L_90148B9;
    goto L_90148B3;
L_90148B3:
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    goto L_90148C0;
L_90148B9:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
L_90148C0:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x90u)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    (void)sub32(edx, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_90148D4;
    goto L_90148CE;
L_90148CE:
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(sub32(eax, edx, &f));
    goto L_90148DB;
L_90148D4:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    eax = (uint32_t)(add32(eax, ebx, &f));
L_90148DB:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(logic32((uint32_t)(eax ^ edx), &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    (void)sub32(eax, edx, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9014967;
    goto L_90148ED;
L_90148ED:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    TS32((uint32_t)(edi + 0x8Cu), (uint32_t)(eax));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(edi + 0x98u)), &f));
    TS32((uint32_t)(edi + 0x90u), (uint32_t)(ebx));
    (void)sub32(eax, TL32((uint32_t)(edi + 0x9Cu)), &f);
    if (f.cf) goto L_901492C;
    goto L_9014911;
L_9014911:
    eax = (uint32_t)((uint32_t)(edi + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    ecx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(edi + 0x98u), (uint32_t)(edx));
    esp -= 4; M32(esp) = 0x9014924u; SPILL(); f_9014620(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_9014849;
L_901492C:
    (void)sub32(TL32((uint32_t)(edi + 0xA4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014944;
    goto L_9014935;
L_9014935:
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9014944;
    goto L_9014939;
L_9014939:
    esi = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9014940u; SPILL(); f_90143F0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
L_9014944:
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(edi + 0x98u), (uint32_t)(edx));
    goto L_90147D5;
L_9014953:
    TS32((uint32_t)(edi + 0x84u), (uint32_t)(eax));
L_9014959:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9014967:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9014980(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014980:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x84u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x80u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x58u));
    esp -= 4; M32(esp) = 0x901499Eu; SPILL(); f_90145C0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xB8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xB4u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    (void)sub32(TL32((uint32_t)(edi + 0xB8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90149D4;
    goto L_90149C0;
L_90149C0:
    (void)sub32(TL32((uint32_t)(edi + 0xB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90149D4;
    goto L_90149C9;
L_90149C9:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_90149D4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_90149E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90149E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebx);
    TS32((uint32_t)(esi + 0x20u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x9014A00u; SPILL(); f_9014690(c); RELOAD();
    esp -= 4; M32(esp) = 0x9014A05u; SPILL(); f_90159C0(c); RELOAD();
    edx = (uint32_t)((uint32_t)(esp + 0x1Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(eax));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(esp + 0x14u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014A20u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
    edi = (uint32_t)((uint32_t)(esi + 0x38u));
L_9014A27:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)((uint32_t)(esi + 0x34u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(edi), (uint32_t)((uint32_t)0x0u));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014A3Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    (void)sub32(ecx, M32((uint32_t)(esp + 0x10u)), &f);
    if (f.zf) goto L_9014A4E;
    goto L_9014A44;
L_9014A44:
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x1u);
    goto L_9014A93;
L_9014A4E:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014A93;
    goto L_9014A55;
L_9014A55:
    esp -= 4; M32(esp) = 0x9014A5Au; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x18u)), &f));
    (void)sub32(eax, (uint32_t)0x32u, &f);
    if ((f.cf || f.zf)) goto L_9014A93;
    goto L_9014A63;
L_9014A63:
    esp -= 4; M32(esp) = 0x9014A68u; SPILL(); f_9014690(c); RELOAD();
    esp -= 4; M32(esp) = 0x9014A6Du; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(esp + 0x1Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    ecx = (uint32_t)((uint32_t)(esp + 0x14u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014A85u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, (uint32_t)0x2u, &f);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x0u);
    if ((f.sf == f.of)) goto L_9014A9A;
    goto L_9014A93;
L_9014A93:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    (void)sub32(eax, TL32((uint32_t)(esi + 0x8u)), &f);
    if ((!f.cf && !f.zf)) goto L_9014A27;
    goto L_9014A9A;
L_9014A9A:
    esp -= 4; M32(esp) = 0x9014A9Fu; SPILL(); f_90159C0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9014AB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014AB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x80u)), edx, &f)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x80u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_9014AD6;
    goto L_9014ACE;
L_9014ACE:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
L_9014AD6:
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(sub32(TL32((uint32_t)(esi + 0x84u)), edx, &f)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xBCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edi = (uint32_t)((uint32_t)(esi + 0x58u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x68u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x60u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x4Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014AFDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(TL32((uint32_t)(esi + 0x78u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(esi + 0xB8u), (uint32_t)((uint32_t)0x0u));
    if (!f.zf) goto L_9014B23;
    goto L_9014B0D;
L_9014B0D:
    (void)sub32(TL32((uint32_t)(esi + 0x84u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014B23;
    goto L_9014B16;
L_9014B16:
    (void)sub32(TL32((uint32_t)(esi + 0x7Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014B23;
    goto L_9014B1C;
L_9014B1C:
    eax = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9014B23u; SPILL(); f_90149E0(c); RELOAD();
L_9014B23:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014B30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014B30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x7FFFu, &f);
    if ((f.zf || f.sf != f.of)) goto L_9014B42;
    goto L_9014B3D;
L_9014B3D:
    eax = (uint32_t)((uint32_t)0x7FFFu);
L_9014B42:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx + 0x70u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx + 0x58u));
    esp -= 4; M32(esp) = 0x9014B50u; SPILL(); f_9014510(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014B60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014B60:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x10000u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9014B72;
    goto L_9014B6D;
L_9014B6D:
    eax = (uint32_t)((uint32_t)0x10000u);
L_9014B72:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx + 0x58u));
    esp -= 4; M32(esp) = 0x9014B80u; SPILL(); f_9014510(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014B90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014B90:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    if (f.zf) goto L_9014BDA;
    goto L_9014B9B;
L_9014B9B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(eax + 0x34u)), ebx, &f);
    if (!f.zf) goto L_9014BD2;
    goto L_9014BA3;
L_9014BA3:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x88u)));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(eax + 0x80u), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x84u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xA8u), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0xACu), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
L_9014BD2:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014BDA:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edi + 0x34u)), ebx, &f);
    if (f.zf) goto L_9014C31;
    goto L_9014BE3;
L_9014BE3:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x58u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x48u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014BF2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf != f.of)) goto L_9014C0C;
    goto L_9014BF6;
L_9014BF6:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)((uint32_t)(ebp + 0x8u));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x24u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014C07u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), ebx, &f);
    if (!f.zf) goto L_9014BF6;
    goto L_9014C0C;
L_9014C0C:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x34u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014C17u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x5Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9014C22u; SPILL(); f_9014620(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(edi + 0x34u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014C31:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014C40(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014C40:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_9014C72;
    goto L_9014C4B;
L_9014C4B:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x78u)), (uint32_t)0x0u, &f);
    edi = (uint32_t)((uint32_t)0x1u);
    if (f.zf) goto L_9014C67;
    goto L_9014C59;
L_9014C59:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x48u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014C64u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(edi));
L_9014C67:
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(edi));
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014C72:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edi + 0x78u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(edi + 0xA8u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(edi + 0xACu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(edi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    if (!f.zf) goto L_9014CB7;
    goto L_9014C96;
L_9014C96:
    (void)sub32(TL32((uint32_t)(edi + 0x84u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014CCA;
    goto L_9014C9F;
L_9014C9F:
    eax = (uint32_t)((uint32_t)(edi + 0x58u));
    esp -= 4; M32(esp) = 0x9014CA7u; SPILL(); f_90149E0(c); RELOAD();
    TS32((uint32_t)(edi + 0x7Cu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x7Cu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014CB7:
    esi = (uint32_t)((uint32_t)(edi + 0x58u));
    esp -= 4; M32(esp) = 0x9014CBFu; SPILL(); f_9014690(c); RELOAD();
    esp -= 4; M32(esp) = 0x9014CC4u; SPILL(); f_90159C0(c); RELOAD();
    TS32((uint32_t)(edi + 0x98u), (uint32_t)(eax));
L_9014CCA:
    TS32((uint32_t)(edi + 0x7Cu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x7Cu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014CE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014CE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    eax = (uint32_t)(TL32((uint32_t)(0x903FDD8u)));
    eax = (uint32_t)(inc32(eax, &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x64u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FDD8u), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9014DA7;
    goto L_9014CFE;
L_9014CFE:
    (void)sub32(TL32((uint32_t)(0x903FDBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014D5E;
    goto L_9014D07;
L_9014D07:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDC8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9014D1A;
    goto L_9014D10;
L_9014D10:
    TS32((uint32_t)(0x903FDD8u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9014D1A:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903FDB8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014D25u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_9014D36;
    goto L_9014D29;
L_9014D29:
    TS32((uint32_t)(0x903FDD8u), (uint32_t)(dec32(TL32((uint32_t)(0x903FDD8u)), &f)));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9014D36:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014D44u; SPILL(); f_9014340(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014D51u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((f.sf == f.of));
    TS32((uint32_t)(0x903FDCCu), (uint32_t)(ecx));
L_9014D5E:
    { uint32_t v_ = 0x60u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0xCu));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FDD4u), (uint32_t)((uint32_t)0x0u));
    esp -= 4; M32(esp) = 0x9014D76u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x8u));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)((uint32_t)0x60u);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9014D93u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9014DA7;
    goto L_9014D97;
L_9014D97:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    TS32((uint32_t)(0x903FDD4u), (uint32_t)(ecx));
L_9014DA7:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9014DC0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014DC0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x58u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014E29;
    goto L_9014DCD;
L_9014DCD:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x48u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014DD8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014DEAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FDC0u), (uint32_t)(dec32(TL32((uint32_t)(0x903FDC0u)), &f)));
    TS32((uint32_t)(0x903FDD8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FDD8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(esi + 0x58u), (uint32_t)((uint32_t)0x0u));
    if (!f.zf) goto L_9014E29;
    goto L_9014E00;
L_9014E00:
    (void)sub32(TL32((uint32_t)(0x903FDBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014E29;
    goto L_9014E09;
L_9014E09:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9014E29;
    goto L_9014E12;
L_9014E12:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9014E29;
    goto L_9014E17;
L_9014E17:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014E1Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FDB8u), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_9014E29:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9014E30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014E30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x4Cu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9014E44;
    goto L_9014E3F;
L_9014E3F:
    edi = (uint32_t)((uint32_t)0xAC44u);
L_9014E44:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0x180u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014E54u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esp -= 4; M32(esp) = 0x9014E5Cu; SPILL(); f_9014CE0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9014E68;
    goto L_9014E60;
L_9014E60:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_9014E68:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL8((uint32_t)(esi + 0x28u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x1u);
    M16((uint32_t)(ebp + 0xFFFFFFECu)) = (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(((uint16_t)eax));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(((uint16_t)edx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)ebx; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M16((uint32_t)(ebp + 0xFFFFFFFAu)) = (uint16_t)(((uint16_t)eax));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)edi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (eax & 0xFFFF0000u) | (uint16_t)(shr16(((uint16_t)eax), (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int16_t)((uint16_t)eax) * (int16_t)((uint16_t)edx); eax = (eax & 0xFFFF0000u) | (uint16_t)(r_); f.cf = f.of = r_ != (int16_t)r_; }
    M16((uint32_t)(ebp + 0xFFFFFFEEu)) = (uint16_t)(((uint16_t)edx));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x64u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edi));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    M16((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint16_t)(((uint16_t)eax));
    M16((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint16_t)(((uint16_t)edx));
    (void)sub32(edi, (uint32_t)0xAC44u, &f);
    if (f.zf) goto L_9014F12;
    goto L_9014ED1;
L_9014ED1:
    (void)sub32(edi, (uint32_t)0xBB80u, &f);
    if (f.zf) goto L_9014F12;
    goto L_9014ED9;
L_9014ED9:
    (void)sub32(edi, (uint32_t)0x5DC0u, &f);
    if (f.zf) goto L_9014F12;
    goto L_9014EE1;
L_9014EE1:
    (void)sub32(edi, (uint32_t)0x2EE0u, &f);
    if (f.zf) goto L_9014F12;
    goto L_9014EE9;
L_9014EE9:
    (void)sub32(edi, (uint32_t)0x7D00u, &f);
    if (f.zf) goto L_9014F12;
    goto L_9014EF1;
L_9014EF1:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    edi = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x90310B8u)); esp -= 4; M32(esp) = 0x9014F03u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFDCu)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    if (f.cf) goto L_9014F12;
    goto L_9014F0C;
L_9014F0C:
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(edi));
L_9014F12:
    edx = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0x258u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edi = (uint32_t)(edx);
    edx = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0x32u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0xFFu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x6u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x3FFu, &f));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(edx));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFC00u), &f));
    edx = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0x46u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x51EB851Fu);
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x5u, &f));
    ebx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)((uint32_t)0x1A4u));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(ebx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edx);
    (void)sub32(edx, ebx, &f);
    if (f.zf) goto L_9014FAA;
    goto L_9014F84;
L_9014F84:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x18u)));
    (void)sub32(edx, ebx, &f);
    if (f.zf) goto L_9014FAA;
    goto L_9014F8B;
L_9014F8B:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014F99u; SPILL(); f_9001B90(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014FA5u; SPILL(); f_9001BD0(c); RELOAD();
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    goto L_9014FAD;
L_9014FAA:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edi);
L_9014FAD:
    edi = (uint32_t)((uint32_t)0x14u);
    (void)sub32(TL32((uint32_t)(0x903FDCCu)), ebx, &f);
    if (f.zf) goto L_901501E;
    goto L_9014FBA;
L_9014FBA:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    { uint32_t v_ = 0x903FDD0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ebx);
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9014FF2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9015018;
    goto L_9014FF6;
L_9014FF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDD0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x38u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015007u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FDD0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015018u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015018:
    TS32((uint32_t)(0x903FDCCu), (uint32_t)(ebx));
L_901501E:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(edi);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(ecx);
    edi = (uint32_t)((uint32_t)(esi + 0x58u));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB4u));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)((uint32_t)0x180E0u);
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901505Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_901506A;
    goto L_901505F;
L_901505F:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_901506A:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x8u, &f);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
    if (!f.zf) goto L_901507B;
    goto L_9015076;
L_9015076:
    eax = (uint32_t)(add32(eax, eax, &f));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
L_901507B:
    eax = (uint32_t)((uint32_t)0x7FFFu);
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(edi);
    TS32((uint32_t)(esi + 0xC4u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0xC8u), (uint32_t)(ebx));
    esp -= 4; M32(esp) = 0x9015099u; SPILL(); f_9014510(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x90150A4u; SPILL(); f_9014620(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(ebx));
    (void)sub32(ecx, eax, &f);
    if (!f.cf) goto L_90150BC;
    goto L_90150BA;
L_90150BA:
    eax = (uint32_t)(ecx);
L_90150BC:
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FDC0u), (uint32_t)(add32(TL32((uint32_t)(0x903FDC0u)), eax, &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    TS32((uint32_t)(esi + 0x160u), (uint32_t)((uint32_t)0x9014980u));
    TS32((uint32_t)(esi + 0x164u), (uint32_t)((uint32_t)0x9014AB0u));
    TS32((uint32_t)(esi + 0x168u), (uint32_t)((uint32_t)0x9014B30u));
    TS32((uint32_t)(esi + 0x16Cu), (uint32_t)((uint32_t)0x9014B60u));
    TS32((uint32_t)(esi + 0x170u), (uint32_t)((uint32_t)0x9014C40u));
    TS32((uint32_t)(esi + 0x174u), (uint32_t)((uint32_t)0x9014B90u));
    TS32((uint32_t)(esi + 0x178u), (uint32_t)((uint32_t)0x9014DC0u));
    TS32((uint32_t)(esi + 0x15Cu), (uint32_t)((uint32_t)0x9014780u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
}

void f_9015150(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015150:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9015182;
    goto L_901515D;
L_901515D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_9015160:
    TS32((uint32_t)(0x903FDB8u), (uint32_t)(eax));
L_9015165:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901519C;
    goto L_9015169;
L_9015169:
    TS32((uint32_t)(0x903FDBCu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x903FDC4u), (uint32_t)((uint32_t)0x0u));
    goto L_9015202;
L_9015182:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(eax, ecx, &f);
    if (f.zf) goto L_9015165;
    goto L_9015189;
L_9015189:
    (void)sub32(TL32((uint32_t)(0x903FDC0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9015196;
    goto L_9015192;
L_9015192:
    eax = (uint32_t)(ecx);
    goto L_9015160;
L_9015196:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_901519C:
    (void)sub32(TL32((uint32_t)(0x903FDC8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(0x903FDBCu), (uint32_t)((uint32_t)0x1u));
    if (!f.zf) goto L_9015202;
    goto L_90151AF;
L_90151AF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDC4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90151E3;
    goto L_90151B8;
L_90151B8:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x90310A0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x90151C7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x903C218u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x90310ACu)); esp -= 4; M32(esp) = 0x90151D4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FDC4u), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x90151DCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FDC4u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_90151E3:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (f.cf) goto L_90151F9;
    goto L_90151E8;
L_90151E8:
    { uint32_t v_ = 0x903C224u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x90151F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FDC8u), (uint32_t)(eax));
L_90151F9:
    (void)sub32(TL32((uint32_t)(0x903FDC8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9015196;
    goto L_9015202;
L_9015202:
    esp -= 4; M32(esp) = 0x9015207u; SPILL(); f_9014CE0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015196;
    goto L_901520B;
L_901520B:
    TS32((uint32_t)(0x903FDD8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FDD8u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_901523D;
    goto L_9015214;
L_9015214:
    (void)sub32(TL32((uint32_t)(0x903FDBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901523D;
    goto L_901521D;
L_901521D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDB8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901523D;
    goto L_9015226;
L_9015226:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_901523D;
    goto L_901522B;
L_901522B:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015233u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FDB8u), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_901523D:
    eax = (uint32_t)((uint32_t)0x9014E30u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9015250(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015250:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x80u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015288;
    goto L_9015260;
L_9015260:
    eax = (uint32_t)(add32(eax, ecx, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x1u), &f));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0x2000000u, &f);
    if ((f.cf || f.zf)) goto L_9015288;
    goto L_9015272;
L_9015272:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, ecx, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
L_9015288:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015291u; SPILL(); f_9002347(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90152B0;
    goto L_9015295;
L_9015295:
    (void)sub32(TL32((uint32_t)(esi + 0x7Cu)), eax, &f);
    if (!f.zf) goto L_90152B0;
    goto L_901529A;
L_901529A:
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)((uint32_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
L_90152B0:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_901534E;
    goto L_90152BB;
L_90152BB:
    eax = (uint32_t)(edi);
    eax = (uint32_t)(sub32(eax, ecx, &f));
    (void)sub32(eax, (uint32_t)0x1F4u, &f);
    if ((f.cf || f.zf)) goto L_901534E;
    goto L_90152CA;
L_90152CA:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x80u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90152ED;
    goto L_90152EB;
L_90152EB:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_90152ED:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90152F5;
    goto L_90152F3;
L_90152F3:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_90152F5:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    edx = (uint32_t)((uint32_t)(ecx + 0x1u));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_9015314;
    goto L_9015302;
L_9015302:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x3Fu, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x6u, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(eax));
    goto L_901532D;
L_9015314:
    edx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_901532D;
    goto L_901531B;
L_901531B:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, eax, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x3Fu, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
L_901532D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x10000u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
L_901534E:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9015360(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015360:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9015379;
    goto L_901536D;
L_901536D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015376u; SPILL(); f_9002347(c); RELOAD();
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
L_9015379:
    (void)sub32(TL32((uint32_t)(esi + 0x50u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90153A3;
    goto L_901537F;
L_901537F:
    (void)sub32(TL32((uint32_t)(esi + 0x78u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90153A3;
    goto L_9015385;
L_9015385:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015398u; SPILL(); f_90023C7(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90153A3;
    goto L_901539C;
L_901539C:
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x1u));
L_90153A3:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), eax, &f);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90153B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90153B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(eax + 0x6Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90153C2;
    goto L_90153BC;
L_90153BC:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_90153C2:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x90u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + ecx*4 + 0x58u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x70u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_90153F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90153F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9015404;
    goto L_90153FD;
L_90153FD:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9015404:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + eax*4 + 0x58u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015420u; SPILL(); f_90022D7(c); RELOAD();
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(inc32(TL32((uint32_t)(esi + 0x90u)), &f)));
    (void)sub32(TL32((uint32_t)(esi + 0x90u)), (uint32_t)0x4u, &f);
    if (f.cf) goto L_9015439;
    goto L_901542F;
L_901542F:
    TS32((uint32_t)(esi + 0x90u), (uint32_t)((uint32_t)0x0u));
L_9015439:
    esp -= 4; M32(esp) = 0x901543Eu; SPILL(); f_90159C0(c); RELOAD();
    edi = (uint32_t)(eax);
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9015447u; SPILL(); f_9015250(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015450u; SPILL(); f_9002387(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9015470(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015470:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x7FFFu, &f);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    if ((f.zf || f.sf != f.of)) goto L_9015485;
    goto L_9015480;
L_9015480:
    eax = (uint32_t)((uint32_t)0x7FFFu);
L_9015485:
    c->xmm[0].f[0] = (float)(int32_t)TL32((uint32_t)(ecx + 0x8Cu));
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x903132Cu));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].f[0] = (float)(int32_t)eax;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x9031328u));
    TS32((uint32_t)(ecx + 0x88u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x68u)));
    M32((uint32_t)(esp)) = c->xmm[0].u[0];
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90154BEu; SPILL(); f_90023A7(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90154D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90154D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x10000u, &f);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    if ((f.zf || f.sf != f.of)) goto L_90154E5;
    goto L_90154E0;
L_90154E0:
    eax = (uint32_t)((uint32_t)0x10000u);
L_90154E5:
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    c->xmm[0].f[0] = (float)(int32_t)eax;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x903132Cu));
    M32((uint32_t)(esp + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].f[0] = (float)(int32_t)TL32((uint32_t)(ecx + 0x88u));
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x9031328u));
    TS32((uint32_t)(ecx + 0x8Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x68u)));
    M32((uint32_t)(esp)) = c->xmm[0].u[0];
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901551Eu; SPILL(); f_90023A7(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9015530(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015530:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901553Fu; SPILL(); f_90022E7(c); RELOAD();
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9015581;
    goto L_9015545;
L_9015545:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9015560;
    goto L_901554E;
L_901554E:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9015560;
    goto L_901555A;
L_901555A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015560u; SPILL(); f_900DDF0(c); RELOAD();
L_9015560:
    (void)sub32(TL32((uint32_t)(esi + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9015581;
    goto L_9015569;
L_9015569:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (f.zf) goto L_9015581;
    goto L_9015572;
L_9015572:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1A0u)));
    edx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015581u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015581:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9015590(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015590:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x10u, &f);
    if (!f.zf) goto L_90155A5;
    goto L_9015598;
L_9015598:
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x2u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(f.zf);
    eax = (uint32_t)((uint32_t)(eax + eax + 0x1u));
    goto L_90155B0;
L_90155A5:
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x2u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(dec32(eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x2u), &f));
L_90155B0:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90155BBu; SPILL(); f_9002367(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90155C8u; SPILL(); f_9002337(c); RELOAD();
    c->xmm[0].f[0] = (float)(int32_t)TL32((uint32_t)(esi + 0x8Cu));
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x903132Cu));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].f[0] = (float)(int32_t)TL32((uint32_t)(esi + 0x88u));
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x9031328u));
    M32((uint32_t)(esp)) = c->xmm[0].u[0];
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90155FFu; SPILL(); f_90023A7(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x74u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901560Fu; SPILL(); f_9002327(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = 0x9015530u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901561Du; SPILL(); f_90022F7(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015656;
    goto L_9015627;
L_9015627:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x903FCF8u);
    (void)sub32(ecx, (uint32_t)0x2u, &f);
    if (f.zf) goto L_9015683;
    goto L_9015635;
L_9015635:
    edi = (uint32_t)((uint32_t)0x903FD78u);
    edx = (uint32_t)((uint32_t)0x903FD98u);
L_901563F:
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x98u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015655u; SPILL(); f_90023B7(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_9015656:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015661u; SPILL(); f_9002397(c); RELOAD();
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x78u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9015683:
    edx = (uint32_t)((uint32_t)0x903FD38u);
    goto L_901563F;
}

void f_9015690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015690:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_90156B9;
    goto L_901569F;
L_901569F:
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90156D3;
    goto L_90156A5;
L_90156A5:
    esp -= 4; M32(esp) = 0x90156AAu; SPILL(); f_9015590(c); RELOAD();
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90156B9:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90156D3;
    goto L_90156BD;
L_90156BD:
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_90156D3;
    goto L_90156C3;
L_90156C3:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90156CCu; SPILL(); f_9002357(c); RELOAD();
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x0u));
L_90156D3:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90156E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90156E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(edi, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9015701;
    goto L_90156F0;
L_90156F0:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90156F9u; SPILL(); f_9002357(c); RELOAD();
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9015701:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901570Au; SPILL(); f_9002387(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x78u), (uint32_t)((uint32_t)0x1u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9015730(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015730:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(edi, (uint32_t)0x8u, &f);
    if ((f.cf || f.zf)) goto L_9015746;
    goto L_9015741;
L_9015741:
    edi = (uint32_t)((uint32_t)0x8u);
L_9015746:
    { uint32_t v_ = 0x40u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(ebx + 0x98u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015756u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)((uint32_t)(edi*8));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015768u; SPILL(); f_9001FE0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x94u), (uint32_t)(edi));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    edx = (uint32_t)((uint32_t)0x903FCF8u);
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (f.zf) goto L_901579F;
    goto L_901577E;
L_901577E:
    edx = (uint32_t)((uint32_t)0x903FD78u);
    ecx = (uint32_t)((uint32_t)0x903FD98u);
L_9015788:
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015798u; SPILL(); f_90023B7(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_901579F:
    ecx = (uint32_t)((uint32_t)0x903FD38u);
    goto L_9015788;
}

void f_90157B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90157B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90157C0u; SPILL(); f_9002317(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90157C9u; SPILL(); f_90022B7(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90157D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90157D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0x180u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90157E4u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x903FCECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(edx));
    esp -= 4; M32(esp) = 0x901580Bu; SPILL(); f_9002377(c); RELOAD();
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015881;
    goto L_9015812;
L_9015812:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x10u, &f);
    if (!f.zf) goto L_9015827;
    goto L_901581A;
L_901581A:
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x2u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(f.zf);
    eax = (uint32_t)((uint32_t)(eax + eax + 0x1u));
    goto L_9015832;
L_9015827:
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x2u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(dec32(eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x2u), &f));
L_9015832:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FCECu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015843u; SPILL(); f_90022C7(c); RELOAD();
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(eax));
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x8u, &f);
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
    if (!f.zf) goto L_901585A;
    goto L_9015855;
L_9015855:
    eax = (uint32_t)(add32(eax, eax, &f));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
L_901585A:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    { uint32_t v_ = 0x157u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = 0x903C238u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015871u; SPILL(); f_90022A7(c); RELOAD();
    TS32((uint32_t)(esi + 0x58u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9015888;
    goto L_9015878;
L_9015878:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015881u; SPILL(); f_90022B7(c); RELOAD();
L_9015881:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_9015888:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(eax));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    TS32((uint32_t)(esi + 0x64u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x78u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x7FFFu));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)((uint32_t)0x8000u));
    esp -= 4; M32(esp) = 0x90158D7u; SPILL(); f_9015590(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FCECu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90158E2u; SPILL(); f_9002307(c); RELOAD();
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x15Cu), (uint32_t)((uint32_t)0x9015360u));
    TS32((uint32_t)(esi + 0x160u), (uint32_t)((uint32_t)0x90153B0u));
    TS32((uint32_t)(esi + 0x164u), (uint32_t)((uint32_t)0x90153F0u));
    TS32((uint32_t)(esi + 0x168u), (uint32_t)((uint32_t)0x9015470u));
    TS32((uint32_t)(esi + 0x16Cu), (uint32_t)((uint32_t)0x90154D0u));
    TS32((uint32_t)(esi + 0x170u), (uint32_t)((uint32_t)0x90156E0u));
    TS32((uint32_t)(esi + 0x174u), (uint32_t)((uint32_t)0x9015690u));
    TS32((uint32_t)(esi + 0x178u), (uint32_t)((uint32_t)0x90157B0u));
    TS32((uint32_t)(esi + 0x17Cu), (uint32_t)((uint32_t)0x9015730u));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
}

void f_9015950(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015950:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90159B1;
    goto L_901595A;
L_901595A:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FCECu)));
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9015969;
    goto L_9015965;
L_9015965:
    (void)sub32(ecx, eax, &f);
    if (f.zf) goto L_901596E;
    goto L_9015969;
L_9015969:
    TS32((uint32_t)(0x903FCECu), (uint32_t)(eax));
L_901596E:
    (void)sub32(TL32((uint32_t)(0x903FCE8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901599D;
    goto L_9015977;
L_9015977:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x90310A0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9015986u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x903C268u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x90310ACu)); esp -= 4; M32(esp) = 0x9015993u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FCE8u), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x901599Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_901599D:
    (void)sub32(TL32((uint32_t)(0x903FCE8u)), (uint32_t)0x20u, &f);
    if (!f.cf) goto L_90159B7;
    goto L_90159A6;
L_90159A6:
    { uint32_t v_ = 0x903C274u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310C0u)); esp -= 4; M32(esp) = 0x90159B1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90159B1:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90159B7:
    eax = (uint32_t)((uint32_t)0x90157D0u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90159C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90159C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x24u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x9031188u)));
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)sub32(TL32((uint32_t)(0x903FCE0u)), ebx, &f);
    if (f.zf) goto L_9015A93;
    goto L_90159E7;
L_90159E7:
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C298u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FCE0u), (uint32_t)(ebx));
    { uint32_t t_ = TL32((uint32_t)(0x90310CCu)); esp -= 4; M32(esp) = 0x90159FEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015A08;
    goto L_9015A02;
L_9015A02:
    (void)sub8(M8((uint32_t)(ebp + 0xFFFFFFECu)), (uint8_t)0x31u, &f);
    if (f.zf) goto L_9015A46;
    goto L_9015A08;
L_9015A08:
    { uint32_t v_ = 0x9028830u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310D0u)); esp -= 4; M32(esp) = 0x9015A13u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015A46;
    goto L_9015A17;
L_9015A17:
    { uint32_t v_ = 0x9028828u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310C4u)); esp -= 4; M32(esp) = 0x9015A22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9028824u), (uint32_t)(ebx));
    { uint32_t t_ = TL32((uint32_t)(0x90310C8u)); esp -= 4; M32(esp) = 0x9015A2Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9028838u), (uint32_t)(eax));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x9015A42u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9015A46:
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9015A48u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FCE4u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028824u), (uint32_t)(ebx));
    TS32((uint32_t)(0x9028830u), (uint32_t)(ebx));
    TS32((uint32_t)(0x9028834u), (uint32_t)(ebx));
L_9015A5F:
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9015A61u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(0x903FCE4u)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9028824u)));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(sub32(edx, ecx, &f));
    (void)sub32(edx, (uint32_t)0xC0000000u, &f);
    if ((!f.cf && !f.zf)) goto L_9015B46;
    goto L_9015A7D;
L_9015A7D:
    TS32((uint32_t)(0x9028824u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x9015A8Fu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9015A93:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028830u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(0x9028834u))), &f));
    if (f.zf) goto L_9015A5F;
    goto L_9015AA1;
L_9015AA1:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310C4u)); esp -= 4; M32(esp) = 0x9015AABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t t_ = TL32((uint32_t)(0x90310C8u)); esp -= 4; M32(esp) = 0x9015AB1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(0x9028828u)), &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(sbb32(ecx, TL32((uint32_t)(0x902882Cu)), &f));
    { uint32_t v_ = 0x3E8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015AD2u; SPILL(); f_9001B90(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9028834u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(0x9028830u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015AE7u; SPILL(); f_9001BD0(c); RELOAD();
    ebx = (uint32_t)(TL32((uint32_t)(0x9028824u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(0x903FCE4u)), &f));
    eax = (uint32_t)(edi);
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(0x9028838u)), &f));
    edx = (uint32_t)(ecx);
    esi = (uint32_t)(eax);
    edx = (uint32_t)(sub32(edx, ebx, &f));
    esi = (uint32_t)(sub32(esi, edx, &f));
    eax = (uint32_t)(esi);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(logic32((uint32_t)(eax ^ edx), &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
    (void)sub32(eax, (uint32_t)0xC8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9015B1B;
    goto L_9015B13;
L_9015B13:
    TS32((uint32_t)(0x903FCE4u), (uint32_t)(add32(TL32((uint32_t)(0x903FCE4u)), esi, &f)));
    ecx = (uint32_t)(add32(ecx, esi, &f));
L_9015B1B:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, ebx, &f));
    (void)sub32(edx, (uint32_t)0xC0000000u, &f);
    if ((f.cf || f.zf)) goto L_9015B3A;
    goto L_9015B27;
L_9015B27:
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x9015B36u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9015B3A:
    TS32((uint32_t)(0x9028838u), (uint32_t)(edi));
    TS32((uint32_t)(0x9028824u), (uint32_t)(ecx));
L_9015B46:
    eax = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9015B55u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9015B60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015B60:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031090u)); esp -= 4; M32(esp) = 0x9015B7Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    (void)sub32(esi, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9015B98;
    goto L_9015B85;
L_9015B85:
    { uint32_t t_ = TL32((uint32_t)(0x90310E0u)); esp -= 4; M32(esp) = 0x9015B8Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015B98;
    goto L_9015B8F;
L_9015B8F:
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | esi), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9015B98:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9015BB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015BB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015BC7;
    goto L_9015BC4;
L_9015BC4:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015BC7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015BC7:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(edi, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9015C01;
    goto L_9015BCF;
L_9015BCF:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9015C01;
    goto L_9015BD9;
L_9015BD9:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    eax = (uint32_t)(edi);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x80u)), &f));
    edx = (uint32_t)(adc32(edx, TL32((uint32_t)(esi + 0x84u)), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9015BF8u; SPILL(); f_9015B60(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(edi));
L_9015C01:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015C32;
    goto L_9015C0A;
L_9015C0A:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x903C2A4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028844u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x5Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015C2Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9015C32:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x10u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310DCu)); esp -= 4; M32(esp) = 0x9015C4Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015C66;
    goto L_9015C57;
L_9015C57:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x67u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015C66u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015C66:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9015C75;
    goto L_9015C6E;
L_9015C6E:
    TS32((uint32_t)(esi + 0x40u), (uint32_t)((uint32_t)0x1u));
L_9015C75:
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA4u)), eax, &f)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x9Cu)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_9015C99;
    goto L_9015C96;
L_9015C96:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
L_9015C99:
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015CA6;
    goto L_9015CA3;
L_9015CA3:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015CA6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015CA6:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9015CB5;
    goto L_9015CAD;
L_9015CAD:
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9015CB5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015CB5:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

void f_9015CD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9015CD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9015D02;
    goto L_9015CF7;
L_9015CF7:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
L_9015D02:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015D11;
    goto L_9015D09;
L_9015D09:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015D0Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    goto L_9015D15;
L_9015D11:
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(ebx);
L_9015D15:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015D79;
    goto L_9015D1E;
L_9015D1E:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(edi, TL32((uint32_t)(0x903FCDCu)), &f);
    if (!f.cf) goto L_9015D41;
    goto L_9015D29;
L_9015D29:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = 0x903C2ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902883Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015D39u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9015D41:
    TS32((uint32_t)(0x903FCDCu), (uint32_t)(edi));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015D79;
    goto L_9015D4B;
L_9015D4B:
    { uint32_t v_ = 0x903C2F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028840u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x97u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015D71u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9015D79:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(edi, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9015E92;
    goto L_9015D85;
L_9015D85:
    (void)sub32(TL32((uint32_t)(esi + 0x8Cu)), edi, &f);
    if (f.zf) goto L_9015E92;
    goto L_9015D91;
L_9015D91:
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x1u);
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015DC7;
    goto L_9015D9D;
L_9015D9D:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x903C300u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902884Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9015DC4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9015DC7:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015DD1;
    goto L_9015DCE;
L_9015DCE:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015DD1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9015DD1:
    (void)sub32(edi, TL32((uint32_t)(esi + 0x8Cu)), &f);
    if ((f.cf || f.zf)) goto L_9015E24;
    goto L_9015DD9;
L_9015DD9:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    (void)sub32(edi, edx, &f);
    if ((!f.cf && !f.zf)) goto L_9015E24;
    goto L_9015DE3;
L_9015DE3:
    eax = (uint32_t)(edi);
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x8Cu)), &f));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(edi));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA8u)), eax, &f)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(sub32(TL32((uint32_t)(esi + 0x6Cu)), eax, &f)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA0u)), ecx, &f)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_9015E70;
    goto L_9015E19;
L_9015E19:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(sub32(TL32((uint32_t)(esi + 0xA0u)), ecx, &f)));
    goto L_9015E70;
L_9015E24:
    eax = (uint32_t)(edi);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x80u)), &f));
    edx = (uint32_t)(adc32(edx, TL32((uint32_t)(esi + 0x84u)), &f));
    ecx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015E43u; SPILL(); f_9015B60(c); RELOAD();
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(edi));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(ebx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(ebx));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(ecx));
L_9015E70:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9015E92;
    goto L_9015E79;
L_9015E79:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0xC3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9015E8Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015E92;
L_9015E90:
    ebx = (uint32_t)(logic32(0, &f));
L_9015E92:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    (void)sub32(edi, ebx, &f);
    if (f.zf) goto L_9015F88;
    goto L_9015E9D;
L_9015E9D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    (void)sub32(edi, eax, &f);
    if ((!f.cf && !f.zf)) { edi = (uint32_t)(eax); }
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(add32(TL32((uint32_t)(esi + 0x8Cu)), edi, &f)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x10u)), edi, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    (void)sub32(ebx, edi, &f);
    if ((!f.cf && !f.zf)) goto L_9015F20;
    goto L_9015EC3;
L_9015EC3:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x90u)), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015EDAu; SPILL(); f_9001FE0(c); RELOAD();
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x14u)), ebx, &f));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, ebx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015F00;
    goto L_9015EF3;
L_9015EF3:
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(neg32(ecx, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x6Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015EFEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015F03;
L_9015F00:
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(sub32(TL32((uint32_t)(esi + 0x6Cu)), ebx, &f)));
L_9015F03:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015F16;
    goto L_9015F0A;
L_9015F0A:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0xA8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015F14u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015F1C;
L_9015F16:
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA8u)), ebx, &f)));
L_9015F1C:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9015F88;
    goto L_9015F20;
L_9015F20:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x90u)), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9015F37u; SPILL(); f_9001FE0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    ebx = (uint32_t)(add32(ebx, edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(ebx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015F52;
    goto L_9015F46;
L_9015F46:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0xA0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015F50u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015F58;
L_9015F52:
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA0u)), edi, &f)));
L_9015F58:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015F6C;
    goto L_9015F5F;
L_9015F5F:
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(neg32(ecx, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x6Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015F6Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015F6F;
L_9015F6C:
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(sub32(TL32((uint32_t)(esi + 0x6Cu)), edi, &f)));
L_9015F6F:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015F82;
    goto L_9015F76;
L_9015F76:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0xA8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015F80u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9015F88;
L_9015F82:
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA8u)), edi, &f)));
L_9015F88:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_9016100;
    goto L_9015F93;
L_9015F93:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901600E;
    goto L_9015F9A;
L_9015F9A:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x1u);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9015FDB;
    goto L_9015FAB;
L_9015FAB:
    { uint32_t v_ = 0x903C318u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028848u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9015FD3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9015FDB:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9015FEA;
    goto L_9015FE2;
L_9015FE2:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9015FE5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_9015FEA:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016000;
    goto L_9015FEE;
L_9015FEE:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x105u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9016000u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016000:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_9015E90;
    goto L_901600B;
L_901600B:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
L_901600E:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016042;
    goto L_9016017;
L_9016017:
    { uint32_t v_ = 0x903C32Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028854u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901603Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9016042:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901604F;
    goto L_9016049;
L_9016049:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901604Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    goto L_9016051;
L_901604F:
    edi = (uint32_t)(logic32(0, &f));
L_9016051:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xB0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_901606F;
    goto L_901605B;
L_901605B:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x20u)) & (uint32_t)0xFFFFFF7Fu), &f)));
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)((uint32_t)0x0u));
L_901606F:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x10u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310DCu)); esp -= 4; M32(esp) = 0x9016088u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_9016097;
    goto L_9016090;
L_9016090:
    TS32((uint32_t)(esi + 0x40u), (uint32_t)((uint32_t)0x1u));
L_9016097:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_90160A7;
    goto L_901609E;
L_901609E:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x90160A3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
L_90160A7:
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA4u)), eax, &f)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(add32(TL32((uint32_t)(esi + 0x8Cu)), eax, &f)));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x48u)), eax, &f)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ebx = (uint32_t)(add32(ebx, M32((uint32_t)(esp + 0xCu)), &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90160CD;
    goto L_90160C9;
L_90160C9:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90160CBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_90160CF;
L_90160CD:
    eax = (uint32_t)(logic32(0, &f));
L_90160CF:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(sub32(eax, edi, &f));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x50u)), eax, &f)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x18u)), &f));
    TS32((uint32_t)(esi + 0x54u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x54u)), eax, &f)));
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901611D;
    goto L_90160EC;
L_90160EC:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x129u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90160FEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901611D;
L_9016100:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901610B;
    goto L_9016107;
L_9016107:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016109u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901610D;
L_901610B:
    eax = (uint32_t)(logic32(0, &f));
L_901610D:
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x18u)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x54u), (uint32_t)(eax));
L_901611D:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x9Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x8Cu)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_901613B;
    goto L_9016138;
L_9016138:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
L_901613B:
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x20000u, &f));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_9016153;
    goto L_901614D;
L_901614D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
L_9016153:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9016164;
    goto L_901615A;
L_901615A:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016164;
    goto L_9016161;
L_9016161:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016164u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016164:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9016173;
    goto L_901616B;
L_901616B:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9016173u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016173:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901618E;
    goto L_901617C;
L_901617C:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x140u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901618Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901618E:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

