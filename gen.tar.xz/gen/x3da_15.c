#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A002B20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002B20:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x1Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x18u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002B42u; SPILL(); f_A002C50(c); RELOAD();
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002B4Bu; SPILL(); f_A002BF0(c); RELOAD();
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x14u)) & (uint8_t)0x40u), &f);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    MF32((uint32_t)(edi + 0x24u)) = (float)ST(0); fpop(c);
    if (f.zf) goto L_A002B68;
    goto L_A002B5A;
L_A002B5A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002B66u; SPILL(); f_A001310(c); RELOAD();
    ST(0) = ST(0); fpop(c);
L_A002B68:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1Du), &f);
    if (f.zf) goto L_A002BBF;
    goto L_A002B6F;
L_A002B6F:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002B78u; SPILL(); f_A001470(c); RELOAD();
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A002B93;
    goto L_A002B7E;
L_A002B7E:
    (void)sub32(TL32((uint32_t)(esi)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_A002B93;
    goto L_A002B83;
L_A002B83:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002B93u; SPILL(); f_A0017F0(c); RELOAD();
L_A002B93:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(TL32((uint32_t)(eax + 0x30u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_A002BA9;
    goto L_A002B9C;
L_A002B9C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002BA9u; SPILL(); f_A001A60(c); RELOAD();
L_A002BA9:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x14u)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_A002BBF;
    goto L_A002BAF;
L_A002BAF:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002BBFu; SPILL(); f_A0024B0(c); RELOAD();
L_A002BBF:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x14u)) & (uint8_t)0x2u), &f);
    if (f.zf) goto L_A002BD1;
    goto L_A002BC5;
L_A002BC5:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002BD1u; SPILL(); f_A0029D0(c); RELOAD();
L_A002BD1:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x14u)) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_A002BE3;
    goto L_A002BD7;
L_A002BD7:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002BE3u; SPILL(); f_A001D80(c); RELOAD();
L_A002BE3:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A002BF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002BF0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    fpush(c, (double)MF32((uint32_t)(eax)));
    fpush(c, (double)MF32((uint32_t)(eax + 0x4u)));
    fpush(c, (double)MF32((uint32_t)(eax + 0x8u)));
    ST(0) = ST(0) * ST(0);
    { double v_ = ST(1); fpush(c, v_); }
    ST(2) = ST(2) * ST(0); fpop(c);
    ST(1) = ST(1) + ST(0); fpop(c);
    { double v_ = ST(1); fpush(c, v_); }
    ST(2) = ST(2) * ST(0); fpop(c);
    ST(1) = ST(1) + ST(0); fpop(c);
    ST(0) = sqrt(ST(0));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

