#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9012B50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012B50:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1B4u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_9012F10;
    goto L_9012B6C;
L_9012B6C:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(ebx & (uint32_t)0x4000000u), &f);
    if (!f.zf) goto L_9012F10;
    goto L_9012B7B;
L_9012B7B:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x80000u), &f);
    if (!f.zf) goto L_9012B99;
    goto L_9012B83;
L_9012B83:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x20u)) & (uint32_t)0x80000u), &f);
    if (!f.zf) goto L_9012B99;
    goto L_9012B8C;
L_9012B8C:
    (void)sub32(TL32((uint32_t)(esi + 0x4BCu)), (uint32_t)0x2u, &f);
    if (f.zf) goto L_9012F10;
    goto L_9012B99;
L_9012B99:
    (void)sub32(TL32((uint32_t)(esi + 0xD4u)), edi, &f);
    if (!f.zf) goto L_9012BDF;
    goto L_9012BA1;
L_9012BA1:
    eax = (uint32_t)((uint32_t)0x64u);
    TS32((uint32_t)(esi + 0x128u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    TS32((uint32_t)(esi + 0x468u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x468u)), eax, &f)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    esp -= 4; M32(esp) = 0x9012BC9u; SPILL(); f_9001070(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xF4u)));
    TS32((uint32_t)(esi + 0xD4u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xD8u), (uint32_t)(eax));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x0u));
L_9012BDF:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xE0u)));
    (void)sub32(eax, edi, &f);
    if (!f.zf) goto L_9012C0B;
    goto L_9012BE9;
L_9012BE9:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x44u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9012C0B:
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9012F04;
    goto L_9012C15;
L_9012C15:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edi);
    edx = (uint32_t)(add32(edx, (uint32_t)0xFu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFF0u), &f));
    edi = (uint32_t)((uint32_t)(esi + 0x40u));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x2Cu));
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9012C4Bu; SPILL(); f_9012870(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
    (void)logic32((uint32_t)(ebx & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_9012DAF;
    goto L_9012C5D;
L_9012C5D:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9012DAF;
    goto L_9012C65;
L_9012C65:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xE0u)));
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)(edx);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0xC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x14Cu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x30u));
    esp -= 4; M32(esp) = 0x9012CA7u; SPILL(); f_90129E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0xA0u)) = (uint32_t)(eax);
L_9012CB1:
    eax = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), eax, &f);
    if ((f.zf || f.sf != f.of)) goto L_9012DAF;
    goto L_9012CC1;
L_9012CC1:
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
L_9012CC4:
    edx = (uint32_t)(M32((uint32_t)(esp + eax*4 + 0xA0u)));
    (void)sub32(edx, edi, &f);
    if ((f.zf || f.sf != f.of)) goto L_9012CD3;
    goto L_9012CCF;
L_9012CCF:
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(edx);
L_9012CD3:
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, ebx, &f);
    if ((f.sf != f.of)) goto L_9012CC4;
    goto L_9012CD8;
L_9012CD8:
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9012DAF;
    goto L_9012CE5;
L_9012CE5:
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(M32((uint32_t)(esp + ecx + 0x140u)));
    M32((uint32_t)(esp + ecx + 0x20u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(esp + ecx + 0x144u)));
    M32((uint32_t)(esp + ecx + 0x24u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(esp + ecx + 0x148u)));
    edx = (uint32_t)((uint32_t)(esp + ecx + 0x140u));
    eax = (uint32_t)((uint32_t)(esp + ecx + 0x20u));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0xCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(edi));
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(esp + ecx + 0xC0u)));
    ecx = (uint32_t)((uint32_t)(esp + ecx + 0xC0u));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x4u, &f));
    edi = (uint32_t)((uint32_t)(esp + edi + 0x20u));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0xCu)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(edi));
    (void)sub32(edi, (uint32_t)0x8u, &f);
    if (f.zf) goto L_9012DAF;
    goto L_9012D50;
L_9012D50:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xE0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9012D65u; SPILL(); f_90129E0(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    M32((uint32_t)(esp + ecx*4 + 0xB0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xE0u)));
    edi = (uint32_t)(dec32(edi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + ecx + 0xD8u));
    eax = (uint32_t)((uint32_t)(esp + ecx + 0x38u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + ecx + 0x15Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9012DA0u; SPILL(); f_90129E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
    M32((uint32_t)(esp + edi*4 + 0xA0u)) = (uint32_t)(eax);
    goto L_9012CB1;
L_9012DAF:
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), (uint32_t)0x0u, &f);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0x0u);
    if ((f.zf || f.sf != f.of)) goto L_9012F04;
    goto L_9012DC1;
L_9012DC1:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    eax = (uint32_t)((uint32_t)(esi + 0x40u));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
L_9012DCB:
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), edx, &f);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)((uint32_t)0x7FFF0000u);
    if ((f.zf || f.sf != f.of)) goto L_9012E08;
    goto L_9012DDC;
L_9012DDC:
    ebx = (uint32_t)((uint32_t)(esp + 0x20u));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
L_9012DE4:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    (void)sub32(eax, M32((uint32_t)(esp + 0x10u)), &f);
    if (!f.cf) goto L_9012DF8;
    goto L_9012DF2;
L_9012DF2:
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    ecx = (uint32_t)(edx);
L_9012DF8:
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x10u, &f));
    (void)sub32(edx, edi, &f);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
    if ((f.sf != f.of)) goto L_9012DE4;
    goto L_9012E08;
L_9012E08:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4A8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    (void)sub32(eax, (uint32_t)0x30000000u, &f);
    if ((!f.cf && !f.zf)) goto L_9012E46;
    goto L_9012E1A;
L_9012E1A:
    if (f.zf) goto L_9012E31;
    goto L_9012E1C;
L_9012E1C:
    (void)sub32(eax, (uint32_t)0x10000000u, &f);
    if (f.zf) goto L_9012E2A;
    goto L_9012E23;
L_9012E23:
    (void)sub32(eax, (uint32_t)0x20000000u, &f);
    if (!f.zf) goto L_9012E81;
    goto L_9012E2A;
L_9012E2A:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    goto L_9012E6D;
L_9012E31:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edx = (uint32_t)(M32((uint32_t)(esp + eax + 0x20u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(esp + eax + 0x20u)) = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)(esp + eax + 0x28u));
    goto L_9012E7B;
L_9012E46:
    (void)sub32(eax, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_9012E54;
    goto L_9012E4D;
L_9012E4D:
    (void)sub32(eax, (uint32_t)0x50000000u, &f);
    if (!f.zf) goto L_9012E81;
    goto L_9012E54;
L_9012E54:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edx = (uint32_t)(M32((uint32_t)(esp + eax + 0x20u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(esp + eax + 0x20u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(esp + eax + 0x28u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(esp + eax + 0x28u)) = (uint32_t)(edx);
L_9012E6D:
    edx = (uint32_t)(M32((uint32_t)(esp + eax + 0x24u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(esp + eax + 0x24u)) = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)(esp + eax + 0x2Cu));
L_9012E7B:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(eax), (uint32_t)(edx));
L_9012E81:
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(M32((uint32_t)(esp + ecx + 0x28u)));
    edx = (uint32_t)(M32((uint32_t)(esp + ecx + 0x20u)));
    eax = (uint32_t)((uint32_t)(esp + ecx + 0x20u));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)sub32(edx, ebx, &f);
    if ((f.cf || f.zf)) goto L_9012EA0;
    goto L_9012E98;
L_9012E98:
    edi = (uint32_t)(sub32(edi, edx, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    M32((uint32_t)(esp + ecx + 0x28u)) = (uint32_t)(edi);
L_9012EA0:
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)((uint32_t)(esp + ecx + 0x2Cu));
    edi = (uint32_t)((uint32_t)(esp + ecx + 0x24u));
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edx)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    (void)sub32(ecx, ebx, &f);
    if ((f.cf || f.zf)) goto L_9012EC3;
    goto L_9012EB9;
L_9012EB9:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edx = (uint32_t)(add32(edx, ebx, &f));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
L_9012EC3:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    TS32((uint32_t)(ecx + 0xCu), (uint32_t)(edx));
    TS32((uint32_t)(edi), (uint32_t)((uint32_t)0x7FFFFFFFu));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x10u, &f));
    (void)sub32(eax, edi, &f);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_9012DCB;
    goto L_9012F04;
L_9012F04:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9012F10:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9012F20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012F20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9012F67;
    goto L_9012F2B;
L_9012F2B:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9012F46;
    goto L_9012F34;
L_9012F34:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(eax + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9012F46;
    goto L_9012F40;
L_9012F40:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9012F46u; SPILL(); f_900DDF0(c); RELOAD();
L_9012F46:
    (void)sub32(TL32((uint32_t)(esi + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9012F67;
    goto L_9012F4F;
L_9012F4F:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (f.zf) goto L_9012F67;
    goto L_9012F58;
L_9012F58:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1A0u)));
    ecx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9012F67u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9012F67:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9012F70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012F70:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x124u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.zf || f.sf != f.of)) goto L_9012F9F;
    goto L_9012F7E;
L_9012F7E:
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x178u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0xECu)));
    ebx = (uint32_t)((uint32_t)(ebx));
L_9012F90:
    ebx = (uint32_t)(TL32((uint32_t)(ecx)));
    (void)sub32(TL32((uint32_t)(esi + ebx*4)), edi, &f);
    if (f.zf) goto L_9012FA2;
    goto L_9012F97;
L_9012F97:
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    (void)sub32(eax, edx, &f);
    if ((f.sf != f.of)) goto L_9012F90;
    goto L_9012F9F;
L_9012F9F:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
L_9012FA2:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9012FB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012FB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9012FFC;
    goto L_9012FBB;
L_9012FBB:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9012FFC;
    goto L_9012FC4;
L_9012FC4:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9012FCFu; SPILL(); f_9012F70(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9012FFC;
    goto L_9012FD5;
L_9012FD5:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    (void)sub32(TL32((uint32_t)(ecx + eax + 0x168u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9012FFC;
    goto L_9012FEB;
L_9012FEB:
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x168u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9012FFCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9012FFC:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9013010(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013010:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x68u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90133F7;
    goto L_9013022;
L_9013022:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90133F7;
    goto L_901302F;
L_901302F:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901303Au; SPILL(); f_9012F70(c); RELOAD();
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90133F6;
    goto L_9013043;
L_9013043:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(add32(eax, ecx, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x17Cu)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    if (f.zf) goto L_90133F6;
    goto L_9013064;
L_9013064:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    (void)sub32(ebx, (uint32_t)0x8u, &f);
    if ((f.cf || f.zf)) goto L_9013075;
    goto L_901306D;
L_901306D:
    ebx = (uint32_t)((uint32_t)0x8u);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(ebx);
L_9013075:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9013176;
    goto L_9013080;
L_9013080:
    c->xmm[1].u[0] = M32((uint32_t)(0x903C210u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(0x9031324u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if ((f.sf != f.of)) goto L_9013139;
    goto L_901309B;
L_901309B:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    esi = (uint32_t)(sub32(esi, edx, &f));
    edi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    eax = (uint32_t)((uint32_t)(edx + 0x8u));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(esi);
    edi = (uint32_t)(sub32(edi, edx, &f));
    goto L_90130B0;
L_90130B0:
    esi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF8u)));
    (void)sub32(esi, (uint32_t)0x10000u, &f);
    if ((f.sf != f.of)) goto L_90130C0;
    goto L_90130BB;
L_90130BB:
    c->xmm[0] = c->xmm[1];
    goto L_90130C8;
L_90130C0:
    c->xmm[0].f[0] = (float)(int32_t)esi;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
L_90130C8:
    esi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFFCu)));
    (void)sub32(esi, (uint32_t)0x10000u, &f);
    M32((uint32_t)(ebp + ecx*4 + 0xFFFFFFD8u)) = c->xmm[0].u[0];
    if ((f.sf != f.of)) goto L_90130DE;
    goto L_90130D9;
L_90130D9:
    c->xmm[0] = c->xmm[1];
    goto L_90130E6;
L_90130DE:
    c->xmm[0].f[0] = (float)(int32_t)esi;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
L_90130E6:
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    (void)sub32(esi, (uint32_t)0x10000u, &f);
    M32((uint32_t)(ebp + ecx*4 + 0xFFFFFFDCu)) = c->xmm[0].u[0];
    if ((f.sf != f.of)) goto L_90130FB;
    goto L_90130F6;
L_90130F6:
    c->xmm[0] = c->xmm[1];
    goto L_9013103;
L_90130FB:
    c->xmm[0].f[0] = (float)(int32_t)esi;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
L_9013103:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(eax + esi)) = c->xmm[0].u[0];
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    (void)sub32(esi, (uint32_t)0x10000u, &f);
    if ((f.sf != f.of)) goto L_901311B;
    goto L_9013116;
L_9013116:
    c->xmm[0] = c->xmm[1];
    goto L_9013123;
L_901311B:
    c->xmm[0].f[0] = (float)(int32_t)esi;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
L_9013123:
    M32((uint32_t)(eax + edi)) = c->xmm[0].u[0];
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    esi = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFDu));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    (void)sub32(ecx, esi, &f);
    if (f.cf) goto L_90130B0;
    goto L_9013139;
L_9013139:
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9013186;
    goto L_901313D;
L_901313D:
    edi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    esi = (uint32_t)(ebx);
    edi = (uint32_t)(sub32(edi, edx, &f));
    eax = (uint32_t)((uint32_t)(edx + ecx*4));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    esp = (uint32_t)((uint32_t)(esp));
L_9013150:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)sub32(ecx, (uint32_t)0x10000u, &f);
    if ((f.sf != f.of)) goto L_901315F;
    goto L_901315A;
L_901315A:
    c->xmm[0] = c->xmm[1];
    goto L_9013167;
L_901315F:
    c->xmm[0].f[0] = (float)(int32_t)ecx;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
L_9013167:
    M32((uint32_t)(eax + edi)) = c->xmm[0].u[0];
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9013150;
    goto L_9013174;
L_9013174:
    goto L_9013186;
L_9013176:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.cf || f.zf)) goto L_9013188;
    goto L_901317A;
L_901317A:
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)((uint32_t)0x3F800000u);
    edi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
L_9013186:
    (void)logic32((uint32_t)(ebx & ebx), &f);
L_9013188:
    if (!f.zf) goto L_9013197;
    goto L_901318A;
L_901318A:
    c->xmm[0].u[0] = M32((uint32_t)(0x903BD5Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[0].u[0];
L_9013197:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFA8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(eax);
    esi = (uint32_t)(TL32((uint32_t)(edx + 0x28u)));
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_90131D9;
    goto L_90131D6;
L_90131D6:
    ecx = (uint32_t)((uint32_t)(eax + 0x1u));
L_90131D9:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(edi, eax, &f);
    if (!f.zf) goto L_90132F7;
    goto L_90131E7;
L_90131E7:
    edi = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(eax);
    (void)sub32(ebx, (uint32_t)0x2u, &f);
    if (f.cf) goto L_901323A;
    goto L_90131F7;
L_90131F7:
    eax = (uint32_t)((uint32_t)0x1u);
    edi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    (void)sub32(ebx, (uint32_t)0x5u, &f);
    if (f.cf) goto L_901323A;
    goto L_9013206;
L_9013206:
    eax = (uint32_t)((uint32_t)0x4u);
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(eax);
    (void)sub32(ebx, (uint32_t)0x6u, &f);
    if (f.cf) goto L_901323A;
    goto L_9013219;
L_9013219:
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)((uint32_t)0x5u);
    eax = (uint32_t)((uint32_t)(edi + 0x4u));
    (void)sub32(ebx, (uint32_t)0x7u, &f);
    if (f.cf) goto L_901323A;
    goto L_9013228;
L_9013228:
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)((uint32_t)0x6u);
    eax = (uint32_t)((uint32_t)(edi + 0x5u));
    (void)sub32(ebx, (uint32_t)0x8u, &f);
    if (f.cf) goto L_901323A;
    goto L_9013237;
L_9013237:
    eax = (uint32_t)((uint32_t)(edi + 0x6u));
L_901323A:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + edi*4 + 0xFFFFFFD8u)));
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    MF32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901328D;
    goto L_9013269;
L_9013269:
    c->xmm[2].u[0] = M32((uint32_t)(0x903C214u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[2].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = c->xmm[0].u[0];
L_901328D:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    fpush(c, (double)MF32((uint32_t)(ebp + edi*4 + 0xFFFFFFD8u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    edx = (uint32_t)((uint32_t)0x2u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = c->xmm[1].u[0];
    edx = (uint32_t)((uint32_t)0x3u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    M32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = c->xmm[0].u[0];
    edx = (uint32_t)((uint32_t)0x4u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    MF32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edx = (uint32_t)((uint32_t)0x5u);
    fpush(c, (double)MF32((uint32_t)(ebp + edi*4 + 0xFFFFFFD8u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    MF32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edx = (uint32_t)((uint32_t)0x6u);
    fpush(c, (double)MF32((uint32_t)(ebp + edi*4 + 0xFFFFFFD8u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    MF32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edx = (uint32_t)((uint32_t)0x7u);
    fpush(c, (double)MF32((uint32_t)(ebp + eax*4 + 0xFFFFFFD8u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    MF32((uint32_t)(ebp + edx*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    goto L_90133BF;
L_90132F7:
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if ((f.sf != f.of)) goto L_901338E;
    goto L_9013300;
L_9013300:
    ebx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)((uint32_t)0x2u);
    edx = (uint32_t)((uint32_t)(edi + 0x8u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(ebx));
L_9013320:
    edi = (uint32_t)(TL32((uint32_t)(edx + 0xFFFFFFF8u)));
    fpush(c, (double)MF32((uint32_t)(ebp + eax*4 + 0xFFFFFFD8u)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & eax), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    MF32((uint32_t)(ebp + edi*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(TL32((uint32_t)(edx + 0xFFFFFFFCu)));
    fpush(c, (double)MF32((uint32_t)(ebp + eax*4 + 0xFFFFFFCCu)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & esi), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x10u, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    MF32((uint32_t)(ebp + edi*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(TL32((uint32_t)(edx + 0xFFFFFFF0u)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & esi), &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    fpush(c, (double)MF32((uint32_t)(ebx + edx + 0xFFFFFFF0u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x4u, &f));
    MF32((uint32_t)(ebp + edi*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(TL32((uint32_t)(edx + 0xFFFFFFF4u)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & esi), &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    fpush(c, (double)MF32((uint32_t)(ebx + edx + 0xFFFFFFF0u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    MF32((uint32_t)(ebp + edi*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    edi = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFDu));
    (void)sub32(eax, edi, &f);
    if (f.cf) goto L_9013320;
    goto L_901338B;
L_901338B:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
L_901338E:
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_90133BF;
    goto L_9013392;
L_9013392:
    ebx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    edx = (uint32_t)((uint32_t)(edi + eax*4));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(ebx);
    ecx = (uint32_t)((uint32_t)(ecx));
L_90133A0:
    edi = (uint32_t)(TL32((uint32_t)(edx)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & eax), &f));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    fpush(c, (double)MF32((uint32_t)(edx + ebx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    MF32((uint32_t)(ebp + edi*4 + 0xFFFFFF98u)) = (float)ST(0); fpop(c);
    (void)sub32(eax, ebx, &f);
    if (f.cf) goto L_90133A0;
    goto L_90133BF;
L_90133BF:
    (void)sub32(ebx, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_90133C9;
    goto L_90133C4;
L_90133C4:
    ebx = (uint32_t)((uint32_t)0x8u);
L_90133C9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x4E8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90133DC;
    goto L_90133D6;
L_90133D6:
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_90133DC;
    goto L_90133DA;
L_90133DA:
    ebx = (uint32_t)(eax);
L_90133DC:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x154u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF98u));
    eax = (uint32_t)(add32(eax, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x17Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90133F5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_90133F6:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_90133F7:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

void f_9013400(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013400:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901344C;
    goto L_901340B;
L_901340B:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901344C;
    goto L_9013414;
L_9013414:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901341Fu; SPILL(); f_9012F70(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_901344C;
    goto L_9013425;
L_9013425:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    (void)sub32(TL32((uint32_t)(ecx + eax + 0x16Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901344C;
    goto L_901343B;
L_901343B:
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x16Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901344Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901344C:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9013460(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013460:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901347A;
    goto L_901346A;
L_901346A:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x174u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901347A:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013480(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013480:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901349F;
    goto L_901348A;
L_901348A:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x170u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x200u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901349F:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90134B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90134B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90134CA;
    goto L_90134BA;
L_90134BA:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x178u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90134CA:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90134D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90134D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x88u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    esi = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF7Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF84u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF8Cu)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFF90u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFF80u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)((uint32_t)0x8u);
    (void)sub32(edi, esi, &f);
    if (f.zf) goto L_90136AC;
    goto L_9013518;
L_9013518:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(ebx, TL32((uint32_t)(edi + 0x38u)), &f);
    if (!f.cf) goto L_90135E4;
    goto L_9013525;
L_9013525:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x174u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + ebx*4)));
    ecx = (uint32_t)((uint32_t)(ecx + ebx*4));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Fu, &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_9013557;
    goto L_901353A;
L_901353A:
    (void)logic32((uint32_t)(edx & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_90135E4;
    goto L_9013546;
L_9013546:
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_9013557;
    goto L_901354A;
L_901354A:
    (void)logic32((uint32_t)(edx & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_9013557;
    goto L_9013552;
L_9013552:
    edx = (uint32_t)((uint32_t)(esi + 0x1u));
    goto L_9013559;
L_9013557:
    edx = (uint32_t)(logic32(0, &f));
L_9013559:
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(eax);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1Du, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(((uint16_t)eax));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901356Eu; SPILL(); f_9018800(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF78u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF7Cu));
    esp -= 4; M32(esp) = 0x9013582u; SPILL(); f_901E260(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF8Cu)));
    { uint32_t v_ = 0x1Cu; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x1Cu, &f));
    TS32((uint32_t)(edi + 0x468u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x468u)), edx, &f)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9013596u; SPILL(); f_901E2B0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x174u)));
    esi = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ecx + ebx*4));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.sf) goto L_90135B6;
    goto L_90135A7;
L_90135A7:
    (void)logic32((uint32_t)(ecx & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_90135B6;
    goto L_90135AF;
L_90135AF:
    ecx = (uint32_t)((uint32_t)0x1u);
    goto L_90135B8;
L_90135B6:
    ecx = (uint32_t)(logic32(0, &f));
L_90135B8:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1Du, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF78u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    edx = (uint32_t)(inc32(edx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(((uint16_t)eax));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90135D4u; SPILL(); f_9018860(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFF78u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90135F9;
    goto L_90135DE;
L_90135DE:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90135E4u; SPILL(); f_9001100(c); RELOAD();
L_90135E4:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x90135F3u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90135F9:
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(edi));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF78u)));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x174u)));
    ecx = (uint32_t)(TL16((uint32_t)(eax + ebx*4)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x174u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + ebx*4)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Bu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8u), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x174u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + ebx*4)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1Du, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x170u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ebx*4)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2000u, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x4u)), (uint32_t)0x8u, &f);
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    if (!f.zf) goto L_9013686;
    goto L_9013669;
L_9013669:
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(ebx));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x9013680u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9013686:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(ebx));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    edx = (uint32_t)(add32(edx, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(edx));
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x90136A6u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90136AC:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90136BAu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90136C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90136C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90136FB;
    goto L_90136CA;
L_90136CA:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)((uint32_t)0x0u));
    if (!f.zf) goto L_90136E9;
    goto L_90136DB;
L_90136DB:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90136E5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90136E9:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x90136FBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90136FB:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9013700(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013700:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013742;
    goto L_9013713;
L_9013713:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9013742;
    goto L_9013719;
L_9013719:
    edi = (uint32_t)(TL32((uint32_t)(eax + 0x10u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0xE8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    ebx = (uint32_t)(add32(ebx, esi, &f));
    esp -= 4; M32(esp) = 0x901372Fu; SPILL(); f_900E070(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x38u)));
    edx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9013753;
    goto L_9013742;
L_9013742:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9013750:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
L_9013753:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(esi, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_9013742;
    goto L_901375C;
L_901375C:
    (void)sub32(esi, TL32((uint32_t)(ecx + 0xE8u)), &f);
    if (f.cf) goto L_9013742;
    goto L_9013764;
L_9013764:
    ecx = (uint32_t)((uint32_t)(eax + esi));
    (void)sub32(ecx, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_9013742;
    goto L_901376B;
L_901376B:
    (void)sub32(edx, TL32((uint32_t)(edi + 0x18u)), &f);
    if (!f.zf) goto L_9013774;
    goto L_9013770;
L_9013770:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9013788;
    goto L_9013774;
L_9013774:
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, M32((uint32_t)(esp + 0x14u)), &f);
    esi = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_9013750;
    goto L_901377D;
L_901377D:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9013788:
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(add32(eax, esi, &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_9013812;
    goto L_90137A3;
L_90137A3:
    goto L_90137A9;
L_90137A5:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
L_90137A9:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    ecx = (uint32_t)((uint32_t)(eax + 0xFu));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)(esp + 0x20u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(edx + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(esp + 0x24u));
    esp -= 4; M32(esp) = 0x90137CEu; SPILL(); f_9018BA0(c); RELOAD();
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    (void)sub32(esi, ebx, &f);
    if ((f.cf || f.zf)) goto L_90137DC;
    goto L_90137D6;
L_90137D6:
    esi = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(esi);
L_90137DC:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(sub32(ebx, esi, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x4u)), (uint32_t)0x10u, &f);
    if (f.zf) goto L_9013807;
    goto L_90137E7;
L_90137E7:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(esi);
    ecx = (uint32_t)(eax);
    if (f.zf) goto L_9013807;
    goto L_90137F4;
L_90137F4:
    edi = (uint32_t)(esi);
L_90137F6:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)edx), (uint8_t)0x80u, &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x2u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_90137F6;
    goto L_9013807;
L_9013807:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xCu)), esi, &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x14u)), esi, &f));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90137A5;
    goto L_9013812;
L_9013812:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013820(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013820:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9013833;
    goto L_901382D;
L_901382D:
    TS32((uint32_t)(ecx + 0x114u), (uint32_t)(eax));
L_9013833:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013840(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013840:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)sub32(edi, esi, &f);
    if (f.zf) goto L_90139CC;
    goto L_901385A;
L_901385A:
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), esi, &f);
    if ((f.cf || f.zf)) goto L_90139CC;
    goto L_901386C;
L_901386C:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
L_9013870:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ebx + eax + 0x174u)), esi, &f);
    if (f.zf) goto L_9013912;
    goto L_9013883;
L_9013883:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), esi, &f);
    if (!f.zf) goto L_90138D1;
    goto L_9013888;
L_9013888:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    (void)sub32(eax, esi, &f);
    if ((f.zf || f.sf != f.of)) goto L_9013896;
    goto L_901388F;
L_901388F:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_90138D1;
    goto L_9013894;
L_9013894:
    (void)sub32(eax, esi, &f);
L_9013896:
    if ((f.sf == f.of)) goto L_90138B0;
    goto L_9013898;
L_9013898:
    { uint32_t v_ = 0x112Cu; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    goto L_90138C7;
L_90138B0:
    { uint32_t v_ = 0x1131u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)((uint32_t)0x2u);
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x3B0u));
L_90138C7:
    esp -= 4; M32(esp) = 0x90138CCu; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    esi = (uint32_t)(logic32(0, &f));
L_90138D1:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + ebx + 0x174u)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), esi, &f);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90138ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_901395E;
    goto L_90138F0;
L_90138F0:
    eax = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(edi + 0x110u)), esi, &f);
    if (!f.zf) goto L_9013912;
    goto L_9013900;
L_9013900:
    TS32((uint32_t)(edi + 0x110u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x474u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0x4CCu), (uint32_t)(esi));
L_9013912:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(inc32(eax, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x180u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    (void)sub32(eax, TL32((uint32_t)(edi + 0x124u)), &f);
    if (f.cf) goto L_9013870;
    goto L_901392B;
L_901392B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_90139C9;
    goto L_9013937;
L_9013937:
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_90139B0;
    goto L_901393C;
L_901393C:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x1158u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x9013950u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901395E:
    (void)sub32(TL32((uint32_t)(edi + 0x110u)), esi, &f);
    if (f.zf) goto L_9013912;
    goto L_9013966;
L_9013966:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + ebx + 0xCu)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + ebx + 0xCu)));
    eax = (uint32_t)((uint32_t)(edx + ebx));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)0x1u);
    (void)sub32(TL32((uint32_t)(edi + 0xCu)), eax, &f);
    if (!f.zf) goto L_9013996;
    goto L_901398E;
L_901398E:
    (void)sub32(TL32((uint32_t)(edi + 0x4ACu)), eax, &f);
    if (!f.zf) goto L_90139A5;
    goto L_9013996;
L_9013996:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    esi = (uint32_t)(add32(esi, ebx, &f));
    esp -= 4; M32(esp) = 0x90139A3u; SPILL(); f_900D6D0(c); RELOAD();
    esi = (uint32_t)(logic32(0, &f));
L_90139A5:
    TS32((uint32_t)(edi + 0x110u), (uint32_t)(esi));
    goto L_9013912;
L_90139B0:
    edi = (uint32_t)(add32(edi, (uint32_t)0x3B0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x115Cu);
    ecx = (uint32_t)((uint32_t)0x90373B0u);
    esp -= 4; M32(esp) = 0x90139C6u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_90139C9:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_90139CC:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90139E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90139E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(0x9036AE4u), (uint32_t)(eax));
    TS32((uint32_t)(0x9036AE8u), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013A00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013A00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013A22;
    goto L_9013A0A;
L_9013A0A:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9013A1B;
    goto L_9013A10;
L_9013A10:
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x20u)) | (uint32_t)0x80u), &f)));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9013A1B:
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x20u)) & (uint32_t)0xFFFFFF7Fu), &f)));
L_9013A22:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013A30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013A30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9013A77;
    goto L_9013A3A;
L_9013A3A:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013A77;
    goto L_9013A44;
L_9013A44:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x190u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9013A52u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013A70;
    goto L_9013A5D;
L_9013A5D:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x9013A70u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9013A70:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9013A77:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9013A80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013A80:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013AC0;
    goto L_9013A90;
L_9013A90:
    eax = (uint32_t)(add32(eax, ecx, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x1u), &f));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0x2000000u, &f);
    if ((f.cf || f.zf)) goto L_9013AC0;
    goto L_9013AA2;
L_9013AA2:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(sub32(ebx, ecx, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9013AC0:
    (void)sub32(TL32((uint32_t)(esi + 0x60u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9013AF7;
    goto L_9013AC6;
L_9013AC6:
    (void)sub32(TL32((uint32_t)(esi + 0x84u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9013AF7;
    goto L_9013ACF;
L_9013ACF:
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x80u)), &f));
    (void)sub32(eax, (uint32_t)0x640u, &f);
    if ((f.cf || f.zf)) goto L_9013AF7;
    goto L_9013ADE;
L_9013ADE:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(ecx));
L_9013AF7:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9013B98;
    goto L_9013B05;
L_9013B05:
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, ecx, &f));
    (void)sub32(eax, (uint32_t)0x1F4u, &f);
    if ((f.cf || f.zf)) goto L_9013B98;
    goto L_9013B14;
L_9013B14:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9013B37;
    goto L_9013B35;
L_9013B35:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_9013B37:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9013B3F;
    goto L_9013B3D;
L_9013B3D:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_9013B3F:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8Cu)));
    edx = (uint32_t)((uint32_t)(ecx + 0x1u));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_9013B5E;
    goto L_9013B4C;
L_9013B4C:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x3Fu, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x6u, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    goto L_9013B77;
L_9013B5E:
    edx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_9013B77;
    goto L_9013B65;
L_9013B65:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, eax, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x3Fu, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(ecx));
L_9013B77:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x10000u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
L_9013B98:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9013BA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013BA0:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(esi + 0x90u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9013BF0;
    goto L_9013BAC;
L_9013BAC:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x10u)) & (uint32_t)0xFFFFFFFEu), &f)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013BE2;
    goto L_9013BCF;
L_9013BCF:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + ecx*4)));
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031180u)); esp -= 4; M32(esp) = 0x9013BE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9013BE2:
    esp -= 4; M32(esp) = 0x9013BE7u; SPILL(); f_90159C0(c); RELOAD();
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9013BF0u; SPILL(); f_9013A80(c); RELOAD();
L_9013BF0:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9013C00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013C00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(esi + 0x24u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(esi + 0x28u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0x190u; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x78u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x9u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1Fu, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Fu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFE0u), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFE0u), &f));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(edx));
    (void)sub32(edx, eax, &f);
    if ((f.cf || f.zf)) goto L_9013C51;
    goto L_9013C4E;
L_9013C4E:
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
L_9013C51:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ebx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(edi*8 + 0x120u));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(ebx));
    esp -= 4; M32(esp) = 0x9013C6Eu; SPILL(); f_9001070(c); RELOAD();
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9013DA5;
    goto L_9013C7C;
L_9013C7C:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    edx = (uint32_t)((uint32_t)(eax + ecx*8));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(edx));
    edx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)((uint32_t)(esp));
L_9013C90:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)((uint32_t)(edi + eax + 0x20u));
    TS32((uint32_t)(eax + edx*4), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0xCu), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x10u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x14u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x18u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x1Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x98u)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edi, (uint32_t)0x100u, &f);
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    if ((f.sf != f.of)) goto L_9013C90;
    goto L_9013CE2;
L_9013CE2:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x98u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x10u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x80u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9013D08u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi + 0x24u)));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL8((uint32_t)(esi + 0x28u)));
    edi = (uint32_t)(((uint16_t)eax));
    ebx = (uint32_t)(((uint16_t)ecx));
    M16((uint32_t)(ebp + 0xFFFFFFFEu)) = (uint16_t)(((uint16_t)eax));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)ebx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (eax & 0xFFFF0000u) | (uint16_t)(shr16(((uint16_t)eax), (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int16_t)((uint16_t)eax) * (int16_t)((uint16_t)ecx); eax = (eax & 0xFFFF0000u) | (uint16_t)(r_); f.cf = f.of = r_ != (int16_t)r_; }
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    M16((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint16_t)(((uint16_t)edx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)edx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    M16((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint16_t)(((uint16_t)eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(esi + 0x90u));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M16((uint32_t)(ebp + 0xFFFFFFF2u)) = (uint16_t)(((uint16_t)ecx));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x9031198u)); esp -= 4; M32(esp) = 0x9013D68u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013DAE;
    goto L_9013D6C;
L_9013D6C:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x98u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9013DA5;
    goto L_9013D76;
L_9013D76:
    (void)sub8(TL8((uint32_t)(esi + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(esi + 0xFFFFFFFFu)));
    if (!f.zf) goto L_9013D93;
    goto L_9013D80;
L_9013D80:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xFFFFFFF4u)));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9013D8Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9013D93:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9013DA5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9013DA5:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9013DAE:
    edi = (uint32_t)(logic32(0, &f));
L_9013DB0:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + eax)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + eax)));
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031194u)); esp -= 4; M32(esp) = 0x9013DD4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + eax)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x10u)) | (uint32_t)0x1u), &f)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    (void)sub32(edi, (uint32_t)0x20u, &f);
    if ((f.sf != f.of)) goto L_9013DB0;
    goto L_9013DE9;
L_9013DE9:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9013E00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013E00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    (void)sub32(eax, (uint32_t)0x7FFFu, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if ((!f.zf && f.sf == f.of)) goto L_9013E2E;
    goto L_9013E14;
L_9013E14:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x7FFFu);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    goto L_9013E52;
L_9013E2E:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)((uint32_t)0x10000u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x8001u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
L_9013E52:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9013E69;
    goto L_9013E5C;
L_9013E5C:
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edi), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031170u)); esp -= 4; M32(esp) = 0x9013E69u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9013E69:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9013E70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013E70:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013EE2;
    goto L_9013E7A;
L_9013E7A:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031174u)); esp -= 4; M32(esp) = 0x9013E83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(TL32((uint32_t)(0x903119Cu)));
    edi = (uint32_t)(logic32(0, &f));
    goto L_9013E90;
L_9013E90:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + edi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + edi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9013EB4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + edi)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x10u)) | (uint32_t)0x1u), &f)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    (void)sub32(edi, (uint32_t)0x20u, &f);
    if ((f.sf != f.of)) goto L_9013E90;
    goto L_9013EC9;
L_9013EC9:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031184u)); esp -= 4; M32(esp) = 0x9013ED6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x90u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9013EE2:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x98u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9013F2B;
    goto L_9013EEC;
L_9013EEC:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_9013F0B;
    goto L_9013EF2;
L_9013EF2:
    edx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9013F00u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x98u), (uint32_t)((uint32_t)0x0u));
    esp += 4; SPILL(); return;
L_9013F0B:
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9013F21u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x98u), (uint32_t)((uint32_t)0x0u));
L_9013F2B:
    esp += 4; SPILL(); return;
}

void f_9013F30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013F30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(edx + 0x64u)), edi, &f);
    if (!f.zf) goto L_9013FC9;
    goto L_9013F42;
L_9013F42:
    (void)sub32(TL32((uint32_t)(edx + 0x34u)), edi, &f);
    if (f.zf) goto L_9013FC9;
    goto L_9013F4B;
L_9013F4B:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(edi + 0x1u));
    (void)sub32(TL32((uint32_t)(edx + 0x60u)), edi, &f);
    if (f.zf) goto L_9013F83;
    goto L_9013F55;
L_9013F55:
    esi = (uint32_t)(TL32((uint32_t)(edx + 0x94u)));
    ecx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)((uint32_t)(ecx));
L_9013F60:
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic8((uint8_t)(TL8((uint32_t)(ebx + 0x10u)) & ((uint8_t)eax)), &f);
    if (f.zf) goto L_9013F83;
    goto L_9013F67;
L_9013F67:
    ecx = (uint32_t)(add32(ecx, eax, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, (uint32_t)0x8u, &f);
    if ((f.sf != f.of)) goto L_9013F60;
    goto L_9013F71;
L_9013F71:
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(edx + 0x50u), (uint32_t)(eax));
    TS32((uint32_t)(edx + 0x60u), (uint32_t)(edi));
    TS32((uint32_t)(edx + 0x70u), (uint32_t)(edi));
    TS32((uint32_t)(edx + 0x6Cu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x68u), (uint32_t)(ecx));
L_9013F83:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x6Cu)));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x80000007u), &f));
    if (!f.sf) goto L_9013F95;
    goto L_9013F90;
L_9013F90:
    ecx = (uint32_t)(dec32(ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFF8u), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
L_9013F95:
    esi = (uint32_t)(TL32((uint32_t)(edx + 0x94u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + ecx*4)));
    (void)logic8((uint8_t)(TL8((uint32_t)(ebx + 0x10u)) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_9013FBF;
    goto L_9013FA3;
L_9013FA3:
    ecx = (uint32_t)(logic32(0, &f));
L_9013FA5:
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic8((uint8_t)(TL8((uint32_t)(edi + 0x10u)) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_9013FBF;
    goto L_9013FAC;
L_9013FAC:
    ecx = (uint32_t)(add32(ecx, eax, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, (uint32_t)0x8u, &f);
    if ((f.sf != f.of)) goto L_9013FA5;
    goto L_9013FB6;
L_9013FB6:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9013FBF:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(edx + 0x68u), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9013FC9:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9013FD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9013FD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x68u)));
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9013FE4;
    goto L_9013FDE;
L_9013FDE:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9013FE4:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(eax + 0x98u)), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9014010(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014010:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9014026;
    goto L_901401F;
L_901401F:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014026:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x70u)), edi, &f)));
    (void)sub32(TL32((uint32_t)(esi + 0x60u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)((uint32_t)0xFFFFFFFFu));
    if (!f.zf) goto L_9014080;
    goto L_9014040;
L_9014040:
    (void)sub32(eax, TL32((uint32_t)(esi + 0x74u)), &f);
    if (f.cf) goto L_901408A;
    goto L_9014045;
L_9014045:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), ebx, &f);
    if ((f.sf != f.of)) goto L_9014062;
    goto L_901404D;
L_901404D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9014050:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901405Cu; SPILL(); f_9013BA0(c); RELOAD();
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, TL32((uint32_t)(esi + 0x6Cu)), &f);
    if ((f.zf || f.sf != f.of)) goto L_9014050;
    goto L_9014062;
L_9014062:
    TS32((uint32_t)(esi + 0x60u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x901406Eu; SPILL(); f_90159C0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9014080:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901408Au; SPILL(); f_9013BA0(c); RELOAD();
L_901408A:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90140A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90140A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x10000u, &f);
    if ((f.sf != f.of)) goto L_90140B2;
    goto L_90140AD;
L_90140AD:
    eax = (uint32_t)((uint32_t)0xFFFFu);
L_90140B2:
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)0x7FFFu);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x10000u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx + 0x58u), (uint32_t)(eax));
    eax = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x90140D4u; SPILL(); f_9013E00(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90140E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90140E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(ecx, (uint32_t)0x10000u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90140F3;
    goto L_90140EE;
L_90140EE:
    ecx = (uint32_t)((uint32_t)0x10000u);
L_90140F3:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x90140FEu; SPILL(); f_9013E00(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014110(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014110:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901415A;
    goto L_901411C;
L_901411C:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014152;
    goto L_9014125;
L_9014125:
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901412Cu; SPILL(); f_9013C00(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9014152;
    goto L_9014130;
L_9014130:
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
L_9014152:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901415A:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901417B;
    goto L_901415E;
L_901415E:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9014152;
    goto L_9014167;
L_9014167:
    esp -= 4; M32(esp) = 0x901416Cu; SPILL(); f_9013E70(c); RELOAD();
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901417B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014190(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014190:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    if (f.zf) goto L_90141BD;
    goto L_90141A3;
L_90141A3:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90141AE;
    goto L_90141A7;
L_90141A7:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903117Cu)); esp -= 4; M32(esp) = 0x90141AEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90141AE:
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90141BD:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90141C8;
    goto L_90141C1;
L_90141C1:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031178u)); esp -= 4; M32(esp) = 0x90141C8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90141C8:
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9014200(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014200:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp -= 4; M32(esp) = 0x901420Cu; SPILL(); f_9013E70(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9014220(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014220:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x180u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014235u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(eax));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(ecx));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901428B;
    goto L_9014266;
L_9014266:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x18u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_901428B;
    goto L_901426D;
L_901426D:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901427Cu; SPILL(); f_9001B90(c); RELOAD();
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9014286u; SPILL(); f_9001BD0(c); RELOAD();
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(eax));
    goto L_901428E;
L_901428B:
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(ecx));
L_901428E:
    eax = (uint32_t)((uint32_t)0x7FFFu);
    TS32((uint32_t)(esi + 0x58u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x15Cu), (uint32_t)((uint32_t)0x9013F30u));
    TS32((uint32_t)(esi + 0x160u), (uint32_t)((uint32_t)0x9013FD0u));
    TS32((uint32_t)(esi + 0x164u), (uint32_t)((uint32_t)0x9014010u));
    TS32((uint32_t)(esi + 0x168u), (uint32_t)((uint32_t)0x90140A0u));
    TS32((uint32_t)(esi + 0x16Cu), (uint32_t)((uint32_t)0x90140E0u));
    TS32((uint32_t)(esi + 0x170u), (uint32_t)((uint32_t)0x9014190u));
    TS32((uint32_t)(esi + 0x174u), (uint32_t)((uint32_t)0x9014110u));
    TS32((uint32_t)(esi + 0x178u), (uint32_t)((uint32_t)0x9014200u));
    esp -= 4; M32(esp) = 0x90142FEu; SPILL(); f_9013C00(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9014308;
    goto L_9014302;
L_9014302:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_9014308:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x10u, &f);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
    if (f.zf) goto L_9014319;
    goto L_9014314;
L_9014314:
    eax = (uint32_t)(add32(eax, eax, &f));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
L_9014319:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x38u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
}

void f_9014330(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014330:
    eax = (uint32_t)((uint32_t)0x9014220u);
    esp += 8; SPILL(); return;
}

void f_9014340(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9014340:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t t_ = TL32((uint32_t)(0x90310BCu)); esp -= 4; M32(esp) = 0x901434Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x9014357u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FCF4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90143E0;
    goto L_9014363;
L_9014363:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310FCu)); esp -= 4; M32(esp) = 0x901436Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90143CB;
    goto L_9014371;
L_9014371:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(0x903110Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(0x9031100u)));
L_9014380:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031108u)); esp -= 4; M32(esp) = 0x901438Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), ecx, &f);
    if (!f.zf) goto L_90143BE;
    goto L_9014393;
L_9014393:
    { uint32_t v_ = 0xFFFFFFFAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x9014398u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if (!f.zf) goto L_90143AF;
    goto L_901439D;
L_901439D:
    { uint32_t v_ = 0xFFFFFFF0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x90143A2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & (uint32_t)0x40000000u), &f);
    if (!f.zf) goto L_90143AF;
    goto L_90143A9;
L_90143A9:
    TS32((uint32_t)(0x903FCF4u), (uint32_t)(esi));
L_90143AF:
    (void)sub32(TL32((uint32_t)(0x903FCF4u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90143BE;
    goto L_90143B8;
L_90143B8:
    TS32((uint32_t)(0x903FCF4u), (uint32_t)(esi));
L_90143BE:
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x90143C3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9014380;
    goto L_90143C9;
L_90143C9:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_90143CB:
    eax = (uint32_t)(TL32((uint32_t)(0x903FCF4u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90143E0;
    goto L_90143D5;
L_90143D5:
    { uint32_t t_ = TL32((uint32_t)(0x9031104u)); esp -= 4; M32(esp) = 0x90143DBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FCF4u), (uint32_t)(eax));
L_90143E0:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90143F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90143F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xACu)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9014430;
    goto L_9014400;
L_9014400:
    eax = (uint32_t)(add32(eax, ecx, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x1u), &f));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0x2000000u, &f);
    if ((f.cf || f.zf)) goto L_9014430;
    goto L_9014412;
L_9014412:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xA8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(sub32(ebx, ecx, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9014430:
    (void)sub32(TL32((uint32_t)(esi + 0x78u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9014467;
    goto L_9014436;
L_9014436:
    (void)sub32(TL32((uint32_t)(esi + 0xA8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9014467;
    goto L_901443F;
L_901443F:
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0xA0u)), &f));
    (void)sub32(eax, (uint32_t)0x12C0u, &f);
    if ((f.cf || f.zf)) goto L_9014467;
    goto L_901444E;
L_901444E:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)(ecx));
L_9014467:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xA8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9014508;
    goto L_9014475;
L_9014475:
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, ecx, &f));
    (void)sub32(eax, (uint32_t)0x4B0u, &f);
    if ((f.cf || f.zf)) goto L_9014508;
    goto L_9014484;
L_9014484:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xACu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)sub32(TL32((uint32_t)(esi + 0x28u)), (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90144A7;
    goto L_90144A5;
L_90144A5:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_90144A7:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90144AF;
    goto L_90144AD;
L_90144AD:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
L_90144AF:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xB0u)));
    edx = (uint32_t)((uint32_t)(ecx + 0x1u));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_90144CE;
    goto L_90144BC;
L_90144BC:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x3Fu, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x6u, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)(eax));
    goto L_90144E7;
L_90144CE:
    edx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_90144E7;
    goto L_90144D5;
L_90144D5:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, eax, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x3Fu, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)(ecx));
L_90144E7:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xB0u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x10000u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
L_9014508:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

