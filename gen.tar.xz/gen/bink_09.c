#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9010690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010690:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x28u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x903FE08u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FE0Cu)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FE10u)));
    M32((uint32_t)(esp)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9028454u)));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(0x903FE14u)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FE1Cu)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(0x903FE18u)));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEA0u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FE10u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FE14u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FE18u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FE08u), (uint32_t)(ecx));
    TS32((uint32_t)(0x903FE0Cu), (uint32_t)(ecx));
    TS32((uint32_t)(0x903FEA0u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x8u));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x903FE20u);
    esp -= 4; M32(esp) = 0x9010724u; SPILL(); f_900F310(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9010730(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010730:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp -= 4; M32(esp) = 0x9010743u; SPILL(); f_900F310(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9010750(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010750:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x474u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010781;
    goto L_901075F;
L_901075F:
    esp -= 4; M32(esp) = 0x9010764u; SPILL(); f_90159C0(c); RELOAD();
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    eax = (uint32_t)(dec32(eax, &f));
    TS32((uint32_t)(esi + 0x478u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)((uint32_t)0x0u));
L_9010781:
    (void)sub32(TL32((uint32_t)(esi + 0x14u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_901081A;
    goto L_901078C;
L_901078C:
    esp -= 4; M32(esp) = 0x9010791u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x478u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x3E8u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x3Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x10u);
    eax = (uint32_t)(shrd32(eax, edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x474u)), &f));
    if (f.sf) goto L_901081A;
    goto L_90107EC;
L_90107EC:
    (void)sub32(ecx, TL32((uint32_t)(esi + 0x47Cu)), &f);
    if ((f.zf || f.sf != f.of)) goto L_901081A;
    goto L_90107F4;
L_90107F4:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901082B;
    goto L_90107FD;
L_90107FD:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    eax = (uint32_t)(dec32(eax, &f));
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x478u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)((uint32_t)0x0u));
L_901081A:
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901082B:
    (void)sub32(ecx, (uint32_t)0x2D5u, &f);
    ecx = (uint32_t)((uint32_t)0x1u);
    if ((f.zf || f.sf != f.of)) goto L_901083E;
    goto L_9010838;
L_9010838:
    TS32((uint32_t)(esi + 0x4C0u), (uint32_t)(ecx));
L_901083E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4C8u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (f.cf) goto L_9010864;
    goto L_9010849;
L_9010849:
    TS32((uint32_t)(esi + 0x4C8u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9010864:
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(esi + 0x4C8u), (uint32_t)(eax));
    if (!f.zf) goto L_9010887;
    goto L_9010871;
L_9010871:
    TS32((uint32_t)(esi + 0x4C4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x4C4u)), ecx, &f)));
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(esi + 0x10Cu), (uint32_t)(ecx));
L_9010887:
    eax = (uint32_t)(ecx);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9010800(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010800:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x0u, &f));
    TS8((uint32_t)(eax + 0xFFFFFF89u), (uint8_t)(add8(TL8((uint32_t)(eax + 0xFFFFFF89u)), ((uint8_t)ecx), &f)));
    esi = (uint32_t)((uint32_t)0x474u);
    TS32((uint32_t)(esi + 0x478u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9010890(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010890:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90108BFu; SPILL(); f_90108D0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 32; SPILL(); return;
}

void f_90108D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90108D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90108F6;
    goto L_90108EB;
L_90108EB:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 48; SPILL(); return;
L_90108F6:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90108EB;
    goto L_90108FC;
L_90108FC:
    (void)sub32(TL32((uint32_t)(ebx + 0xD0u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90108EB;
    goto L_9010905;
L_9010905:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x168u)));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x168u)));
    M32((uint32_t)(ebp + 0x20u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x16Cu)));
    M32((uint32_t)(ebp + 0x28u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x16Cu)));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    M32((uint32_t)(ebp + 0x24u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x168u)));
    M32((uint32_t)(ebp + 0x2Cu)) = (uint32_t)(eax);
    (void)sub32(esi, ecx, &f);
    if (f.cf) goto L_90109A2;
    goto L_901099D;
L_901099D:
    M32((uint32_t)(ebp + 0x20u)) = (uint32_t)(ecx);
    esi = (uint32_t)(ecx);
L_90109A2:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x16Cu)));
    (void)sub32(edi, edx, &f);
    if (f.cf) goto L_90109B1;
    goto L_90109AC;
L_90109AC:
    M32((uint32_t)(ebp + 0x24u)) = (uint32_t)(edx);
    edi = (uint32_t)(edx);
L_90109B1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    eax = (uint32_t)(add32(eax, esi, &f));
    (void)sub32(eax, ecx, &f);
    if ((f.cf || f.zf)) goto L_90109BF;
    goto L_90109BA;
L_90109BA:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    M32((uint32_t)(ebp + 0x28u)) = (uint32_t)(ecx);
L_90109BF:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    eax = (uint32_t)((uint32_t)(edi + ecx));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_90109CE;
    goto L_90109C9;
L_90109C9:
    edx = (uint32_t)(sub32(edx, edi, &f));
    M32((uint32_t)(ebp + 0x2Cu)) = (uint32_t)(edx);
L_90109CE:
    (void)sub32(M32((uint32_t)(ebp + 0x28u)), (uint32_t)0x0u, &f);
    eax = (uint32_t)((uint32_t)0x2u);
    if (f.zf) goto L_9010C9E;
    goto L_90109DD;
L_90109DD:
    (void)sub32(M32((uint32_t)(ebp + 0x2Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010C9E;
    goto L_90109E7;
L_90109E7:
    (void)sub32(TL32((uint32_t)(ebx + 0x4BCu)), eax, &f);
    if (f.zf) goto L_9010C9E;
    goto L_90109F3;
L_90109F3:
    (void)sub32(TL32((uint32_t)(ebx + 0x470u)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9010A07;
    goto L_90109FC;
L_90109FC:
    esp -= 4; M32(esp) = 0x9010A01u; SPILL(); f_90159C0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x470u), (uint32_t)(eax));
L_9010A07:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0xD0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x70030000u), &f));
    M32((uint32_t)(ebp + 0x30u)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0x30u)) | ecx), &f));
    TS32((uint32_t)(ebx + 0x1DCu), (uint32_t)((uint32_t)0x1u));
    (void)sub32(TL32((uint32_t)(edx + 0x40u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010A30;
    goto L_9010A29;
L_9010A29:
    M32((uint32_t)(ebp + 0x30u)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0x30u)) & (uint32_t)0xFFFFF7FFu), &f));
L_9010A30:
    esp -= 4; M32(esp) = 0x9010A35u; SPILL(); f_900D230(c); RELOAD();
    { uint32_t v_ = 0xA57u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037398u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028518u);
    esp -= 4; M32(esp) = 0x9010A49u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD0u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    ecx = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x40u)), ecx, &f);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    edi = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9010A65u; SPILL(); f_901E170(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.sf == f.of)) goto L_9010A80;
    goto L_9010A6C;
L_9010A6C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0x1Cu)), &f));
    M32((uint32_t)(ebp + 0x1Cu)) = (uint32_t)((uint32_t)0x0u);
    eax = (uint32_t)(dec32(eax, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xCu)), eax, &f));
L_9010A80:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010B32;
    goto L_9010A8D;
L_9010A8D:
    (void)sub32(TL32((uint32_t)(ebx + 0x14u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010B32;
    goto L_9010A97;
L_9010A97:
    (void)sub32(TL32((uint32_t)(ebx + 0x108u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010B32;
    goto L_9010AA4;
L_9010AA4:
    (void)sub32(TL32((uint32_t)(ebx + 0x110u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010B32;
    goto L_9010AB1;
L_9010AB1:
    (void)sub32(TL32((uint32_t)(ebx + 0x4BCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010B32;
    goto L_9010ABA;
L_9010ABA:
    eax = (uint32_t)((uint32_t)0x80000u);
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0x30u)) & eax), &f);
    if (!f.zf) goto L_9010B10;
    goto L_9010AC4;
L_9010AC4:
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & eax), &f);
    if (!f.zf) goto L_9010B10;
    goto L_9010AC9;
L_9010AC9:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ecx, TL32((uint32_t)(ebx + 0x8u)), &f);
    if (!f.cf) goto L_9010B10;
    goto L_9010AD1;
L_9010AD1:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9010ADAu; SPILL(); f_9010750(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010B28;
    goto L_9010AE1;
L_9010AE1:
    { uint32_t v_ = 0x9028518u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xA72u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    TS32((uint32_t)(ebx + 0x1DCu), (uint32_t)((uint32_t)0x0u));
    esp -= 4; M32(esp) = 0x9010AFFu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 48; SPILL(); return;
L_9010B10:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9010B19u; SPILL(); f_9010750(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010B28;
    goto L_9010B20;
L_9010B20:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x1u);
L_9010B28:
    TS32((uint32_t)(ebx + 0x10Cu), (uint32_t)((uint32_t)0x0u));
L_9010B32:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010B5C;
    goto L_9010B3B;
L_9010B3B:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90375F8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902848Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA7Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9010B59u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_9010B5C:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    TS32((uint32_t)(ebx + 0x4A8u), (uint32_t)(esi));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.sf) goto L_9010C1B;
    goto L_9010B6D;
L_9010B6D:
    (void)sub32(TL32((uint32_t)(ebx + 0x34u)), (uint32_t)0x4Bu, &f);
    if (!f.cf) goto L_9010C1B;
    goto L_9010B77;
L_9010B77:
    (void)sub32(TL32((uint32_t)(ebx + 0x4DCu)), (uint32_t)0x6132424Bu, &f);
    if (f.zf) goto L_9010C1B;
    goto L_9010B87;
L_9010B87:
    (void)sub32(TL32((uint32_t)(ebx + 0xD4u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010BCE;
    goto L_9010B90;
L_9010B90:
    eax = (uint32_t)((uint32_t)0x64u);
    TS32((uint32_t)(ebx + 0x128u), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0x34u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    TS32((uint32_t)(ebx + 0x468u), (uint32_t)(add32(TL32((uint32_t)(ebx + 0x468u)), eax, &f)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    esp -= 4; M32(esp) = 0x9010BB8u; SPILL(); f_9001070(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xF4u)));
    TS32((uint32_t)(ebx + 0xD4u), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0xD8u), (uint32_t)(eax));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x0u));
L_9010BCE:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0xE0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9010C1B;
    goto L_9010BD8;
L_9010BD8:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD0u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    ecx = (uint32_t)((uint32_t)(ecx + ecx*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)((uint32_t)(ecx + eax + 0x18u));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xF0u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp -= 4; M32(esp) = 0x9010C19u; SPILL(); f_901DC10(c); RELOAD();
    goto L_9010C55;
L_9010C1B:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD0u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)((uint32_t)(ecx + ecx*2));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)((uint32_t)(ecx + eax + 0x18u));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010C55u; SPILL(); f_901D950(c); RELOAD();
L_9010C55:
    { uint32_t v_ = 0x9028518u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xA9Au);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x9010C69u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010C87;
    goto L_9010C75;
L_9010C75:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0xA9Du; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9010C87u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9010C87:
    TS32((uint32_t)(ebx + 0x1DCu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 48; SPILL(); return;
L_9010C9E:
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebx + 0x4BCu)), eax, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(f.zf);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(edx);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 48; SPILL(); return;
}

void f_9010CC0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010CC0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_9010CCB;
    goto L_9010CC7;
L_9010CC7:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9010CCB:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4ACu)));
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.zf) goto L_9010CC7;
    goto L_9010CD6;
L_9010CD6:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1D0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9010CE7;
    goto L_9010CE0;
L_9010CE0:
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)((uint32_t)0x1u));
L_9010CE7:
    (void)sub32(TL32((uint32_t)(esi + 0x1Cu)), edi, &f);
    if (!f.zf) goto L_9010CC7;
    goto L_9010CEC;
L_9010CEC:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x470u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9010D09;
    goto L_9010CF6;
L_9010CF6:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9010D09;
    goto L_9010CFB;
L_9010CFB:
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    TS32((uint32_t)(esi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x498u)), ecx, &f)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)(edi));
L_9010D09:
    (void)sub32(TL32((uint32_t)(esi + 0x4B8u)), edi, &f);
    if (f.zf) goto L_9010D3A;
    goto L_9010D11;
L_9010D11:
    TS32((uint32_t)(esi + 0x4B8u), (uint32_t)(edi));
    (void)sub32(TL32((uint32_t)(esi + 0x110u)), edi, &f);
    if (f.zf) goto L_9010D2E;
    goto L_9010D1F;
L_9010D1F:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010D26u; SPILL(); f_9013840(c); RELOAD();
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010D2Eu; SPILL(); f_9013840(c); RELOAD();
L_9010D2E:
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)(edi));
L_9010D3A:
    (void)sub32(TL32((uint32_t)(esi + 0x108u)), edi, &f);
    if (f.zf) goto L_9010D4E;
    goto L_9010D42;
L_9010D42:
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)(edi));
L_9010D4E:
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x1DCu), (uint32_t)((uint32_t)0x1u));
    (void)sub32(TL32((uint32_t)(esi + 0x114u)), edi, &f);
    if (f.zf) goto L_9010D9D;
    goto L_9010D66;
L_9010D66:
    (void)sub32(TL32((uint32_t)(esi + 0xD0u)), edi, &f);
    if (f.zf) goto L_9010D9D;
    goto L_9010D6E;
L_9010D6E:
    (void)sub32(TL32((uint32_t)(esi + 0x4DCu)), (uint32_t)0x6132424Bu, &f);
    if (f.zf) goto L_9010D9D;
    goto L_9010D7A;
L_9010D7A:
    (void)sub32(TL32((uint32_t)(esi + 0x10Cu)), edi, &f);
    if (!f.zf) goto L_9010D9D;
    goto L_9010D82;
L_9010D82:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xD8u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9010D9D;
    goto L_9010D8C;
L_9010D8C:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xF4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010D9Au; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9010D9D:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xD8u)));
    TS32((uint32_t)(esi + 0x128u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0xDCu), (uint32_t)(edx));
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9010DC0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010DC0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xD0u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9010DE9;
    goto L_9010DD3;
L_9010DD3:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ (uint32_t)0x1u), &f));
    edx = (uint32_t)((uint32_t)(eax + eax*2));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edx + ecx + 0x1Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010DE9;
    goto L_9010DE6;
L_9010DE6:
    TS32((uint32_t)(ecx + 0x14u), (uint32_t)(eax));
L_9010DE9:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    eax = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFFu));
    TS32((uint32_t)(esi + 0x454u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_9010E0A;
    goto L_9010DFD;
L_9010DFD:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x450u)));
    eax = (uint32_t)(dec32(eax, &f));
    TS32((uint32_t)(esi + 0x454u), (uint32_t)(eax));
L_9010E0A:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4B0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9010E62;
    goto L_9010E14;
L_9010E14:
    eax = (uint32_t)(edi);
    eax = (uint32_t)(sub32(eax, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x480u)));
    (void)sub32(eax, ecx, &f);
    if ((f.cf || f.zf)) goto L_9010E48;
    goto L_9010E22;
L_9010E22:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4ACu)));
    TS32((uint32_t)(esi + 0x488u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x484u)));
    TS32((uint32_t)(esi + 0x48Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x480u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x484u), (uint32_t)(edx));
    goto L_9010E62;
L_9010E48:
    (void)sub32(edi, TL32((uint32_t)(esi + 0x488u)), &f);
    if ((f.cf || f.zf)) goto L_9010E62;
    goto L_9010E50;
L_9010E50:
    TS32((uint32_t)(esi + 0x488u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4ACu)));
    TS32((uint32_t)(esi + 0x48Cu), (uint32_t)(eax));
L_9010E62:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x434u)));
    TS32((uint32_t)(esi + 0x4B0u), (uint32_t)(edi));
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(edi));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x43Cu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x490u)));
    TS32((uint32_t)(ecx + eax*4), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x438u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x494u)));
    TS32((uint32_t)(ecx + eax*4), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x440u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x498u)));
    TS32((uint32_t)(ecx + eax*4), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1E4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x444u)));
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1E8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x448u)));
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1ECu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x44Cu)));
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(eax));
    (void)sub32(TL32((uint32_t)(esi + 0x464u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010F42;
    goto L_9010EFE;
L_9010EFE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4A0u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4A4u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x3E8u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x434u)));
    TS32((uint32_t)(eax + ebx*4), (uint32_t)(edx));
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(esi + 0x464u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x1ECu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x1E8u), (uint32_t)(eax));
    goto L_9010F5D;
L_9010F42:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010F5D;
    goto L_9010F4B;
L_9010F4B:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9010F5D;
    goto L_9010F57;
L_9010F57:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010F5Du; SPILL(); f_900DDF0(c); RELOAD();
L_9010F5D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xDCu)));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(esi + 0xE0u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010F74;
    goto L_9010F71;
L_9010F71:
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(edi));
L_9010F74:
    TS32((uint32_t)(esi + 0x460u), (uint32_t)(inc32(TL32((uint32_t)(esi + 0x460u)), &f)));
    (void)sub32(TL32((uint32_t)(esi + 0x474u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010FA5;
    goto L_9010F83;
L_9010F83:
    esp -= 4; M32(esp) = 0x9010F88u; SPILL(); f_90159C0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    edx = (uint32_t)(dec32(edx, &f));
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x478u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)((uint32_t)0x0u));
L_9010FA5:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x4ACu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x128u)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x1DCu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9010FE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9010FE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)((uint32_t)0x40B4u);
    esp -= 4; M32(esp) = 0x9010FEDu; SPILL(); f_9001E10(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFBF58u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)((uint32_t)(eax + 0x4u));
    ecx = (uint32_t)((uint32_t)(eax + ecx));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFBF5Cu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFBF50u)) = (uint32_t)(ecx);
    if (f.zf) goto L_90111D4;
    goto L_9011025;
L_9011025:
    edx = (uint32_t)((uint32_t)(edx + edx*2));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x7u, &f));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(esi + 0x154u)), &f));
    edi = (uint32_t)(TL32((uint32_t)(edx)));
    edi = (uint32_t)(sub32(edi, TL32((uint32_t)(edx + 0x18u)), &f));
    esi = (uint32_t)(TL32((uint32_t)(edx + 0x14u)));
    M32((uint32_t)(ebp + 0xFFFFBF60u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFBF4Cu)) = (uint32_t)(edi);
    if (!f.sf) goto L_9011064;
    goto L_9011047;
L_9011047:
    edi = (uint32_t)(add32(edi, TL32((uint32_t)(edx + 0x8u)), &f));
    M32((uint32_t)(ebp + 0xFFFFBF4Cu)) = (uint32_t)(edi);
    goto L_9011064;
L_9011052:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF60u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF4Cu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF5Cu)));
L_9011064:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)sub32(eax, ecx, &f);
    if ((!f.cf && !f.zf)) goto L_90111D4;
    goto L_901106F;
L_901106F:
    (void)sub32(eax, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_90111D4;
    goto L_9011078;
L_9011078:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFBF50u)), ecx, &f);
    if ((!f.cf && !f.zf)) goto L_90111D4;
    goto L_9011084;
L_9011084:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFBF54u)) = (uint32_t)(ecx);
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if ((f.cf || f.zf)) goto L_90110A0;
    goto L_9011097;
L_9011097:
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFBF54u)) = (uint32_t)(ecx);
L_90110A0:
    edi = (uint32_t)(TL32((uint32_t)(edx)));
    ebx = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    (void)sub32(ebx, ecx, &f);
    edx = (uint32_t)((uint32_t)(eax + eax));
    if ((!f.cf && !f.zf)) { ebx = (uint32_t)(ecx); }
    M32((uint32_t)(ebp + 0xFFFFBF64u)) = (uint32_t)(edi);
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_90110C0;
    goto L_90110BC;
L_90110BC:
    ecx = (uint32_t)(edi);
    goto L_90110D3;
L_90110C0:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFBF77u));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    (void)sub32(ebx, eax, &f);
    if (!f.cf) goto L_90110D3;
    goto L_90110CD;
L_90110CD:
    M32((uint32_t)(ebp + 0xFFFFBF64u)) = (uint32_t)(ecx);
L_90110D3:
    (void)sub32(TL32((uint32_t)(esi + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90110DD;
    goto L_90110D9;
L_90110D9:
    edx = (uint32_t)(logic32(0, &f));
    goto L_90110E0;
L_90110DD:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
L_90110E0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    fpush(c, (double)MF32((uint32_t)(esi + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF50u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    eax = (uint32_t)((uint32_t)(esi + 0x34u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF64u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF5Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    esp -= 4; M32(esp) = 0x9011124u; SPILL(); f_9018600(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFBF5Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFBF5Cu)), eax, &f));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    edi = (uint32_t)(sub32(edi, TL32((uint32_t)(esi + 0x14u)), &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF58u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF60u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x34u, &f));
    (void)sub32(edi, eax, &f);
    if ((!f.cf && !f.zf)) { edi = (uint32_t)(eax); }
    eax = (uint32_t)(sub32(eax, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFBF58u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF54u)));
    (void)sub32(edi, eax, &f);
    if ((!f.cf && !f.zf)) { edi = (uint32_t)(eax); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF64u)));
    TS32((uint32_t)(esi + 0x20u), (uint32_t)((uint32_t)0x0u));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9011170;
    goto L_901116A;
L_901116A:
    ecx = (uint32_t)(add32(ecx, edi, &f));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    goto L_90111C7;
L_9011170:
    (void)sub32(ebx, edi, &f);
    if (!f.cf) goto L_90111B4;
    goto L_9011174;
L_9011174:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_9011197;
    goto L_9011178;
L_9011178:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011180u; SPILL(); f_9001FE0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF60u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFBF64u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFBF64u)), ebx, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF64u)));
L_9011197:
    edx = (uint32_t)(TL32((uint32_t)(edx + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90111A2u; SPILL(); f_9001FE0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF60u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    goto L_90111C7;
L_90111B4:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90111BCu; SPILL(); f_9001FE0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFBF60u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(eax), (uint32_t)(add32(TL32((uint32_t)(eax)), edi, &f)));
L_90111C7:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFBF58u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9011052;
    goto L_90111D4;
L_90111D4:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90111E1u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

