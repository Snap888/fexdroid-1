#include "funcs_bink.h"
#include "lift_prelude.h"

void f_900AA20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AA20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xD4u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x13u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031154u)); esp -= 4; M32(esp) = 0x900AA37u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900AD3C;
    goto L_900AA3F;
L_900AA3F:
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x54u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900AA4Eu; SPILL(); f_9001EB0(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)((uint32_t)0x6Cu);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(esp + 0xC8u)) = (uint32_t)((uint32_t)0x200u);
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x64u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900AA80u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, (uint32_t)0x887601C2u, &f);
    if (!f.zf) goto L_900AAAF;
    goto L_900AA87;
L_900AA87:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x6Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900AA8Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900AD3C;
    goto L_900AA97;
L_900AA97:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x64u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900AAA8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, (uint32_t)0x887601C2u, &f);
    if (f.zf) goto L_900AA87;
    goto L_900AAAF;
L_900AAAF:
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900AD3C;
    goto L_900AAB7;
L_900AAB7:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x74u)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x80u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900AAC7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(TL32((uint32_t)(0x903FEF0u)), eax, &f);
    if (!f.zf) goto L_900AAFB;
    goto L_900AAD2;
L_900AAD2:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEF4u)));
    (void)sub32(ecx, M32((uint32_t)(esp + 0x74u)), &f);
    if (!f.zf) goto L_900AAFB;
    goto L_900AADE;
L_900AADE:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEF8u)));
    (void)sub32(edx, M32((uint32_t)(esp + 0xA4u)), &f);
    if (!f.zf) goto L_900AAFB;
    goto L_900AAED;
L_900AAED:
    eax = (uint32_t)(TL32((uint32_t)(0x9028004u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900AAFB:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x900AB02u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(esp + 0x28u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)((uint32_t)0x200u);
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x900A980u);
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x44u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x4Cu)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)((uint32_t)0x90370B4u);
    { uint32_t t_ = TL32((uint32_t)(0x9031164u)); esp -= 4; M32(esp) = 0x900AB4Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)((uint32_t)(esp + 0x1Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031150u)); esp -= 4; M32(esp) = 0x900AB55u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFF0u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFFFFFF0u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90000000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90370C2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90370B4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031140u)); esp -= 4; M32(esp) = 0x900AB84u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0xD4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031144u)); esp -= 4; M32(esp) = 0x900AB98u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    edx = (uint32_t)((uint32_t)(esp + 0x10u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    { uint32_t t_ = TL32((uint32_t)(0x9031120u)); esp -= 4; M32(esp) = 0x900ABB4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900ABB4:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(inc32(esi, &f));
    { uint32_t t_ = TL32((uint32_t)(0x9031138u)); esp -= 4; M32(esp) = 0x900ABBDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900ABB4;
    goto L_900ABC1;
L_900ABC1:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900ABC8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031028u)); esp -= 4; M32(esp) = 0x900ABDDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900ABEDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903111Cu)); esp -= 4; M32(esp) = 0x900ABF7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    goto L_900AC00;
L_900AC00:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(dec32(esi, &f));
    { uint32_t t_ = TL32((uint32_t)(0x9031138u)); esp -= 4; M32(esp) = 0x900AC09u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf != f.of)) goto L_900AC00;
    goto L_900AC0D;
L_900AC0D:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903111Cu)); esp -= 4; M32(esp) = 0x900AC17u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x64u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900AC2Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)M32((uint32_t)(esp + 0xA4u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)M32((uint32_t)(esp + 0x20u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(esp + 0x74u)), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(dec8(((uint8_t)eax), &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x74u)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x80u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900AC63u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900AC63:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(inc32(esi, &f));
    { uint32_t t_ = TL32((uint32_t)(0x9031138u)); esp -= 4; M32(esp) = 0x900AC6Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900AC63;
    goto L_900AC70;
L_900AC70:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900AC77u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031028u)); esp -= 4; M32(esp) = 0x900AC8Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    (void)sub32(ecx, eax, &f);
    if (f.zf) goto L_900ACAE;
    goto L_900AC92;
L_900AC92:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031010u)); esp -= 4; M32(esp) = 0x900ACA4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900ACB6;
L_900ACAE:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x1u);
L_900ACB6:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900ACBEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031118u)); esp -= 4; M32(esp) = 0x900ACC5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90370B4u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903113Cu)); esp -= 4; M32(esp) = 0x900ACD5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.zf || f.sf != f.of)) goto L_900ACEF;
    goto L_900ACD9;
L_900ACD9:
    esp = (uint32_t)((uint32_t)(esp));
L_900ACE0:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(dec32(esi, &f));
    { uint32_t t_ = TL32((uint32_t)(0x9031138u)); esp -= 4; M32(esp) = 0x900ACE9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900ACE0;
    goto L_900ACED;
L_900ACED:
    goto L_900AD00;
L_900ACEF:
    if ((f.sf == f.of)) goto L_900AD00;
    goto L_900ACF1;
L_900ACF1:
    esi = (uint32_t)(neg32(esi, &f));
L_900ACF3:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031138u)); esp -= 4; M32(esp) = 0x900ACFBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900ACF3;
    goto L_900AD00;
L_900AD00:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903111Cu)); esp -= 4; M32(esp) = 0x900AD0Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x74u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0xA4u)));
    TS32((uint32_t)(0x903FEF0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(0x903FEF4u), (uint32_t)(ecx));
    TS32((uint32_t)(0x903FEF8u), (uint32_t)(edx));
    TS32((uint32_t)(0x9028004u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900AD3C:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900AD50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AD50:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(0x903FEFCu)), edi, &f);
    if (!f.zf) goto L_900AD7A;
    goto L_900AD62;
L_900AD62:
    esi = (uint32_t)(TL32((uint32_t)(0x9031154u)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900AD6Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEFCu), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900AD75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9028110u), (uint32_t)(eax));
L_900AD7A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900AD98;
    goto L_900AD8D;
L_900AD8D:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900AD98u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900AD98:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031150u)); esp -= 4; M32(esp) = 0x900ADA2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEFCu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)((uint32_t)(ecx + eax));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    (void)sub32(edx, ecx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900ADE9;
    goto L_900ADB5;
L_900ADB5:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    (void)sub32(eax, ecx, &f);
    if ((f.sf == f.of)) goto L_900ADE9;
    goto L_900ADBE;
L_900ADBE:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028110u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)((uint32_t)(ecx + eax));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(edx, ecx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900ADE9;
    goto L_900ADD1;
L_900ADD1:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    (void)sub32(eax, ecx, &f);
    if ((f.sf == f.of)) goto L_900ADE9;
    goto L_900ADDA;
L_900ADDA:
    esi = (uint32_t)(TL32((uint32_t)(0x9031138u)));
L_900ADE0:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(inc32(edi, &f));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900ADE5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900ADE0;
    goto L_900ADE9;
L_900ADE9:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

void f_900AE00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AE00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900AE1C;
    goto L_900AE0B;
L_900AE0B:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(0x9031138u)));
L_900AE12:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(dec32(esi, &f));
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900AE17u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900AE12;
    goto L_900AE1B;
L_900AE1B:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_900AE1C:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900AE30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AE30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(0x903FEC4u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FEC8u), (uint32_t)(ecx));
    TS32((uint32_t)(0x903FECCu), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900AE60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AE60:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x5Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(esi + 0x68u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_900AFD6;
    goto L_900AE78;
L_900AE78:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031158u)); esp -= 4; M32(esp) = 0x900AE82u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900AFB6;
    goto L_900AE8A;
L_900AE8A:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    edi = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(ecx, eax, &f);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    if ((f.zf || f.sf != f.of)) goto L_900AEB2;
    goto L_900AEAC;
L_900AEAC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(ecx);
    goto L_900AEBE;
L_900AEB2:
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(neg32(edi, &f));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edi);
L_900AEBE:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    (void)sub32(edx, eax, &f);
    if ((f.zf || f.sf != f.of)) goto L_900AECB;
    goto L_900AEC5;
L_900AEC5:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edx);
    goto L_900AED7;
L_900AECB:
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(neg32(ebx, &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
L_900AED7:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    (void)sub32(eax, edx, &f);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(ecx);
    if ((f.zf || f.sf != f.of)) goto L_900AF05;
    goto L_900AEF3;
L_900AEF3:
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x18u)), ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
L_900AF05:
    edx = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    (void)sub32(ecx, edx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900AF1F;
    goto L_900AF0F;
L_900AF0F:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x1Cu)), edx, &f));
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(ecx);
L_900AF1F:
    (void)sub32(M32((uint32_t)(esp + 0x18u)), edi, &f);
    if ((f.sf != f.of)) goto L_900AFB6;
    goto L_900AF29;
L_900AF29:
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), ebx, &f);
    if ((f.sf != f.of)) goto L_900AFB6;
    goto L_900AF33;
L_900AF33:
    (void)sub32(eax, M32((uint32_t)(esp + 0x20u)), &f);
    if ((f.sf != f.of)) goto L_900AFB6;
    goto L_900AF39;
L_900AF39:
    (void)sub32(ecx, M32((uint32_t)(esp + 0x24u)), &f);
    if ((f.sf != f.of)) goto L_900AFB6;
    goto L_900AF3F;
L_900AF3F:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (f.zf) goto L_900AF55;
    goto L_900AF47;
L_900AF47:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900AF5C;
    goto L_900AF4C;
L_900AF4C:
    TS32((uint32_t)(esi + 0x70u), (uint32_t)((uint32_t)0x1u));
    goto L_900AF5C;
L_900AF55:
    TS32((uint32_t)(esi + 0x70u), (uint32_t)((uint32_t)0x0u));
L_900AF5C:
    eax = (uint32_t)(TL32((uint32_t)(0x9028114u)));
    edx = (uint32_t)((uint32_t)(esp + 0x30u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    edx = (uint32_t)(neg32(edx, &f));
    edx = (uint32_t)(sbb32(edx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3E00u), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x200u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0x800u), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    edx = (uint32_t)((uint32_t)(esp + 0x20u));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)((uint32_t)0x38u);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x84u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900AFAFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900AFB6:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x84u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900AFD6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900AFD6:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900AFE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900AFE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900B084;
    goto L_900AFEE;
L_900AFEE:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B04C;
    goto L_900AFF8;
L_900AFF8:
    edi = (uint32_t)(TL32((uint32_t)(ecx + 0x1Cu)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, edi, &f));
    (void)sub32(TL32((uint32_t)(ecx + 0x84u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B021;
    goto L_900B008;
L_900B008:
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    ebx = (uint32_t)((uint32_t)(esi + eax));
    (void)sub32(ebx, edx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B01B;
    goto L_900B017;
L_900B017:
    edx = (uint32_t)(sub32(edx, esi, &f));
    eax = (uint32_t)(edx);
L_900B01B:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900B021;
    goto L_900B01F;
L_900B01F:
    eax = (uint32_t)(logic32(0, &f));
L_900B021:
    edx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    (void)sub32(edx, (uint32_t)0x4u, &f);
    if (!f.zf) goto L_900B032;
    goto L_900B02C;
L_900B02C:
    eax = (uint32_t)(inc32(eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    goto L_900B045;
L_900B032:
    (void)sub32(edx, (uint32_t)0x3u, &f);
    if (!f.zf) goto L_900B03F;
    goto L_900B037;
L_900B037:
    eax = (uint32_t)(add32(eax, (uint32_t)0x7u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f));
    goto L_900B045;
L_900B03F:
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
L_900B045:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(sub32(eax, edi, &f));
    TS32((uint32_t)(edx), (uint32_t)(eax));
L_900B04C:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900B081;
    goto L_900B053;
L_900B053:
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(add32(eax, esi, &f));
    (void)sub32(TL32((uint32_t)(ecx + 0x84u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B07D;
    goto L_900B063;
L_900B063:
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    ebx = (uint32_t)((uint32_t)(ecx + eax));
    (void)sub32(ebx, edx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B077;
    goto L_900B073;
L_900B073:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    eax = (uint32_t)(edx);
L_900B077:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900B07D;
    goto L_900B07B;
L_900B07B:
    eax = (uint32_t)(logic32(0, &f));
L_900B07D:
    eax = (uint32_t)(sub32(eax, esi, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
L_900B081:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_900B084:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900B090(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B090:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900B0AA;
    goto L_900B0A1;
L_900B0A1:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_900B0AA:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031128u)); esp -= 4; M32(esp) = 0x900B0B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(esi + 0x64u), (uint32_t)(eax));
    if (!f.zf) goto L_900B10F;
    goto L_900B0BF;
L_900B0BF:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    ecx = (uint32_t)((uint32_t)(esp + 0x8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)((uint32_t)0x0u);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900B0DEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + 0x10u)) | (uint32_t)0x80000000u), &f)));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(esi + 0x58u), (uint32_t)(eax));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    TS32((uint32_t)(esi + 0x54u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900B10Cu; SPILL(); f_900AE60(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900B10F:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900B120(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B120:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    esi = (uint32_t)(ecx);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    (void)sub32(eax, (uint32_t)0xFu, &f);
    if ((!f.cf && !f.zf)) goto L_900B29C;
    goto L_900B13A;
L_900B13A:
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x900B2BCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { jt_ = TL32((uint32_t)(eax*4 + 0x900B2A4u)); goto L_dispatch; }
L_900B149:
    ebx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)edi; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B15D;
L_900B15D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_900B160:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B169u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B160;
    goto L_900B174;
L_900B174:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B17B:
    ebx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)edi; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B18F;
L_900B18F:
L_900B190:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B199u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B190;
    goto L_900B1A4;
L_900B1A4:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B1AB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_900B1CB;
    goto L_900B1B2;
L_900B1B2:
    ebx = (uint32_t)(eax);
L_900B1B4:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B1BDu; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ebx = (uint32_t)(sub32(ebx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B1B4;
    goto L_900B1C8;
L_900B1C8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
L_900B1CB:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(eax);
    if (f.zf) goto L_900B1FA;
    goto L_900B1D9;
L_900B1D9:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    esp = (uint32_t)((uint32_t)(esp));
L_900B1E0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B1ECu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B1E0;
    goto L_900B1F7;
L_900B1F7:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
L_900B1FA:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B202;
L_900B202:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
L_900B205:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B211u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B205;
    goto L_900B21C;
L_900B21C:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B223:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B22A;
L_900B22A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_900B230:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x80u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    c->df = 0;
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x80u);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f));
    while (ecx) { M16(edi) = (uint16_t)eax; edi += (c->df ? -2 : 2); ecx--; }
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    if (!f.zf) goto L_900B230;
    goto L_900B25B;
L_900B25B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B262:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B269;
L_900B269:
    esp = (uint32_t)((uint32_t)(esp));
L_900B270:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x8000u);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    c->df = 0;
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x8000u);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f));
    while (ecx) { M16(edi) = (uint16_t)eax; edi += (c->df ? -2 : 2); ecx--; }
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    if (!f.zf) goto L_900B270;
    goto L_900B29B;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_900B29C:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B120u: goto L_900B120; case 0x900B13Au: goto L_900B13A; case 0x900B149u: goto L_900B149; case 0x900B15Du: goto L_900B15D; case 0x900B160u: goto L_900B160; case 0x900B174u: goto L_900B174; case 0x900B17Bu: goto L_900B17B; case 0x900B18Fu: goto L_900B18F; case 0x900B190u: goto L_900B190; case 0x900B1A4u: goto L_900B1A4; case 0x900B1ABu: goto L_900B1AB; case 0x900B1B2u: goto L_900B1B2; case 0x900B1B4u: goto L_900B1B4; case 0x900B1C8u: goto L_900B1C8; case 0x900B1CBu: goto L_900B1CB; case 0x900B1D9u: goto L_900B1D9; case 0x900B1E0u: goto L_900B1E0; case 0x900B1F7u: goto L_900B1F7; case 0x900B1FAu: goto L_900B1FA; case 0x900B202u: goto L_900B202; case 0x900B205u: goto L_900B205; case 0x900B21Cu: goto L_900B21C; case 0x900B223u: goto L_900B223; case 0x900B22Au: goto L_900B22A; case 0x900B230u: goto L_900B230; case 0x900B25Bu: goto L_900B25B; case 0x900B262u: goto L_900B262; case 0x900B269u: goto L_900B269; case 0x900B270u: goto L_900B270; case 0x900B29Bu: goto L_900B29B; case 0x900B29Cu: goto L_900B29C; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900B149(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B149:
    ebx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)edi; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B15D;
L_900B15D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_900B160:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B169u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B160;
    goto L_900B174;
L_900B174:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B17B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B17B:
    ebx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)edi; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B18F;
L_900B18F:
L_900B190:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B199u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B190;
    goto L_900B1A4;
L_900B1A4:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B1AB(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B1AB:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_900B1CB;
    goto L_900B1B2;
L_900B1B2:
    ebx = (uint32_t)(eax);
L_900B1B4:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B1BDu; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(ebp + 0x8u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ebx = (uint32_t)(sub32(ebx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900B1B4;
    goto L_900B1C8;
L_900B1C8:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
L_900B1CB:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0x10u), (uint32_t)(eax));
    if (f.zf) goto L_900B1FA;
    goto L_900B1D9;
L_900B1D9:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(eax));
    esp = (uint32_t)((uint32_t)(esp));
L_900B1E0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B1ECu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900B1E0;
    goto L_900B1F7;
L_900B1F7:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
L_900B1FA:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B202;
L_900B202:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(eax));
L_900B205:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B211u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900B205;
    goto L_900B21C;
L_900B21C:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B223(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B223:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B22A;
L_900B22A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_900B230:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x80u);
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    c->df = 0;
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x80u);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f));
    while (ecx) { M16(edi) = (uint16_t)eax; edi += (c->df ? -2 : 2); ecx--; }
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    if (!f.zf) goto L_900B230;
    goto L_900B25B;
L_900B25B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B262(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B262:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.cf || f.zf)) goto L_900B29B;
    goto L_900B269;
L_900B269:
    esp = (uint32_t)((uint32_t)(esp));
L_900B270:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x8000u);
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    c->df = 0;
    eax = (eax & 0xFFFF0000u) | (uint16_t)((uint16_t)0x8000u);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f));
    while (ecx) { M16(edi) = (uint16_t)eax; edi += (c->df ? -2 : 2); ecx--; }
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    if (!f.zf) goto L_900B270;
    goto L_900B29B;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B29B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B29B:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B2BC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B2BC:
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x5050501u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1010105u, &f));
    TS32((uint32_t)(edx), (uint32_t)(add32(TL32((uint32_t)(edx)), eax, &f)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(esp + ecx*8)), &f));
    SPILL(); rt_int3(c, 0x900B2CDu);
    { SPILL(); rt_call(c, 0x900B2CEu); return; }
}

void f_900B2D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B2D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x6Cu, &f));
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B2E3u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)((uint32_t)0x6Cu);
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)((uint32_t)0x1007u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x4080u);
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)((uint32_t)0x20u);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)((uint32_t)0x4u);
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x18u)));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900B32Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B354;
    goto L_900B330;
L_900B330:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x64u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B345u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B35A;
    goto L_900B349;
L_900B349:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900B354u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900B354:
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B35A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFA4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp -= 4; M32(esp) = 0x900B36Bu; SPILL(); f_900B120(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x80u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B380u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B390(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B390:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x6Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B3A7u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(dec32(ecx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3800u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x800u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0x40u), &f));
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)((uint32_t)0x6Cu);
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)((uint32_t)0x7u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = (uint32_t)(edi);
    (void)sub32(esi, (uint32_t)0x10u, &f);
    if ((f.cf || f.zf)) goto L_900B3F4;
    goto L_900B3DC;
L_900B3DC:
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)((uint32_t)0x1007u);
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)((uint32_t)0x20u);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)((uint32_t)0x4u);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
L_900B3F4:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x18u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900B40Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B433;
    goto L_900B40F;
L_900B40F:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x64u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B424u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B43A;
    goto L_900B428;
L_900B428:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900B433u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900B433:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B43A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFA4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp -= 4; M32(esp) = 0x900B44Bu; SPILL(); f_900B120(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x80u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B460u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B470(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B470:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x42Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    if ((f.zf || f.sf != f.of)) goto L_900B4C2;
    goto L_900B491;
L_900B491:
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(eax, (uint32_t)0x3u, &f);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0xFF0000u));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)((uint32_t)0xFF00u));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)((uint32_t)0xFFu));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)((uint32_t)(ecx + ecx + 0x1u));
    eax = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x900B4BEu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B4C2:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFBD4u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B4D6u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFBD4u)) = (uint32_t)((uint32_t)0x28u);
    { uint32_t t_ = TL32((uint32_t)(0x9031020u)); esp -= 4; M32(esp) = 0x900B4EEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B552;
    goto L_900B4F4;
L_900B4F4:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFBD4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903100Cu)); esp -= 4; M32(esp) = 0x900B50Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFBD4u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903100Cu)); esp -= 4; M32(esp) = 0x900B522u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900B529u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFBE4u)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_900B552;
    goto L_900B532;
L_900B532:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFBFCu)), (uint32_t)0xF800u, &f);
    if (!f.zf) goto L_900B552;
    goto L_900B53E;
L_900B53E:
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0xF800u));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)((uint32_t)0x7E0u));
    eax = (uint32_t)((uint32_t)0xAu);
    goto L_900B564;
L_900B552:
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x7C00u));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)((uint32_t)0x3E0u));
    eax = (uint32_t)((uint32_t)0x9u);
L_900B564:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)((uint32_t)0x1Fu));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x900B577u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B580(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B580:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x6Cu, &f));
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B593u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)((uint32_t)0x6Cu);
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x200u);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x64u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B5C2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, (uint32_t)0x887601B3u, &f);
    if (!f.zf) goto L_900B5CF;
    goto L_900B5C9;
L_900B5C9:
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900B5CF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B5E7;
    goto L_900B5D3;
L_900B5D3:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x80u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B5E7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900B5E7:
    eax = (uint32_t)((uint32_t)0x1u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900B5F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900B5F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x5Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    esi = (uint32_t)(edi);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFF000000u), &f));
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x4Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x44u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(esi);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900B652;
L_900B652:
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), ebx, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900B65B;
L_900B65B:
    eax = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1Fu), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    if (!f.zf) goto L_900B670;
    goto L_900B666;
L_900B666:
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    goto L_900B679;
L_900B670:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900B74E;
    goto L_900B679;
L_900B679:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(edi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x17u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B68Au; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B733;
    goto L_900B695;
L_900B695:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B733:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B746u; SPILL(); f_900A460(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_900B69D;
L_900B74E:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(edi);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x17u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B767u; SPILL(); f_900A460(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), ebx, &f);
    if (f.zf) goto L_900BFCE;
    goto L_900B776;
L_900B776:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(edx);
    goto L_900B8AF;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
L_900B8AF:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFCE:
    ecx = (uint32_t)((uint32_t)0x7u);
    esi = (uint32_t)((uint32_t)0x9037148u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    esp -= 4; M32(esp) = 0x900BFE4u; SPILL(); f_900A660(c); RELOAD();
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B5F0u: goto L_900B5F0; case 0x900B652u: goto L_900B652; case 0x900B65Bu: goto L_900B65B; case 0x900B666u: goto L_900B666; case 0x900B670u: goto L_900B670; case 0x900B679u: goto L_900B679; case 0x900B695u: goto L_900B695; case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B733u: goto L_900B733; case 0x900B74Eu: goto L_900B74E; case 0x900B776u: goto L_900B776; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8AFu: goto L_900B8AF; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFCEu: goto L_900BFCE; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900B8D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900B8D0;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900B930(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900B930;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900B982(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900B982;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900B9E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900B9E0;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BA64(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BA64;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BACC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BACC;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BAE5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BAE5;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BB01(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BB01;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BB1B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BB1B;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900BBAF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900BBAF;
L_900B69D:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6A4;
L_900B6A4:
    (void)sub32(TL32((uint32_t)(0x903FEBCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900B6B6;
    goto L_900B6AD;
L_900B6AD:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900B6D4;
    goto L_900B6B6;
L_900B6B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x17u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B6C5u; SPILL(); f_900A690(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B6D4;
    goto L_900B6CC;
L_900B6CC:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x1u);
L_900B6D4:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    if ((f.sf != f.of)) goto L_900B897;
    goto L_900B6E1;
L_900B6E1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900B6EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903101Cu)); esp -= 4; M32(esp) = 0x900B6F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900B705u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900B897;
    goto L_900B70D;
L_900B70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B716;
L_900B716:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900B71Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B787;
    goto L_900B721;
L_900B721:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900B783;
    goto L_900B726;
L_900B726:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B783:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_900B7CF;
L_900B787:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7A6;
    goto L_900B790;
L_900B790:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x900B79Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900B7BC;
    goto L_900B7A6;
L_900B7A6:
    { uint32_t v_ = 0x468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x900B7B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900B7C9;
    goto L_900B7BC;
L_900B7BC:
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900B897;
L_900B7C9:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_900B7CF:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, ebx, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900B7F5;
    goto L_900B7EC;
L_900B7EC:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
L_900B7F5:
    { uint32_t v_ = 0x428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900B806u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED0u)));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ebp + 0xCu)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(ebx), (uint32_t)((uint32_t)0x28u));
    TS16((uint32_t)(ebx + 0xCu), (uint16_t)(((uint16_t)edx)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx*8));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    TS16((uint32_t)(ebx + 0xEu), (uint16_t)(((uint16_t)eax)));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(ecx));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x28u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B85Eu; SPILL(); f_900B470(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031000u)); esp -= 4; M32(esp) = 0x900B87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900BD21;
    goto L_900B886;
L_900B886:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900B88Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B897u; SPILL(); f_9001100(c); RELOAD();
L_900B897:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x14u)), esi, &f);
    if (!f.zf) goto L_900BC88;
    goto L_900B8A3;
L_900B8A3:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)((uint32_t)0x3u);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    goto L_900B8C0;
L_900B8C0:
    (void)sub32(eax, (uint32_t)0x9u, &f);
L_900B8C3:
    if ((!f.cf && !f.zf)) goto L_900BBAF;
    goto L_900B8C9;
L_900B8C9:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900BFF0u)); goto L_dispatch; }
L_900B8D0:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B8E0;
L_900B8E0:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32315659u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B8F2u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B901;
L_900B901:
    edx = (uint32_t)(eax);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B911u; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    goto L_900BBAB;
L_900B930:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B940;
L_900B940:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x32595559u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B952u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B961;
L_900B961:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B96Fu; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    goto L_900BB9F;
L_900B982:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B991;
L_900B991:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x59565955u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900B9A3u; SPILL(); f_900B2D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9B2;
L_900B9B2:
    ecx = (uint32_t)(eax);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x900B9C2u; SPILL(); f_900CAD0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    goto L_900BBAB;
L_900B9E0:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900B9E8;
L_900B9E8:
    esp -= 4; M32(esp) = 0x900B9EDu; SPILL(); f_900B580(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900B9F5;
L_900B9F5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA01u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA0B;
L_900BA0B:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BA28;
    goto L_900BA10;
L_900BA10:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x9037104u);
    edi = (uint32_t)((uint32_t)0x9028118u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    goto L_900BBAB;
L_900BA28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = 0xFFFFFFF4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0x4000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)((uint32_t)0x1u);
    { uint32_t t_ = TL32((uint32_t)(0x9031160u)); esp -= 4; M32(esp) = 0x900BA54u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA5Bu; SPILL(); f_900AA20(c); RELOAD();
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    goto L_900BBAF;
L_900BA64:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BA74;
L_900BA74:
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32315659u);
L_900BA7B:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA87u; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BA96;
L_900BA96:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BA9Cu; SPILL(); f_900CAD0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
    goto L_900BBAB;
L_900BACC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BADC;
L_900BADC:
    { uint32_t v_ = 0xDu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x32595559u);
    goto L_900BA7B;
L_900BAE5:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BAF5;
L_900BAF5:
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x59565955u);
    goto L_900BA7B;
L_900BB01:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB11;
L_900BB11:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    goto L_900BB35;
L_900BB1B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    (void)sub32(eax, esi, &f);
    if (!f.zf) goto L_900BBAF;
    goto L_900BB2A;
L_900BB2A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x1u);
L_900BB35:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    esp -= 4; M32(esp) = 0x900BB3Du; SPILL(); f_900B390(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BBAB;
    goto L_900BB48;
L_900BB48:
    esi = (uint32_t)(eax);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BB50u; SPILL(); f_900CAD0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_900BB64;
    goto L_900BB56;
L_900BB56:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BB5Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    goto L_900BBAB;
L_900BB64:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900BB82;
    goto L_900BB69;
L_900BB69:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BB75u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    goto L_900BA10;
L_900BB82:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEE4u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)((uint32_t)0x1u);
L_900BB9F:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ecx);
L_900BBAB:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_900BBAF:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BBE2;
    goto L_900BBB6;
L_900BBB6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0x18u)), &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    TS8((uint32_t)(0x9028118u), (uint8_t)((uint8_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900BBDA;
    goto L_900BBCF;
L_900BBCF:
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900B8C3;
    goto L_900BBD8;
L_900BBD8:
    goto L_900BBF6;
L_900BBDA:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    goto L_900B69D;
L_900BBE2:
    (void)sub32(M32((uint32_t)(esp + 0xCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900BC6D;
    goto L_900BBED;
L_900BBED:
    (void)sub8(TL8((uint32_t)(0x9028118u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_900BC1D;
    goto L_900BBF6;
L_900BBF6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900BC09;
    goto L_900BBFF;
L_900BBFF:
    (void)sub32(eax, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.zf || f.sf != f.of)) goto L_900BC0E;
    goto L_900BC09;
L_900BC09:
    ecx = (uint32_t)((uint32_t)0x9037120u);
L_900BC0E:
    edx = (uint32_t)((uint32_t)0x9028118u);
L_900BC13:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BC13;
    goto L_900BC1D;
L_900BC1D:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BC29;
    goto L_900BC24;
L_900BC24:
    esp -= 4; M32(esp) = 0x900BC29u; SPILL(); f_900A660(c); RELOAD();
L_900BC29:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC34;
L_900BC34:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BC41;
L_900BC41:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BC4E;
L_900BC4E:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BC62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BC6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BC83u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BD64;
L_900BC88:
    (void)sub32(TL32((uint32_t)(0x903FED0u)), (uint32_t)0x2u, &f);
    ecx = (uint32_t)((uint32_t)0x90370C4u);
    if ((f.sf != f.of)) goto L_900BC9B;
    goto L_900BC96;
L_900BC96:
    ecx = (uint32_t)((uint32_t)0x90370E4u);
L_900BC9B:
    edx = (uint32_t)((uint32_t)0x9028118u);
    edi = (uint32_t)((uint32_t)0x1u);
L_900BCA5:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & ((uint8_t)eax)), &f);
    if (!f.zf) goto L_900BCA5;
    goto L_900BCB1;
L_900BCB1:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), esi, &f);
    if (f.zf) goto L_900BCE5;
    goto L_900BCB7;
L_900BCB7:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), edi, &f)));
    if (!f.zf) goto L_900BCE5;
    goto L_900BCBF;
L_900BCBF:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCCCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BCD9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(esi));
L_900BCE5:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BCEF;
L_900BCEF:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), edi, &f)));
    if (!f.zf) goto L_900BFE4;
    goto L_900BCFB;
L_900BCFB:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), esi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BD07;
L_900BD07:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)(esi));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900BD16u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BD21:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BD29u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(0x903FED0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x2u);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)((uint32_t)0xFF000000u);
L_900BD64:
    eax = (uint32_t)((uint32_t)0xA8u);
    esp -= 4; M32(esp) = 0x900BD6Eu; SPILL(); f_9001070(c); RELOAD();
    esi = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900BE4B;
    goto L_900BD7A;
L_900BD7A:
    ecx = (uint32_t)(TL32((uint32_t)(0x9037164u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9037168u)));
    eax = (uint32_t)(TL32((uint32_t)(0x903716Cu)));
    TS32((uint32_t)(0x9028118u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(0x9037170u)));
    TS32((uint32_t)(0x902811Cu), (uint32_t)(edx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9037172u)));
    TS32((uint32_t)(0x9028120u), (uint32_t)(eax));
    TS16((uint32_t)(0x9028124u), (uint16_t)(((uint16_t)ecx)));
    TS8((uint32_t)(0x9028126u), (uint8_t)(((uint8_t)edx)));
    (void)sub32(M32((uint32_t)(esp + 0x2Cu)), edi, &f);
    if (f.zf) goto L_900BDE4;
    goto L_900BDBC;
L_900BDBC:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BDDAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900BDE2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900BDF6;
L_900BDE4:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), edi, &f);
    if (f.zf) goto L_900BDF6;
    goto L_900BDEA;
L_900BDEA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900BDF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BDF6:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900BE26;
    goto L_900BDFE;
L_900BDFE:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900BE0Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900BE15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900BE1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE26u; SPILL(); f_9001100(c); RELOAD();
L_900BE26:
    (void)sub32(M32((uint32_t)(esp + 0x28u)), edi, &f);
    if (f.zf) goto L_900BE31;
    goto L_900BE2C;
L_900BE2C:
    esp -= 4; M32(esp) = 0x900BE31u; SPILL(); f_900A660(c); RELOAD();
L_900BE31:
    (void)sub32(M32((uint32_t)(esp + 0x20u)), edi, &f);
    if (f.zf) goto L_900BFE4;
    goto L_900BE3B;
L_900BE3B:
    esp -= 4; M32(esp) = 0x900BE40u; SPILL(); f_900A8F0(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BE4B:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BE57u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(ebx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902810Cu)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031124u)); esp -= 4; M32(esp) = 0x900BF22u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x58u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x5Cu)), &f));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x64u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x9031114u)); esp -= 4; M32(esp) = 0x900BF5Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x1Cu)), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x58u));
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(esi + 0x20u)), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x903112Cu)); esp -= 4; M32(esp) = 0x900BF7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x60u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(esi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(esp + 0x64u)), &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x4u)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900BFA5u; SPILL(); f_900B090(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900BFB2u; SPILL(); f_900C720(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900BFC3;
    goto L_900BFB9;
L_900BFB9:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900BFC3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900BFC3:
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900BFE4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900B69Du: goto L_900B69D; case 0x900B6A4u: goto L_900B6A4; case 0x900B6ADu: goto L_900B6AD; case 0x900B6B6u: goto L_900B6B6; case 0x900B6CCu: goto L_900B6CC; case 0x900B6D4u: goto L_900B6D4; case 0x900B6E1u: goto L_900B6E1; case 0x900B70Du: goto L_900B70D; case 0x900B716u: goto L_900B716; case 0x900B721u: goto L_900B721; case 0x900B726u: goto L_900B726; case 0x900B783u: goto L_900B783; case 0x900B787u: goto L_900B787; case 0x900B790u: goto L_900B790; case 0x900B7A6u: goto L_900B7A6; case 0x900B7BCu: goto L_900B7BC; case 0x900B7C9u: goto L_900B7C9; case 0x900B7CFu: goto L_900B7CF; case 0x900B7ECu: goto L_900B7EC; case 0x900B7F5u: goto L_900B7F5; case 0x900B886u: goto L_900B886; case 0x900B897u: goto L_900B897; case 0x900B8A3u: goto L_900B8A3; case 0x900B8C0u: goto L_900B8C0; case 0x900B8C3u: goto L_900B8C3; case 0x900B8C9u: goto L_900B8C9; case 0x900B8D0u: goto L_900B8D0; case 0x900B8E0u: goto L_900B8E0; case 0x900B901u: goto L_900B901; case 0x900B930u: goto L_900B930; case 0x900B940u: goto L_900B940; case 0x900B961u: goto L_900B961; case 0x900B982u: goto L_900B982; case 0x900B991u: goto L_900B991; case 0x900B9B2u: goto L_900B9B2; case 0x900B9E0u: goto L_900B9E0; case 0x900B9E8u: goto L_900B9E8; case 0x900B9F5u: goto L_900B9F5; case 0x900BA0Bu: goto L_900BA0B; case 0x900BA10u: goto L_900BA10; case 0x900BA28u: goto L_900BA28; case 0x900BA64u: goto L_900BA64; case 0x900BA74u: goto L_900BA74; case 0x900BA7Bu: goto L_900BA7B; case 0x900BA96u: goto L_900BA96; case 0x900BACCu: goto L_900BACC; case 0x900BADCu: goto L_900BADC; case 0x900BAE5u: goto L_900BAE5; case 0x900BAF5u: goto L_900BAF5; case 0x900BB01u: goto L_900BB01; case 0x900BB11u: goto L_900BB11; case 0x900BB1Bu: goto L_900BB1B; case 0x900BB2Au: goto L_900BB2A; case 0x900BB35u: goto L_900BB35; case 0x900BB48u: goto L_900BB48; case 0x900BB56u: goto L_900BB56; case 0x900BB64u: goto L_900BB64; case 0x900BB69u: goto L_900BB69; case 0x900BB82u: goto L_900BB82; case 0x900BB9Fu: goto L_900BB9F; case 0x900BBABu: goto L_900BBAB; case 0x900BBAFu: goto L_900BBAF; case 0x900BBB6u: goto L_900BBB6; case 0x900BBCFu: goto L_900BBCF; case 0x900BBD8u: goto L_900BBD8; case 0x900BBDAu: goto L_900BBDA; case 0x900BBE2u: goto L_900BBE2; case 0x900BBEDu: goto L_900BBED; case 0x900BBF6u: goto L_900BBF6; case 0x900BBFFu: goto L_900BBFF; case 0x900BC09u: goto L_900BC09; case 0x900BC0Eu: goto L_900BC0E; case 0x900BC13u: goto L_900BC13; case 0x900BC1Du: goto L_900BC1D; case 0x900BC24u: goto L_900BC24; case 0x900BC29u: goto L_900BC29; case 0x900BC34u: goto L_900BC34; case 0x900BC41u: goto L_900BC41; case 0x900BC4Eu: goto L_900BC4E; case 0x900BC6Du: goto L_900BC6D; case 0x900BC88u: goto L_900BC88; case 0x900BC96u: goto L_900BC96; case 0x900BC9Bu: goto L_900BC9B; case 0x900BCA5u: goto L_900BCA5; case 0x900BCB1u: goto L_900BCB1; case 0x900BCB7u: goto L_900BCB7; case 0x900BCBFu: goto L_900BCBF; case 0x900BCE5u: goto L_900BCE5; case 0x900BCEFu: goto L_900BCEF; case 0x900BCFBu: goto L_900BCFB; case 0x900BD07u: goto L_900BD07; case 0x900BD21u: goto L_900BD21; case 0x900BD64u: goto L_900BD64; case 0x900BD7Au: goto L_900BD7A; case 0x900BDBCu: goto L_900BDBC; case 0x900BDE4u: goto L_900BDE4; case 0x900BDEAu: goto L_900BDEA; case 0x900BDF6u: goto L_900BDF6; case 0x900BDFEu: goto L_900BDFE; case 0x900BE26u: goto L_900BE26; case 0x900BE2Cu: goto L_900BE2C; case 0x900BE31u: goto L_900BE31; case 0x900BE3Bu: goto L_900BE3B; case 0x900BE4Bu: goto L_900BE4B; case 0x900BFB9u: goto L_900BFB9; case 0x900BFC3u: goto L_900BFC3; case 0x900BFE4u: goto L_900BFE4; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900C020(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C020:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900C126;
    goto L_900C02F;
L_900C02F:
    (void)sub32(TL32((uint32_t)(esi)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C126;
    goto L_900C038;
L_900C038:
    (void)sub32(TL32((uint32_t)(esi + 0x68u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C060;
    goto L_900C03E;
L_900C03E:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x200u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x84u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C05Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900C066;
L_900C060:
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C071;
    goto L_900C066;
L_900C066:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900C071u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900C071:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900C0AF;
    goto L_900C07B;
L_900C07B:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031018u)); esp -= 4; M32(esp) = 0x900C089u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031014u)); esp -= 4; M32(esp) = 0x900C096u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903102Cu)); esp -= 4; M32(esp) = 0x900C0A3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x9Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C0AFu; SPILL(); f_9001100(c); RELOAD();
L_900C0AF:
    (void)sub32(TL32((uint32_t)(esi + 0x88u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C0BD;
    goto L_900C0B8;
L_900C0B8:
    esp -= 4; M32(esp) = 0x900C0BDu; SPILL(); f_900A660(c); RELOAD();
L_900C0BD:
    (void)sub32(TL32((uint32_t)(esi + 0x8Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C0EC;
    goto L_900C0C6;
L_900C0C6:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900C0EC;
    goto L_900C0CF;
L_900C0CF:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C0EC;
    goto L_900C0D8;
L_900C0D8:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900C0ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900C0EC:
    { uint32_t v_ = 0xA8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C0F9u; SPILL(); f_9001EB0(c); RELOAD();
    edx = (uint32_t)(TL8((uint32_t)(esi + 0xFFFFFFFFu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)sub8(TL8((uint32_t)(esi + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_900C115;
    goto L_900C106;
L_900C106:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xFFFFFFF4u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(sub32(eax, edx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900C110u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C115:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    esi = (uint32_t)(sub32(esi, edx, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x900C126u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900C126:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C130(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C130:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x6Cu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900C147;
    goto L_900C13E;
L_900C13E:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C147:
    (void)sub32(TL32((uint32_t)(esi + 0x48u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_900C21A;
    goto L_900C152;
L_900C152:
    (void)sub32(TL32((uint32_t)(esi + 0x64u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900C1D4;
    goto L_900C158;
L_900C158:
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C165u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x74u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)((uint32_t)0x6Cu);
    if (f.zf) goto L_900C18E;
    goto L_900C175;
L_900C175:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C18Bu; SPILL(); f_900AD50(c); RELOAD();
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(eax));
L_900C18E:
    edi = (uint32_t)((uint32_t)0x80000000u);
L_900C193:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x64u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900C1A8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900C1DE;
    goto L_900C1AC;
L_900C1AC:
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + 0x10u)) | edi), &f)));
    (void)sub32(eax, (uint32_t)0x887601C2u, &f);
    if (!f.zf) goto L_900C1C5;
    goto L_900C1B6;
L_900C1B6:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x6Cu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900C1C1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900C193;
    goto L_900C1C5;
L_900C1C5:
    (void)sub32(TL32((uint32_t)(esi + 0x74u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C1D4;
    goto L_900C1CB;
L_900C1CB:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x78u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C1D4u; SPILL(); f_900AE00(c); RELOAD();
L_900C1D4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C1DE:
    (void)sub32(TL32((uint32_t)(esi + 0x68u)), (uint32_t)0x0u, &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFA4u)));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(eax));
    if (!f.zf) goto L_900C22F;
    goto L_900C1ED;
L_900C1ED:
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900C22F;
    goto L_900C1F3;
L_900C1F3:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)TL32((uint32_t)(0x903FED0u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)ecx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, eax, &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C21A:
    (void)sub32(TL32((uint32_t)(esi + 0x90u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900C235;
    goto L_900C223;
L_900C223:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x94u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x98u)));
L_900C22F:
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(ecx));
L_900C235:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C250(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C250:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_900C266;
    goto L_900C25E;
L_900C25E:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C266:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900C2AE;
    goto L_900C26D;
L_900C26D:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x80u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C27Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(TL32((uint32_t)(esi + 0x74u)), edi, &f);
    if (f.zf) goto L_900C28A;
    goto L_900C281;
L_900C281:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x78u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900C28Au; SPILL(); f_900AE00(c); RELOAD();
L_900C28A:
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x900C299u; SPILL(); f_900AE60(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + 0x10u)) & (uint32_t)0x7FFFFFFFu), &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C2AE:
    (void)sub32(TL32((uint32_t)(esi + 0x90u)), edi, &f);
    if (f.zf) goto L_900C2BC;
    goto L_900C2B6;
L_900C2B6:
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(edi));
L_900C2BC:
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + 0x10u)) & (uint32_t)0x7FFFFFFFu), &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C2D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C2D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xB4u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_900C70E;
    goto L_900C2EC;
L_900C2EC:
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), edi, &f);
    if (f.zf) goto L_900C70E;
    goto L_900C2F5;
L_900C2F5:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900C322;
    goto L_900C2FE;
L_900C2FE:
    { uint32_t v_ = 0x9037174u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028218u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x591u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903717Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C31Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900C322:
    (void)sub32(TL32((uint32_t)(esi + 0x68u)), edi, &f);
    if (f.zf) goto L_900C3E1;
    goto L_900C32B;
L_900C32B:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x70u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C33Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(0x9028114u)));
    M32((uint32_t)(esp + 0x58u)) = (uint32_t)((uint32_t)0x64u);
    M32((uint32_t)(esp + 0xA8u)) = (uint32_t)(ecx);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), edi, &f);
    if (!f.zf) goto L_900C377;
    goto L_900C356;
L_900C356:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    edx = (uint32_t)(add32(edx, eax, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    M32((uint32_t)(esp + 0x44u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(edx);
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(edi);
    goto L_900C3A4;
L_900C377:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + edx + 0x8u)));
    eax = (uint32_t)((uint32_t)(ecx + edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(eax)), &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(esi + 0x54u)), &f));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    M32((uint32_t)(esp + 0x40u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x44u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(ebx);
    eax = (uint32_t)(add32(eax, edx, &f));
L_900C3A4:
    edx = (uint32_t)((uint32_t)(esp + 0x58u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1000400u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x48u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x58u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C3C7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(edi, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_900C377;
    goto L_900C3CD;
L_900C3CD:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x70u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900C3DCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900C6F3;
L_900C3E1:
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), edi, &f);
    if (f.zf) goto L_900C571;
    goto L_900C3EA;
L_900C3EA:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x70u)));
    ebx = (uint32_t)(logic32(0, &f));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C3FDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), edx, &f);
    if (!f.zf) goto L_900C43D;
    goto L_900C404;
L_900C404:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    edi = (uint32_t)(add32(edi, eax, &f));
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(edx);
    goto L_900C52D;
L_900C43D:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    eax = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edi = (uint32_t)((uint32_t)(eax + ecx));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(edi)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(edi + 0x4u)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0x38u)), ecx, &f));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x50u)), &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(esi + 0x54u)), &f));
    M32((uint32_t)(esp + 0x38u)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x38u)), ecx, &f));
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x3Cu)), edx, &f));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    edx = (uint32_t)(add32(edx, eax, &f));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    M32((uint32_t)(esp + 0x30u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(edx);
    eax = (uint32_t)(add32(eax, ecx, &f));
L_900C52D:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1000000u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x3Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(esp + 0x40u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C553u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_900C43D;
    goto L_900C55D;
L_900C55D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x70u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900C56Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900C6F3;
L_900C571:
    (void)sub32(TL32((uint32_t)(esi + 0x90u)), edi, &f);
    if (f.zf) goto L_900C6F8;
    goto L_900C57D;
L_900C57D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900C587u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031024u)); esp -= 4; M32(esp) = 0x900C594u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), edi, &f);
    if (!f.zf) goto L_900C5CA;
    goto L_900C59D;
L_900C59D:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    M32((uint32_t)(esp + 0x4Cu)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(edi);
    goto L_900C6A7;
L_900C5CA:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    M32((uint32_t)(esp + 0x50u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    M32((uint32_t)(esp + 0x54u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(edi)), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(edi + 0x4u)), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    M32((uint32_t)(esp + 0x4Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x58u)));
    ebx = (uint32_t)(sub32(ebx, ecx, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x5Cu)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
L_900C6A7:
    { uint32_t v_ = 0xCC0020u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xA0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x64u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031008u)); esp -= 4; M32(esp) = 0x900C6D6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(inc32(edi, &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(edi);
    (void)sub32(edi, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_900C5CA;
    goto L_900C6E4;
L_900C6E4:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x60u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900C6F3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900C6F3:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900C6F8:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900C70E;
    goto L_900C6FC;
L_900C6FC:
    { uint32_t v_ = 0x635u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903717Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900C70Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900C70E:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

