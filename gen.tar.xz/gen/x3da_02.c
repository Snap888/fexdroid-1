#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A001470(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001470:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x18u, &f));
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x10u)) & (uint8_t)0x4u), &f);
    { Xmm s_ = c->xmm[7]; c->xmm[7].q[0] ^= s_.q[0]; c->xmm[7].q[1] ^= s_.q[1]; }
    c->xmm[4].u[0] = M32((uint32_t)(0xA00111Cu)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(0xA001128u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    c->xmm[5].u[0] = M32((uint32_t)(esi + 0x24u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] / MF32((uint32_t)(ebx + 0x5Cu));
    M32((uint32_t)(ebp + 0x14u)) = c->xmm[5].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x2u);
    if (f.zf) goto L_A0014F5;
    goto L_A0014B1;
L_A0014B1:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x50u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    if (f.zf) goto L_A0014BF;
    goto L_A0014BC;
L_A0014BC:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    goto L_A0014E0;
L_A0014BF:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
L_A0014E0:
    esp -= 4; M32(esp) = 0xA0014E5u; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0); fpop(c);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    M32((uint32_t)(esi + 0x10u)) = c->xmm[0].u[0];
L_A0014F5:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x10u)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_A00153C;
    goto L_A0014FB;
L_A0014FB:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x54u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    if (!f.zf) goto L_A001526;
    goto L_A001506;
L_A001506:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
L_A001526:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00152Cu; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0); fpop(c);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    M32((uint32_t)(esi + 0x14u)) = c->xmm[0].u[0];
L_A00153C:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x10u)) & (uint8_t)0x10u), &f);
    if (f.zf) goto L_A00158A;
    goto L_A001542;
L_A001542:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x58u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A001550;
    goto L_A001549;
L_A001549:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    goto L_A001575;
L_A001550:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
L_A001575:
    esp -= 4; M32(esp) = 0xA00157Au; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0); fpop(c);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    M32((uint32_t)(esi + 0x18u)) = c->xmm[0].u[0];
L_A00158A:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x10u)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_A0017D1;
    goto L_A001594;
L_A001594:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x48u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A0015B2;
    goto L_A00159B;
L_A00159B:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0015A5u; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0); fpop(c);
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    goto L_A0015C1;
L_A0015B2:
    { float a_ = c->xmm[5].f[0], b_ = c->xmm[4].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    c->xmm[0] = c->xmm[4];
    if ((f.cf || f.zf)) goto L_A0015BE;
    goto L_A0015BA;
L_A0015BA:
    c->xmm[0].f[0] = c->xmm[0].f[0] / c->xmm[5].f[0];
L_A0015BE:
    c->xmm[6] = c->xmm[0];
L_A0015C1:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x3Cu)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A00164F;
    goto L_A0015CD;
L_A0015CD:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(eax)) = c->xmm[6].u[0];
    eax = (uint32_t)((uint32_t)0x1u);
    (void)sub32(TL32((uint32_t)(esi + 0xCu)), eax, &f);
    if ((f.cf || f.zf)) goto L_A0015F2;
    goto L_A0015DD;
L_A0015DD:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    M32((uint32_t)(edx + ecx*4)) = c->xmm[7].u[0];
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.cf) goto L_A0015DD;
    goto L_A0015F2;
L_A0015F2:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0x10u)) & (uint32_t)0x20000u), &f);
    if (f.zf) goto L_A0017D1;
    goto L_A0015FF;
L_A0015FF:
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0x4Cu)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_A00162E;
    goto L_A001606;
L_A001606:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001610u; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0x10u)) = (float)ST(0); fpop(c);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(edx + ecx*4)) = c->xmm[4].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A00162E:
    { float a_ = c->xmm[5].f[0], b_ = c->xmm[4].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    ST(0) = ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A001639;
    goto L_A001635;
L_A001635:
    c->xmm[4].f[0] = c->xmm[4].f[0] / c->xmm[5].f[0];
L_A001639:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(edx + ecx*4)) = c->xmm[4].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A00164F:
    edi = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_A0016A2;
    goto L_A001655;
L_A001655:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0xCu)), eax, &f);
    if ((f.cf || f.zf)) goto L_A001673;
    goto L_A00165C;
L_A00165C:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, edi, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    M32((uint32_t)(edx + ecx*4)) = c->xmm[7].u[0];
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.cf) goto L_A00165C;
    goto L_A001673;
L_A001673:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x44u)));
    c->xmm[0].u[0] = M32((uint32_t)(eax + edi*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = MF32((uint32_t)(0xA001124u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (!f.pf) goto L_A001691;
    goto L_A001688;
L_A001688:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(ecx + edi*4)) = c->xmm[6].u[0];
    goto L_A00169A;
L_A001691:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_A0016A2;
    goto L_A00169A;
L_A00169A:
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    (void)sub32(edi, TL32((uint32_t)(ebx + 0x3Cu)), &f);
    if (f.cf) goto L_A001655;
    goto L_A0016A2;
L_A0016A2:
    (void)sub32(edi, TL32((uint32_t)(ebx + 0x3Cu)), &f);
    if (!f.cf) goto L_A001753;
    goto L_A0016AB;
L_A0016AB:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A0016C6;
    goto L_A0016B2;
L_A0016B2:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0016BCu; SPILL(); f_A001380(c); RELOAD();
    MF32((uint32_t)(ebp + 0x10u)) = (float)ST(0); fpop(c);
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    goto L_A0016D1;
L_A0016C6:
    { float a_ = c->xmm[5].f[0], b_ = c->xmm[4].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    ST(0) = ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A0016D1;
    goto L_A0016CD;
L_A0016CD:
    c->xmm[4].f[0] = c->xmm[4].f[0] / c->xmm[5].f[0];
L_A0016D1:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(ecx + 0x8u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(add32(eax, edi, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    M32((uint32_t)(edx + eax*4)) = c->xmm[4].u[0];
    (void)sub32(edi, TL32((uint32_t)(ebx + 0x3Cu)), &f);
    if (!f.cf) goto L_A0017D3;
    goto L_A0016F0;
L_A0016F0:
    c->xmm[0].u[0] = M32((uint32_t)(0xA001124u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
L_A0016F8:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0xCu)), eax, &f);
    if ((f.cf || f.zf)) goto L_A001717;
    goto L_A0016FF;
L_A0016FF:
L_A001700:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, edi, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    M32((uint32_t)(edx + ecx*4)) = c->xmm[7].u[0];
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.cf) goto L_A001700;
    goto L_A001717;
L_A001717:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x44u)));
    c->xmm[1].u[0] = M32((uint32_t)(eax + edi*4)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (!f.pf) goto L_A001731;
    goto L_A00172A;
L_A00172A:
    M32((uint32_t)(ecx + edi*4)) = c->xmm[6].u[0];
    goto L_A001742;
L_A001731:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)TL32((uint32_t)(eax + 0x8u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, edi, &f));
    M32((uint32_t)(ecx + edx*4)) = c->xmm[4].u[0];
L_A001742:
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    (void)sub32(edi, TL32((uint32_t)(ebx + 0x3Cu)), &f);
    if (f.cf) goto L_A0016F8;
    goto L_A00174A;
L_A00174A:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A001753:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0x10u)) & (uint32_t)0x20000u), &f);
    if (f.zf) goto L_A0017D1;
    goto L_A00175C;
L_A00175C:
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0x4Cu)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_A00176F;
    goto L_A001763;
L_A001763:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00176Du; SPILL(); f_A001380(c); RELOAD();
    goto L_A001782;
L_A00176F:
    { float a_ = c->xmm[5].f[0], b_ = c->xmm[4].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    ST(0) = ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A00177A;
    goto L_A001776;
L_A001776:
    c->xmm[4].f[0] = c->xmm[4].f[0] / c->xmm[5].f[0];
L_A00177A:
    M32((uint32_t)(ebp + 0x10u)) = c->xmm[4].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0x10u)));
L_A001782:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(ecx);
    (void)logic32((uint32_t)(edx & edx), &f);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(edx);
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0x10u)));
    if ((f.sf == f.of)) goto L_A001797;
    goto L_A001791;
L_A001791:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0xA001120u));
L_A001797:
    ST(1) = ST(1) / ST(0); fpop(c);
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    MF32((uint32_t)(ebp + 0x10u)) = (float)ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A0017D3;
    goto L_A0017A2;
L_A0017A2:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)((uint32_t)(ebx));
L_A0017B0:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)TL32((uint32_t)(ecx + 0x8u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(add32(edx, eax, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    M32((uint32_t)(edi + edx*4)) = c->xmm[0].u[0];
    (void)sub32(eax, TL32((uint32_t)(esi + 0x8u)), &f);
    if (f.cf) goto L_A0017B0;
    goto L_A0017C8;
L_A0017C8:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A0017D1:
    ST(0) = ST(0); fpop(c);
L_A0017D3:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

