#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A00246C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00246C:
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)eax), &f)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    TS8((uint32_t)(ebx), (uint8_t)(add8(TL8((uint32_t)(ebx)), ((uint8_t)eax), &f)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), TL8((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx)), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)(eax >> 8)), &f));
    SPILL(); rt_int3(c, 0xA0024A6u);
    { SPILL(); rt_call(c, 0xA0024A7u); return; }
}

void f_A0024B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0024B0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x78u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(ecx);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0024DDu; SPILL(); f_A002CA0(c); RELOAD();
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0024EEu; SPILL(); f_A002CA0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { Xmm s_ = c->xmm[0]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x3Cu)));
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[0].u[0];
    if ((f.cf || f.zf)) goto L_A00253A;
    goto L_A00250B;
L_A00250B:
    c->xmm[0].u[0] = M32((uint32_t)(edx + 0x40u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0x8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[1].u[0];
L_A00253A:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_A0029BB;
    goto L_A002545;
L_A002545:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)((uint32_t)(ecx));
L_A002550:
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((f.cf || f.zf)) goto L_A0026B1;
    goto L_A002559;
L_A002559:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x44u)));
    c->xmm[0].u[0] = M32((uint32_t)(eax + edi*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = MF32((uint32_t)(0xA001124u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[0].u[0];
    if (!f.pf) goto L_A0026B1;
    goto L_A002577;
L_A002577:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFECu)));
    c->xmm[4].u[0] = M32((uint32_t)(edx + 0x18u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { double v_ = ST(0); fpush(c, v_); }
    c->xmm[5].u[0] = M32((uint32_t)(edx + 0x14u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ST(0) = cos(ST(0)); c->c2 = 0;
    c->xmm[2].u[0] = M32((uint32_t)(edx + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(0xA00111Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3] = c->xmm[5];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    c->xmm[1] = c->xmm[2];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[4].f[0];
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0); fpop(c);
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ST(0) = sin(ST(0)); c->c2 = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[6].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[5].u[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    MF32((uint32_t)(ebp + 0xFFFFFFF8u)) = (float)ST(0); fpop(c);
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[3].u[0];
    c->xmm[3] = c->xmm[4];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[7].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[3].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFC8u));
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFE8u));
    c->xmm[7] = c->xmm[2];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[0].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFC4u));
    c->xmm[6].u[0] = M32((uint32_t)(edx + 0x14u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[1].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFCCu));
    c->xmm[1].f[0] = c->xmm[1].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + MF32((uint32_t)(edx + 0x1Cu));
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = c->xmm[7].u[0];
    c->xmm[5] = c->xmm[6];
    c->xmm[7] = c->xmm[6];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[0].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + MF32((uint32_t)(ebp + 0x18u));
    c->xmm[7].f[0] = c->xmm[7].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFC8u));
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[4].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[2].u[0];
    c->xmm[6] = c->xmm[5];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFCCu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[2].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + MF32((uint32_t)(edx + 0x20u));
    c->xmm[3] = c->xmm[4];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[4].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(ebp + 0x18u));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[5].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFC8u));
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[0].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[6].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[1].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(edx + 0x24u));
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = c->xmm[3].u[0];
    goto L_A0026C3;
L_A0026B1:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x1Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(eax);
L_A0026C3:
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((f.cf || f.zf)) goto L_A0026E1;
    goto L_A0026C8;
L_A0026C8:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x44u)));
    c->xmm[0].u[0] = M32((uint32_t)(ecx + edi*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = MF32((uint32_t)(0xA001124u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (!f.pf) goto L_A0029AB;
    goto L_A0026E1;
L_A0026E1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFA0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x18u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFACu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0026F5u; SPILL(); f_A002C50(c); RELOAD();
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFA8u)));
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFF9Cu)));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFF90u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ST(0) = ST(0) * ST(1);
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFA8u));
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFA4u)));
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFF8Cu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFF98u)));
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFA4u));
    ST(0) = ST(0) * ST(1);
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    { Xmm s_ = c->xmm[2]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    ST(2) = ST(2) + ST(0); fpop(c);
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFF88u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFA0u)));
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFA0u));
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)((uint32_t)(edx + edi*4));
    ST(0) = ST(0) * ST(1);
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    c->xmm[1].u[0] = M32((uint32_t)(eax)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[0].u[0];
    ST(3) = ST(3) + ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFC0u)));
    ST(4) = ST(4) * ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFBCu)));
    ST(2) = ST(2) * ST(0); fpop(c);
    { double v_ = ST(0); ST(0) = ST(3); ST(3) = v_; }
    ST(1) = ST(1) + ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFB8u)));
    M32((uint32_t)(eax)) = c->xmm[2].u[0];
    ST(3) = ST(3) * ST(0); fpop(c);
    ST(2) = ST(2) + ST(0); fpop(c);
    { double v_ = ST(1); fpush(c, v_); }
    ST(0) = ST(0) * ST(2);
    { double v_ = ST(1); fpush(c, v_); }
    ST(0) = ST(0) * ST(2);
    ST(1) = ST(1) + ST(0); fpop(c);
    ST(0) = sqrt(ST(0));
    MF32((uint32_t)(ebp + 0xFFFFFFF8u)) = (float)ST(0);
    fpush(c, (double)MF32((uint32_t)(0xA001118u)));
    { double a_ = ST(0), b_ = ST(1); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; fpop(c); }
    if (f.cf) goto L_A0027F3;
    goto L_A00277F;
L_A00277F:
    (void)sub32(TL32((uint32_t)(ebx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    ST(1) = ST(0); fpop(c);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    ST(1) = ST(0); fpop(c);
    ST(0) = ST(0); fpop(c);
    eax = (uint32_t)(ecx);
    if (f.zf) goto L_A002793;
    goto L_A002790;
L_A002790:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
L_A002793:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10000u), &f));
    if (f.zf) goto L_A0027A1;
    goto L_A00279E;
L_A00279E:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
L_A0027A1:
    (void)logic32((uint32_t)(eax & eax), &f);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0x18u)));
    if ((f.sf == f.of)) goto L_A0027B1;
    goto L_A0027AB;
L_A0027AB:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0xA001120u));
L_A0027B1:
    ST(0) = (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)) / ST(0);
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A0029A8;
    goto L_A0027C1;
L_A0027C1:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
L_A0027C6:
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x8u)), &f);
    if (f.zf) goto L_A0027E6;
    goto L_A0027CB;
L_A0027CB:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_A0027D4;
    goto L_A0027D0;
L_A0027D0:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_A0027E6;
    goto L_A0027D4;
L_A0027D4:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, edi, &f));
    M32((uint32_t)(ebx + ecx*4)) = c->xmm[0].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_A0027E6:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.cf) goto L_A0027C6;
    goto L_A0027EE;
L_A0027EE:
    goto L_A0029A8;
L_A0027F3:
    { double v_ = ST(0); ST(0) = ST(2); ST(2) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ST(1) = atan2(ST(1), ST(0)); fpop(c);
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x38u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x34u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = c->xmm[2].u[0];
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(ebp + 0xFFFFFFD0u)) = (float)ST(0);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFE0u)));
    ST(0) = sin(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0); fpop(c);
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[0].f[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[2].f[0];
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[3].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A00284F;
    goto L_A002837;
L_A002837:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ST(1) = ST(0); fpop(c);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    MF32((uint32_t)(esp + 0x4u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    goto L_A0028CD;
L_A00284F:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFDCu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ST(0) = sin(ST(0)); c->c2 = 0;
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    ST(0) = ST(0) * (double)MF32((uint32_t)(ebp + 0xFFFFFFD8u));
    ST(0) = ST(0) + (double)MF32((uint32_t)(ebp + 0xFFFFFFD4u));
    { double v_ = ST(0); fpush(c, v_); }
    ST(3) = ST(0) - ST(3); fpop(c);
    { double v_ = ST(0); ST(0) = ST(2); ST(2) = v_; }
    ST(0) = ST(0) * (double)MF32((uint32_t)(0xA001150u));
    { double v_ = ST(0); ST(0) = ST(2); ST(2) = v_; }
    ST(0) = ST(0) + ST(0);
    ST(2) = ST(2) / ST(0); fpop(c);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = tan(ST(0)); fpush(c, 1.0); c->c2 = 0;
    ST(0) = ST(0); fpop(c);
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0); fpop(c);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(0xA00111Cu));
    MF32((uint32_t)(esp + 0x4u)) = (float)ST(0); fpop(c);
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF0u)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0028A2u; SPILL(); f_A001E80(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(0xA00114Cu));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    M32((uint32_t)(esp + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ebp + 0x18u));
    M32((uint32_t)(esp)) = c->xmm[0].u[0];
L_A0028CD:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0028D3u; SPILL(); f_A001E80(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0].u[0] = M32((uint32_t)(edx + 0x34u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0xA00112Cu));
    c->xmm[1].u[0] = M32((uint32_t)(0xA001164u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0028F3;
    goto L_A0028F0;
L_A0028F0:
    c->xmm[0] = c->xmm[1];
L_A0028F3:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A0029A8;
    goto L_A002901;
L_A002901:
    (void)sub32(TL32((uint32_t)(ebx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(ecx);
    if (f.zf) goto L_A00290F;
    goto L_A00290C;
L_A00290C:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
L_A00290F:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10000u), &f));
    if (f.zf) goto L_A00291D;
    goto L_A00291A;
L_A00291A:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
L_A00291D:
    (void)logic32((uint32_t)(eax & eax), &f);
    M32((uint32_t)(ebp + 0x18u)) = (uint32_t)(eax);
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0x18u)));
    if ((f.sf == f.of)) goto L_A00292D;
    goto L_A002927;
L_A002927:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0xA001120u));
L_A00292D:
    ST(0) = (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)) / ST(0);
    c->xmm[1].f[0] = c->xmm[1].f[0] - MF32((uint32_t)(0xA001118u));
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[0].f[0];
    c->xmm[0] = c->xmm[1];
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0); fpop(c);
    if ((f.cf || f.zf)) goto L_A0029A8;
    goto L_A002948;
L_A002948:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(ecx));
L_A002950:
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x8u)), &f);
    if (f.zf) goto L_A0029A0;
    goto L_A002955;
L_A002955:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_A00295E;
    goto L_A00295A;
L_A00295A:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_A0029A0;
    goto L_A00295E;
L_A00295E:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, edi, &f));
    c->xmm[2].u[0] = M32((uint32_t)(ebx + ecx*4)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(ebx + ecx*4));
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    c->xmm[2].u[0] = M32((uint32_t)(0xA00111Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)((uint32_t)(ebx + ecx*4));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + MF32((uint32_t)(ecx));
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
L_A0029A0:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    (void)sub32(eax, TL32((uint32_t)(esi + 0xCu)), &f);
    if (f.cf) goto L_A002950;
    goto L_A0029A8;
L_A0029A8:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
L_A0029AB:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x3Cu)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    (void)sub32(edi, ecx, &f);
    if (f.cf) goto L_A002550;
    goto L_A0029B9;
L_A0029B9:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_A0029BB:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

