#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A0037D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0037D0:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | eax), &f));
    if (!f.zf) goto L_A003801;
    goto L_A0037D9;
L_A0037D9:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(ebx);
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x10u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x10u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    goto L_A003848;
L_A003801:
    ecx = (uint32_t)(eax);
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
L_A00380F:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(rcr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(rcr32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ecx), &f));
    if (!f.zf) goto L_A00380F;
    goto L_A00381B;
L_A00381B:
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ebx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    esi = (uint32_t)(eax);
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x14u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint64_t r_ = (uint64_t)eax * esi; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    if (f.cf) goto L_A00383D;
    goto L_A00382F;
L_A00382F:
    (void)sub32(edx, M32((uint32_t)(esp + 0xCu)), &f);
    if ((!f.cf && !f.zf)) goto L_A00383D;
    goto L_A003835;
L_A003835:
    if (f.cf) goto L_A003846;
    goto L_A003837;
L_A003837:
    (void)sub32(eax, M32((uint32_t)(esp + 0x8u)), &f);
    if ((f.cf || f.zf)) goto L_A003846;
    goto L_A00383D;
L_A00383D:
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x10u)), &f));
    edx = (uint32_t)(sbb32(edx, M32((uint32_t)(esp + 0x14u)), &f));
L_A003846:
    ebx = (uint32_t)(logic32(0, &f));
L_A003848:
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x8u)), &f));
    edx = (uint32_t)(sbb32(edx, M32((uint32_t)(esp + 0xCu)), &f));
    edx = (uint32_t)(neg32(edx, &f));
    eax = (uint32_t)(neg32(eax, &f));
    edx = (uint32_t)(sbb32(edx, (uint32_t)0x0u, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(ebx);
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

