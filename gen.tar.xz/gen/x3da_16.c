#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A002C20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002C20:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    fpush(c, (double)MF32((uint32_t)(eax + 0x8u)));
    ST(0) = ST(0) * (double)MF32((uint32_t)(ecx + 0x8u));
    fpush(c, (double)MF32((uint32_t)(eax + 0x4u)));
    ST(0) = ST(0) * (double)MF32((uint32_t)(ecx + 0x4u));
    ST(1) = ST(1) + ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax)));
    ST(0) = ST(0) * (double)MF32((uint32_t)(ecx));
    ST(1) = ST(1) + ST(0); fpop(c);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_A002C50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002C50:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    c->xmm[0].u[0] = M32((uint32_t)(eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(edx)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ecx + 0x4u));
    M32((uint32_t)(edx + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ecx + 0x8u));
    M32((uint32_t)(edx + 0x8u)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_A002CA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002CA0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ecx + 0x8u));
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(eax + 0x8u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[1].f[0];
    M32((uint32_t)(edx)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ecx));
    c->xmm[1].u[0] = M32((uint32_t)(eax)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ecx + 0x8u));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[1].f[0];
    M32((uint32_t)(edx + 0x4u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(eax));
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ecx));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[1].f[0];
    M32((uint32_t)(edx + 0x8u)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_A002D09(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002D09:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)((uint32_t)0xE06D7363u);
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), eax, &f);
    if (!f.zf) goto L_A002D25;
    goto L_A002D18;
L_A002D18:
    { uint32_t v_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002D21u; SPILL(); f_A003498(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_A002D25:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A002D2E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002D2E:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(logic32(0, &f));
    goto L_A002D4A;
L_A002D3B:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_A002D4F;
    goto L_A002D3F;
L_A002D3F:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_A002D47;
    goto L_A002D45;
L_A002D45:
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0xA002D47u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A002D47:
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
L_A002D4A:
    (void)sub32(esi, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.cf) goto L_A002D3B;
    goto L_A002D4F;
L_A002D4F:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A002D57(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002D57:
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001054u)); esp -= 4; M32(esp) = 0xA002D62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    TS32((uint32_t)(0xA004644u), (uint32_t)(eax));
    TS32((uint32_t)(0xA004640u), (uint32_t)(eax));
    if (!f.zf) goto L_A002D73;
    goto L_A002D71;
L_A002D71:
    eax = (uint32_t)(inc32(eax, &f));
    esp += 4; SPILL(); return;
L_A002D73:
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) & (uint32_t)0x0u), &f)));
    eax = (uint32_t)(logic32(0, &f));
    esp += 4; SPILL(); return;
}

void f_A002D7E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002D7E:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), eax, &f);
    if (!f.zf) goto L_A002D98;
    goto L_A002D8A;
L_A002D8A:
    (void)sub32(TL32((uint32_t)(0xA004310u)), eax, &f);
    if ((f.zf || f.sf != f.of)) goto L_A002DCE;
    goto L_A002D92;
L_A002D92:
    TS32((uint32_t)(0xA004310u), (uint32_t)(dec32(TL32((uint32_t)(0xA004310u)), &f)));
L_A002D98:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    ecx = (uint32_t)(TL32((uint32_t)(0xA001044u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0xA004634u), (uint32_t)(ecx));
    if (!f.zf) goto L_A002E87;
    goto L_A002DB3;
L_A002DB3:
    ecx = (uint32_t)(M32((uint32_t)(0x18u + c->fs_base)));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(0xA00102Cu)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0xA00463Cu);
    goto L_A002DE6;
L_A002DCE:
    eax = (uint32_t)(logic32(0, &f));
    goto L_A002F1B;
L_A002DD5:
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_A002DF0;
    goto L_A002DD9;
L_A002DD9:
    { uint32_t v_ = 0x3E8u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001030u)); esp -= 4; M32(esp) = 0xA002DE4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
L_A002DE6:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0xA002DEAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_A002DD5;
    goto L_A002DEE;
L_A002DEE:
    goto L_A002DF7;
L_A002DF0:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)((uint32_t)0x1u);
L_A002DF7:
    eax = (uint32_t)(TL32((uint32_t)(0xA004638u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    if (f.zf) goto L_A002E0C;
    goto L_A002E03;
L_A002E03:
    { uint32_t v_ = 0x1Fu; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002E0Au; SPILL(); f_A0035B8(c); RELOAD();
L_A002E0C:
    { uint32_t v_ = 0xA001074u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA00106Cu; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0xA004638u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0xA002E25u; SPILL(); f_A002D2E(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    if (f.zf) goto L_A002E32;
    goto L_A002E2B;
L_A002E2B:
    eax = (uint32_t)(logic32(0, &f));
    goto L_A002F18;
L_A002E32:
    { uint32_t v_ = 0xA001068u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA001064u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002E41u; SPILL(); f_A0035AC(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    TS32((uint32_t)(0xA004638u), (uint32_t)(edi));
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    if (!f.zf) goto L_A002E58;
    goto L_A002E50;
L_A002E50:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001034u)); esp -= 4; M32(esp) = 0xA002E58u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A002E58:
    (void)sub32(TL32((uint32_t)(0xA004650u)), ebx, &f);
    if (f.zf) goto L_A002E7C;
    goto L_A002E60;
L_A002E60:
    { uint32_t v_ = 0xA004650u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002E6Au; SPILL(); f_A00353B(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    if (f.zf) goto L_A002E7C;
    goto L_A002E6F;
L_A002E6F:
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA004650u)); esp -= 4; M32(esp) = 0xA002E7Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A002E7C:
    TS32((uint32_t)(0xA004310u), (uint32_t)(inc32(TL32((uint32_t)(0xA004310u)), &f)));
    goto L_A002F15;
L_A002E87:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), eax, &f);
    if (!f.zf) goto L_A002F15;
    goto L_A002E90;
L_A002E90:
    edi = (uint32_t)(TL32((uint32_t)(0xA00102Cu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0xA00463Cu);
    goto L_A002EAB;
L_A002E9E:
    { uint32_t v_ = 0x3E8u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001030u)); esp -= 4; M32(esp) = 0xA002EA9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
L_A002EAB:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0xA002EB0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_A002E9E;
    goto L_A002EB4;
L_A002EB4:
    eax = (uint32_t)(TL32((uint32_t)(0xA004638u)));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (f.zf) goto L_A002EC8;
    goto L_A002EBE;
L_A002EBE:
    { uint32_t v_ = 0x1Fu; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002EC5u; SPILL(); f_A0035B8(c); RELOAD();
L_A002EC8:
    ebx = (uint32_t)(TL32((uint32_t)(0xA004644u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_A002F02;
    goto L_A002ED2;
L_A002ED2:
    edi = (uint32_t)(TL32((uint32_t)(0xA004640u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
    goto L_A002EE8;
L_A002EDD:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A002EE5;
    goto L_A002EE3;
L_A002EE3:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA002EE5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A002EE5:
    edi = (uint32_t)(sub32(edi, (uint32_t)0x4u, &f));
L_A002EE8:
    (void)sub32(edi, ebx, &f);
    if (!f.cf) goto L_A002EDD;
    goto L_A002EEC;
L_A002EEC:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001050u)); esp -= 4; M32(esp) = 0xA002EF3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0xA004640u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0xA004640u)) & (uint32_t)0x0u), &f)));
    TS32((uint32_t)(0xA004644u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0xA004644u)) & (uint32_t)0x0u), &f)));
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
L_A002F02:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0xA004638u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0xA001034u)); esp -= 4; M32(esp) = 0xA002F15u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A002F15:
    eax = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(inc32(eax, &f));
L_A002F18:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_A002F1B:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

