#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A003310(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_A003310;
L_A0032C1:
    ebp = (uint32_t)(edx);
    esi = (uint32_t)(ecx);
    eax = (uint32_t)(ecx);
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0032CEu; SPILL(); f_A003875(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(logic32(0, &f));
    { jt_ = esi; goto L_dispatch; }
L_A003310:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    esi = (uint32_t)(logic32((uint32_t)(esi ^ TL32((uint32_t)(eax))), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFEu, &f);
    M8((uint32_t)(ebp + 0xFFFFFFFFu)) = (uint8_t)((uint8_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x1u);
    edi = (uint32_t)((uint32_t)(ebx + 0x10u));
    if (f.zf) goto L_A003346;
    goto L_A00333B;
L_A00333B:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(eax + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA003346u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A003346:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(edx + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA003354u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic8((uint8_t)(TL8((uint32_t)(eax + 0x4u)) & (uint8_t)0x66u), &f);
    if (!f.zf) goto L_A003473;
    goto L_A003361;
L_A003361:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    TS32((uint32_t)(ebx + 0xFFFFFFFCu), (uint32_t)(ecx));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebx, (uint32_t)0xFFFFFFFEu, &f);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    if (f.zf) goto L_A0033D8;
    goto L_A003378;
L_A003378:
    goto L_A003380;
L_A003380:
    edx = (uint32_t)((uint32_t)(ebx + ebx*2));
    ecx = (uint32_t)(TL32((uint32_t)(esi + edx*4 + 0x14u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    eax = (uint32_t)((uint32_t)(esi + edx*4 + 0x10u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    if (f.zf) goto L_A0033AB;
    goto L_A003397;
L_A003397:
    edx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0xA00339Eu; SPILL(); f_A0032AA(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    M8((uint32_t)(ebp + 0xFFFFFFFFu)) = (uint8_t)((uint8_t)0x1u);
    if ((f.sf != f.of)) goto L_A0033E2;
    goto L_A0033A6;
L_A0033A6:
    if ((!f.zf && f.sf == f.of)) goto L_A0033EB;
    goto L_A0033A8;
L_A0033A8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
L_A0033AB:
    (void)sub32(eax, (uint32_t)0xFFFFFFFEu, &f);
    ebx = (uint32_t)(eax);
    if (!f.zf) goto L_A003380;
    goto L_A0033B2;
L_A0033B2:
    (void)sub8(M8((uint32_t)(ebp + 0xFFFFFFFFu)), (uint8_t)0x0u, &f);
    if (f.zf) goto L_A0033D8;
    goto L_A0033B8;
L_A0033B8:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFEu, &f);
    if (f.zf) goto L_A0033CA;
    goto L_A0033BF;
L_A0033BF:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(eax + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA0033CAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A0033CA:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(edx + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA0033D8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A0033D8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_A0033E2:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x0u);
    goto L_A0033B8;
L_A0033EB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xE06D7363u, &f);
    if (!f.zf) goto L_A00341F;
    goto L_A0033F6;
L_A0033F6:
    (void)sub32(TL32((uint32_t)(0xA004648u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_A00341F;
    goto L_A0033FF;
L_A0033FF:
    { uint32_t v_ = 0xA004648u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003409u; SPILL(); f_A00353B(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A00341F;
    goto L_A003410;
L_A003410:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA004648u)); esp -= 4; M32(esp) = 0xA00341Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_A00341F:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    esp -= 4; M32(esp) = 0xA003427u; SPILL(); f_A0032DA(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)sub32(TL32((uint32_t)(eax + 0xCu)), ebx, &f);
    if (f.zf) goto L_A003440;
    goto L_A00342F;
L_A00342F:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(ebx);
    ecx = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0xA00343Du; SPILL(); f_A0032F4(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
L_A003440:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFEu, &f);
    if (f.zf) goto L_A003458;
    goto L_A00344D;
L_A00344D:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(eax + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA003458u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_A003458:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ TL32((uint32_t)(edx + edi))), &f));
    { uint32_t t_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = 0xA003466u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    edx = (uint32_t)(edi);
    goto L_A0032C1;
L_A003473:
    edx = (uint32_t)((uint32_t)0xFFFFFFFEu);
    (void)sub32(TL32((uint32_t)(ebx + 0xCu)), edx, &f);
    if (f.zf) goto L_A0033D8;
    goto L_A003481;
L_A003481:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0xA00348Du; SPILL(); f_A0032F4(c); RELOAD();
    goto L_A0033B8;
L_dispatch:
    switch (jt_) { case 0xA0032C1u: goto L_A0032C1; case 0xA003310u: goto L_A003310; case 0xA00333Bu: goto L_A00333B; case 0xA003346u: goto L_A003346; case 0xA003361u: goto L_A003361; case 0xA003378u: goto L_A003378; case 0xA003380u: goto L_A003380; case 0xA003397u: goto L_A003397; case 0xA0033A6u: goto L_A0033A6; case 0xA0033A8u: goto L_A0033A8; case 0xA0033ABu: goto L_A0033AB; case 0xA0033B2u: goto L_A0033B2; case 0xA0033B8u: goto L_A0033B8; case 0xA0033BFu: goto L_A0033BF; case 0xA0033CAu: goto L_A0033CA; case 0xA0033D8u: goto L_A0033D8; case 0xA0033E2u: goto L_A0033E2; case 0xA0033EBu: goto L_A0033EB; case 0xA0033F6u: goto L_A0033F6; case 0xA0033FFu: goto L_A0033FF; case 0xA003410u: goto L_A003410; case 0xA00341Fu: goto L_A00341F; case 0xA00342Fu: goto L_A00342F; case 0xA003440u: goto L_A003440; case 0xA00344Du: goto L_A00344D; case 0xA003458u: goto L_A003458; case 0xA003473u: goto L_A003473; case 0xA003481u: goto L_A003481; default: SPILL(); rt_call(c, jt_); return; }
}

void f_A003498(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003498:
    { SPILL(); rt_call(c, M32(0xA001058u)); return; }
}

void f_A0034B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0034B0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub16(TL16((uint32_t)(ecx)), (uint16_t)0x5A4Du, &f);
    if (f.zf) goto L_A0034C3;
    goto L_A0034BF;
L_A0034BF:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_A0034C3:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x3Cu)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0x4550u, &f);
    if (!f.zf) goto L_A0034BF;
    goto L_A0034D0;
L_A0034D0:
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub16(TL16((uint32_t)(eax + 0x18u)), (uint16_t)0x10Bu, &f);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(f.zf);
    eax = (uint32_t)(ecx);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

