#include "funcs_bink.h"
#include "lift_prelude.h"

void f_900C720(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C720:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x1u);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900C73C;
    goto L_900C733;
L_900C733:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_900C73C:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) { edi = (uint32_t)(TL32((uint32_t)(0x902810Cu))); }
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900C758;
    goto L_900C750;
L_900C750:
    eax = (uint32_t)(TL32((uint32_t)(0x9028108u)));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(eax);
L_900C758:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(edi, ecx, &f);
    if (f.zf) goto L_900C794;
    goto L_900C760;
L_900C760:
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(edi);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900C771;
    goto L_900C76A;
L_900C76A:
    ebx = (uint32_t)((uint32_t)0x80000000u);
    goto L_900C794;
L_900C771:
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = edi; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900C782;
    goto L_900C77B;
L_900C77B:
    ebx = (uint32_t)((uint32_t)0x20000000u);
    goto L_900C794;
L_900C782:
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_900C78D;
    goto L_900C786;
L_900C786:
    ebx = (uint32_t)((uint32_t)0x40000000u);
    goto L_900C794;
L_900C78D:
    if (!f.cf) goto L_900C794;
    goto L_900C78F;
L_900C78F:
    ebx = (uint32_t)((uint32_t)0x10000000u);
L_900C794:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & ebx), &f));
    (void)sub32(eax, ebx, &f);
    if (!f.zf) goto L_900C7A2;
    goto L_900C79D;
L_900C79D:
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(edi));
    goto L_900C7A9;
L_900C7A2:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
L_900C7A9:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.zf) goto L_900C7DB;
    goto L_900C7B3;
L_900C7B3:
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(edi);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900C7C4;
    goto L_900C7BD;
L_900C7BD:
    ebx = (uint32_t)((uint32_t)0x8000000u);
    goto L_900C7F0;
L_900C7C4:
    (void)sub32(ecx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.zf) goto L_900C7DB;
    goto L_900C7C9;
L_900C7C9:
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(ebp + 0x10u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900C7DB;
    goto L_900C7D4;
L_900C7D4:
    ebx = (uint32_t)((uint32_t)0x2000000u);
    goto L_900C7F0;
L_900C7DB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(eax, ecx, &f);
    if ((f.cf || f.zf)) goto L_900C7E9;
    goto L_900C7E2;
L_900C7E2:
    ebx = (uint32_t)((uint32_t)0x4000000u);
    goto L_900C7F0;
L_900C7E9:
    if (!f.cf) goto L_900C7F0;
    goto L_900C7EB;
L_900C7EB:
    ebx = (uint32_t)((uint32_t)0x1000000u);
L_900C7F0:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & ebx), &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)sub32(eax, ebx, &f);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    if (!f.zf) goto L_900C803;
    goto L_900C7FB;
L_900C7FB:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(ecx));
    goto L_900C80A;
L_900C803:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
L_900C80A:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(esi + 0x30u)), &f));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x34u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900C830(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C830:
    eax = (uint32_t)(logic32(0, &f));
    esp += 12; SPILL(); return;
}

void f_900C840(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C840:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CA36;
    goto L_900C84E;
L_900C84E:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x80u)));
    eax = (uint32_t)(dec32(eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)sub32(eax, (uint32_t)0x9u, &f);
    if ((!f.cf && !f.zf)) goto L_900CA2B;
    goto L_900C860;
L_900C860:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900CA3Cu)); goto L_dispatch; }
L_900C867:
    eax = (uint32_t)(TL32((uint32_t)(0x90371B4u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371B8u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371BCu)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371C0u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371C4u)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371C8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C8B6:
    eax = (uint32_t)(TL32((uint32_t)(0x90371CCu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371D0u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371D4u)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371D8u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371DCu)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371E0u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C905:
    eax = (uint32_t)(TL32((uint32_t)(0x90371E4u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371E8u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371ECu)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371F0u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371F4u)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371F8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C954:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x90371FCu);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C973:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x9037220u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C992:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x9037244u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C9B1:
    ecx = (uint32_t)((uint32_t)0xAu);
    esi = (uint32_t)((uint32_t)0x9037268u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C9CD:
    ecx = (uint32_t)((uint32_t)0xAu);
    esi = (uint32_t)((uint32_t)0x9037290u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900C9EA:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x90372BCu);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CA09:
    eax = (uint32_t)(TL32((uint32_t)(0x90372D8u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90372DCu)));
    edx = (uint32_t)(TL32((uint32_t)(0x90372E0u)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
L_900CA2B:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CA36:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900C840u: goto L_900C840; case 0x900C84Eu: goto L_900C84E; case 0x900C860u: goto L_900C860; case 0x900C867u: goto L_900C867; case 0x900C8B6u: goto L_900C8B6; case 0x900C905u: goto L_900C905; case 0x900C954u: goto L_900C954; case 0x900C973u: goto L_900C973; case 0x900C992u: goto L_900C992; case 0x900C9B1u: goto L_900C9B1; case 0x900C9CDu: goto L_900C9CD; case 0x900C9EAu: goto L_900C9EA; case 0x900CA09u: goto L_900CA09; case 0x900CA2Bu: goto L_900CA2B; case 0x900CA36u: goto L_900CA36; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900C867(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C867:
    eax = (uint32_t)(TL32((uint32_t)(0x90371B4u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371B8u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371BCu)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371C0u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371C4u)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371C8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C8B6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C8B6:
    eax = (uint32_t)(TL32((uint32_t)(0x90371CCu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371D0u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371D4u)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371D8u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371DCu)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371E0u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C905(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C905:
    eax = (uint32_t)(TL32((uint32_t)(0x90371E4u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371E8u)));
    edx = (uint32_t)(TL32((uint32_t)(0x90371ECu)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x90371F0u)));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x90371F4u)));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x90371F8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028014u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028018u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902801Cu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C954(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C954:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x90371FCu);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C973(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C973:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x9037220u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C992(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C992:
    ecx = (uint32_t)((uint32_t)0x8u);
    esi = (uint32_t)((uint32_t)0x9037244u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C9B1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C9B1:
    ecx = (uint32_t)((uint32_t)0xAu);
    esi = (uint32_t)((uint32_t)0x9037268u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C9CD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C9CD:
    ecx = (uint32_t)((uint32_t)0xAu);
    esi = (uint32_t)((uint32_t)0x9037290u);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900C9EA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900C9EA:
    ecx = (uint32_t)((uint32_t)0x6u);
    esi = (uint32_t)((uint32_t)0x90372BCu);
    edi = (uint32_t)((uint32_t)0x9028008u);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    M16(edi) = M16(esi); esi += (c->df ? -2 : 2); edi += (c->df ? -2 : 2);
    M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CA09(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CA09:
    eax = (uint32_t)(TL32((uint32_t)(0x90372D8u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x90372DCu)));
    edx = (uint32_t)(TL32((uint32_t)(0x90372E0u)));
    TS32((uint32_t)(0x9028008u), (uint32_t)(eax));
    TS32((uint32_t)(0x902800Cu), (uint32_t)(ecx));
    TS32((uint32_t)(0x9028010u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x9028008u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CA70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CA70:
    eax = (uint32_t)((uint32_t)0x9028118u);
    esp += 4; SPILL(); return;
}

void f_900CA80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CA80:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900CA8Du; SPILL(); f_900C130(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CABA;
    goto L_900CA91;
L_900CA91:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900CAA7u; SPILL(); f_900B120(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900CAB0u; SPILL(); f_900C250(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900CABA:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900CAD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CAD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x24u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900CCA2;
    goto L_900CAE5;
L_900CAE5:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    edx = (uint32_t)((uint32_t)(esp + 0x8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x20u);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900CB1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    (void)sub32(eax, (uint32_t)0x59565955u, &f);
    if (!f.zf) goto L_900CB33;
    goto L_900CB27;
L_900CB27:
    eax = (uint32_t)((uint32_t)0xEu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CB33:
    (void)sub32(eax, (uint32_t)0x32315659u, &f);
    if (!f.zf) goto L_900CB46;
    goto L_900CB3A;
L_900CB3A:
    eax = (uint32_t)((uint32_t)0xFu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CB46:
    (void)sub32(eax, (uint32_t)0x32595559u, &f);
    if (!f.zf) goto L_900CB59;
    goto L_900CB4D;
L_900CB4D:
    eax = (uint32_t)((uint32_t)0xDu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CB59:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    (void)sub32(eax, (uint32_t)0x8u, &f);
    if (!f.zf) goto L_900CB6B;
    goto L_900CB62;
L_900CB62:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CB6B:
    (void)sub32(eax, (uint32_t)0x18u, &f);
    if (!f.zf) goto L_900CB85;
    goto L_900CB70;
L_900CB70:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x18u)), (uint32_t)0xFF0000u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(inc32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CB85:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_900CBBC;
    goto L_900CB8A;
L_900CB8A:
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x24u)), eax, &f);
    if (!f.zf) goto L_900CBA7;
    goto L_900CB92;
L_900CB92:
    (void)sub32(M32((uint32_t)(esp + 0x18u)), (uint32_t)0xFF0000u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CBA7:
    (void)sub32(M32((uint32_t)(esp + 0x18u)), (uint32_t)0xFF0000u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(add32(eax, (uint32_t)0x5u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CBBC:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    (void)sub32(ecx, (uint32_t)0xF800u, &f);
    if (!f.zf) goto L_900CBE9;
    goto L_900CBD0;
L_900CBD0:
    (void)sub32(edx, (uint32_t)0x7E0u, &f);
    if (!f.zf) goto L_900CBE9;
    goto L_900CBD8;
L_900CBD8:
    (void)sub32(eax, (uint32_t)0x1Fu, &f);
    if (!f.zf) goto L_900CBE9;
    goto L_900CBDD;
L_900CBDD:
    eax = (uint32_t)((uint32_t)0xAu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CBE9:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    (void)sub32(esi, (uint32_t)0x8000u, &f);
    if (!f.zf) goto L_900CC1E;
    goto L_900CBF5;
L_900CBF5:
    (void)sub32(ecx, (uint32_t)0x7C00u, &f);
    if (!f.zf) goto L_900CC3F;
    goto L_900CBFD;
L_900CBFD:
    (void)sub32(edx, (uint32_t)0x3E0u, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC09;
L_900CC09:
    (void)sub32(eax, (uint32_t)0x1Fu, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC12;
L_900CC12:
    eax = (uint32_t)((uint32_t)0x8u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CC1E:
    (void)sub32(ecx, (uint32_t)0x7C00u, &f);
    if (!f.zf) goto L_900CC3F;
    goto L_900CC26;
L_900CC26:
    (void)sub32(edx, (uint32_t)0x3E0u, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC2E;
L_900CC2E:
    (void)sub32(eax, (uint32_t)0x1Fu, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC33;
L_900CC33:
    eax = (uint32_t)((uint32_t)0x9u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CC3F:
    (void)sub32(ecx, (uint32_t)0xFC00u, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC47;
L_900CC47:
    (void)sub32(edx, (uint32_t)0x3E0u, &f);
    if (!f.zf) goto L_900CC60;
    goto L_900CC4F;
L_900CC4F:
    (void)sub32(eax, (uint32_t)0x1Fu, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC54;
L_900CC54:
    eax = (uint32_t)((uint32_t)0xBu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CC60:
    (void)sub32(edx, (uint32_t)0x3F0u, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC68;
L_900CC68:
    (void)sub32(eax, (uint32_t)0xFu, &f);
    if (!f.zf) goto L_900CC79;
    goto L_900CC6D;
L_900CC6D:
    eax = (uint32_t)((uint32_t)0xCu);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CC79:
    (void)sub32(esi, (uint32_t)0xF000u, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC81;
L_900CC81:
    (void)sub32(ecx, (uint32_t)0xF00u, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC89;
L_900CC89:
    (void)sub32(edx, (uint32_t)0xF0u, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC91;
L_900CC91:
    (void)sub32(eax, (uint32_t)0xFu, &f);
    if (!f.zf) goto L_900CCA2;
    goto L_900CC96;
L_900CC96:
    eax = (uint32_t)((uint32_t)0x7u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CCA2:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CCB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CCB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_900CCC9;
    goto L_900CCC0;
L_900CCC0:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CCC9:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x20u)));
    edx = (uint32_t)((uint32_t)(esp));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900CCF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)sub32(eax, (uint32_t)0x1Eu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_900CD5C;
    goto L_900CCFE;
L_900CCFE:
    if (f.zf) goto L_900CD51;
    goto L_900CD00;
L_900CD00:
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFECu, &f));
    (void)sub32(eax, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_900CCC0;
    goto L_900CD08;
L_900CD08:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900CD84u)); goto L_dispatch; }
L_900CD0F:
    eax = (uint32_t)((uint32_t)0x1u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD1A:
    eax = (uint32_t)((uint32_t)0x5u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD25:
    eax = (uint32_t)((uint32_t)0x3u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD30:
    eax = (uint32_t)((uint32_t)0xAu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD3B:
    eax = (uint32_t)((uint32_t)0x9u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD46:
    eax = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD51:
    eax = (uint32_t)((uint32_t)0x7u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD5C:
    (void)sub32(eax, (uint32_t)0x32595559u, &f);
    if (f.zf) goto L_900CD79;
    goto L_900CD63;
L_900CD63:
    (void)sub32(eax, (uint32_t)0x59565955u, &f);
    if (!f.zf) goto L_900CCC0;
    goto L_900CD6E;
L_900CD6E:
    eax = (uint32_t)((uint32_t)0xEu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CD79:
    eax = (uint32_t)((uint32_t)0xDu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900CCB0u: goto L_900CCB0; case 0x900CCC0u: goto L_900CCC0; case 0x900CCC9u: goto L_900CCC9; case 0x900CCFEu: goto L_900CCFE; case 0x900CD00u: goto L_900CD00; case 0x900CD08u: goto L_900CD08; case 0x900CD0Fu: goto L_900CD0F; case 0x900CD1Au: goto L_900CD1A; case 0x900CD25u: goto L_900CD25; case 0x900CD30u: goto L_900CD30; case 0x900CD3Bu: goto L_900CD3B; case 0x900CD46u: goto L_900CD46; case 0x900CD51u: goto L_900CD51; case 0x900CD5Cu: goto L_900CD5C; case 0x900CD63u: goto L_900CD63; case 0x900CD6Eu: goto L_900CD6E; case 0x900CD79u: goto L_900CD79; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900CD0F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD0F:
    eax = (uint32_t)((uint32_t)0x1u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD1A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD1A:
    eax = (uint32_t)((uint32_t)0x5u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD25(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD25:
    eax = (uint32_t)((uint32_t)0x3u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD30:
    eax = (uint32_t)((uint32_t)0xAu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD3B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD3B:
    eax = (uint32_t)((uint32_t)0x9u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD46(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD46:
    eax = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CD51(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CD51:
    eax = (uint32_t)((uint32_t)0x7u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CDA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CDA0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_900CDB9;
    goto L_900CDB0;
L_900CDB0:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CDB9:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x30u)));
    edx = (uint32_t)((uint32_t)(esp));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900CDE6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)sub32(eax, (uint32_t)0x1Eu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_900CE4C;
    goto L_900CDEE;
L_900CDEE:
    if (f.zf) goto L_900CE41;
    goto L_900CDF0;
L_900CDF0:
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFECu, &f));
    (void)sub32(eax, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_900CDB0;
    goto L_900CDF8;
L_900CDF8:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900CE74u)); goto L_dispatch; }
L_900CDFF:
    eax = (uint32_t)((uint32_t)0x1u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE0A:
    eax = (uint32_t)((uint32_t)0x5u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE15:
    eax = (uint32_t)((uint32_t)0x3u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE20:
    eax = (uint32_t)((uint32_t)0xAu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE2B:
    eax = (uint32_t)((uint32_t)0x9u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE36:
    eax = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE41:
    eax = (uint32_t)((uint32_t)0x7u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE4C:
    (void)sub32(eax, (uint32_t)0x32595559u, &f);
    if (f.zf) goto L_900CE69;
    goto L_900CE53;
L_900CE53:
    (void)sub32(eax, (uint32_t)0x59565955u, &f);
    if (!f.zf) goto L_900CDB0;
    goto L_900CE5E;
L_900CE5E:
    eax = (uint32_t)((uint32_t)0xEu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900CE69:
    eax = (uint32_t)((uint32_t)0xDu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x900CDA0u: goto L_900CDA0; case 0x900CDB0u: goto L_900CDB0; case 0x900CDB9u: goto L_900CDB9; case 0x900CDEEu: goto L_900CDEE; case 0x900CDF0u: goto L_900CDF0; case 0x900CDF8u: goto L_900CDF8; case 0x900CDFFu: goto L_900CDFF; case 0x900CE0Au: goto L_900CE0A; case 0x900CE15u: goto L_900CE15; case 0x900CE20u: goto L_900CE20; case 0x900CE2Bu: goto L_900CE2B; case 0x900CE36u: goto L_900CE36; case 0x900CE41u: goto L_900CE41; case 0x900CE4Cu: goto L_900CE4C; case 0x900CE53u: goto L_900CE53; case 0x900CE5Eu: goto L_900CE5E; case 0x900CE69u: goto L_900CE69; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900CDFF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CDFF:
    eax = (uint32_t)((uint32_t)0x1u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE0A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE0A:
    eax = (uint32_t)((uint32_t)0x5u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE15(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE15:
    eax = (uint32_t)((uint32_t)0x3u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE20:
    eax = (uint32_t)((uint32_t)0xAu);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE2B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE2B:
    eax = (uint32_t)((uint32_t)0x9u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE36(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE36:
    eax = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE41(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE41:
    eax = (uint32_t)((uint32_t)0x7u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900CE90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CE90:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(0x9031054u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900CEE0;
    goto L_900CE9F;
L_900CE9F:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900CEC4;
    goto L_900CEA8;
L_900CEA8:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900CEB0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CF4F;
    goto L_900CEB8;
L_900CEB8:
    (void)sub32(eax, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_900CEE0;
    goto L_900CEBF;
L_900CEBF:
    goto L_900CF4F;
L_900CEC4:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900CEE0;
    goto L_900CEC8;
L_900CEC8:
    { uint32_t t_ = TL32((uint32_t)(0x9031188u)); esp -= 4; M32(esp) = 0x900CECEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x900CED8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900CF4F;
    goto L_900CEDC;
L_900CEDC:
    esp = (uint32_t)((uint32_t)(esp));
L_900CEE0:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CF0F;
    goto L_900CEE9;
L_900CEE9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372E4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028464u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x60u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900CF07u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900CF0F:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900CF3B;
    goto L_900CF13;
L_900CF13:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900CF27;
    goto L_900CF1D;
L_900CF1D:
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900CF25u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900CF36;
L_900CF27:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900CF3B;
    goto L_900CF2C;
L_900CF2C:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031034u)); esp -= 4; M32(esp) = 0x900CF36u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900CF36:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900CF3B:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CF7B;
    goto L_900CF3F;
L_900CF3F:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x64u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2Du; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900CF4Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900CF4F:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CF7B;
    goto L_900CF58;
L_900CF58:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372E4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028224u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x6Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900CF78u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
L_900CF7B:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900CF80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900CF80:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900CFAC;
    goto L_900CF8C;
L_900CF8C:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D00C;
    goto L_900CF95;
L_900CF95:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x900CFA1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D024;
    goto L_900CFA5;
L_900CFA5:
    (void)sub32(eax, (uint32_t)0x80u, &f);
    if (f.zf) goto L_900D024;
    goto L_900CFAC;
L_900CFAC:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900D06A;
    goto L_900CFB7;
L_900CFB7:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CFDE;
    goto L_900CFC0;
L_900CFC0:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x60u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037334u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028470u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900CFDBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900CFDE:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x900CFE6u; SPILL(); f_9027720(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    if (f.zf) goto L_900D056;
    goto L_900CFEF;
L_900CFEF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D003;
    goto L_900CFF3;
L_900CFF3:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x40u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x64u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D003u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D003:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D00C:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900CFAC;
    goto L_900D010;
L_900D010:
    { uint32_t t_ = TL32((uint32_t)(0x9031188u)); esp -= 4; M32(esp) = 0x900D016u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x900D020u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900CFAC;
    goto L_900D024;
L_900D024:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D04D;
    goto L_900D02D;
L_900D02D:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x6Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037328u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028490u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900D04Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
L_900D04D:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D056:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D06A;
    goto L_900D05A;
L_900D05A:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x64u)));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x45u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900D06Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D06A:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D070(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D070:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D09D;
    goto L_900D080;
L_900D080:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037348u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028234u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x6Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D09Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
L_900D09D:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900D0C5;
    goto L_900D0A1;
L_900D0A1:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D0B7;
    goto L_900D0AA;
L_900D0AA:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031078u)); esp -= 4; M32(esp) = 0x900D0B4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D0B7:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900D0C5;
    goto L_900D0BB;
L_900D0BB:
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031048u)); esp -= 4; M32(esp) = 0x900D0C5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D0C5:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D0D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D0D0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D0E6;
    goto L_900D0D4;
L_900D0D4:
    ecx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(edx);
    TS32((uint32_t)(esi + 0x468u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x468u)), ecx, &f)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D0E5u; SPILL(); f_901E2B0(c); RELOAD();
    esp += 4; SPILL(); return;
L_900D0E6:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(esi + 0x468u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x468u)), ecx, &f)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D0F8u; SPILL(); f_901E2B0(c); RELOAD();
    esp += 4; SPILL(); return;
}

void f_900D100(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D100:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9028598u);
    esi = (uint32_t)((uint32_t)0x1u);
    TS8((uint32_t)(0x9028598u), (uint8_t)(((uint8_t)edx)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_900D120;
L_900D120:
    (void)sub8(TL8((uint32_t)(ecx)), (uint8_t)0x0u, &f);
    if (f.zf) goto L_900D13A;
    goto L_900D125;
L_900D125:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x1u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)((uint32_t)(esi + eax));
    (void)sub32(edx, (uint32_t)0xFFu, &f);
    if (!f.zf) goto L_900D120;
    goto L_900D137;
L_900D137:
    TS8((uint32_t)(eax), (uint8_t)((uint8_t)0x0u));
L_900D13A:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900D140(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D140:
    eax = (uint32_t)((uint32_t)0x9028598u);
    esp += 4; SPILL(); return;
}

void f_900D150(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D150:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x903FDE8u);
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(ecx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D220;
    goto L_900D169;
L_900D169:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(0x9031050u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
L_900D171:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)((uint32_t)0x903FDE8u);
    { uint32_t s_ = edx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(eax)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); edx = (uint32_t)(o_); }
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(edi, (uint32_t)0x200u, &f);
    if (!f.zf) goto L_900D1CE;
    goto L_900D188;
L_900D188:
    eax = (uint32_t)(TL32((uint32_t)(0x904000Cu)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_900D1CA;
    goto L_900D192;
L_900D192:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D1C0;
    goto L_900D196;
L_900D196:
    { uint32_t v_ = 0x9041090u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x900D1A6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x900D1ADu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x904000Cu), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D1CA;
    goto L_900D1B6;
L_900D1B6:
    TS32((uint32_t)(0x904000Cu), (uint32_t)((uint32_t)0x1u));
L_900D1C0:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x900D1C8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D208;
L_900D1CA:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D1CCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D208;
L_900D1CE:
    (void)sub32(edi, (uint32_t)0x400u, &f);
    if (f.cf) goto L_900D208;
    goto L_900D1D6;
L_900D1D6:
    edi = (uint32_t)(logic32(0, &f));
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900D1DAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x900D1E1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900D1E7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x900D1EEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x900D1F6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(esi, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_900D208;
    goto L_900D1FE;
L_900D1FE:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900D201u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x900D208u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D208:
    eax = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x903FDE8u);
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(ecx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D171;
    goto L_900D21E;
L_900D21E:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_900D220:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D230(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D230:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D239u; SPILL(); f_900D150(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D36B;
    goto L_900D246;
L_900D246:
    ecx = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(eax + 0x1u));
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900D27A;
    goto L_900D255;
L_900D255:
    TS32((uint32_t)(0x903302Cu), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x900D260u; SPILL(); f_90011C0(c); RELOAD();
    (void)sub32(TL32((uint32_t)(0x9033028u)), edi, &f);
    if (!f.zf) goto L_900D270;
    goto L_900D268;
L_900D268:
    TS32((uint32_t)(0x903302Cu), (uint32_t)(edi));
    goto L_900D27A;
L_900D270:
    TS32((uint32_t)(0x903302Cu), (uint32_t)((uint32_t)0x1F4u));
L_900D27A:
    edx = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x90286A7u);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x9028714u), (uint32_t)(esi));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903106Cu)); esp -= 4; M32(esp) = 0x900D2A1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(eax));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0x22u), &f));
    { uint32_t o_ = __atomic_exchange_n((uint32_t *)(MEM + (uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)eax, __ATOMIC_SEQ_CST); eax = (uint32_t)(o_); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9028240u);
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900D2BAu; SPILL(); f_90275A0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D2C0;
    goto L_900D2BF;
L_900D2BF:
    SPILL(); rt_int3(c, 0x900D2BFu);
L_900D2C0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x900D2CBu; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D2D0;
    goto L_900D2CF;
L_900D2CF:
    SPILL(); rt_int3(c, 0x900D2CFu);
L_900D2D0:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D333;
    goto L_900D2D9;
L_900D2D9:
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028448u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D2EEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D333;
    goto L_900D2FA;
L_900D2FA:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90282C0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900D30Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D333;
    goto L_900D31B;
L_900D31B:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t v_ = 0x9037380u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902823Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900D330u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_900D333:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9028518u);
    esp -= 4; M32(esp) = 0x900D33Eu; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D343;
    goto L_900D342;
L_900D342:
    SPILL(); rt_int3(c, 0x900D342u);
L_900D343:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D364;
    goto L_900D34C;
L_900D34C:
    { uint32_t v_ = 0x9037398u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028488u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028518u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D361u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_900D364:
    TS32((uint32_t)(0x903FDE0u), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_900D36B:
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)((uint32_t)0x903FDE8u);
    { uint32_t s_ = ecx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(edx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); ecx = (uint32_t)(o_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D490(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D490:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D496u; SPILL(); f_900D230(c); RELOAD();
    { uint32_t v_ = 0x107u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900D4AAu; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D4C5;
    goto L_900D4B7;
L_900D4B7:
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900D4D6;
    goto L_900D4BB;
L_900D4BB:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D4B7;
    goto L_900D4C5;
L_900D4C5:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    TS32((uint32_t)(edi + 0xE4u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FDE4u), (uint32_t)(edi));
L_900D4D6:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x118u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900D4EAu; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D4F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D4F0:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x11Du; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900D505u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(eax, edi, &f);
    if (!f.zf) goto L_900D526;
    goto L_900D512;
L_900D512:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0xE4u)));
    TS32((uint32_t)(0x903FDE4u), (uint32_t)(edx));
    goto L_900D54E;
L_900D526:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D54E;
    goto L_900D52F;
L_900D52F:
L_900D530:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xE4u)));
    (void)sub32(ecx, edi, &f);
    if (f.zf) goto L_900D542;
    goto L_900D53A;
L_900D53A:
    eax = (uint32_t)(ecx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D530;
    goto L_900D540;
L_900D540:
    goto L_900D54E;
L_900D542:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xE4u)));
    TS32((uint32_t)(eax + 0xE4u), (uint32_t)(ecx));
L_900D54E:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x130u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900D562u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D570(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D570:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x137u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900D58Cu; SPILL(); f_900CE90(c); RELOAD();
    { uint32_t v_ = 0x138u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900D59Bu; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D620;
    goto L_900D5A2;
L_900D5A2:
    goto L_900D5B0;
L_900D5B0:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x13Au);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900D5C4u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = 0x13Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900D5D1u; SPILL(); f_900CE90(c); RELOAD();
    { uint32_t v_ = 0x13Du; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900D5E7u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D620;
    goto L_900D5EE;
L_900D5EE:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x13Fu);
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x900D5FBu; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = 0x137u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D60Au; SPILL(); f_900CE90(c); RELOAD();
    { uint32_t v_ = 0x138u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900D619u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D5B0;
    goto L_900D620;
L_900D620:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D630(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D630:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900D686;
    goto L_900D63B;
L_900D63B:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D641u; SPILL(); f_900D230(c); RELOAD();
    { uint32_t v_ = 0x155u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x900D655u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D68D;
    goto L_900D662;
L_900D662:
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_900D694;
    goto L_900D666;
L_900D666:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDF4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D68D;
    goto L_900D66F;
L_900D66F:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x162u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900D683u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900D686:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900D68D:
    eax = (uint32_t)(edi);
    TS32((uint32_t)(0x903FDECu), (uint32_t)(eax));
L_900D694:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D69Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D6A3;
    goto L_900D69E;
L_900D69E:
    TS32((uint32_t)(0x903FDF0u), (uint32_t)(eax));
L_900D6A3:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x16Eu);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900D6B7u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(0x903FDF0u)), eax, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900D6D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D6D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x18u)), &f));
    if (!f.sf) goto L_900D6DE;
    goto L_900D6DB;
L_900D6DB:
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(esi + 0x8u)), &f));
L_900D6DE:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x48u)));
    (void)sub32(eax, ecx, &f);
    if ((f.sf == f.of)) goto L_900D756;
    goto L_900D6E5;
L_900D6E5:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(esi + 0x24u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(esi + 0x20u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x3E8u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = edi; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(sub32(TL32((uint32_t)(esi + 0x18u)), ecx, &f)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_900D742;
    goto L_900D712;
L_900D712:
    edi = (uint32_t)(edx);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edi = (uint32_t)(sub32(edi, eax, &f));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(add32(ebx, eax, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(ebx));
    esp -= 4; M32(esp) = 0x900D72Au; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D736u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D742:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D74Bu; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D756:
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900D760(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900D760:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0x903FE00u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900D9ED;
    goto L_900D771;
L_900D771:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    goto L_900D780;
L_900D780:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900D9EA;
    goto L_900D78E;
L_900D78E:
    { uint32_t v_ = 0x1D7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    esp -= 4; M32(esp) = 0x900D7A9u; SPILL(); f_900CE90(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_900D7B2:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900D923;
    goto L_900D7BA;
L_900D7BA:
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900D918;
    goto L_900D7C7;
L_900D7C7:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900D918;
    goto L_900D7D4;
L_900D7D4:
    { uint32_t v_ = 0x1DDu; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(edi + 0x3B0u));
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900D7EDu; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D903;
    goto L_900D7F8;
L_900D7F8:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x1E1u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900D80Cu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(0x903FE04u), (uint32_t)((uint32_t)0xDu));
    if (!f.zf) goto L_900D8B5;
    goto L_900D826;
L_900D826:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900D8B5;
    goto L_900D833;
L_900D833:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D86A;
    goto L_900D840;
L_900D840:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (f.zf) goto L_900D86A;
    goto L_900D845;
L_900D845:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900D8B5;
    goto L_900D849;
L_900D849:
    eax = (uint32_t)(edx);
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x164u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FE04u)));
    eax = (uint32_t)(neg32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_900D8B5;
    goto L_900D863;
L_900D863:
    TS32((uint32_t)(0x903FE04u), (uint32_t)(eax));
    goto L_900D8B5;
L_900D86A:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D894;
    goto L_900D873;
L_900D873:
    { uint32_t v_ = 0x90373CCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902821Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1E9u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900D891u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900D894:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900D89Au; SPILL(); f_900DDF0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D8B5;
    goto L_900D8A3;
L_900D8A3:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x1EBu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900D8B5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D8B5:
    { uint32_t v_ = 0x1F5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900D8CBu; SPILL(); f_900CF80(c); RELOAD();
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x1F7u);
    ecx = (uint32_t)((uint32_t)0x90373B0u);
    esi = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900D8DDu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900D918;
    goto L_900D8E4;
L_900D8E4:
    eax = (uint32_t)(TL32((uint32_t)(0x903FE00u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D780;
    goto L_900D8F1;
L_900D8F1:
    eax = (uint32_t)(TL32((uint32_t)(0x903FE00u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(neg32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(sbb32(eax, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(neg32(eax, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D903:
    edx = (uint32_t)(TL32((uint32_t)(0x903FE04u)));
    (void)sub32(edx, (uint32_t)0x2u, &f);
    if ((f.cf || f.zf)) goto L_900D918;
    goto L_900D90E;
L_900D90E:
    TS32((uint32_t)(0x903FE04u), (uint32_t)((uint32_t)0x2u));
L_900D918:
    edi = (uint32_t)(TL32((uint32_t)(edi + 0xE4u)));
    goto L_900D7B2;
L_900D923:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x205u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900D937u; SPILL(); f_900D070(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900D9EA;
    goto L_900D945;
L_900D945:
    { uint32_t v_ = 0x20Au; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x900D95Bu; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D9D6;
    goto L_900D962;
L_900D962:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D98C;
    goto L_900D96B;
L_900D96B:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90373D8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028478u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x20Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900D989u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900D98C:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900D992u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D9AD;
    goto L_900D99B;
L_900D99B:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x20Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900D9ADu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D9AD:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x20Fu);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900D9C1u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FE00u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(neg32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(sbb32(eax, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(neg32(eax, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900D9D6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FE04u)));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if ((f.cf || f.zf)) goto L_900D9EA;
    goto L_900D9E0;
L_900D9E0:
    TS32((uint32_t)(0x903FE04u), (uint32_t)((uint32_t)0x2u));
L_900D9EA:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_900D9ED:
    eax = (uint32_t)(TL32((uint32_t)(0x903FE00u)));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(neg32(eax, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900DA00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DA00:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DA23;
    goto L_900DA09;
L_900DA09:
    { uint32_t v_ = 0x90373ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028494u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x58u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900DA1Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_900DA23:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x9031054u)));
    goto L_900DA35;
L_900DA30:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900DA35:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DA5A;
    goto L_900DA39;
L_900DA39:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90373F8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028460u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x222u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900DA57u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900DA5A:
    eax = (uint32_t)(TL32((uint32_t)(0x903FE04u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900DA66;
    goto L_900DA64;
L_900DA64:
    eax = (uint32_t)(logic32((uint32_t)(eax | eax), &f));
L_900DA66:
    edx = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900DA72u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DA8D;
    goto L_900DA7B;
L_900DA7B:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x224u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900DA8Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900DA8D:
    esp -= 4; M32(esp) = 0x900DA92u; SPILL(); f_900D760(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DA30;
    goto L_900DA96;
L_900DA96:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900DAA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DAA0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x22Fu; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x900DAC0u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDF8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DADF;
    goto L_900DACC;
L_900DACC:
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FDFCu), (uint32_t)(add32(TL32((uint32_t)(0x903FDFCu)), eax, &f)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    goto L_900DBC5;
L_900DADF:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4000u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x90283D7u);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FE00u), (uint32_t)(edi));
    TS32((uint32_t)(0x9028404u), (uint32_t)(ecx));
    { uint32_t t_ = TL32((uint32_t)(0x9031044u)); esp -= 4; M32(esp) = 0x900DB01u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    TS32((uint32_t)(edx), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900DBC5;
    goto L_900DB17;
L_900DB17:
    { uint32_t v_ = 0x90373ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x900DA00u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90282C8u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900DB31u; SPILL(); f_9027170(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DBA7;
    goto L_900DB35;
L_900DB35:
    ebx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FDFCu), (uint32_t)(add32(TL32((uint32_t)(0x903FDFCu)), ebx, &f)));
    TS32((uint32_t)(0x903FDF8u), (uint32_t)(ebx));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900DB4Eu; SPILL(); f_90011C0(c); RELOAD();
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)0x2u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = TL32((uint32_t)(0x9033028u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    eax = (uint32_t)((uint32_t)0x90282C8u);
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(edx + 0x9036AA0u)));
    esp -= 4; M32(esp) = 0x900DB6Cu; SPILL(); f_9027400(c); RELOAD();
    esi = (uint32_t)(TL32((uint32_t)(0x90283C4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    edi = (uint32_t)(TL32((uint32_t)(0x9031068u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x34u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900DB81u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ebx = (uint32_t)(TL32((uint32_t)(0x9031040u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900DB8Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(TL32((uint32_t)(0x90283C4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x34u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900DB9Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(inc32(eax, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900DBA5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900DBC5;
L_900DBA7:
    eax = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900DBC5;
    goto L_900DBB1;
L_900DBB1:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x900DBBAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_900DBC5:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x254u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900DBD9u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900DBF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DBF0:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x25Bu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x900DC05u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDF8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DCAF;
    goto L_900DC15;
L_900DC15:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FE00u), (uint32_t)((uint32_t)0x1u));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x900DC32u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x90283C4u)));
    (void)sub32(TL32((uint32_t)(eax + 0x40u)), (uint32_t)0x0u, &f);
    esi = (uint32_t)((uint32_t)(eax + 0x40u));
    if (!f.zf) goto L_900DC5B;
    goto L_900DC40;
L_900DC40:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x900DC4Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900DC56;
    goto L_900DC50;
L_900DC50:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x80000000u));
L_900DC56:
    eax = (uint32_t)(TL32((uint32_t)(0x90283C4u)));
L_900DC5B:
    ecx = (uint32_t)((uint32_t)(eax + 0x3Cu));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)0x3u);
    esi = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(esi)), &exp_, (uint32_t)edx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(TL32((uint32_t)(ecx)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900DC7B;
    goto L_900DC76;
L_900DC76:
    esp -= 4; M32(esp) = 0x900DC7Bu; SPILL(); f_90274F0(c); RELOAD();
L_900DC7B:
    eax = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    if (f.zf) goto L_900DC9B;
    goto L_900DC86;
L_900DC86:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x900DC8Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_900DC9B:
    TS32((uint32_t)(0x903FDFCu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x903FDF8u), (uint32_t)((uint32_t)0x0u));
L_900DCAF:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x26Au);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900DCC3u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900DCD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DCD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x26Fu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x900DCE9u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(0x903FDFCu), (uint32_t)(add32(TL32((uint32_t)(0x903FDFCu)), eax, &f)));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FDFCu)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    if (!f.zf) goto L_900DD10;
    goto L_900DCFE;
L_900DCFE:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900DD0B;
    goto L_900DD04;
L_900DD04:
    esp -= 4; M32(esp) = 0x900DD09u; SPILL(); f_900DBF0(c); RELOAD();
    goto L_900DD10;
L_900DD0B:
    TS32((uint32_t)(0x903FE04u), (uint32_t)(eax));
L_900DD10:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x27Bu);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x900DD24u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900DD30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DD30:
    (void)sub32(TL32((uint32_t)(ecx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900DD68;
    goto L_900DD39;
L_900DD39:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_900DD4B;
    goto L_900DD46;
L_900DD46:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900DD68;
    goto L_900DD4B;
L_900DD4B:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x282u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(ecx + 0x3B0u));
    esp -= 4; M32(esp) = 0x900DD63u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900DD68:
    eax = (uint32_t)(logic32(0, &f));
    esp += 4; SPILL(); return;
}

void f_900DD70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DD70:
    (void)sub32(TL32((uint32_t)(ecx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900DDA5;
    goto L_900DD79;
L_900DD79:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_900DD8B;
    goto L_900DD86;
L_900DD86:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900DDA5;
    goto L_900DD8B;
L_900DD8B:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x28Au; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(ecx + 0x3B0u));
    esp -= 4; M32(esp) = 0x900DDA1u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_900DDA5:
    esp += 4; SPILL(); return;
}

