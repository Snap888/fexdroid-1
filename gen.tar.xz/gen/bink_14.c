#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9017800(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017800:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)sub32(TL32((uint32_t)(esi + 0xCCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901781D;
    goto L_901780D;
L_901780D:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C478u));
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901781D:
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf != f.of)) goto L_9017836;
    goto L_9017821;
L_9017821:
    ecx = (uint32_t)((uint32_t)(eax + 0x3E7u));
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    (void)sub32(edx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9017839;
    goto L_9017836;
L_9017836:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
L_9017839:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(0x9031054u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x9017849u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901785B;
    goto L_901784D;
L_901784D:
    (void)sub32(eax, (uint32_t)0x80u, &f);
    if (f.zf) goto L_901785B;
    goto L_9017854;
L_9017854:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901785B:
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)((uint32_t)(esi + 0xC0u));
    { uint32_t s_ = ecx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(edx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); ecx = (uint32_t)(o_); }
    eax = (uint32_t)((uint32_t)(esi + 0x40u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017895;
    goto L_9017872;
L_9017872:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_9017886;
    goto L_901787C;
L_901787C:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x9017884u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9017895;
L_9017886:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_9017895;
    goto L_901788B;
L_901788B:
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031034u)); esp -= 4; M32(esp) = 0x9017895u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9017895:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xC4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xC8u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    if (!f.sf) goto L_90178AA;
    goto L_90178A5;
L_90178A5:
    eax = (uint32_t)(add32(eax, (uint32_t)0x180u, &f));
L_90178AA:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_90178B7;
    goto L_90178B2;
L_90178B2:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
L_90178B7:
    edi = (uint32_t)((uint32_t)0x180u);
    edi = (uint32_t)(sub32(edi, ecx, &f));
    (void)sub32(edi, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_90178EB;
    goto L_90178C2;
L_90178C2:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + ecx*4 + 0xD0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90178D4u; SPILL(); f_9001FE0(c); RELOAD();
    ebx = (uint32_t)(add32(ebx, edi, &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xC4u), (uint32_t)((uint32_t)0x0u));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
L_90178EB:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xC4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + edx*4 + 0xD0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017903u; SPILL(); f_9001FE0(c); RELOAD();
    TS32((uint32_t)(esi + 0xC4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xC4u)), ebx, &f)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901793D;
    goto L_9017914;
L_9017914:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_901792F;
    goto L_901791D;
L_901791D:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031078u)); esp -= 4; M32(esp) = 0x9017927u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901792F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_901793D;
    goto L_9017933;
L_9017933:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031048u)); esp -= 4; M32(esp) = 0x901793Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901793D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017950(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017950:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90179A6;
    goto L_9017958;
L_9017958:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xFCu)));
    (void)sub32(TL32((uint32_t)(edi + 0x40u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901797B;
    goto L_9017964;
L_9017964:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x34u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x9017970u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90179A6;
    goto L_9017974;
L_9017974:
    TS32((uint32_t)(edi + 0x40u), (uint32_t)((uint32_t)0x80000000u));
L_901797B:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xFCu)));
    ecx = (uint32_t)((uint32_t)(edi + 0x3Cu));
    edx = (uint32_t)((uint32_t)0x3u);
    esi = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(esi)), &exp_, (uint32_t)edx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(TL32((uint32_t)(ecx)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901799E;
    goto L_9017999;
L_9017999:
    esp -= 4; M32(esp) = 0x901799Eu; SPILL(); f_90274F0(c); RELOAD();
L_901799E:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90179A6:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90179B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90179B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(ecx, (uint32_t)0x8u, &f);
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x0u));
    if ((f.sf != f.of)) goto L_90179D6;
    goto L_90179C6;
L_90179C6:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C48Cu));
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90179D6:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & ebx), &f);
    if (f.zf) goto L_90179F7;
    goto L_90179E6;
L_90179E6:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4A8u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90179F7:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0x6D0u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)((uint32_t)(edi + 0x90290C8u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9017A0Fu; SPILL(); f_90174F0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017A46;
    goto L_9017A13;
L_9017A13:
    esi = (uint32_t)((uint32_t)(edi + 0x902C748u));
    esp -= 4; M32(esp) = 0x9017A1Eu; SPILL(); f_90174F0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017A3E;
    goto L_9017A22;
L_9017A22:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0x10Cu; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)(add32(esi, (uint32_t)0x9028868u, &f));
    esp -= 4; M32(esp) = 0x9017A37u; SPILL(); f_9017660(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9017A4F;
    goto L_9017A3E;
L_9017A3E:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp -= 4; M32(esp) = 0x9017A46u; SPILL(); f_9017580(c); RELOAD();
L_9017A46:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017A4F:
    TS32((uint32_t)(0x903FAECu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) | ebx), &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017A70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017A70:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & eax), &f);
    if (!f.zf) goto L_9017A90;
    goto L_9017A82;
L_9017A82:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
L_9017A8C:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017A90:
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0x10Cu; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x9028868u, &f));
    eax = (uint32_t)(ecx);
    if (!f.zf) goto L_9017ABC;
    goto L_9017AA0;
L_9017AA0:
    ecx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9017A8C;
    goto L_9017AAB;
L_9017AAB:
    edx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903105Cu)); esp -= 4; M32(esp) = 0x9017AB8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017A8C;
    goto L_9017ABC;
L_9017ABC:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017AE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017AE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    edx = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(eax);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x0u));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & edx), &f);
    if (!f.zf) goto L_9017B0C;
    goto L_9017AFE;
L_9017AFE:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017B0C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x6D0u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x90290C8u, &f));
    esp -= 4; M32(esp) = 0x9017B22u; SPILL(); f_90176E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(neg32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017B30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017B30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    TS32((uint32_t)(0x903FCD4u), (uint32_t)(ecx));
    esi = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(eax);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & esi), &f);
    if (!f.zf) goto L_9017B62;
    goto L_9017B51;
L_9017B51:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
L_9017B5B:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017B62:
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x6D0u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x90290C8u, &f));
    esp -= 4; M32(esp) = 0x9017B78u; SPILL(); f_90176E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017B5B;
    goto L_9017B7F;
L_9017B7F:
    edx = (uint32_t)(esi);
    edx = (uint32_t)(~edx);
    TS32((uint32_t)(0x903FAECu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & edx), &f)));
    TS32((uint32_t)(0x903FCD0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FCD0u)) | esi), &f)));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017BA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017BA0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x0u));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FCD0u)) & eax), &f);
    if (!f.zf) goto L_9017BCC;
    goto L_9017BBE;
L_9017BBE:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4E8u));
L_9017BC8:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017BCC:
    eax = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x10Cu; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x9028868u, &f));
    esp -= 4; M32(esp) = 0x9017BDEu; SPILL(); f_9017950(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017BC8;
    goto L_9017BE2;
L_9017BE2:
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0x6D0u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x90290C8u));
    esp -= 4; M32(esp) = 0x9017BF4u; SPILL(); f_9017580(c); RELOAD();
    esi = (uint32_t)((uint32_t)(edi + 0x902C748u));
    esp -= 4; M32(esp) = 0x9017BFFu; SPILL(); f_9017580(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017C10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017C10:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    fpush(c, (double)MF32((uint32_t)(ebp + 0x10u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_9017C27:
    fpush(c, (double)MF32((uint32_t)(esi)));
    fpush(c, (double)MF32((uint32_t)(esi + 0x4u)));
    ST(0) = ST(0) * ST(2);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = ST(0) * ST(2);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(eax, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017C6E;
    goto L_9017C48;
L_9017C48:
    (void)sub32(eax, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017C8F;
    goto L_9017C4F;
L_9017C4F:
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017CB4;
    goto L_9017C5A;
L_9017C5A:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017CC6;
    goto L_9017C62;
L_9017C62:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017C27;
    goto L_9017C6C;
L_9017C6C:
    goto L_9017CD6;
L_9017C6E:
    TS16((uint32_t)(edi), (uint16_t)((uint16_t)0x7FFFu));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017CB4;
    goto L_9017C7B;
L_9017C7B:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017CC6;
    goto L_9017C83;
L_9017C83:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017C27;
    goto L_9017C8D;
L_9017C8D:
    goto L_9017CD6;
L_9017C8F:
    TS16((uint32_t)(edi), (uint16_t)((uint16_t)0x8000u));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017CB4;
    goto L_9017C9C;
L_9017C9C:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017CC6;
    goto L_9017CA4;
L_9017CA4:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017C27;
    goto L_9017CB2;
L_9017CB2:
    goto L_9017CD6;
L_9017CB4:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)((uint16_t)0x7FFFu));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017C27;
    goto L_9017CC4;
L_9017CC4:
    goto L_9017CD6;
L_9017CC6:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)((uint16_t)0x8000u));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017C27;
    goto L_9017CD6;
L_9017CD6:
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017CE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017CE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    fpush(c, (double)MF32((uint32_t)(ebp + 0x14u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(sub32(ebx, esi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_9017CFC:
    fpush(c, (double)MF32((uint32_t)(esi)));
    fpush(c, (double)MF32((uint32_t)(esi + ebx)));
    ST(0) = ST(0) * ST(2);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = ST(0) * ST(2);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(eax, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017D43;
    goto L_9017D1D;
L_9017D1D:
    (void)sub32(eax, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017D64;
    goto L_9017D24;
L_9017D24:
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017D89;
    goto L_9017D2F;
L_9017D2F:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017D9B;
    goto L_9017D37;
L_9017D37:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017CFC;
    goto L_9017D41;
L_9017D41:
    goto L_9017DAB;
L_9017D43:
    TS16((uint32_t)(edi), (uint16_t)((uint16_t)0x7FFFu));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017D89;
    goto L_9017D50;
L_9017D50:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017D9B;
    goto L_9017D58;
L_9017D58:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017CFC;
    goto L_9017D62;
L_9017D62:
    goto L_9017DAB;
L_9017D64:
    TS16((uint32_t)(edi), (uint16_t)((uint16_t)0x8000u));
    (void)sub32(edx, (uint32_t)0x7FFFu, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017D89;
    goto L_9017D71;
L_9017D71:
    (void)sub32(edx, (uint32_t)0xFFFF8000u, &f);
    if ((f.sf != f.of)) goto L_9017D9B;
    goto L_9017D79;
L_9017D79:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)(((uint16_t)edx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017CFC;
    goto L_9017D87;
L_9017D87:
    goto L_9017DAB;
L_9017D89:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)((uint16_t)0x7FFFu));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017CFC;
    goto L_9017D99;
L_9017D99:
    goto L_9017DAB;
L_9017D9B:
    TS16((uint32_t)(edi + 0x2u), (uint16_t)((uint16_t)0x8000u));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9017CFC;
    goto L_9017DAB;
L_9017DAB:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)fist32(c, ST(0)); fpop(c);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017DC0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017DC0:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF0u), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    c->xmm[1] = c->xmm[0];
    c->xmm[3] = c->xmm[0];
    c->xmm[2] = c->xmm[0];
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    { Xmm d_ = c->xmm[3], s_ = c->xmm[1]; c->xmm[3].u[0] = d_.u[0]; c->xmm[3].u[1] = s_.u[0]; c->xmm[3].u[2] = d_.u[1]; c->xmm[3].u[3] = s_.u[1]; }
    { Xmm d_ = c->xmm[0], s_ = c->xmm[2]; c->xmm[0].u[0] = d_.u[0]; c->xmm[0].u[1] = s_.u[0]; c->xmm[0].u[2] = d_.u[1]; c->xmm[0].u[3] = s_.u[1]; }
    { Xmm d_ = c->xmm[0], s_ = c->xmm[3]; c->xmm[0].u[0] = d_.u[0]; c->xmm[0].u[1] = s_.u[0]; c->xmm[0].u[2] = d_.u[1]; c->xmm[0].u[3] = s_.u[1]; }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9017E18;
    goto L_9017DE9;
L_9017DE9:
    esp = (uint32_t)((uint32_t)(esp));
L_9017DF0:
    c->xmm[1] = (*(Xmm *)(MEM + (uint32_t)(eax)));
    c->xmm[2] = (*(Xmm *)(MEM + (uint32_t)(eax + 0x10u)));
    { Xmm s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) c->xmm[1].f[k_] *= s_.f[k_]; }
    { Xmm s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) c->xmm[2].f[k_] *= s_.f[k_]; }
    { Xmm s_ = c->xmm[1]; for (int k_ = 0; k_ < 4; k_++) c->xmm[1].i[k_] = cvt_f2i(nearbyintf(s_.f[k_])); }
    { Xmm s_ = c->xmm[2]; for (int k_ = 0; k_ < 4; k_++) c->xmm[2].i[k_] = cvt_f2i(nearbyintf(s_.f[k_])); }
    { Xmm d_ = c->xmm[1], s_ = c->xmm[2]; for (int k_ = 0; k_ < 8; k_++) { int32_t v_ = k_ < 4 ? d_.i[k_] : s_.i[k_ - 4]; c->xmm[1].w[k_] = (uint16_t)(int16_t)(v_ > 32767 ? 32767 : v_ < -32768 ? -32768 : v_); } }
    memcpy(MEM + (uint32_t)(ecx), &c->xmm[1], 16);
    eax = (uint32_t)(add32(eax, (uint32_t)0x20u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x10u, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9017DF0;
    goto L_9017E18;
L_9017E18:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017E20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017E20:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF0u), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    c->xmm[0] = c->xmm[1];
    c->xmm[3] = c->xmm[1];
    c->xmm[2] = c->xmm[1];
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    { Xmm d_ = c->xmm[1], s_ = c->xmm[2]; c->xmm[1].u[0] = d_.u[0]; c->xmm[1].u[1] = s_.u[0]; c->xmm[1].u[2] = d_.u[1]; c->xmm[1].u[3] = s_.u[1]; }
    { Xmm d_ = c->xmm[3], s_ = c->xmm[0]; c->xmm[3].u[0] = d_.u[0]; c->xmm[3].u[1] = s_.u[0]; c->xmm[3].u[2] = d_.u[1]; c->xmm[3].u[3] = s_.u[1]; }
    { Xmm d_ = c->xmm[1], s_ = c->xmm[3]; c->xmm[1].u[0] = d_.u[0]; c->xmm[1].u[1] = s_.u[0]; c->xmm[1].u[2] = d_.u[1]; c->xmm[1].u[3] = s_.u[1]; }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9017E86;
    goto L_9017E52;
L_9017E52:
    esi = (uint32_t)(sub32(esi, eax, &f));
L_9017E54:
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(eax)));
    { Xmm s_ = c->xmm[1]; for (int k_ = 0; k_ < 4; k_++) c->xmm[0].f[k_] *= s_.f[k_]; }
    { Xmm s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) c->xmm[2].i[k_] = cvt_f2i(nearbyintf(s_.f[k_])); }
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(eax + ecx)));
    { Xmm s_ = c->xmm[1]; for (int k_ = 0; k_ < 4; k_++) c->xmm[0].f[k_] *= s_.f[k_]; }
    { Xmm s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) c->xmm[0].i[k_] = cvt_f2i(nearbyintf(s_.f[k_])); }
    c->xmm[3] = c->xmm[2];
    { Xmm d_ = c->xmm[3], s_ = c->xmm[0]; for (int k_ = 0; k_ < 8; k_++) { int32_t v_ = k_ < 4 ? d_.i[k_] : s_.i[k_ - 4]; c->xmm[3].w[k_] = (uint16_t)(int16_t)(v_ > 32767 ? 32767 : v_ < -32768 ? -32768 : v_); } }
    { Xmm d_ = c->xmm[0], s_ = c->xmm[2]; for (int k_ = 0; k_ < 8; k_++) { int32_t v_ = k_ < 4 ? d_.i[k_] : s_.i[k_ - 4]; c->xmm[0].w[k_] = (uint16_t)(int16_t)(v_ > 32767 ? 32767 : v_ < -32768 ? -32768 : v_); } }
    { Xmm d_ = c->xmm[3], s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[3].w[2 * k_] = d_.w[0 + k_]; c->xmm[3].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    memcpy(MEM + (uint32_t)(esi + eax), &c->xmm[3], 16);
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9017E54;
    goto L_9017E86;
L_9017E86:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017E90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017E90:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32(0, &f));
    M16((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint16_t)(((uint16_t)edx));
    edx = (uint32_t)((uint32_t)0x1u);
    M16((uint32_t)(ebp + 0xFFFFFFFAu)) = (uint16_t)(((uint16_t)edx));
    edx = (uint32_t)((uint32_t)0x2u);
    M16((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint16_t)(((uint16_t)edx));
    edx = (uint32_t)((uint32_t)0x3u);
    M16((uint32_t)(ebp + 0xFFFFFFFEu)) = (uint16_t)(((uint16_t)edx));
    c->mm[0] = M64((uint32_t)(ebp + 0xFFFFFFF8u));
    edx = (uint32_t)((uint32_t)0x4u);
    c->mm[1] = (uint64_t)edx;
    c->mm[2] = c->mm[1];
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[1]);
    edx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    c->mm[1] = c->mm[2];
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[1]);
    M64((uint32_t)(ebp + 0xFFFFFFF0u)) = c->mm[2];
    c->mm[1] = M64((uint32_t)(ebp + 0xFFFFFFF8u));
    c->mm[4] = c->mm[1];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x10u);
    c->mm[5] ^= c->mm[5];
    c->mm[1] = M64((uint32_t)(ebp + 0xFFFFFFF8u));
    M64((uint32_t)(ebp + 0xFFFFFFE8u)) = c->mm[5];
    M64((uint32_t)(ebp + 0xFFFFFFF8u)) = c->mm[1];
    (void)sub32(ecx, edx, &f);
    if ((f.cf || f.zf)) goto L_9017F75;
    goto L_9017F02;
L_9017F02:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    edx = (uint32_t)(sub32(edx, eax, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
L_9017F0C:
    c->mm[1] = M64((uint32_t)(edx + eax));
    c->mm[2] = M64((uint32_t)(eax));
    c->mm[3] = c->mm[1];
    c->mm[2] = mmx_psubw(c->mm[2], c->mm[3]);
    c->mm[3] = c->mm[2];
    c->mm[6] = c->mm[0];
    c->mm[3] = mmx_pmulhw(c->mm[3], c->mm[6]);
    c->mm[2] = mmx_pmullw(c->mm[2], c->mm[6]);
    c->mm[6] = M64((uint32_t)(ebp + 0xFFFFFFF0u));
    c->mm[0] = mmx_paddw(c->mm[0], c->mm[6]);
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[7]);
    c->mm[7] = c->mm[4];
    c->mm[6] = mmx_psrad(c->mm[6], c->mm[7]);
    c->mm[7] = c->mm[1];
    c->mm[5] = mmx_punpcklwd(c->mm[5], c->mm[7]);
    c->mm[7] = M64((uint32_t)(ebp + 0xFFFFFFF8u));
    c->mm[5] = mmx_psrad(c->mm[5], c->mm[7]);
    c->mm[6] = mmx_paddd(c->mm[6], c->mm[5]);
    c->mm[2] = mmx_punpckhwd(c->mm[2], c->mm[3]);
    c->mm[3] = c->mm[4];
    c->mm[2] = mmx_psrad(c->mm[2], c->mm[3]);
    c->mm[5] = M64((uint32_t)(ebp + 0xFFFFFFE8u));
    c->mm[3] = c->mm[5];
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[1]);
    c->mm[1] = c->mm[7];
    c->mm[3] = mmx_psrad(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_paddd(c->mm[2], c->mm[3]);
    c->mm[6] = mmx_packssdw(c->mm[6], c->mm[2]);
    M64((uint32_t)(eax)) = c->mm[6];
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9017F0C;
    goto L_9017F75;
L_9017F75:
    c->top = 0;
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017F80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017F80:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF0u), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x38u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    TS32((uint32_t)(ebp + 0xFFFFFFDCu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFFD8u), (uint32_t)(ecx));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFCCu), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)((uint32_t)(eax + 0x2u));
    TS32((uint32_t)(ebp + 0xFFFFFFD4u), (uint32_t)(eax));
    ecx = (uint32_t)((uint32_t)0x2u);
    TS32((uint32_t)(ebp + 0xFFFFFFD0u), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)(ecx + 0x2u));
    ecx = (uint32_t)((uint32_t)(edx + 0x2u));
    ecx = (uint32_t)(((uint16_t)ecx));
    c->xmm[3].u[0] = ecx; c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    eax = (uint32_t)(((uint16_t)eax));
    ecx = (uint32_t)(((uint16_t)edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFD0u)));
    c->xmm[4].u[0] = eax; c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = ecx; c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFD4u)));
    eax = (uint32_t)(((uint16_t)edx));
    edx = (uint32_t)(((uint16_t)ecx));
    edi = (uint32_t)((uint32_t)0x7u);
    esi = (uint32_t)((uint32_t)0x6u);
    c->xmm[6].u[0] = eax; c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFCCu)));
    edi = (uint32_t)(((uint16_t)edi));
    esi = (uint32_t)(((uint16_t)esi));
    ecx = (uint32_t)(((uint16_t)eax));
    c->xmm[0].u[0] = edi; c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2].u[0] = esi; c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[7].u[0] = edx; c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    edx = (uint32_t)((uint32_t)0x8u);
    eax = (uint32_t)((uint32_t)(int16_t)((uint16_t)edx));
    c->xmm[1].u[0] = ecx; c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)(logic32(0, &f));
    { Xmm d_ = c->xmm[5], s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[5].w[2 * k_] = d_.w[0 + k_]; c->xmm[5].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    { Xmm d_ = c->xmm[6], s_ = c->xmm[2]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[6].w[2 * k_] = d_.w[0 + k_]; c->xmm[6].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    c->xmm[0].u[0] = eax; c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2] = c->xmm[0];
    { Xmm d_ = c->xmm[2], s_ = c->xmm[0]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[2].w[2 * k_] = d_.w[0 + k_]; c->xmm[2].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    { Xmm s_ = c->xmm[2]; c->xmm[0].u[0] = s_.u[0]; c->xmm[0].u[1] = s_.u[0]; c->xmm[0].u[2] = s_.u[0]; c->xmm[0].u[3] = s_.u[0]; }
    { Xmm d_ = c->xmm[1], s_ = c->xmm[4]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[1].w[2 * k_] = d_.w[0 + k_]; c->xmm[1].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    c->xmm[4].u[0] = TL32((uint32_t)(ebx + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { Xmm d_ = c->xmm[7], s_ = c->xmm[3]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[7].w[2 * k_] = d_.w[0 + k_]; c->xmm[7].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(logic32(0, &f));
    memcpy(MEM + (uint32_t)(ebp + 0xFFFFFFE0u), &c->xmm[0], 16);
    c->xmm[0].u[0] = ecx; c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2].u[0] = edx; c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = eax; c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    { Xmm d_ = c->xmm[7], s_ = c->xmm[5]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[7].w[2 * k_] = d_.w[0 + k_]; c->xmm[7].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    esi = (uint32_t)((uint32_t)0x10u);
    c->xmm[5].u[0] = esi; c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    { Xmm d_ = c->xmm[1], s_ = c->xmm[6]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[1].w[2 * k_] = d_.w[0 + k_]; c->xmm[1].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    { Xmm d_ = c->xmm[4], s_ = c->xmm[2]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[4].u[2 * k_] = d_.u[0 + k_]; c->xmm[4].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    { Xmm d_ = c->xmm[3], s_ = c->xmm[0]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[3].u[2 * k_] = d_.u[0 + k_]; c->xmm[3].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    { Xmm d_ = c->xmm[4], s_ = c->xmm[3]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[4].u[2 * k_] = d_.u[0 + k_]; c->xmm[4].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    c->xmm[0].u[0] = ecx; c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    c->xmm[2].u[0] = edx; c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = eax; c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    { Xmm s_ = c->xmm[6]; c->xmm[6].q[0] ^= s_.q[0]; c->xmm[6].q[1] ^= s_.q[1]; }
    { Xmm d_ = c->xmm[1], s_ = c->xmm[7]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[1].w[2 * k_] = d_.w[0 + k_]; c->xmm[1].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    memcpy(MEM + (uint32_t)(ebp + 0xFFFFFFF0u), &c->xmm[6], 16);
    { Xmm d_ = c->xmm[5], s_ = c->xmm[2]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[5].u[2 * k_] = d_.u[0 + k_]; c->xmm[5].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    { Xmm d_ = c->xmm[3], s_ = c->xmm[0]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[3].u[2 * k_] = d_.u[0 + k_]; c->xmm[3].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    { Xmm d_ = c->xmm[5], s_ = c->xmm[3]; for (int k_ = 0; k_ < 2; k_++) { c->xmm[5].u[2 * k_] = d_.u[0 + k_]; c->xmm[5].u[2 * k_ + 1] = s_.u[0 + k_]; } }
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_9018102;
    goto L_9018092;
L_9018092:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFDCu)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFD8u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(sub32(edx, eax, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
L_901809F:
    c->xmm[3] = (*(Xmm *)(MEM + (uint32_t)(edx + eax)));
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(eax)));
    { Xmm s_ = c->xmm[3]; for (int k_ = 0; k_ < 8; k_++) c->xmm[0].w[k_] -= s_.w[k_]; }
    c->xmm[2] = c->xmm[0];
    SPILL(); rt_unimpl(c, 0x90180B0u, "pmulhw");
    { Xmm s_ = c->xmm[1]; for (int k_ = 0; k_ < 8; k_++) c->xmm[0].w[k_] = (uint16_t)((int16_t)c->xmm[0].w[k_] * (int16_t)s_.w[k_]); }
    { Xmm s_ = (*(Xmm *)(MEM + (uint32_t)(ebp + 0xFFFFFFE0u))); for (int k_ = 0; k_ < 8; k_++) c->xmm[1].w[k_] += s_.w[k_]; }
    c->xmm[7] = c->xmm[0];
    { Xmm d_ = c->xmm[7], s_ = c->xmm[2]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[7].w[2 * k_] = d_.w[0 + k_]; c->xmm[7].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    { Xmm d_ = c->xmm[6], s_ = c->xmm[3]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[6].w[2 * k_] = d_.w[0 + k_]; c->xmm[6].w[2 * k_ + 1] = s_.w[0 + k_]; } }
    { Xmm d_ = c->xmm[0], s_ = c->xmm[2]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[0].w[2 * k_] = d_.w[4 + k_]; c->xmm[0].w[2 * k_ + 1] = s_.w[4 + k_]; } }
    { int n_ = (c->xmm[4].q[0] > 64 ? 64 : (int)c->xmm[4].q[0]); if (n_ > 31) n_ = 31; for (int k_ = 0; k_ < 4; k_++) c->xmm[7].u[k_] = (uint32_t)((int32_t)c->xmm[7].u[k_] >> n_); }
    { int n_ = (c->xmm[5].q[0] > 64 ? 64 : (int)c->xmm[5].q[0]); if (n_ > 31) n_ = 31; for (int k_ = 0; k_ < 4; k_++) c->xmm[6].u[k_] = (uint32_t)((int32_t)c->xmm[6].u[k_] >> n_); }
    { Xmm s_ = c->xmm[6]; for (int k_ = 0; k_ < 4; k_++) c->xmm[7].u[k_] += s_.u[k_]; }
    c->xmm[6] = (*(Xmm *)(MEM + (uint32_t)(ebp + 0xFFFFFFF0u)));
    c->xmm[2] = c->xmm[6];
    { Xmm d_ = c->xmm[2], s_ = c->xmm[3]; for (int k_ = 0; k_ < 4; k_++) { c->xmm[2].w[2 * k_] = d_.w[4 + k_]; c->xmm[2].w[2 * k_ + 1] = s_.w[4 + k_]; } }
    { int n_ = (c->xmm[4].q[0] > 64 ? 64 : (int)c->xmm[4].q[0]); if (n_ > 31) n_ = 31; for (int k_ = 0; k_ < 4; k_++) c->xmm[0].u[k_] = (uint32_t)((int32_t)c->xmm[0].u[k_] >> n_); }
    { int n_ = (c->xmm[5].q[0] > 64 ? 64 : (int)c->xmm[5].q[0]); if (n_ > 31) n_ = 31; for (int k_ = 0; k_ < 4; k_++) c->xmm[2].u[k_] = (uint32_t)((int32_t)c->xmm[2].u[k_] >> n_); }
    { Xmm s_ = c->xmm[2]; for (int k_ = 0; k_ < 4; k_++) c->xmm[0].u[k_] += s_.u[k_]; }
    { Xmm d_ = c->xmm[7], s_ = c->xmm[0]; for (int k_ = 0; k_ < 8; k_++) { int32_t v_ = k_ < 4 ? d_.i[k_] : s_.i[k_ - 4]; c->xmm[7].w[k_] = (uint16_t)(int16_t)(v_ > 32767 ? 32767 : v_ < -32768 ? -32768 : v_); } }
    memcpy(MEM + (uint32_t)(eax), &c->xmm[7], 16);
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_901809F;
    goto L_9018102;
L_9018102:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9018110(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018110:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    edx = (uint32_t)((uint32_t)0x0u);
    if (f.zf) goto L_9018156;
    goto L_9018120;
L_9018120:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edi = (uint32_t)(sub32(edi, eax, &f));
    goto L_9018130;
L_9018130:
    esi = (uint32_t)(TL16((uint32_t)(edi + eax)));
    ebx = (uint32_t)((uint32_t)(int16_t)TL16((uint32_t)(eax)));
    ecx = (uint32_t)((uint32_t)(int16_t)((uint16_t)esi));
    ebx = (uint32_t)(sub32(ebx, ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)edx; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(add32(ebx, esi, &f));
    TS16((uint32_t)(eax + 0xFFFFFFFEu), (uint16_t)(((uint16_t)ebx)));
    (void)sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f);
    if (f.cf) goto L_9018130;
    goto L_9018153;
L_9018153:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9018156:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9018160(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018160:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x90u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    c->xmm[4].u[0] = M32((uint32_t)(0x903BD58u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    c->xmm[1] = c->xmm[4];
    c->xmm[0] = c->xmm[4];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    (void)sub32(esi, (uint32_t)0x1Du, &f);
    if (!f.cf) goto L_90181CC;
    goto L_901819E;
L_901819E:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_90181A7;
L_90181A7:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x1Du);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1FFFFFFFu), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x3u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    goto L_90181D9;
L_90181CC:
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1FFFFFFFu), &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1Du, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1Du, &f));
L_90181D9:
    c->xmm[3].u[0] = M32((uint32_t)(0x9031300u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x77FFFFFu), &f));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    c->xmm[2].f[0] = (float)(int32_t)ecx;
    c->xmm[2].f[0] = c->xmm[2].f[0] * MF32((uint32_t)(edx*4 + 0x903FC70u));
    (void)logic32((uint32_t)(eax & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_9018208;
    goto L_9018205;
L_9018205:
    { Xmm s_ = c->xmm[3]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
L_9018208:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(eax)) = c->xmm[2].u[0];
    (void)sub32(esi, (uint32_t)0x1Du, &f);
    if (!f.cf) goto L_9018242;
    goto L_9018214;
L_9018214:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_901821D;
L_901821D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x1Du);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1FFFFFFFu), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x3u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    goto L_901824F;
L_9018242:
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1FFFFFFFu), &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1Du, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1Du, &f));
L_901824F:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x77FFFFFu), &f));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    c->xmm[2].f[0] = (float)(int32_t)ecx;
    c->xmm[2].f[0] = c->xmm[2].f[0] * MF32((uint32_t)(edx*4 + 0x903FC70u));
    (void)logic32((uint32_t)(eax & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_9018276;
    goto L_9018273;
L_9018273:
    { Xmm s_ = c->xmm[3]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
L_9018276:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), ecx, &f);
    if ((f.cf || f.zf)) goto L_90182E8;
    goto L_9018288;
L_9018288:
    (void)sub32(esi, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_90182BB;
    goto L_901828D;
L_901828D:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_9018296;
L_9018296:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x8u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x18u, &f));
    ebx = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    goto L_90182C4;
L_90182BB:
    eax = (uint32_t)(((uint8_t)ebx));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x8u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x8u, &f));
L_90182C4:
    (void)sub32(eax, (uint32_t)0x5Fu, &f);
    if ((f.cf || f.zf)) goto L_90182CE;
    goto L_90182C9;
L_90182C9:
    eax = (uint32_t)((uint32_t)0x5Fu);
L_90182CE:
    fpush(c, (double)MF32((uint32_t)(eax*4 + 0x903FAF0u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    MF32((uint32_t)(ebp + ecx*4 + 0xFFFFFF6Cu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(ecx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_9018288;
    goto L_90182E5;
L_90182E5:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
L_90182E8:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.cf) goto L_9018331;
    goto L_90182F9;
L_90182F9:
    eax = (uint32_t)(logic32(0, &f));
    goto L_9018300;
L_9018300:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + eax + 0xFFFFFF70u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    eax = (uint32_t)((uint32_t)(ecx*4));
    edx = (uint32_t)(TL32((uint32_t)(eax + edx)));
    edx = (uint32_t)(add32(edx, edx, &f));
    c->xmm[0] = c->xmm[1];
    { Xmm s_ = c->xmm[3]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[0].u[0];
    (void)sub32(edx, (uint32_t)0x2u, &f);
    if (f.cf) goto L_9018300;
    goto L_901832E;
L_901832E:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
L_9018331:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)0x2u);
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ecx, &f);
    if ((f.cf || f.zf)) goto L_90185C8;
    goto L_901834B;
L_901834B:
    goto L_9018350;
L_9018350:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901836A;
    goto L_9018354;
L_9018354:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_901835D;
L_901835D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    esi = (uint32_t)((uint32_t)0x20u);
L_901836A:
    eax = (uint32_t)(ebx);
    esi = (uint32_t)(dec32(esi, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90183C1;
    goto L_9018373;
L_9018373:
    (void)sub32(esi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_90183A4;
    goto L_9018378;
L_9018378:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_9018381;
L_9018381:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Cu, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    goto L_90183AF;
L_90183A4:
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x4u, &f));
L_90183AF:
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x903FA78u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)((uint32_t)(edx + ecx*8));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    goto L_90183C7;
L_90183C1:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
L_90183C7:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFECu)), eax, &f);
    if ((f.cf || f.zf)) goto L_90183D2;
    goto L_90183CF;
L_90183CF:
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
L_90183D2:
    (void)sub32(esi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_9018403;
    goto L_90183D7;
L_90183D7:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_90183E0;
L_90183E0:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Cu, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    goto L_901840E;
L_9018403:
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x4u, &f));
L_901840E:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901849D;
    goto L_9018416;
L_9018416:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x901842Fu; SPILL(); f_9001EB0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), edx, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    c->xmm[3].u[0] = M32((uint32_t)(0x9031300u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + edx)));
    edx = (uint32_t)(add32(edx, edx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(ecx, edx, &f);
    if ((f.cf || f.zf)) goto L_90185E4;
    goto L_901845D;
L_901845D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9018460:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + eax + 0xFFFFFF70u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + edx)));
    edx = (uint32_t)(add32(edx, edx, &f));
    c->xmm[0] = c->xmm[1];
    { Xmm s_ = c->xmm[3]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[0].u[0];
    (void)sub32(ecx, edx, &f);
    if ((!f.cf && !f.zf)) goto L_9018460;
    goto L_9018490;
L_9018490:
    c->xmm[4].u[0] = M32((uint32_t)(0x903BD58u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    goto L_90185BC;
L_901849D:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), ecx, &f);
    if (!f.cf) goto L_90185BC;
    goto L_90184A9;
L_90184A9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF70u));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ecx);
    goto L_90184C6;
L_90184C0:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
L_90184C6:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)((uint32_t)(ecx + edx*4));
    edx = (uint32_t)(M32((uint32_t)(ebp + ecx + 0xFFFFFF70u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), edx, &f);
    if (!f.zf) goto L_90184FA;
    goto L_90184DA;
L_90184DA:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    c->xmm[1].u[0] = M32((uint32_t)(ebp + ecx*4 + 0xFFFFFF70u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0] = c->xmm[1];
    ecx = (uint32_t)(inc32(ecx, &f));
    { Xmm s_ = c->xmm[3]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
L_90184FA:
    (void)sub32(esi, eax, &f);
    if (!f.cf) goto L_9018538;
    goto L_90184FE;
L_90184FE:
    (void)sub32(edi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if (!f.cf) goto L_90185CF;
    goto L_9018507;
L_9018507:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0xFFFFFFFFu), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edx);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebx), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & edx), &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x4u, &f));
    goto L_901854C;
L_9018538:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0xFFFFFFFFu), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(logic32((uint32_t)(edi & ebx), &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
L_901854C:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901859C;
    goto L_9018550;
L_9018550:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901856A;
    goto L_9018554;
L_9018554:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_901856F;
L_901856A:
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_901856F:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9018588;
    goto L_9018574;
L_9018574:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    c->xmm[2] = c->xmm[0];
    c->xmm[5].f[0] = (float)(int32_t)edi;
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(ecx)) = c->xmm[5].u[0];
    goto L_90185A3;
L_9018588:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    c->xmm[2] = c->xmm[1];
    c->xmm[5].f[0] = (float)(int32_t)edi;
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(ecx)) = c->xmm[5].u[0];
    goto L_90185A3;
L_901859C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    M32((uint32_t)(ecx)) = c->xmm[4].u[0];
L_90185A3:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFECu)), &f);
    if (f.cf) goto L_90184C0;
    goto L_90185B9;
L_90185B9:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_90185BC:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.cf) goto L_9018350;
    goto L_90185C8;
L_90185C8:
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)((uint32_t)0x1u);
L_90185CF:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(eax), (uint32_t)(ebx));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90185E4:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(0x903BD58u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    goto L_90185BC;
}

void f_9018600(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018600:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    if (f.zf) goto L_9018645;
    goto L_9018622;
L_9018622:
    (void)sub32(eax, M32((uint32_t)(ebp + 0x20u)), &f);
    if (f.cf) goto L_9018630;
    goto L_9018627;
L_9018627:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9018630:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)((uint32_t)0x1Eu);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
L_9018645:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    (void)sub32(eax, edx, &f);
    if ((f.cf || f.zf)) goto L_9018713;
    goto L_9018653;
L_9018653:
    ebx = (uint32_t)((uint32_t)(edi*4));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
L_901865D:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9018674u; SPILL(); f_9018160(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90186EE;
    goto L_901867B;
L_901867B:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9018692;
    goto L_9018681;
L_9018681:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9018690u; SPILL(); f_901E320(c); RELOAD();
    goto L_90186FA;
L_9018692:
    c->xmm[1].u[0] = M32((uint32_t)(esi)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    c->xmm[0] = c->xmm[1];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(esi + 0x4u));
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x903C214u));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x2u, &f));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[0].u[0];
    M32((uint32_t)(esi)) = c->xmm[1].u[0];
    if ((f.zf || f.sf != f.of)) goto L_90186DE;
    goto L_90186C0;
L_90186C0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)((uint32_t)(edx + ebx*4));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90186CEu; SPILL(); f_9024150(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90186DCu; SPILL(); f_901E810(c); RELOAD();
    goto L_90186F7;
L_90186DE:
    if (!f.zf) goto L_90186FA;
    goto L_90186E0;
L_90186E0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90186ECu; SPILL(); f_901E810(c); RELOAD();
    goto L_90186F7;
L_90186EE:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90186F7u; SPILL(); f_9001EB0(c); RELOAD();
L_90186F7:
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_90186FA:
    ebx = (uint32_t)((uint32_t)(edi*4));
    esi = (uint32_t)(add32(esi, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_901865D;
    goto L_901870D;
L_901870D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
L_9018713:
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901874F;
    goto L_9018718;
L_9018718:
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_9018738;
    goto L_9018721;
L_9018721:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(edi);
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9018733u; SPILL(); f_9017DC0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_901878A;
L_9018738:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901874Au; SPILL(); f_9017C10(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    goto L_9018787;
L_901874F:
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x8u), &f);
    ecx = (uint32_t)((uint32_t)(esi + edi*4));
    if (f.zf) goto L_9018771;
    goto L_901875B;
L_901875B:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x901876Cu; SPILL(); f_9017E20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_9018787;
L_9018771:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9018784u; SPILL(); f_9017CE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
L_9018787:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
L_901878A:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x34u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90187CC;
    goto L_9018791;
L_9018791:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x9036AFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_90187AD;
    goto L_901879D;
L_901879D:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x38u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90187A8u; SPILL(); f_9017F80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    goto L_90187CC;
L_90187AD:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90187BD;
    goto L_90187B1;
L_90187B1:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x38u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90187BBu; SPILL(); f_9017E90(c); RELOAD();
    goto L_90187C9;
L_90187BD:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x38u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x90187C9u; SPILL(); f_9018110(c); RELOAD();
L_90187C9:
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_90187CC:
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)M32((uint32_t)(ebp + 0x10u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x38u)));
    edi = (uint32_t)(add32(edi, edi, &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(add32(edi, ebx, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90187E4u; SPILL(); f_9001FE0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(add32(eax, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(shr32(eax, (uint8_t)0x3u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9018800(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018800:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(eax, (uint32_t)0xAC44u, &f);
    if (f.cf) goto L_9018811;
    goto L_901880A;
L_901880A:
    ecx = (uint32_t)((uint32_t)0x800u);
    goto L_9018824;
L_9018811:
    (void)sub32(eax, (uint32_t)0x5622u, &f);
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFE00u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x400u, &f));
L_9018824:
    edx = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)M32((uint32_t)(ebp + 0x8u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0xCu)) & (uint8_t)0x1u), &f);
    eax = (uint32_t)((uint32_t)(edx + edx));
    if (f.zf) { ecx = (uint32_t)(edx); }
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xAFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    (void)sub32(ecx, (uint32_t)0x800u, &f);
    if ((f.cf || f.zf)) goto L_9018855;
    goto L_9018847;
L_9018847:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    eax = (uint32_t)((uint32_t)(eax + edx*4 + 0xFu));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
L_9018855:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9018860(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018860:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x24u, &f));
    (void)sub32(TL32((uint32_t)(0x9036AF8u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    if (!f.zf) goto L_901888E;
    goto L_901887A;
L_901887A:
    esp -= 4; M32(esp) = 0x901887Fu; SPILL(); f_9001550(c); RELOAD();
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x80000000u), &f));
    TS32((uint32_t)(0x9036AF8u), (uint32_t)(eax));
    TS32((uint32_t)(0x9036AFCu), (uint32_t)(eax));
L_901888E:
    (void)sub32(edi, (uint32_t)0xAC44u, &f);
    if (f.cf) goto L_90188A1;
    goto L_9018896;
L_9018896:
    esi = (uint32_t)((uint32_t)0x800u);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(esi);
    goto L_90188B9;
L_90188A1:
    (void)sub32(edi, (uint32_t)0x5622u, &f);
    eax = (uint32_t)(sbb32(eax, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFE00u), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x400u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    esi = (uint32_t)(eax);
L_90188B9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(esi);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x10u)) & (uint8_t)0x1u), &f);
    edx = (uint32_t)((uint32_t)(eax + eax));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(edx);
    if (!f.zf) goto L_90188DE;
    goto L_90188CE;
L_90188CE:
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)ecx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(eax);
L_90188DE:
    eax = (uint32_t)(esi);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)((uint32_t)(edi + 0x1u));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(ecx);
    eax = (uint32_t)(logic32(0, &f));
L_90188F1:
    (void)sub32(TL32((uint32_t)(eax*4 + 0x903FA88u)), ecx, &f);
    if (!f.cf) goto L_9018938;
    goto L_90188FA;
L_90188FA:
    (void)sub32(TL32((uint32_t)(eax*4 + 0x903FA8Cu)), ecx, &f);
    if (!f.cf) goto L_9018928;
    goto L_9018903;
L_9018903:
    (void)sub32(TL32((uint32_t)(eax*4 + 0x903FA90u)), ecx, &f);
    if (!f.cf) goto L_901892B;
    goto L_901890C;
L_901890C:
    (void)sub32(TL32((uint32_t)(eax*4 + 0x903FA94u)), ecx, &f);
    if (!f.cf) goto L_9018930;
    goto L_9018915;
L_9018915:
    (void)sub32(TL32((uint32_t)(eax*4 + 0x903FA98u)), ecx, &f);
    if (!f.cf) goto L_9018935;
    goto L_901891E;
L_901891E:
    eax = (uint32_t)(add32(eax, (uint32_t)0x5u, &f));
    (void)sub32(eax, (uint32_t)0x19u, &f);
    if (f.cf) goto L_90188F1;
    goto L_9018926;
L_9018926:
    goto L_9018938;
L_9018928:
    eax = (uint32_t)(inc32(eax, &f));
    goto L_9018938;
L_901892B:
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    goto L_9018938;
L_9018930:
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
    goto L_9018938;
L_9018935:
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_9018938:
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(edi + 0xAFu));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    (void)sub32(esi, (uint32_t)0x800u, &f);
    if ((f.cf || f.zf)) goto L_901896C;
    goto L_901895E;
L_901895E:
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (uint32_t)(add32(ecx, esi, &f));
    eax = (uint32_t)((uint32_t)(eax + ecx*4 + 0xFu));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
L_901896C:
    { uint32_t v_ = 0x9Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x901897Du; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edx = (uint32_t)((uint32_t)(ebx + 0xA0u));
    TS32((uint32_t)(ebx), (uint32_t)(edx));
    (void)sub32(esi, (uint32_t)0x800u, &f);
    if ((f.cf || f.zf)) goto L_90189BD;
    goto L_9018990;
L_9018990:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    TS32((uint32_t)(ebx + 0x28u), (uint32_t)(esi));
    edi = (uint32_t)((uint32_t)(eax + ebx));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    eax = (uint32_t)(esi);
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x90189A7u; SPILL(); f_901E3E0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esi = (uint32_t)((uint32_t)(edi + esi*4));
    esp -= 4; M32(esp) = 0x90189B3u; SPILL(); f_901E550(c); RELOAD();
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    goto L_90189CB;
L_90189BD:
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)((uint32_t)0x903D000u));
    TS32((uint32_t)(ebx + 0x28u), (uint32_t)((uint32_t)0x800u));
L_90189CB:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ebx + 0x30u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(ebx + 0x14u), (uint32_t)(edi));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebx + 0x2Cu), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    TS32((uint32_t)(ebx + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFE0u, &f));
    TS32((uint32_t)(ebx + 0x1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ebx + 0x10u), (uint32_t)(edx));
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0xE0u, &f);
    if ((!f.cf && !f.zf)) goto L_9018A34;
    goto L_9018A04;
L_9018A04:
    eax = (uint32_t)(TL8((uint32_t)(edi + 0x9018AB4u)));
    { jt_ = TL32((uint32_t)(eax*4 + 0x9018AA0u)); goto L_dispatch; }
L_9018A12:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x8u));
    goto L_9018A34;
L_9018A1B:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x7u));
    goto L_9018A34;
L_9018A24:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x6u));
    goto L_9018A34;
L_9018A2D:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x5u));
L_9018A34:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9018860u: goto L_9018860; case 0x901887Au: goto L_901887A; case 0x901888Eu: goto L_901888E; case 0x9018896u: goto L_9018896; case 0x90188A1u: goto L_90188A1; case 0x90188B9u: goto L_90188B9; case 0x90188CEu: goto L_90188CE; case 0x90188DEu: goto L_90188DE; case 0x90188F1u: goto L_90188F1; case 0x90188FAu: goto L_90188FA; case 0x9018903u: goto L_9018903; case 0x901890Cu: goto L_901890C; case 0x9018915u: goto L_9018915; case 0x901891Eu: goto L_901891E; case 0x9018926u: goto L_9018926; case 0x9018928u: goto L_9018928; case 0x901892Bu: goto L_901892B; case 0x9018930u: goto L_9018930; case 0x9018935u: goto L_9018935; case 0x9018938u: goto L_9018938; case 0x901895Eu: goto L_901895E; case 0x901896Cu: goto L_901896C; case 0x9018990u: goto L_9018990; case 0x90189BDu: goto L_90189BD; case 0x90189CBu: goto L_90189CB; case 0x9018A04u: goto L_9018A04; case 0x9018A12u: goto L_9018A12; case 0x9018A1Bu: goto L_9018A1B; case 0x9018A24u: goto L_9018A24; case 0x9018A2Du: goto L_9018A2D; case 0x9018A34u: goto L_9018A34; case 0x9018A40u: goto L_9018A40; case 0x9018A46u: goto L_9018A46; case 0x9018A59u: goto L_9018A59; case 0x9018A60u: goto L_9018A60; case 0x9018A78u: goto L_9018A78; case 0x9018A7Eu: goto L_9018A7E; case 0x9018A86u: goto L_9018A86; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9018A12(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018A12:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x8u));
    goto L_9018A34;
L_9018A34:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9018A1B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018A1B:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x7u));
    goto L_9018A34;
L_9018A34:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9018A24(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018A24:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x6u));
    goto L_9018A34;
L_9018A34:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9018A2D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018A2D:
    TS32((uint32_t)(ebx + 0x18u), (uint32_t)((uint32_t)0x5u));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9018A34(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018A34:
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(esi);
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x24u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf == f.of)) goto L_9018A46;
    goto L_9018A40;
L_9018A40:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_9018A46:
    ST(0) = sqrt(ST(0));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ST(0) = (double)MF32((uint32_t)(0x903C210u)) / ST(0);
    MF32((uint32_t)(ebx + 0xCu)) = (float)ST(0); fpop(c);
    (void)sub32(edi, ecx, &f);
    if ((f.cf || f.zf)) goto L_9018A86;
    goto L_9018A59;
L_9018A59:
    esi = (uint32_t)((uint32_t)(ebx + 0x34u));
    esp = (uint32_t)((uint32_t)(esp));
L_9018A60:
    eax = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903FA88u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = M32((uint32_t)(esp + 0x2Cu)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(esi), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018A7E;
    goto L_9018A78;
L_9018A78:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x1u));
L_9018A7E:
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_9018A60;
    goto L_9018A86;
L_9018A86:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + ecx*4 + 0x34u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9018AA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018AA0:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x2409018Au, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS32((uint32_t)(ebx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx)) | ebx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS32((uint32_t)(edx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edx)) | edx), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edx + ecx*4)) | esi), &f)));
    TS32((uint32_t)(ecx), (uint32_t)(add32(TL32((uint32_t)(ecx)), ecx, &f)));
    M8((uint32_t)(esp + eax)) = (uint8_t)(add8(M8((uint32_t)(esp + eax)), ((uint8_t)eax), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x1u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x2u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x3u, &f));
    SPILL(); rt_int3(c, 0x9018B95u);
    { SPILL(); rt_call(c, 0x9018B96u); return; }
}

void f_9018AB4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018AB4:
    M8((uint32_t)(esp + eax)) = (uint8_t)(add8(M8((uint32_t)(esp + eax)), ((uint8_t)eax), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x1u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x2u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0x3u, &f));
    SPILL(); rt_int3(c, 0x9018B95u);
    { SPILL(); rt_call(c, 0x9018B96u); return; }
}

void f_9018BA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018BA0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(TL32((uint32_t)(esi + 0x20u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_9018BAE;
    goto L_9018BAA;
L_9018BAA:
    eax = (uint32_t)(logic32(0, &f));
    goto L_9018BB1;
L_9018BAE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
L_9018BB1:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    fpush(c, (double)MF32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)((uint32_t)(esi + 0x34u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9018BF1u; SPILL(); f_9018600(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(esi + 0x14u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x34u, &f));
    TS32((uint32_t)(esi + 0x20u), (uint32_t)((uint32_t)0x0u));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9018C07;
    goto L_9018C05;
L_9018C05:
    TS32((uint32_t)(edi), (uint32_t)(ecx));
L_9018C07:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9018C12;
    goto L_9018C0E;
L_9018C0E:
    eax = (uint32_t)(add32(eax, ebx, &f));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
L_9018C12:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

void f_9018C20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018C20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
L_9018C36:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x8u)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9018C48;
    goto L_9018C3F;
L_9018C3F:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    esi = (uint32_t)(dec32(esi, &f));
    goto L_9018C4F;
L_9018C48:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(dec32(edx, &f));
L_9018C4F:
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(shr32(M32((uint32_t)(ebp + 0x8u)), (uint8_t)0x1u, &f));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9018C75;
    goto L_9018C56;
L_9018C56:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9018C36;
    goto L_9018C5A;
L_9018C5A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9018C60:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9018C60;
    goto L_9018C6B;
L_9018C6B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9018C75:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9018C8B;
    goto L_9018C79;
L_9018C79:
    esp = (uint32_t)((uint32_t)(esp));
L_9018C80:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9018C80;
    goto L_9018C8B;
L_9018C8B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9018CA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9018CA0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x38u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(ecx);
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_9018CF2;
    goto L_9018CD2;
L_9018CD2:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    esi = (uint32_t)(edx);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018CFD;
L_9018CF2:
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x4u, &f));
L_9018CFD:
    edx = (uint32_t)(TL32((uint32_t)(eax*4 + 0x903C140u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD0u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x903BD60u, &f));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(eax + 0x903BD44u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9018D30;
    goto L_9018D1F;
L_9018D1F:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
L_9018D22:
    TS8((uint32_t)(ecx + eax), (uint8_t)(((uint8_t)eax)));
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, (uint32_t)0x10u, &f);
    if (f.cf) goto L_9018D22;
    goto L_9018D2B;
L_9018D2B:
    goto L_90192DD;
L_9018D30:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9018D44;
    goto L_9018D34;
L_9018D34:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9018D49;
L_9018D44:
    eax = (uint32_t)(esi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)(dec32(edi, &f));
L_9018D49:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_901922E;
    goto L_9018D51;
L_9018D51:
    (void)sub32(edi, (uint32_t)0x2u, &f);
    if (!f.cf) goto L_9018D76;
    goto L_9018D56;
L_9018D56:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    edx = (uint32_t)(eax);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x2u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | esi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Eu, &f));
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018D81;
L_9018D76:
    edx = (uint32_t)(esi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x2u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x2u, &f));
L_9018D81:
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_9018DEC;
    goto L_9018D88;
L_9018D88:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edx = (uint32_t)((uint32_t)(ecx + 0x1u));
    eax = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(ecx);
    goto L_9018DA3;
L_9018DA0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD0u)));
L_9018DA3:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9018DB7;
    goto L_9018DA7;
L_9018DA7:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    esi = (uint32_t)(ecx);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9018DBC;
L_9018DB7:
    ecx = (uint32_t)(esi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)(dec32(edi, &f));
L_9018DBC:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    ecx = (uint32_t)((uint32_t)(edx + eax));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    if (f.zf) goto L_9018DD3;
    goto L_9018DC7;
L_9018DC7:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)eax), &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)(((uint8_t)eax)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFCCu)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)eax)));
    goto L_9018DDC;
L_9018DD3:
    TS8((uint32_t)(edx + ecx), (uint8_t)(((uint8_t)eax)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)edx), &f));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)edx)));
L_9018DDC:
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(eax);
    (void)sub32(eax, (uint32_t)0x10u, &f);
    if (f.cf) goto L_9018DA0;
    goto L_9018DE7;
L_9018DE7:
    goto L_90192DD;
L_9018DEC:
    ecx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(edi);
L_9018DF0:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9018E04;
    goto L_9018DF4;
L_9018DF4:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9018E09;
L_9018E04:
    eax = (uint32_t)(esi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edi = (uint32_t)(dec32(edi, &f));
L_9018E09:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9018E1B;
    goto L_9018E0D;
L_9018E0D:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)eax), &f));
    M8((uint32_t)(ebp + ecx + 0xFFFFFFECu)) = (uint8_t)(((uint8_t)eax));
    M8((uint32_t)(ebp + ecx + 0xFFFFFFEDu)) = (uint8_t)(((uint8_t)ecx));
    goto L_9018E27;
L_9018E1B:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)edx), &f));
    M8((uint32_t)(ebp + ecx + 0xFFFFFFECu)) = (uint8_t)(((uint8_t)ecx));
    M8((uint32_t)(ebp + ecx + 0xFFFFFFEDu)) = (uint8_t)(((uint8_t)edx));
L_9018E27:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x2u, &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_9018DF0;
    goto L_9018E2F;
L_9018E2F:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFD8u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9018F76;
    goto L_9018E39;
L_9018E39:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018E48;
    goto L_9018E3E;
L_9018E3E:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018E4A;
L_9018E48:
    eax = (uint32_t)(esi);
L_9018E4A:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFEEu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    esp -= 4; M32(esp) = 0x9018E63u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018E80;
    goto L_9018E6C;
L_9018E6C:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018E84;
L_9018E80:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9018E84:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018E93;
    goto L_9018E89;
L_9018E89:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018E95;
L_9018E93:
    eax = (uint32_t)(esi);
L_9018E95:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF2u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    esp -= 4; M32(esp) = 0x9018EB1u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018ECE;
    goto L_9018EBA;
L_9018EBA:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018ED2;
L_9018ECE:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9018ED2:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018EE1;
    goto L_9018ED7;
L_9018ED7:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018EE3;
L_9018EE1:
    eax = (uint32_t)(esi);
L_9018EE3:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF6u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    esp -= 4; M32(esp) = 0x9018EFFu; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018F1C;
    goto L_9018F08;
L_9018F08:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018F20;
L_9018F1C:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9018F20:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018F2F;
    goto L_9018F25;
L_9018F25:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018F31;
L_9018F2F:
    eax = (uint32_t)(esi);
L_9018F31:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFAu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    esp -= 4; M32(esp) = 0x9018F4Du; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018F6D;
    goto L_9018F56;
L_9018F56:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90192DD;
L_9018F6D:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
    goto L_90192DD;
L_9018F76:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018F85;
    goto L_9018F7B;
L_9018F7B:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018F87;
L_9018F85:
    eax = (uint32_t)(esi);
L_9018F87:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFEEu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    esp -= 4; M32(esp) = 0x9018FA0u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018FBD;
    goto L_9018FA9;
L_9018FA9:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9018FC1;
L_9018FBD:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9018FC1:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9018FD0;
    goto L_9018FC6;
L_9018FC6:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9018FD2;
L_9018FD0:
    eax = (uint32_t)(esi);
L_9018FD2:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF2u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    esp -= 4; M32(esp) = 0x9018FEBu; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9019008;
    goto L_9018FF4;
L_9018FF4:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_901900C;
L_9019008:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_901900C:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_901901B;
    goto L_9019011;
L_9019011:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_901901D;
L_901901B:
    eax = (uint32_t)(esi);
L_901901D:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF6u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    esp -= 4; M32(esp) = 0x9019036u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9019053;
    goto L_901903F;
L_901903F:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9019057;
L_9019053:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9019057:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9019066;
    goto L_901905C;
L_901905C:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9019068;
L_9019066:
    eax = (uint32_t)(esi);
L_9019068:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFAu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x2u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    esp -= 4; M32(esp) = 0x9019081u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_901909E;
    goto L_901908A;
L_901908A:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90190A2;
L_901909E:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_90190A2:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFD8u)), (uint32_t)0x2u, &f);
    if (!f.zf) goto L_9019148;
    goto L_90190AC;
L_90190AC:
    (void)sub32(edi, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_90190BB;
    goto L_90190B1;
L_90190B1:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_90190BD;
L_90190BB:
    eax = (uint32_t)(esi);
L_90190BD:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4u);
    esp -= 4; M32(esp) = 0x90190D6u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_90190F3;
    goto L_90190DF;
L_90190DF:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90190F7;
L_90190F3:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_90190F7:
    (void)sub32(edi, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_9019106;
    goto L_90190FC;
L_90190FC:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9019108;
L_9019106:
    eax = (uint32_t)(esi);
L_9019108:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4u);
    esp -= 4; M32(esp) = 0x9019124u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018F6D;
    goto L_9019131;
L_9019131:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90192DD;
L_9019148:
    (void)sub32(edi, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_9019157;
    goto L_901914D;
L_901914D:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_9019159;
L_9019157:
    eax = (uint32_t)(esi);
L_9019159:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    esp -= 4; M32(esp) = 0x9019172u; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_901918F;
    goto L_901917B;
L_901917B:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_9019193;
L_901918F:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_9019193:
    (void)sub32(edi, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_90191A2;
    goto L_9019198;
L_9019198:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_90191A4;
L_90191A2:
    eax = (uint32_t)(esi);
L_90191A4:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    esp -= 4; M32(esp) = 0x90191BDu; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_90191DA;
    goto L_90191C6;
L_90191C6:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90191DE;
L_90191DA:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
L_90191DE:
    (void)sub32(edi, (uint32_t)0xFu, &f);
    if (!f.cf) goto L_90191ED;
    goto L_90191E3;
L_90191E3:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    goto L_90191EF;
L_90191ED:
    eax = (uint32_t)(esi);
L_90191EF:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7FFFu), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x8u);
    esp -= 4; M32(esp) = 0x901920Au; SPILL(); f_9018C20(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(edi, eax, &f);
    if (!f.cf) goto L_9018F6D;
    goto L_9019217;
L_9019217:
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90192DD;
L_901922E:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9019253;
    goto L_9019233;
L_9019233:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x3u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Du, &f));
    esi = (uint32_t)(edx);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_901925E;
L_9019253:
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x3u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x3u, &f));
L_901925E:
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)((uint32_t)0xFFFFu);
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)((uint32_t)0x0u);
L_9019270:
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_9019295;
    goto L_9019275;
L_9019275:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    esi = (uint32_t)(edx);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_90192A0;
L_9019295:
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x4u, &f));
L_90192A0:
    ecx = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFCCu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(ecx);
    edx = (uint32_t)(~edx);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)) & edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    TS8((uint32_t)(edx + ecx + 0xFFFFFFFFu), (uint8_t)(((uint8_t)eax)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD0u)));
    (void)sub32(ecx, eax, &f);
    if ((f.cf || f.zf)) goto L_9019270;
    goto L_90192C3;
L_90192C3:
    ecx = (uint32_t)(logic32(0, &f));
L_90192C5:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFD8u)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90192D7;
    goto L_90192CB;
L_90192CB:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(edx + eax), (uint8_t)(((uint8_t)ecx)));
    (void)sub32(eax, (uint32_t)0xFu, &f);
    if (f.zf) goto L_90192DD;
    goto L_90192D7;
L_90192D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(shr32(M32((uint32_t)(ebp + 0xFFFFFFD8u)), (uint8_t)0x1u, &f));
    if (!f.zf) goto L_90192C5;
    goto L_90192DD;
L_90192DD:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFC8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90192F5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

