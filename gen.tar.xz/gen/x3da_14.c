#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A0029D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0029D0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x3Cu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0xCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0029FEu; SPILL(); f_A002CA0(c); RELOAD();
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002A0Fu; SPILL(); f_A002CA0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x1Cu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x20u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    esi = (uint32_t)(add32(esi, (uint32_t)0x18u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0xA002A35u; SPILL(); f_A002C50(c); RELOAD();
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[0] = c->xmm[2];
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFF0u));
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFECu));
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE8u));
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[3].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[4].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(0xA001118u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    M32((uint32_t)(ebp + 0xCu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0x10u)) = c->xmm[1].u[0];
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    if (f.cf) goto L_A002AD1;
    goto L_A002A9F;
L_A002A9F:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002AD1;
    goto L_A002AA4;
L_A002AA4:
    c->xmm[2].u[0] = M32((uint32_t)(0xA001168u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002AD1;
    goto L_A002AB1;
L_A002AB1:
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002AD1;
    goto L_A002AB6;
L_A002AB6:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { Xmm s_ = c->xmm[0]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx)) = c->xmm[0].u[0];
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    M32((uint32_t)(edx + 0x4u)) = c->xmm[0].u[0];
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A002AD1:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xCu)));
    { Xmm s_ = c->xmm[1]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    fpush(c, (double)MF32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ST(1) = atan2(ST(1), ST(0)); fpop(c);
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    if ((f.cf || f.zf)) goto L_A002AF9;
    goto L_A002AE7;
L_A002AE7:
    ST(0) = sin(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ecx)) = (float)ST(0); fpop(c);
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    M32((uint32_t)(edx + 0x4u)) = c->xmm[1].u[0];
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_A002AF9:
    ST(0) = -ST(0);
    M32((uint32_t)(ecx)) = c->xmm[1].u[0];
    ST(0) = sin(ST(0)); c->c2 = 0;
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    MF32((uint32_t)(edx + 0x4u)) = (float)ST(0); fpop(c);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

