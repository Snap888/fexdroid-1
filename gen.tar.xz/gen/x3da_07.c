#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A001D80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001D80:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { Xmm s_ = c->xmm[0]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    c->xmm[2].u[0] = M32((uint32_t)(0xA00111Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    c->xmm[5] = c->xmm[0];
    c->xmm[6] = c->xmm[0];
    c->xmm[0].u[0] = M32((uint32_t)(edi + 0x24u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = MF32((uint32_t)(0xA001118u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A001E5D;
    goto L_A001DAF;
L_A001DAF:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x1Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebx + 0x18u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001DC8u; SPILL(); f_A002C50(c); RELOAD();
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x24u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001DD5u; SPILL(); f_A002C20(c); RELOAD();
    ST(0) = ST(0) / (double)MF32((uint32_t)(edi + 0x24u));
    ecx = (uint32_t)((uint32_t)(esi + 0x28u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(ebp + 0x14u)) = (float)ST(0); fpop(c);
    esp -= 4; M32(esp) = 0xA001DE8u; SPILL(); f_A002C20(c); RELOAD();
    ST(0) = ST(0) / (double)MF32((uint32_t)(edi + 0x24u));
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0x60u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0x14u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(0xA001130u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[0] = c->xmm[1];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[5].f[0];
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    MF32((uint32_t)(ebp + 0x10u)) = (float)ST(0); fpop(c);
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[6].f[0];
    if ((f.cf || f.zf)) goto L_A001E24;
    goto L_A001E1F;
L_A001E1F:
    c->xmm[0] = c->xmm[2];
    goto L_A001E33;
L_A001E24:
    c->xmm[3] = c->xmm[4];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[2].f[0];
    { float a_ = c->xmm[3].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A001E33;
    goto L_A001E30;
L_A001E30:
    c->xmm[0] = c->xmm[3];
L_A001E33:
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A001E3D;
    goto L_A001E38;
L_A001E38:
    c->xmm[1] = c->xmm[2];
    goto L_A001E49;
L_A001E3D:
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[2].f[0];
    { float a_ = c->xmm[4].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A001E49;
    goto L_A001E46;
L_A001E46:
    c->xmm[1] = c->xmm[4];
L_A001E49:
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[2] = c->xmm[3];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] / c->xmm[3].f[0];
L_A001E5D:
    M32((uint32_t)(edi + 0x1Cu)) = c->xmm[2].u[0];
    M32((uint32_t)(edi + 0x2Cu)) = c->xmm[5].u[0];
    M32((uint32_t)(edi + 0x28u)) = c->xmm[6].u[0];
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

