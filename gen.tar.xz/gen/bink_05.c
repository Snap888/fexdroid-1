#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9009080(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9009080:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebp);
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_90090B3;
    goto L_90090AA;
L_90090AA:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_90090B3:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebp);
    if (!f.cf) goto L_9009148;
    goto L_90090C3;
L_90090C3:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(edx + 0xFFFFFFFFu)));
    esi = (uint32_t)(TL8((uint32_t)(esi)));
    ebp = (uint32_t)(M8((uint32_t)(ebp)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903026Eu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(edx*4 + 0x9030274u))), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(rol32(ebp, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(eax*4 + 0x903027Bu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(ecx + 0xFFFFFFFFu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(ecx));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | eax), &f));
    TS32((uint32_t)(edi), (uint32_t)(esi));
    TS32((uint32_t)(esi + 0xFFFFFFFCu), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(edi + 0xCu)), (uint32_t)0x1u, &f)));
L_9009148:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900924B;
    goto L_9009153;
L_9009153:
    edx = (uint32_t)(logic32(0, &f));
    goto L_9009160;
L_9009160:
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(M16((uint32_t)(ebp + edx*2 + 0xFFFFFFFEu)));
    esi = (uint32_t)(TL8((uint32_t)(edx + ecx + 0xFFFFFFFFu)));
    ebp = (uint32_t)(TL8((uint32_t)(edx + ebx + 0xFFFFFFFFu)));
    M32((uint32_t)(esp)) = (uint32_t)(edx);
    ebx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(eax >> 8)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + 0x903F938u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    edi = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ebx = (uint32_t)(sub32(ebx, ebp, &f));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903026Eu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(edi*4 + 0x9030274u))), &f));
    ebp = (uint32_t)(rol32(ebp, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(eax*4 + 0x903027Bu))), &f));
    eax = (uint32_t)(TL32((uint32_t)(esi*4 + 0x903026Eu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(edx*4 + 0x9030274u))), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(rol32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(M32((uint32_t)(esp)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebx*4 + 0x903027Bu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    ecx = (uint32_t)(TL16((uint32_t)(ecx + edx*2 + 0xFFFFFFFEu)));
    ebx = (uint32_t)(((uint8_t)(ecx >> 8)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x18u, &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x18u, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    (void)sub32(M32((uint32_t)(esp + 0x4u)), edx, &f);
    TS32((uint32_t)(esi + edx*8 + 0xFFFFFFF8u), (uint32_t)(ebp));
    TS32((uint32_t)(esi + edx*8 + 0xFFFFFFFCu), (uint32_t)(eax));
    if (!f.zf) goto L_9009160;
    goto L_900921F;
L_900921F:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebp = (uint32_t)(add32(ebp, edx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
L_900924B:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9009260(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9009260:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_9009275;
    goto L_900926E;
L_900926E:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9009275:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x5u, &f));
    if (f.zf) goto L_9009290;
    goto L_9009282;
L_9009282:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900926E;
    goto L_9009287;
L_9009287:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    goto L_900929A;
L_9009290:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
L_900929A:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x90092A5u; SPILL(); f_901CE90(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008CE0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008D10u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9009080u));
    esp -= 4; M32(esp) = 0x900933Bu; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009340u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900A000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x610u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_900A196;
    goto L_900A022;
L_900A022:
    { uint32_t v_ = 0x2FFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x9028000u), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x903109Cu)); esp -= 4; M32(esp) = 0x900A03Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCFCu));
    edx = (uint32_t)((uint32_t)(eax + 0x1u));
L_900A043:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)ecx) & ((uint8_t)ecx)), &f);
    if (!f.zf) goto L_900A043;
    goto L_900A04A;
L_900A04A:
    eax = (uint32_t)(sub32(eax, edx, &f));
    if (f.zf) goto L_900A066;
    goto L_900A04E;
L_900A04E:
    edi = (uint32_t)(edi);
L_900A050:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + eax + 0xFFFFFCFCu)));
    (void)sub8(((uint8_t)ecx), (uint8_t)0x5Cu, &f);
    if (f.zf) goto L_900A066;
    goto L_900A05C;
L_900A05C:
    (void)sub8(((uint8_t)ecx), (uint8_t)0x3Au, &f);
    if (f.zf) goto L_900A066;
    goto L_900A061;
L_900A061:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900A050;
    goto L_900A066;
L_900A066:
    { uint32_t v_ = 0x2FFu; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFF9FCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M8((uint32_t)(ebp + eax + 0xFFFFFCFCu)) = (uint8_t)((uint8_t)0x0u);
    { uint32_t t_ = TL32((uint32_t)(0x9031094u)); esp -= 4; M32(esp) = 0x900A080u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFF9FCu));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCFCu));
    M32((uint32_t)(ebp + 0xFFFFF9F0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFF9F4u)) = (uint32_t)(ecx);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFF9F4u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFF9F0u)));
    eax = (uint32_t)((uint32_t)0x1u);
L_900A0A9:
    (void)sub32(eax, (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A0DD;
    goto L_900A0AE;
L_900A0AE:
    eax = (uint32_t)(TL8((uint32_t)(edi)));
    edx = (uint32_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(inc32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(eax, edx, &f);
    if (f.zf) goto L_900A0A9;
    goto L_900A0BA;
L_900A0BA:
    (void)sub32(eax, (uint32_t)0x61u, &f);
    if (f.cf) goto L_900A0C7;
    goto L_900A0BF;
L_900A0BF:
    (void)sub32(eax, (uint32_t)0x7Au, &f);
    if ((!f.cf && !f.zf)) goto L_900A0C7;
    goto L_900A0C4;
L_900A0C4:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x20u, &f));
L_900A0C7:
    (void)sub32(edx, (uint32_t)0x61u, &f);
    if (f.cf) goto L_900A0D4;
    goto L_900A0CC;
L_900A0CC:
    (void)sub32(edx, (uint32_t)0x7Au, &f);
    if ((!f.cf && !f.zf)) goto L_900A0D4;
    goto L_900A0D1;
L_900A0D1:
    edx = (uint32_t)(sub32(edx, (uint32_t)0x20u, &f));
L_900A0D4:
    eax = (uint32_t)(sub32(eax, edx, &f));
    if (f.zf) goto L_900A0AE;
    goto L_900A0D8;
L_900A0D8:
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)((uint32_t)(edx + edx + 0x1u));
L_900A0DD:
    M32((uint32_t)(ebp + 0xFFFFF9F8u)) = (uint32_t)(eax);
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFF9F8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A16E;
    goto L_900A0F0;
L_900A0F0:
    { uint32_t v_ = 0x2FFu; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFF9FCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031098u)); esp -= 4; M32(esp) = 0x900A102u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFF9FCu));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCFCu));
    M32((uint32_t)(ebp + 0xFFFFF9F4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFF9F0u)) = (uint32_t)(ecx);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFF9F0u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFF9F4u)));
    eax = (uint32_t)((uint32_t)0x1u);
L_900A12B:
    (void)sub32(eax, (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A15F;
    goto L_900A130;
L_900A130:
    eax = (uint32_t)(TL8((uint32_t)(edi)));
    edx = (uint32_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(inc32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(eax, edx, &f);
    if (f.zf) goto L_900A12B;
    goto L_900A13C;
L_900A13C:
    (void)sub32(eax, (uint32_t)0x61u, &f);
    if (f.cf) goto L_900A149;
    goto L_900A141;
L_900A141:
    (void)sub32(eax, (uint32_t)0x7Au, &f);
    if ((!f.cf && !f.zf)) goto L_900A149;
    goto L_900A146;
L_900A146:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x20u, &f));
L_900A149:
    (void)sub32(edx, (uint32_t)0x61u, &f);
    if (f.cf) goto L_900A156;
    goto L_900A14E;
L_900A14E:
    (void)sub32(edx, (uint32_t)0x7Au, &f);
    if ((!f.cf && !f.zf)) goto L_900A156;
    goto L_900A153;
L_900A153:
    edx = (uint32_t)(sub32(edx, (uint32_t)0x20u, &f));
L_900A156:
    eax = (uint32_t)(sub32(eax, edx, &f));
    if (f.zf) goto L_900A130;
    goto L_900A15A;
L_900A15A:
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)((uint32_t)(edx + edx + 0x1u));
L_900A15F:
    M32((uint32_t)(ebp + 0xFFFFF9F8u)) = (uint32_t)(eax);
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFF9F8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900A196;
    goto L_900A16E;
L_900A16E:
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037010u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031168u)); esp -= 4; M32(esp) = 0x900A182u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x900A190u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_900A196:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x900A1A7u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900A1B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A1B0:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x90310A0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A1BFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x9037094u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x90310ACu)); esp -= 4; M32(esp) = 0x900A1CCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEDCu), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A1D4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEDCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (f.cf) goto L_900A201;
    goto L_900A1E0;
L_900A1E0:
    { uint32_t v_ = 0x90370A0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x900A1ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FED8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A20B;
    goto L_900A1F5;
L_900A1F5:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A4u)); esp -= 4; M32(esp) = 0x900A201u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900A201:
    TS32((uint32_t)(0x903FEDCu), (uint32_t)((uint32_t)0x1u));
L_900A20B:
    esp += 4; SPILL(); return;
}

void f_900A210(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A210:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x164u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x13Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x34u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900A230u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x34u));
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)((uint32_t)0x13Cu);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x2Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900A24Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    (void)logic32((uint32_t)(eax & (uint32_t)0x800000u), &f);
    if (f.zf) goto L_900A264;
    goto L_900A25A;
L_900A25A:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | (uint32_t)0xC0000000u), &f)));
L_900A264:
    (void)logic32((uint32_t)(eax & (uint32_t)0x1000000u), &f);
    if (f.zf) goto L_900A275;
    goto L_900A26B;
L_900A26B:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | (uint32_t)0x80000000u), &f)));
L_900A275:
    ebx = (uint32_t)((uint32_t)0x30000000u);
    (void)logic32((uint32_t)(eax & (uint32_t)0x80000u), &f);
    if (f.zf) goto L_900A287;
    goto L_900A281;
L_900A281:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | ebx), &f)));
L_900A287:
    edi = (uint32_t)((uint32_t)0x20000000u);
    (void)logic32((uint32_t)(eax & (uint32_t)0x100000u), &f);
    if (f.zf) goto L_900A299;
    goto L_900A293;
L_900A293:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | edi), &f)));
L_900A299:
    esi = (uint32_t)((uint32_t)0xC000000u);
    (void)logic32((uint32_t)(eax & (uint32_t)0x2000000u), &f);
    if (f.zf) goto L_900A2AB;
    goto L_900A2A5;
L_900A2A5:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | esi), &f)));
L_900A2AB:
    edx = (uint32_t)((uint32_t)0x8000000u);
    (void)logic32((uint32_t)(eax & (uint32_t)0x4000000u), &f);
    if (f.zf) goto L_900A2BD;
    goto L_900A2B7;
L_900A2B7:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | edx), &f)));
L_900A2BD:
    ecx = (uint32_t)((uint32_t)0x3000000u);
    (void)logic32((uint32_t)(eax & (uint32_t)0x200000u), &f);
    if (f.zf) goto L_900A2CF;
    goto L_900A2C9;
L_900A2C9:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | ecx), &f)));
L_900A2CF:
    (void)logic32((uint32_t)(eax & (uint32_t)0x400000u), &f);
    if (f.zf) goto L_900A2E0;
    goto L_900A2D6;
L_900A2D6:
    TS32((uint32_t)(0x903FEE0u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE0u)) | (uint32_t)0x2000000u), &f)));
L_900A2E0:
    (void)logic32((uint32_t)(eax & (uint32_t)0x4000u), &f);
    if (f.zf) goto L_900A2F1;
    goto L_900A2E7;
L_900A2E7:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | (uint32_t)0xC0000000u), &f)));
L_900A2F1:
    (void)logic32((uint32_t)(eax & (uint32_t)0x8000u), &f);
    if (f.zf) goto L_900A302;
    goto L_900A2F8;
L_900A2F8:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | (uint32_t)0x80000000u), &f)));
L_900A302:
    (void)logic32((uint32_t)(eax & (uint32_t)0x400u), &f);
    if (f.zf) goto L_900A30F;
    goto L_900A309;
L_900A309:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | ebx), &f)));
L_900A30F:
    (void)logic32((uint32_t)(eax & (uint32_t)0x800u), &f);
    if (f.zf) goto L_900A31C;
    goto L_900A316;
L_900A316:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | edi), &f)));
L_900A31C:
    (void)logic32((uint32_t)(eax & (uint32_t)0x10000u), &f);
    if (f.zf) goto L_900A329;
    goto L_900A323;
L_900A323:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | esi), &f)));
L_900A329:
    (void)logic32((uint32_t)(eax & (uint32_t)0x20000u), &f);
    if (f.zf) goto L_900A336;
    goto L_900A330;
L_900A330:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | edx), &f)));
L_900A336:
    (void)logic32((uint32_t)(eax & (uint32_t)0x1000u), &f);
    if (f.zf) goto L_900A343;
    goto L_900A33D;
L_900A33D:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | ecx), &f)));
L_900A343:
    (void)logic32((uint32_t)(eax & (uint32_t)0x2000u), &f);
    if (f.zf) goto L_900A354;
    goto L_900A34A;
L_900A34A:
    TS32((uint32_t)(0x903FEE4u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x903FEE4u)) | (uint32_t)0x2000000u), &f)));
L_900A354:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x2Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    edx = (uint32_t)((uint32_t)(esp + 0x10u));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x54u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900A390u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esi = (uint32_t)(TL32((uint32_t)(0x9031154u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FED0u), (uint32_t)(ecx));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A3A7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x902810Cu), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A3B0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x9028108u), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900A3BDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(TL32((uint32_t)(0x9031004u)));
    esi = (uint32_t)(eax);
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900A3CAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900A3D1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)eax; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FED4u), (uint32_t)(ebx));
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900A3E3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(TL32((uint32_t)(0x903FED4u)), (uint32_t)0x8u, &f);
    if (!f.zf) goto L_900A3FD;
    goto L_900A3EC;
L_900A3EC:
    TS32((uint32_t)(0x9028114u), (uint32_t)((uint32_t)0xFDu));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900A3FD:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    eax = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)((uint32_t)(eax + 0x1Fu));
    ecx = (uint32_t)((uint32_t)(ecx));
L_900A410:
    (void)logic32((uint32_t)(esi & eax), &f);
    if (f.zf) goto L_900A41D;
    goto L_900A414;
L_900A414:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_900A41B;
    goto L_900A419;
L_900A419:
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
L_900A41B:
    edx = (uint32_t)(add32(edx, edx, &f));
L_900A41D:
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900A410;
    goto L_900A424;
L_900A424:
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    eax = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(eax);
    esi = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)((uint32_t)(eax + 0x1Fu));
L_900A434:
    (void)logic32((uint32_t)(edi & eax), &f);
    if (f.zf) goto L_900A441;
    goto L_900A438;
L_900A438:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_900A43F;
    goto L_900A43D;
L_900A43D:
    esi = (uint32_t)(logic32((uint32_t)(esi | eax), &f));
L_900A43F:
    edx = (uint32_t)(add32(edx, edx, &f));
L_900A441:
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900A434;
    goto L_900A448;
L_900A448:
    esi = (uint32_t)(add32(esi, ebx, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x9028114u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900A460(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A460:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x78u, &f));
    (void)sub32(TL32((uint32_t)(0x903FEB8u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    if (!f.zf) goto L_900A648;
    goto L_900A478;
L_900A478:
    (void)sub32(TL32((uint32_t)(0x903FEDCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900A486;
    goto L_900A481;
L_900A481:
    esp -= 4; M32(esp) = 0x900A486u; SPILL(); f_900A1B0(c); RELOAD();
L_900A486:
    (void)sub32(TL32((uint32_t)(0x903FEDCu)), (uint32_t)0x20u, &f);
    if (f.cf) goto L_900A64E;
    goto L_900A493;
L_900A493:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903FEBCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903FED8u)); esp -= 4; M32(esp) = 0x900A4A2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A64E;
    goto L_900A4AA;
L_900A4AA:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900A4C8;
    goto L_900A4AE;
L_900A4AE:
    (void)sub32(TL32((uint32_t)(0x903FEC4u)), eax, &f);
    if (f.zf) goto L_900A4C6;
    goto L_900A4B6;
L_900A4B6:
    (void)sub32(TL32((uint32_t)(0x903FEC8u)), eax, &f);
    if (f.zf) goto L_900A4C6;
    goto L_900A4BE;
L_900A4BE:
    (void)sub32(TL32((uint32_t)(0x903FECCu)), eax, &f);
    if (!f.zf) goto L_900A4C8;
    goto L_900A4C6;
L_900A4C6:
    esi = (uint32_t)(logic32(0, &f));
L_900A4C8:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(neg32(edx, &f));
    edx = (uint32_t)(sbb32(edx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x9u), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900A4E6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A62F;
    goto L_900A4EE;
L_900A4EE:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900A5DC;
    goto L_900A4F6;
L_900A4F6:
    eax = (uint32_t)(TL32((uint32_t)(0x903FECCu)));
    ebx = (uint32_t)(TL32((uint32_t)(0x9031004u)));
    edi = (uint32_t)(eax);
    goto L_900A50A;
L_900A505:
    eax = (uint32_t)(TL32((uint32_t)(0x903FECCu)));
L_900A50A:
    (void)sub32(edi, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_900A531;
    goto L_900A50F;
L_900A50F:
    (void)sub32(eax, (uint32_t)0x10u, &f);
    if (!f.zf) goto L_900A520;
    goto L_900A514;
L_900A514:
    eax = (uint32_t)((uint32_t)0x20u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A569;
L_900A520:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (f.zf) goto L_900A55D;
    goto L_900A525;
L_900A525:
    eax = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A569;
L_900A531:
    (void)sub32(edi, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900A553;
    goto L_900A536;
L_900A536:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_900A547;
    goto L_900A53B;
L_900A53B:
    eax = (uint32_t)((uint32_t)0x18u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A569;
L_900A547:
    (void)sub32(eax, (uint32_t)0x18u, &f);
    if (!f.zf) goto L_900A514;
    goto L_900A54C;
L_900A54C:
    eax = (uint32_t)((uint32_t)0x10u);
    goto L_900A562;
L_900A553:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.zf) goto L_900A567;
    goto L_900A558;
L_900A558:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_900A514;
    goto L_900A55D;
L_900A55D:
    eax = (uint32_t)((uint32_t)0x18u);
L_900A562:
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
L_900A567:
    edi = (uint32_t)(logic32(0, &f));
L_900A569:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x54u)));
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900A584u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A5D4;
    goto L_900A588;
L_900A588:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900A592u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A599u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A5A1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FED4u), (uint32_t)(ecx));
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900A5B8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FECCu)));
    (void)sub32(TL32((uint32_t)(0x903FED4u)), eax, &f);
    if (f.zf) goto L_900A5DC;
    goto L_900A5C5;
L_900A5C5:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900A5DC;
    goto L_900A5C9;
L_900A5C9:
    ebx = (uint32_t)(TL32((uint32_t)(0x9031004u)));
    goto L_900A50A;
L_900A5D4:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_900A505;
    goto L_900A5DC;
L_900A5DC:
    esi = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = 0x6Cu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FECCu), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC8u), (uint32_t)(esi));
    TS32((uint32_t)(0x903FEC4u), (uint32_t)(esi));
    esp -= 4; M32(esp) = 0x900A5FCu; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903FEC0u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = (uint32_t)((uint32_t)0x6Cu);
    M32((uint32_t)(ebp + 0xFFFFFF8Cu)) = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)((uint32_t)0x200u);
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x18u)));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900A62Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900A643;
    goto L_900A62F;
L_900A62F:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900A63Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900A643:
    esp -= 4; M32(esp) = 0x900A648u; SPILL(); f_900A210(c); RELOAD();
L_900A648:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(inc32(TL32((uint32_t)(0x903FEB8u)), &f)));
L_900A64E:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900A660(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A660:
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(sub32(TL32((uint32_t)(0x903FEB8u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900A68F;
    goto L_900A669;
L_900A669:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEC0u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900A676u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FEBCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900A683u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(eax));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(eax));
L_900A68F:
    esp += 4; SPILL(); return;
}

void f_900A690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A690:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xA8u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(0x903FEB8u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(edi);
    if (f.zf) goto L_900A6C6;
    goto L_900A6B5;
L_900A6B5:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x900A6C2u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900A6C6:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(0x9031004u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_900A870;
    goto L_900A6D8;
L_900A6D8:
    (void)sub32(TL32((uint32_t)(0x903FEC4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A870;
    goto L_900A6E5;
L_900A6E5:
    (void)sub32(TL32((uint32_t)(0x903FEC8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A870;
    goto L_900A6F2;
L_900A6F2:
    eax = (uint32_t)(TL32((uint32_t)(0x903FECCu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900A870;
    goto L_900A6FF;
L_900A6FF:
    esi = (uint32_t)(TL32((uint32_t)(0x903115Cu)));
    edi = (uint32_t)(eax);
    goto L_900A715;
L_900A710:
    eax = (uint32_t)(TL32((uint32_t)(0x903FECCu)));
L_900A715:
    (void)sub32(edi, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_900A73C;
    goto L_900A71A;
L_900A71A:
    (void)sub32(eax, (uint32_t)0x10u, &f);
    if (!f.zf) goto L_900A72B;
    goto L_900A71F;
L_900A71F:
    eax = (uint32_t)((uint32_t)0x20u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A774;
L_900A72B:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (f.zf) goto L_900A768;
    goto L_900A730;
L_900A730:
    eax = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A774;
L_900A73C:
    (void)sub32(edi, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900A75E;
    goto L_900A741;
L_900A741:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_900A752;
    goto L_900A746;
L_900A746:
    eax = (uint32_t)((uint32_t)0x18u);
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    goto L_900A774;
L_900A752:
    (void)sub32(eax, (uint32_t)0x18u, &f);
    if (!f.zf) goto L_900A71F;
    goto L_900A757;
L_900A757:
    eax = (uint32_t)((uint32_t)0x10u);
    goto L_900A76D;
L_900A75E:
    (void)sub32(edi, (uint32_t)0x3u, &f);
    if (!f.zf) goto L_900A772;
    goto L_900A763;
L_900A763:
    (void)sub32(eax, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_900A71F;
    goto L_900A768;
L_900A768:
    eax = (uint32_t)((uint32_t)0x18u);
L_900A76D:
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
L_900A772:
    edi = (uint32_t)(logic32(0, &f));
L_900A774:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEC4u)));
    ecx = (uint32_t)((uint32_t)0x9Cu);
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(edx);
    M16((uint32_t)(ebp + 0xFFFFFF84u)) = (uint16_t)(((uint16_t)ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC8u)));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = (uint32_t)((uint32_t)0x1C0000u);
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(eax);
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A7A4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A80E;
    goto L_900A7A8;
L_900A7A8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x1u));
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900A7BFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A7C6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(eax);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A7D1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS32((uint32_t)(0x903FED4u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900A7EEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    (void)sub32(edx, TL32((uint32_t)(0x903FECCu)), &f);
    if (f.zf) goto L_900A853;
    goto L_900A7FC;
L_900A7FC:
    esi = (uint32_t)(TL32((uint32_t)(0x903115Cu)));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A808u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(TL32((uint32_t)(0x9031004u)));
L_900A80E:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_900A710;
    goto L_900A816;
L_900A816:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEC4u)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEC8u)));
    eax = (uint32_t)((uint32_t)0x9Cu);
    M16((uint32_t)(ebp + 0xFFFFFF84u)) = (uint16_t)(((uint16_t)eax));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = (uint32_t)((uint32_t)0x180000u);
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(edx);
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A843u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900A859;
    goto L_900A847;
L_900A847:
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x1u));
    goto L_900A859;
L_900A853:
    ebx = (uint32_t)(TL32((uint32_t)(0x9031004u)));
L_900A859:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FECCu), (uint32_t)(eax));
    TS32((uint32_t)(0x903FEC8u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FEC4u), (uint32_t)(eax));
L_900A870:
    esi = (uint32_t)(TL32((uint32_t)(0x9031154u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A87Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x902810Cu), (uint32_t)(eax));
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900A883u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x9028108u), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031134u)); esp -= 4; M32(esp) = 0x900A88Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    { uint32_t v_ = 0xEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A896u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(eax);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900A8A1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)eax; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FED4u), (uint32_t)(ecx));
    { uint32_t t_ = TL32((uint32_t)(0x9031148u)); esp -= 4; M32(esp) = 0x900A8B8u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FED4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x3u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(0x903FED0u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FEECu), (uint32_t)(add32(TL32((uint32_t)(0x903FEECu)), eax, &f)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x900A8E3u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900A8F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A8F0:
    TS32((uint32_t)(0x903FEECu), (uint32_t)(sub32(TL32((uint32_t)(0x903FEECu)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_900A916;
    goto L_900A8F9;
L_900A8F9:
    (void)sub32(TL32((uint32_t)(0x903FEE8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900A916;
    goto L_900A902;
L_900A902:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEE8u), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903115Cu)); esp -= 4; M32(esp) = 0x900A916u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900A916:
    esp += 4; SPILL(); return;
}

void f_900A920(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A920:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(ecx, edx, &f);
    if (f.zf) goto L_900A956;
    goto L_900A92C;
L_900A92C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, edx, &f);
    if (f.zf) goto L_900A956;
    goto L_900A933;
L_900A933:
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(ecx));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FEB8u), (uint32_t)((uint32_t)0x8000000u));
    esp -= 4; M32(esp) = 0x900A94Du; SPILL(); f_900A210(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900A956:
    TS32((uint32_t)(0x903FEBCu), (uint32_t)(edx));
    TS32((uint32_t)(0x903FEC0u), (uint32_t)(edx));
    TS32((uint32_t)(0x903FEB8u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900A980(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900A980:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x4Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ esp), &f));
    M32((uint32_t)(esp + 0x48u)) = (uint32_t)(eax);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(sub32(eax, (uint32_t)0x2u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    if (f.zf) goto L_900A9FD;
    goto L_900A9A2;
L_900A9A2:
    eax = (uint32_t)(sub32(eax, (uint32_t)0xDu, &f));
    if (f.zf) goto L_900A9E5;
    goto L_900A9A7;
L_900A9A7:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x5u, &f));
    if (f.zf) goto L_900A9CE;
    goto L_900A9AC;
L_900A9AC:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903114Cu)); esp -= 4; M32(esp) = 0x900A9BCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x900A9C8u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900A9CE:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x900A9DFu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
L_900A9E5:
    eax = (uint32_t)((uint32_t)(esp + 0x8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031130u)); esp -= 4; M32(esp) = 0x900A9F1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)((uint32_t)(esp + 0x8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031110u)); esp -= 4; M32(esp) = 0x900A9FDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900A9FD:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x4Cu)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x900AA0Bu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

