#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A001270(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001270:
    eax = (uint32_t)(dec32(eax, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) ^ TL8((uint32_t)(eax))), &f));
    TS8((uint32_t)(esi), (uint8_t)(add8(TL8((uint32_t)(esi)), ((uint8_t)(ecx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(ebx + 0xEC8B55FFu), (uint8_t)(add8(TL8((uint32_t)(ebx + 0xEC8B55FFu)), ((uint8_t)ecx), &f)));
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA00101Cu)); esp -= 4; M32(esp) = 0xA001292u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_A0012AC;
    goto L_A001296;
L_A001296:
    edx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA001104u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA0010B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA00103Cu)); esp -= 4; M32(esp) = 0xA0012AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_A0012AC:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x8u)) | (uint32_t)0xFFFFFFFFu), &f)));
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x8u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    if (f.zf) goto L_A0012D9;
    goto L_A0012BE;
L_A0012BE:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    esi = (uint32_t)(ecx);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    esi = (uint32_t)(ecx);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
L_A0012D9:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
L_A0012DE:
    esi = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    if (!f.zf) goto L_A0012DE;
    goto L_A0012E6;
L_A0012E6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(dec32(ecx, &f));
    TS32((uint32_t)(ebp + 0x10u), (uint32_t)(ecx));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x10u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    M32((uint32_t)(eax + 0xCu)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A001285(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001285:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA00101Cu)); esp -= 4; M32(esp) = 0xA001292u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_A0012AC;
    goto L_A001296;
L_A001296:
    edx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA001104u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA0010B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA00103Cu)); esp -= 4; M32(esp) = 0xA0012AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_A0012AC:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x8u)) | (uint32_t)0xFFFFFFFFu), &f)));
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x8u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    if (f.zf) goto L_A0012D9;
    goto L_A0012BE;
L_A0012BE:
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    esi = (uint32_t)(ecx);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    esi = (uint32_t)(ecx);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
L_A0012D9:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
L_A0012DE:
    esi = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    if (!f.zf) goto L_A0012DE;
    goto L_A0012E6;
L_A0012E6:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(dec32(ecx, &f));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(ecx);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x10u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    M32((uint32_t)(eax + 0xCu)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A001310(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001310:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(edi + 0x24u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = MF32((uint32_t)(0xA001118u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A00135E;
    goto L_A001332;
L_A001332:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x1Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x18u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00134Au; SPILL(); f_A002C50(c); RELOAD();
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001357u; SPILL(); f_A002C20(c); RELOAD();
    ST(0) = ST(0) / (double)MF32((uint32_t)(edi + 0x24u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    MF32((uint32_t)(ebp + 0xFFFFFFFCu)) = (float)ST(0); fpop(c);
L_A00135E:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp -= 4; M32(esp) = 0xA001366u; SPILL(); f_A003196(c); RELOAD();
    MF32((uint32_t)(edi + 0x20u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

void f_A001380(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001380:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    (void)sub32(edx, (uint32_t)0x4u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x1u);
    if ((f.sf != f.of)) goto L_A0013D8;
    goto L_A00139F;
L_A00139F:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x18u, &f));
L_A0013A4:
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0xFFFFFFF0u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((!f.cf && !f.zf)) goto L_A001403;
    goto L_A0013AE;
L_A0013AE:
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((!f.cf && !f.zf)) goto L_A0013F6;
    goto L_A0013B8;
L_A0013B8:
    c->xmm[1].u[0] = M32((uint32_t)(edx)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((!f.cf && !f.zf)) goto L_A0013FB;
    goto L_A0013C1;
L_A0013C1:
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0x8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((!f.cf && !f.zf)) goto L_A001400;
    goto L_A0013CB;
L_A0013CB:
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    edi = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFDu));
    edx = (uint32_t)(add32(edx, (uint32_t)0x20u, &f));
    (void)sub32(eax, edi, &f);
    if (f.cf) goto L_A0013A4;
    goto L_A0013D8;
L_A0013D8:
    (void)sub32(eax, ecx, &f);
    if (!f.cf) goto L_A001447;
    goto L_A0013DC;
L_A0013DC:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)((uint32_t)(edx + eax*8));
L_A0013E1:
    c->xmm[1].u[0] = M32((uint32_t)(edx)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((!f.cf && !f.zf)) goto L_A001403;
    goto L_A0013EA;
L_A0013EA:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_A0013E1;
    goto L_A0013F4;
L_A0013F4:
    goto L_A001403;
L_A0013F6:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    goto L_A001403;
L_A0013FB:
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    goto L_A001403;
L_A001400:
    eax = (uint32_t)(add32(eax, (uint32_t)0x3u, &f));
L_A001403:
    (void)sub32(eax, ecx, &f);
    if (!f.cf) goto L_A001447;
    goto L_A001407;
L_A001407:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    c->xmm[2].u[0] = M32((uint32_t)(ecx + eax*8 + 0xFFFFFFF8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + eax*8)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    eax = (uint32_t)((uint32_t)(ecx + eax*8));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[2].f[0];
    c->xmm[3] = c->xmm[0];
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(eax + 0xFFFFFFFCu));
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[2].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] / c->xmm[1].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[3].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(eax + 0xFFFFFFFCu));
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_A001447:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    c->xmm[0].u[0] = M32((uint32_t)(edx + ecx*8 + 0xFFFFFFFCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

