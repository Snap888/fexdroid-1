#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A00386C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00386C:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)0xA004010u);
    goto L_A003880;
L_A003880:
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0xCu), (uint32_t)(ebp));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_A003875(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003875:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)0xA004010u);
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0xCu), (uint32_t)(ebp));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_A003894(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003894:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA003896u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp += 4; SPILL(); return;
}

void f_A0038A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0038A0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    if (!f.zf) goto L_A0038B9;
    goto L_A0038B0;
L_A0038B0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    esp += 20; SPILL(); return;
L_A0038B9:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x14u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ebx = (uint32_t)(add32(ebx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(add32(edx, ebx, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

void f_A0038DA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0038DA:
    { SPILL(); rt_call(c, M32(0xA001028u)); return; }
}

void f_A003977(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003977:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) | TL8((uint32_t)(ebp + 0x100A0035u))), &f));
    (void)sub8(((uint8_t)eax), TL8((uint32_t)(eax)), &f);
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edx + edi + 0x10440000u), (uint8_t)(add8(TL8((uint32_t)(edx + edi + 0x10440000u)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    SPILL(); rt_int3(c, 0xA003990u);
    { SPILL(); rt_call(c, 0xA003991u); return; }
}

void f_A0039F6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0039F6:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    esp += 62; SPILL(); return;
}

void f_A0039FC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0039FC:
    esp += 62; SPILL(); return;
}

