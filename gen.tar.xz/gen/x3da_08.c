#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A001E80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001E80:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xE4u, &f));
    c->xmm[0].u[0] = M32((uint32_t)(0xA001160u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(0xA00115Cu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[6]; c->xmm[6].q[0] ^= s_.q[0]; c->xmm[6].q[1] ^= s_.q[1]; }
    c->xmm[3].u[0] = M32((uint32_t)(0xA001158u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(0xA001154u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(0xA001150u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(0xA00114Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    c->xmm[7].u[0] = M32((uint32_t)(0xA001148u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(0xA001144u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(0xA001140u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFF7Cu)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF80u)) = c->xmm[7].u[0];
    { Xmm s_ = c->xmm[7]; c->xmm[7].q[0] ^= s_.q[0]; c->xmm[7].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFF4Cu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(0xA001148u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(eax, (uint32_t)0x3Fu, &f);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFA8u)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF6Cu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF70u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF74u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF78u)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF38u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF3Cu)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF40u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF44u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF48u)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF50u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF84u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF8Cu)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF90u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF60u)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF1Cu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF20u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = c->xmm[4].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF34u)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    if ((!f.cf && !f.zf)) goto L_A0020B6;
    goto L_A00204B;
L_A00204B:
    if (f.zf) goto L_A002095;
    goto L_A00204D;
L_A00204D:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x3u, &f));
    (void)sub32(eax, (uint32_t)0x38u, &f);
    if ((!f.cf && !f.zf)) goto L_A00213B;
    goto L_A002059;
L_A002059:
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xA00246Cu)));
    { jt_ = TL32((uint32_t)(ecx*4 + 0xA00245Cu)); goto L_dispatch; }
L_A002067:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    c->xmm[0].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(ebp + 0xCu));
    eax = (uint32_t)((uint32_t)(eax + ecx*4));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(eax)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_A002088:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD8u));
    edx = (uint32_t)((uint32_t)0x2u);
    goto L_A00213B;
L_A002095:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF98u));
    edx = (uint32_t)((uint32_t)0x5u);
    if (f.zf) goto L_A00213B;
    goto L_A0020A9;
L_A0020A9:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    edx = (uint32_t)((uint32_t)0x4u);
    goto L_A00213B;
L_A0020B6:
    (void)sub32(eax, (uint32_t)0x60Fu, &f);
    if ((!f.cf && !f.zf)) goto L_A002116;
    goto L_A0020BD;
L_A0020BD:
    if (f.zf) goto L_A0020FC;
    goto L_A0020BF;
L_A0020BF:
    eax = (uint32_t)(sub32(eax, (uint32_t)0xFFu, &f));
    if (f.zf) goto L_A0020E1;
    goto L_A0020C6;
L_A0020C6:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x8u, &f));
    if (!f.zf) goto L_A00213B;
    goto L_A0020CB;
L_A0020CB:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    edx = (uint32_t)((uint32_t)(eax + 0x4u));
    if (f.zf) goto L_A00213B;
    goto L_A0020D9;
L_A0020D9:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFCCu));
    edx = (uint32_t)((uint32_t)(eax + 0x3u));
    goto L_A00213B;
L_A0020E1:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF38u));
    edx = (uint32_t)((uint32_t)0x7u);
    if (f.zf) goto L_A00213B;
    goto L_A0020F4;
L_A0020F4:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF6Cu));
    goto L_A002136;
L_A0020FC:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF84u));
    edx = (uint32_t)((uint32_t)0x5u);
    if (f.zf) goto L_A00213B;
    goto L_A00210C;
L_A00210C:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFACu));
    edx = (uint32_t)((uint32_t)0x4u);
    goto L_A00213B;
L_A002116:
    (void)sub32(eax, (uint32_t)0x63Fu, &f);
    if (!f.zf) goto L_A00213B;
    goto L_A00211D;
L_A00211D:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF1Cu));
    edx = (uint32_t)((uint32_t)0x7u);
    if (f.zf) goto L_A00213B;
    goto L_A002130;
L_A002130:
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF54u));
L_A002136:
    edx = (uint32_t)((uint32_t)0x6u);
L_A00213B:
    c->xmm[1].u[0] = M32((uint32_t)(0xA00113Cu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(0xA001138u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(0xA001124u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(0xA001134u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(0xA00114Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32((uint32_t)(edi | ecx), &f));
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(edx, (uint32_t)0x4u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[2].u[0];
    if ((f.sf != f.of)) goto L_A0022BC;
    goto L_A002186;
L_A002186:
    ebx = (uint32_t)((uint32_t)(esi + 0x8u));
    ecx = (uint32_t)((uint32_t)(eax + 0x2u));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(ebx);
L_A002190:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0] = c->xmm[4];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebx + 0xFFFFFFF8u));
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[5].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021A6;
    goto L_A0021A0;
L_A0021A0:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    goto L_A0021AF;
L_A0021A6:
    { float a_ = c->xmm[6].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021AF;
    goto L_A0021AB;
L_A0021AB:
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
L_A0021AF:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A0021C1;
    goto L_A0021B4;
L_A0021B4:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021C1;
    goto L_A0021B9;
L_A0021B9:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    c->xmm[1] = c->xmm[0];
    goto L_A0021D0;
L_A0021C1:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[7].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A0021D0;
    goto L_A0021C6;
L_A0021C6:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021D0;
    goto L_A0021CB;
L_A0021CB:
    edi = (uint32_t)(eax);
    c->xmm[2] = c->xmm[0];
L_A0021D0:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0] = c->xmm[4];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebx + 0xFFFFFFFCu));
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[5].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021E6;
    goto L_A0021E0;
L_A0021E0:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    goto L_A0021EF;
L_A0021E6:
    { float a_ = c->xmm[6].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0021EF;
    goto L_A0021EB;
L_A0021EB:
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
L_A0021EF:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002204;
    goto L_A0021F4;
L_A0021F4:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002204;
    goto L_A0021F9;
L_A0021F9:
    ebx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    c->xmm[1] = c->xmm[0];
    goto L_A002214;
L_A002204:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[7].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002214;
    goto L_A002209;
L_A002209:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002214;
    goto L_A00220E;
L_A00220E:
    edi = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    c->xmm[2] = c->xmm[0];
L_A002214:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0] = c->xmm[4];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebx));
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[5].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002229;
    goto L_A002223;
L_A002223:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    goto L_A002232;
L_A002229:
    { float a_ = c->xmm[6].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002232;
    goto L_A00222E;
L_A00222E:
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
L_A002232:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002244;
    goto L_A002237;
L_A002237:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002244;
    goto L_A00223C;
L_A00223C:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    c->xmm[1] = c->xmm[0];
    goto L_A002253;
L_A002244:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[7].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002253;
    goto L_A002249;
L_A002249:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002253;
    goto L_A00224E;
L_A00224E:
    edi = (uint32_t)(ecx);
    c->xmm[2] = c->xmm[0];
L_A002253:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[0] = c->xmm[4];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebx + 0x4u));
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[5].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002269;
    goto L_A002263;
L_A002263:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    goto L_A002272;
L_A002269:
    { float a_ = c->xmm[6].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002272;
    goto L_A00226E;
L_A00226E:
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
L_A002272:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002287;
    goto L_A002277;
L_A002277:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002287;
    goto L_A00227C;
L_A00227C:
    ebx = (uint32_t)((uint32_t)(ecx + 0x1u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    c->xmm[1] = c->xmm[0];
    goto L_A002297;
L_A002287:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[7].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A002297;
    goto L_A00228C;
L_A00228C:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A002297;
    goto L_A002291;
L_A002291:
    edi = (uint32_t)((uint32_t)(ecx + 0x1u));
    c->xmm[2] = c->xmm[0];
L_A002297:
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x10u)), (uint32_t)0x10u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    ebx = (uint32_t)((uint32_t)(edx + 0xFFFFFFFDu));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    (void)sub32(eax, ebx, &f);
    if (f.cf) goto L_A002190;
    goto L_A0022AC;
L_A0022AC:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
L_A0022BC:
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_A00230D;
    goto L_A0022C0;
L_A0022C0:
    c->xmm[0] = c->xmm[4];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(esi + eax*4));
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[5].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0022D3;
    goto L_A0022CD;
L_A0022CD:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    goto L_A0022DC;
L_A0022D3:
    { float a_ = c->xmm[6].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0022DC;
    goto L_A0022D8;
L_A0022D8:
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
L_A0022DC:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A0022ED;
    goto L_A0022E1;
L_A0022E1:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0022ED;
    goto L_A0022E6;
L_A0022E6:
    ecx = (uint32_t)(eax);
    c->xmm[1] = c->xmm[0];
    goto L_A0022FC;
L_A0022ED:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[7].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (f.cf) goto L_A0022FC;
    goto L_A0022F2;
L_A0022F2:
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0022FC;
    goto L_A0022F7;
L_A0022F7:
    edi = (uint32_t)(eax);
    c->xmm[2] = c->xmm[0];
L_A0022FC:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_A0022C0;
    goto L_A002303;
L_A002303:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
L_A00230D:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    c->xmm[0].u[0] = M32((uint32_t)(0xA001130u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    if ((f.cf || f.zf)) goto L_A002329;
    goto L_A00231A;
L_A00231A:
    c->xmm[3] = c->xmm[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[1].f[0];
    c->xmm[1] = c->xmm[3];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
L_A002329:
    { float a_ = c->xmm[7].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A00233A;
    goto L_A00232E;
L_A00232E:
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[2].f[0];
    c->xmm[2] = c->xmm[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[2].u[0];
L_A00233A:
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_A002344;
    goto L_A00233F;
L_A00233F:
    (void)sub32(edi, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_A002348;
    goto L_A002344;
L_A002344:
    edi = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
L_A002348:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    if (f.zf) goto L_A002360;
    goto L_A002350;
L_A002350:
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_A002358;
    goto L_A002355;
L_A002355:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
L_A002358:
    (void)sub32(edi, (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_A002360;
    goto L_A00235D;
L_A00235D:
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
L_A002360:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_A00238C;
    goto L_A002369;
L_A002369:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF0u)) & (uint8_t)0x4u), &f);
    if (f.zf) goto L_A00237C;
    goto L_A00236F;
L_A00236F:
    (void)sub32(ecx, (uint32_t)0x2u, &f);
    if ((f.zf || f.sf != f.of)) goto L_A002377;
    goto L_A002374;
L_A002374:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
L_A002377:
    (void)sub32(edi, (uint32_t)0x2u, &f);
    goto L_A002387;
L_A00237C:
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_A002384;
    goto L_A002381;
L_A002381:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
L_A002384:
    (void)sub32(edi, (uint32_t)0x1u, &f);
L_A002387:
    if ((f.zf || f.sf != f.of)) goto L_A00238C;
    goto L_A002389;
L_A002389:
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
L_A00238C:
    c->xmm[0].u[0] = M32((uint32_t)(0xA001118u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    if ((f.cf || f.zf)) goto L_A0023C1;
    goto L_A00239C;
L_A00239C:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0x1Cu)), &f));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(eax + edx*4));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)(eax + edx*4));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(eax)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_A0023C1:
    { float a_ = c->xmm[0].f[0], b_ = c->xmm[2].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if ((f.cf || f.zf)) goto L_A0023EB;
    goto L_A0023C6;
L_A0023C6:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)edi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0x1Cu)), &f));
    c->xmm[0].u[0] = M32((uint32_t)(edx + ecx*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(ebp + 0xCu));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)(edx + ecx*4));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(eax)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_A0023EB:
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF8u)));
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    fpush(c, (double)MF32((uint32_t)(0xA001150u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)ecx; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ST(0) = ST(0) * ST(1);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ST(2) = ST(2) + ST(0); fpop(c);
    ST(1) = ST(0) / ST(1); fpop(c);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)((uint32_t)(ecx + esi*4));
    ST(0) = tan(ST(0)); fpush(c, 1.0); c->c2 = 0;
    ST(0) = ST(0); fpop(c);
    MF32((uint32_t)(ebp + 0x14u)) = (float)ST(0); fpop(c);
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x14u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2] = c->xmm[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + MF32((uint32_t)(0xA00111Cu));
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ecx)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)edi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)(edx + ecx*4));
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + MF32((uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    M32((uint32_t)(eax)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0xA001E80u: goto L_A001E80; case 0xA00204Bu: goto L_A00204B; case 0xA00204Du: goto L_A00204D; case 0xA002059u: goto L_A002059; case 0xA002067u: goto L_A002067; case 0xA002088u: goto L_A002088; case 0xA002095u: goto L_A002095; case 0xA0020A9u: goto L_A0020A9; case 0xA0020B6u: goto L_A0020B6; case 0xA0020BDu: goto L_A0020BD; case 0xA0020BFu: goto L_A0020BF; case 0xA0020C6u: goto L_A0020C6; case 0xA0020CBu: goto L_A0020CB; case 0xA0020D9u: goto L_A0020D9; case 0xA0020E1u: goto L_A0020E1; case 0xA0020F4u: goto L_A0020F4; case 0xA0020FCu: goto L_A0020FC; case 0xA00210Cu: goto L_A00210C; case 0xA002116u: goto L_A002116; case 0xA00211Du: goto L_A00211D; case 0xA002130u: goto L_A002130; case 0xA002136u: goto L_A002136; case 0xA00213Bu: goto L_A00213B; case 0xA002186u: goto L_A002186; case 0xA002190u: goto L_A002190; case 0xA0021A0u: goto L_A0021A0; case 0xA0021A6u: goto L_A0021A6; case 0xA0021ABu: goto L_A0021AB; case 0xA0021AFu: goto L_A0021AF; case 0xA0021B4u: goto L_A0021B4; case 0xA0021B9u: goto L_A0021B9; case 0xA0021C1u: goto L_A0021C1; case 0xA0021C6u: goto L_A0021C6; case 0xA0021CBu: goto L_A0021CB; case 0xA0021D0u: goto L_A0021D0; case 0xA0021E0u: goto L_A0021E0; case 0xA0021E6u: goto L_A0021E6; case 0xA0021EBu: goto L_A0021EB; case 0xA0021EFu: goto L_A0021EF; case 0xA0021F4u: goto L_A0021F4; case 0xA0021F9u: goto L_A0021F9; case 0xA002204u: goto L_A002204; case 0xA002209u: goto L_A002209; case 0xA00220Eu: goto L_A00220E; case 0xA002214u: goto L_A002214; case 0xA002223u: goto L_A002223; case 0xA002229u: goto L_A002229; case 0xA00222Eu: goto L_A00222E; case 0xA002232u: goto L_A002232; case 0xA002237u: goto L_A002237; case 0xA00223Cu: goto L_A00223C; case 0xA002244u: goto L_A002244; case 0xA002249u: goto L_A002249; case 0xA00224Eu: goto L_A00224E; case 0xA002253u: goto L_A002253; case 0xA002263u: goto L_A002263; case 0xA002269u: goto L_A002269; case 0xA00226Eu: goto L_A00226E; case 0xA002272u: goto L_A002272; case 0xA002277u: goto L_A002277; case 0xA00227Cu: goto L_A00227C; case 0xA002287u: goto L_A002287; case 0xA00228Cu: goto L_A00228C; case 0xA002291u: goto L_A002291; case 0xA002297u: goto L_A002297; case 0xA0022ACu: goto L_A0022AC; case 0xA0022BCu: goto L_A0022BC; case 0xA0022C0u: goto L_A0022C0; case 0xA0022CDu: goto L_A0022CD; case 0xA0022D3u: goto L_A0022D3; case 0xA0022D8u: goto L_A0022D8; case 0xA0022DCu: goto L_A0022DC; case 0xA0022E1u: goto L_A0022E1; case 0xA0022E6u: goto L_A0022E6; case 0xA0022EDu: goto L_A0022ED; case 0xA0022F2u: goto L_A0022F2; case 0xA0022F7u: goto L_A0022F7; case 0xA0022FCu: goto L_A0022FC; case 0xA002303u: goto L_A002303; case 0xA00230Du: goto L_A00230D; case 0xA00231Au: goto L_A00231A; case 0xA002329u: goto L_A002329; case 0xA00232Eu: goto L_A00232E; case 0xA00233Au: goto L_A00233A; case 0xA00233Fu: goto L_A00233F; case 0xA002344u: goto L_A002344; case 0xA002348u: goto L_A002348; case 0xA002350u: goto L_A002350; case 0xA002355u: goto L_A002355; case 0xA002358u: goto L_A002358; case 0xA00235Du: goto L_A00235D; case 0xA002360u: goto L_A002360; case 0xA002369u: goto L_A002369; case 0xA00236Fu: goto L_A00236F; case 0xA002374u: goto L_A002374; case 0xA002377u: goto L_A002377; case 0xA00237Cu: goto L_A00237C; case 0xA002381u: goto L_A002381; case 0xA002384u: goto L_A002384; case 0xA002387u: goto L_A002387; case 0xA002389u: goto L_A002389; case 0xA00238Cu: goto L_A00238C; case 0xA00239Cu: goto L_A00239C; case 0xA0023C1u: goto L_A0023C1; case 0xA0023C6u: goto L_A0023C6; case 0xA0023EBu: goto L_A0023EB; default: SPILL(); rt_call(c, jt_); return; }
}

