#include "funcs_bink.h"
#include "lift_prelude.h"

void f_90111F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90111F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x38u)), ebx, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if ((!f.zf && f.sf == f.of)) goto L_9011213;
    goto L_9011206;
L_9011206:
    TS32((uint32_t)(ecx), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9011210:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
L_9011213:
    (void)sub32(esi, M32((uint32_t)(ebp + 0x1Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_9011206;
    goto L_9011218;
L_9011218:
    (void)sub32(esi, M32((uint32_t)(ebp + 0x18u)), &f);
    if (f.cf) goto L_9011206;
    goto L_901121D;
L_901121D:
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011261;
    goto L_9011228;
L_9011228:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x124u)));
    edx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_9011261;
    goto L_9011234;
L_9011234:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(TL32((uint32_t)(ecx + edx*4)), ebx, &f);
    if (f.zf) goto L_9011243;
    goto L_901123C;
L_901123C:
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, eax, &f);
    if ((f.sf != f.of)) goto L_9011234;
    goto L_9011241;
L_9011241:
    goto L_9011261;
L_9011243:
    (void)sub32(edx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9011261;
    goto L_9011248;
L_9011248:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9011261;
    goto L_901124C;
L_901124C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901125Eu; SPILL(); f_9010FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_9011261:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    esi = (uint32_t)(add32(esi, edi, &f));
    (void)sub32(ebx, TL32((uint32_t)(eax + 0x38u)), &f);
    if ((f.sf != f.of)) goto L_9011210;
    goto L_901126C;
L_901126C:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(edx), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901120E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_901120E;
L_9011206:
    TS32((uint32_t)(ecx), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901120E:
    edi = (uint32_t)(edi);
L_9011210:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    (void)sub32(esi, TL32((uint32_t)(ebp + 0x1Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_9011206;
    goto L_9011218;
L_9011218:
    (void)sub32(esi, TL32((uint32_t)(ebp + 0x18u)), &f);
    if (f.cf) goto L_9011206;
    goto L_901121D;
L_901121D:
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011261;
    goto L_9011228;
L_9011228:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x124u)));
    edx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_9011261;
    goto L_9011234;
L_9011234:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x10u)));
    (void)sub32(TL32((uint32_t)(ecx + edx*4)), ebx, &f);
    if (f.zf) goto L_9011243;
    goto L_901123C;
L_901123C:
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, eax, &f);
    if ((f.sf != f.of)) goto L_9011234;
    goto L_9011241;
L_9011241:
    goto L_9011261;
L_9011243:
    (void)sub32(edx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9011261;
    goto L_9011248;
L_9011248:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9011261;
    goto L_901124C;
L_901124C:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x1Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901125Eu; SPILL(); f_9010FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_9011261:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    esi = (uint32_t)(add32(esi, edi, &f));
    (void)sub32(ebx, TL32((uint32_t)(eax + 0x38u)), &f);
    if ((f.sf != f.of)) goto L_9011210;
    goto L_901126C;
L_901126C:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(edx), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9011280(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9011280:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) & (uint32_t)0x100u), &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    if (f.zf) goto L_90112BB;
    goto L_901129D;
L_901129D:
    esp -= 4; M32(esp) = 0x90112A2u; SPILL(); f_90159C0(c); RELOAD();
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x90112ACu; SPILL(); f_9010CC0(c); RELOAD();
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90112BE;
    goto L_90112B2;
L_90112B2:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90112BB:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_90112BE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xD0u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xECu)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x11Cu)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xE8u)));
    edi = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, eax, &f));
    esp -= 4; M32(esp) = 0x90112EFu; SPILL(); f_900E070(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011319;
    goto L_90112F8;
L_90112F8:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x9037604u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028718u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1ACu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011316u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_9011319:
    esp -= 4; M32(esp) = 0x901131Eu; SPILL(); f_90159C0(c); RELOAD();
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901134A;
    goto L_9011329;
L_9011329:
    { uint32_t v_ = 0x9037648u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902845Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1B5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011347u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_901134A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x200u), &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(ecx);
    if (f.zf) goto L_9011360;
    goto L_901135B;
L_901135B:
    eax = (uint32_t)((uint32_t)0x1u);
L_9011360:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    edx = (uint32_t)((uint32_t)(esp + 0x18u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011377u; SPILL(); f_90111F0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011395;
    goto L_9011383;
L_9011383:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x1C9u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011395u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011395:
    esp -= 4; M32(esp) = 0x901139Au; SPILL(); f_90159C0(c); RELOAD();
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    eax = (uint32_t)(sub32(eax, edi, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x114u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    if (f.zf) goto L_9011467;
    goto L_90113B1;
L_90113B1:
    (void)sub32(M32((uint32_t)(esp + 0x18u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011467;
    goto L_90113BC;
L_90113BC:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90113CC;
    goto L_90113C6;
L_90113C6:
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x200u), &f));
L_90113CC:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x2u), &f));
    if (!f.zf) goto L_90113D7;
    goto L_90113D1;
L_90113D1:
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x20000u), &f));
L_90113D7:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90113E1;
    goto L_90113DB;
L_90113DB:
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFEFFFFFu), &f));
L_90113E1:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011410;
    goto L_90113EA;
L_90113EA:
    { uint32_t v_ = 0x903765Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90282C4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1F7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011408u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_9011410:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    (void)sub32(edx, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_901144F;
    goto L_9011418;
L_9011418:
    (void)sub32(edx, M32((uint32_t)(esp + 0x14u)), &f);
    if (f.cf) goto L_901144F;
    goto L_901141E;
L_901141E:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xDCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x130u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011442u; SPILL(); f_901CB00(c); RELOAD();
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
L_901144F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011486;
    goto L_9011453;
L_9011453:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x215u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9011465u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901146B;
L_9011467:
    edi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
L_901146B:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011486;
    goto L_9011474;
L_9011474:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x21Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011486u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011486:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    TS32((uint32_t)(esi + 0x494u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x494u)), eax, &f)));
    esp -= 4; M32(esp) = 0x9011495u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x20u)), &f));
    TS32((uint32_t)(esi + 0x490u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x490u)), ecx, &f)));
    (void)sub32(edi, TL32((uint32_t)(esi + 0x128u)), &f);
    if ((f.cf || f.zf)) goto L_90114AF;
    goto L_90114A9;
L_90114A9:
    TS32((uint32_t)(esi + 0x128u), (uint32_t)(edi));
L_90114AF:
    (void)sub32(M32((uint32_t)(esp + 0x24u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90114C4;
    goto L_90114B6;
L_90114B6:
    esp -= 4; M32(esp) = 0x90114BBu; SPILL(); f_9010DC0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90114C4:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90114E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90114E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xD0u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xECu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x11Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xE8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, eax, &f));
    esp -= 4; M32(esp) = 0x901151Cu; SPILL(); f_900E070(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011546;
    goto L_9011525;
L_9011525:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x9037604u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902871Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1ACu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011543u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_9011546:
    esp -= 4; M32(esp) = 0x901154Bu; SPILL(); f_90159C0(c); RELOAD();
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011577;
    goto L_9011556;
L_9011556:
    { uint32_t v_ = 0x9037648u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028820u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1B5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011574u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_9011577:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x2u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    if (f.zf) goto L_9011589;
    goto L_9011584;
L_9011584:
    eax = (uint32_t)((uint32_t)0x1u);
L_9011589:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901159Du; SPILL(); f_90111F0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90115BB;
    goto L_90115A9;
L_90115A9:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x1C9u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90115BBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90115BB:
    esp -= 4; M32(esp) = 0x90115C0u; SPILL(); f_90159C0(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(sub32(eax, edi, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x114u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    if (f.zf) goto L_90116A1;
    goto L_90115D5;
L_90115D5:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90116A1;
    goto L_90115DF;
L_90115DF:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(edi & (uint32_t)0x8000u), &f);
    if (f.zf) goto L_90115F9;
    goto L_90115EA;
L_90115EA:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0x8u)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f));
    (void)sub8(((uint8_t)eax), (uint8_t)0x1u, &f);
    if (f.zf) goto L_90116A4;
    goto L_90115F7;
L_90115F7:
    goto L_901161A;
L_90115F9:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0x8u)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9011605;
    goto L_90115FF;
L_90115FF:
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x200u), &f));
L_9011605:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901161A;
    goto L_901160B;
L_901160B:
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFEFFFFFu), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x20000u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
L_901161A:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x100u), &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901164F;
    goto L_9011629;
L_9011629:
    { uint32_t v_ = 0x903765Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028484u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1F7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011647u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_901164F:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    (void)sub32(edx, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_9011689;
    goto L_9011656;
L_9011656:
    (void)sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if (f.cf) goto L_9011689;
    goto L_901165B;
L_901165B:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xDCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x130u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901167Eu; SPILL(); f_901CB00(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_9011689:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90116BF;
    goto L_901168D;
L_901168D:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x215u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x901169Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_90116A4;
L_90116A1:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_90116A4:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90116BF;
    goto L_90116AD;
L_90116AD:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x21Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037610u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90116BFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90116BF:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    TS32((uint32_t)(esi + 0x494u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x494u)), eax, &f)));
    esp -= 4; M32(esp) = 0x90116CDu; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFE4u)), &f));
    TS32((uint32_t)(esi + 0x490u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x490u)), eax, &f)));
    eax = (uint32_t)((uint32_t)0x1u);
    (void)sub32(edi, TL32((uint32_t)(esi + 0x128u)), &f);
    if ((f.cf || f.zf)) goto L_90116E9;
    goto L_90116E3;
L_90116E3:
    TS32((uint32_t)(esi + 0x128u), (uint32_t)(edi));
L_90116E9:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90116F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90116F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0x303u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011701u; SPILL(); f_9011280(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9011710(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9011710:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9011766;
    goto L_901171B;
L_901171B:
    (void)sub32(TL32((uint32_t)(esi + 0x1Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9011766;
    goto L_9011721;
L_9011721:
    (void)sub32(TL32((uint32_t)(esi + 0x108u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9011766;
    goto L_901172A;
L_901172A:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011766;
    goto L_9011733;
L_9011733:
    (void)sub32(TL32((uint32_t)(esi + 0x110u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011766;
    goto L_901173C;
L_901173C:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    (void)sub32(eax, TL32((uint32_t)(esi + 0x8u)), &f);
    if (!f.cf) goto L_9011766;
    goto L_9011747;
L_9011747:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4BCu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011757;
    goto L_9011751;
L_9011751:
    eax = (uint32_t)(dec32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9011757:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901175Eu; SPILL(); f_9010750(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9011766:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9011770(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9011770:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_90118D6;
    goto L_9011786;
L_9011786:
    (void)sub32(TL32((uint32_t)(esi + 0x100u)), edi, &f);
    if (!f.zf) goto L_90118D6;
    goto L_9011792;
L_9011792:
    (void)sub32(TL32((uint32_t)(esi + 0x104u)), edi, &f);
    if (!f.zf) goto L_90118D6;
    goto L_901179E;
L_901179E:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), edi, &f);
    if (f.zf) goto L_9011873;
    goto L_90117AA;
L_90117AA:
    (void)sub32(TL32((uint32_t)(esi + 0x14u)), edi, &f);
    if (f.zf) goto L_9011873;
    goto L_90117B3;
L_90117B3:
    (void)sub32(TL32((uint32_t)(esi + 0x108u)), edi, &f);
    if (!f.zf) goto L_9011873;
    goto L_90117BF;
L_90117BF:
    (void)sub32(TL32((uint32_t)(esi + 0x110u)), edi, &f);
    if (f.zf) goto L_9011873;
    goto L_90117CB;
L_90117CB:
    (void)sub32(TL32((uint32_t)(esi + 0x4BCu)), edi, &f);
    if (!f.zf) goto L_90117DC;
    goto L_90117D3;
L_90117D3:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90117D9u; SPILL(); f_9010750(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_90117DC:
    TS32((uint32_t)(esi + 0x4BCu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x1DCu), (uint32_t)(edi));
    (void)sub32(TL32((uint32_t)(esi + 0x4C0u)), edi, &f);
    if (f.zf) goto L_90117F8;
    goto L_90117F0;
L_90117F0:
    TS32((uint32_t)(esi + 0x4C0u), (uint32_t)(edi));
    goto L_9011852;
L_90117F8:
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), edi, &f);
    if ((f.cf || f.zf)) goto L_9011873;
    goto L_9011802;
L_9011802:
    ecx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    goto L_9011810;
L_9011810:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + eax + 0x50u)), edi, &f);
    eax = (uint32_t)((uint32_t)(ecx + eax + 0x50u));
    if (f.zf) goto L_901183D;
    goto L_9011820;
L_9011820:
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((f.cf || f.zf)) goto L_901183D;
    goto L_901182A;
L_901182A:
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(eax, TL32((uint32_t)(ecx + ebx + 0x40u)), &f);
    if ((!f.zf && f.sf == f.of)) goto L_901183D;
    goto L_9011836;
L_9011836:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x1u);
L_901183D:
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x180u, &f));
    (void)sub32(edx, TL32((uint32_t)(esi + 0x124u)), &f);
    if (f.cf) goto L_9011810;
    goto L_901184C;
L_901184C:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), edi, &f);
    if (f.zf) goto L_9011873;
    goto L_9011852;
L_9011852:
    TS32((uint32_t)(esi + 0x46Cu), (uint32_t)(inc32(TL32((uint32_t)(esi + 0x46Cu)), &f)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901185Fu; SPILL(); f_9013840(c); RELOAD();
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x9011873u; SPILL(); f_9013840(c); RELOAD();
L_9011873:
    TS32((uint32_t)(esi + 0x1DCu), (uint32_t)((uint32_t)0x1u));
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), edi, &f);
    if (f.zf) goto L_9011897;
    goto L_9011885;
L_9011885:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9011897;
    goto L_9011891;
L_9011891:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011897u; SPILL(); f_900DDF0(c); RELOAD();
L_9011897:
    esp -= 4; M32(esp) = 0x901189Cu; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x470u)));
    (void)sub32(ecx, edi, &f);
    if (f.zf) goto L_90118B9;
    goto L_90118A6;
L_90118A6:
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90118B9;
    goto L_90118AB;
L_90118AB:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x498u)), eax, &f)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)(edi));
L_90118B9:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    (void)sub32(eax, TL32((uint32_t)(esi + 0x8u)), &f);
    if (f.cf) goto L_90118C8;
    goto L_90118C1;
L_90118C1:
    eax = (uint32_t)((uint32_t)0x1u);
    goto L_90118C9;
L_90118C8:
    eax = (uint32_t)(inc32(eax, &f));
L_90118C9:
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x90118D0u; SPILL(); f_900E160(c); RELOAD();
    TS32((uint32_t)(esi + 0x1DCu), (uint32_t)(edi));
L_90118D6:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90118E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90118E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_90118F0;
    goto L_90118EA;
L_90118EA:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_90118F0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(((uint8_t)edx) & ((uint8_t)edx)), &f);
    if (f.sf) goto L_9011908;
    goto L_90118FB;
L_90118FB:
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x158u)));
    (void)logic8((uint8_t)(TL8((uint32_t)(esi + eax*4 + 0xFFFFFFFCu)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9011957;
    goto L_9011908;
L_9011908:
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x0u, &f));
    if (f.zf) goto L_901198C;
    goto L_9011910;
L_9011910:
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (f.zf) goto L_9011964;
    goto L_9011915;
L_9011915:
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9011985;
    goto L_901191A;
L_901191A:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(eax + 0xFFFFFFFEu));
    edi = (uint32_t)(edi);
L_9011920:
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.sf != f.of)) goto L_901193A;
    goto L_9011924;
L_9011924:
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x158u)));
    (void)logic8((uint8_t)(TL8((uint32_t)(esi + edi*4)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9011953;
    goto L_9011930;
L_9011930:
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x8u)), &f);
    if (!f.cf) goto L_9011950;
    goto L_9011935;
L_9011935:
    edx = (uint32_t)(TL32((uint32_t)(esi + eax*4)));
    goto L_9011948;
L_901193A:
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x8u)), &f);
    if (!f.cf) goto L_901195C;
    goto L_901193F;
L_901193F:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x158u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + eax*4)));
L_9011948:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f));
    eax = (uint32_t)(inc32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & ((uint8_t)edx)), &f);
    if (!f.zf) goto L_9011956;
    goto L_9011950;
L_9011950:
    edi = (uint32_t)(dec32(edi, &f));
    goto L_9011920;
L_9011953:
    eax = (uint32_t)((uint32_t)(edi + 0x1u));
L_9011956:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_9011957:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_901195C:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9011964:
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9011985;
    goto L_901196B;
L_901196B:
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x158u)));
    ecx = (uint32_t)((uint32_t)(ecx + eax*4));
L_9011974:
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & ((uint8_t)edx)), &f);
    if (!f.zf) goto L_9011957;
    goto L_9011981;
L_9011981:
    (void)sub32(eax, esi, &f);
    if (f.cf) goto L_9011974;
    goto L_9011985;
L_9011985:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_901198C:
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFFEu, &f));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((f.sf != f.of)) goto L_90119AE;
    goto L_9011994;
L_9011994:
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x158u)));
    ecx = (uint32_t)((uint32_t)(ecx + eax*4));
    ecx = (uint32_t)((uint32_t)(ecx));
L_90119A0:
    (void)logic8((uint8_t)(TL8((uint32_t)(ecx)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90119AE;
    goto L_90119A5;
L_90119A5:
    eax = (uint32_t)(dec32(eax, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x4u, &f));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((f.sf == f.of)) goto L_90119A0;
    goto L_90119AE;
L_90119AE:
    eax = (uint32_t)(inc32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_90119C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90119C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9011C09;
    goto L_90119CF;
L_90119CF:
    (void)sub32(TL32((uint32_t)(edi + 0x100u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9011C09;
    goto L_90119DC;
L_90119DC:
    (void)sub32(TL32((uint32_t)(edi + 0x104u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9011C09;
    goto L_90119E9;
L_90119E9:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90119F6;
    goto L_90119F1;
L_90119F1:
    ebx = (uint32_t)((uint32_t)0x1u);
L_90119F6:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    (void)sub32(ebx, eax, &f);
    if ((!f.cf && !f.zf)) { ebx = (uint32_t)(eax); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x2u), &f));
    TS32((uint32_t)(edi + 0x4BCu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(edi + 0x1DCu), (uint32_t)((uint32_t)0x1u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    if (!f.zf) goto L_9011A46;
    goto L_9011A1E;
L_9011A1E:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011A46;
    goto L_9011A27;
L_9011A27:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x14u)));
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(eax + ecx + 0xFFFFFFFFu));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    (void)sub32(eax, ebx, &f);
    if (f.cf) goto L_9011A40;
    goto L_9011A39;
L_9011A39:
    esi = (uint32_t)((uint32_t)0x1u);
    goto L_9011A48;
L_9011A40:
    esi = (uint32_t)(ebx);
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_9011A48;
L_9011A46:
    esi = (uint32_t)(ebx);
L_9011A48:
    (void)sub32(TL32((uint32_t)(edi + 0xCu)), ebx, &f);
    if (f.zf) goto L_9011BFD;
    goto L_9011A51;
L_9011A51:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    if (f.zf) goto L_9011A79;
    goto L_9011A59;
L_9011A59:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011A79;
    goto L_9011A5F;
L_9011A5F:
    eax = (uint32_t)(ebx);
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9011A68u; SPILL(); f_900E160(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(edi + 0x1DCu), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9011A79:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011A84;
    goto L_9011A7D;
L_9011A7D:
    eax = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    goto L_9011A90;
L_9011A84:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011A8Du; SPILL(); f_90118E0(c); RELOAD();
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
L_9011A90:
    (void)sub32(eax, esi, &f);
    if ((f.cf || f.zf)) goto L_9011AA7;
    goto L_9011A94;
L_9011A94:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x114u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9011AA5u; SPILL(); f_9013820(c); RELOAD();
    goto L_9011AB0;
L_9011AA7:
    esi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)((uint32_t)0x0u);
L_9011AB0:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    (void)sub32(ebx, eax, &f);
    if (f.cf) goto L_9011ABB;
    goto L_9011AB7;
L_9011AB7:
    (void)sub32(esi, eax, &f);
    if ((f.cf || f.zf)) goto L_9011AF6;
    goto L_9011ABB;
L_9011ABB:
    eax = (uint32_t)(esi);
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9011AC4u; SPILL(); f_900E160(c); RELOAD();
    (void)sub32(esi, ebx, &f);
    if (!f.zf) goto L_9011AF6;
    goto L_9011AC8;
L_9011AC8:
    (void)sub32(TL32((uint32_t)(edi + 0x110u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(edi + 0x1DCu), (uint32_t)((uint32_t)0x0u));
    if (f.zf) goto L_9011C07;
    goto L_9011ADF;
L_9011ADF:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011AE7u; SPILL(); f_9013840(c); RELOAD();
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011AEFu; SPILL(); f_9013840(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9011AF6:
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9011AFDu; SPILL(); f_900DD70(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x110u)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011B12;
    goto L_9011B0A;
L_9011B0A:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011B12u; SPILL(); f_9013840(c); RELOAD();
L_9011B12:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    (void)sub32(edx, TL32((uint32_t)(edi + 0x4ACu)), &f);
    if (f.zf) goto L_9011B30;
    goto L_9011B1D;
L_9011B1D:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011B23u; SPILL(); f_90116F0(c); RELOAD();
    esi = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(edi + 0x10Cu), (uint32_t)(esi));
    goto L_9011B35;
L_9011B30:
    esi = (uint32_t)((uint32_t)0x1u);
L_9011B35:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011B3Bu; SPILL(); f_9011770(c); RELOAD();
    (void)sub32(TL32((uint32_t)(edi + 0xCu)), ebx, &f);
    if (f.zf) goto L_9011BD0;
    goto L_9011B44;
L_9011B44:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011B95;
    goto L_9011B4D;
L_9011B4D:
    { uint32_t v_ = 0xC79u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x2B0u));
    { uint32_t v_ = 0x9037428u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011B62u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011B7D;
    goto L_9011B6E;
L_9011B6E:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1A0u)));
    eax = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9011B7Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011B7D:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xC7Eu);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x9011B8Du; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    esi = (uint32_t)((uint32_t)0x1u);
L_9011B95:
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011BB0;
    goto L_9011B9B;
L_9011B9B:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edi + 0xCu)), edx, &f);
    if (!f.zf) goto L_9011BB0;
    goto L_9011BA3;
L_9011BA3:
    TS32((uint32_t)(edi + 0x114u), (uint32_t)(esi));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)((uint32_t)0x0u);
L_9011BB0:
    { uint32_t v_ = 0x303u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011BBBu; SPILL(); f_9011280(c); RELOAD();
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(edi + 0x10Cu), (uint32_t)(esi));
    esp -= 4; M32(esp) = 0x9011BC7u; SPILL(); f_9011770(c); RELOAD();
    (void)sub32(TL32((uint32_t)(edi + 0xCu)), ebx, &f);
    if (!f.zf) goto L_9011B44;
    goto L_9011BD0;
L_9011BD0:
    ebx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(edi + 0x474u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x4CCu), (uint32_t)(ebx));
    (void)sub32(M32((uint32_t)(ebp + 0x10u)), ebx, &f);
    if (f.zf) goto L_9011BEA;
    goto L_9011BE3;
L_9011BE3:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011BEAu; SPILL(); f_9013820(c); RELOAD();
L_9011BEA:
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9011BF1u; SPILL(); f_900DDB0(c); RELOAD();
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    if (f.zf) goto L_9011BFD;
    goto L_9011BF6;
L_9011BF6:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011BFDu; SPILL(); f_9013840(c); RELOAD();
L_9011BFD:
    TS32((uint32_t)(edi + 0x1DCu), (uint32_t)((uint32_t)0x0u));
L_9011C07:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9011C09:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9011C10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9011C10;
L_900D380:
    esp -= 4; M32(esp) = 0x900D385u; SPILL(); f_900D150(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900D474;
    goto L_900D392;
L_900D392:
    eax = (uint32_t)(TL32((uint32_t)(0x9028714u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(eax);
    edi = (uint32_t)(eax);
    esi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edi)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    esi = (uint32_t)(TL32((uint32_t)(0x90310E4u)));
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_900D3CD;
    goto L_900D3B1;
L_900D3B1:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D3BE;
    goto L_900D3B6;
L_900D3B6:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900D3BCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D3CD;
L_900D3BE:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900D3CD;
    goto L_900D3C3;
L_900D3C3:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x900D3CDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D3CD:
    eax = (uint32_t)(TL32((uint32_t)(0x9028514u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)edi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_900D401;
    goto L_900D3E5;
L_900D3E5:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D3F2;
    goto L_900D3EA;
L_900D3EA:
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900D3F0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D401;
L_900D3F2:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900D401;
    goto L_900D3F7;
L_900D3F7:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x900D401u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D401:
    eax = (uint32_t)(TL32((uint32_t)(0x90282BCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)edi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_900D434;
    goto L_900D418;
L_900D418:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D425;
    goto L_900D41D;
L_900D41D:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900D423u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D434;
L_900D425:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900D434;
    goto L_900D42A;
L_900D42A:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x900D434u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D434:
    eax = (uint32_t)(TL32((uint32_t)(0x9028594u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)edi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_900D468;
    goto L_900D44C;
L_900D44C:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900D459;
    goto L_900D451;
L_900D451:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900D457u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900D468;
L_900D459:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_900D468;
    goto L_900D45E;
L_900D45E:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x900D468u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900D468:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x903FDE0u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_900D474:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)((uint32_t)0x903FDE8u);
    { uint32_t s_ = edx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(eax)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); edx = (uint32_t)(o_); }
    esp += 4; SPILL(); return;
L_9011C10:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011C39;
    goto L_9011C1D;
L_9011C1D:
    { uint32_t v_ = 0xCAFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    edi = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x9011C36u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_9011C39:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FDFCu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_9011C48;
    goto L_9011C43;
L_9011C43:
    esp -= 4; M32(esp) = 0x9011C48u; SPILL(); f_900DBF0(c); RELOAD();
L_9011C48:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9011C6D;
    goto L_9011C4C;
L_9011C4C:
    edx = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9011C6D;
    goto L_9011C56;
L_9011C56:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xCB6u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x9011C6Au; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9011C6D:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    edi = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011C94;
    goto L_9011C78;
L_9011C78:
    { uint32_t v_ = 0xCC0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    edi = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x9011C91u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_9011C94:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEA8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_9011CA3;
    goto L_9011C9E;
L_9011C9E:
    esp -= 4; M32(esp) = 0x9011CA3u; SPILL(); f_900EF60(c); RELOAD();
L_9011CA3:
    (void)logic32((uint32_t)(edi & edi), &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    if (f.zf) goto L_9011CCA;
    goto L_9011CA9;
L_9011CA9:
    edx = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9011CCA;
    goto L_9011CB3;
L_9011CB3:
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xCC7u);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x9011CC7u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9011CCA:
    goto L_900D380;
}

void f_9011CD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9011CD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_901215D;
    goto L_9011CDF;
L_9011CDF:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9011CE7u; SPILL(); f_9012370(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEB4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011CF6;
    goto L_9011CF0;
L_9011CF0:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011CF3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9011CF6:
    (void)sub32(TL32((uint32_t)(ebx + 0x160u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebx + 0x164u), (uint32_t)((uint32_t)0x1u));
    if (f.zf) goto L_9011D1C;
    goto L_9011D0B;
L_9011D0B:
    edi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9011D12u; SPILL(); f_900D4F0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x160u), (uint32_t)((uint32_t)0x0u));
L_9011D1C:
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_9011D73;
    goto L_9011D25;
L_9011D25:
    esi = (uint32_t)((uint32_t)(ebx + 0x330u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x9011D36u; SPILL(); f_900D570(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(eax, ebx, &f);
    if (!f.zf) goto L_9011D4C;
    goto L_9011D42;
L_9011D42:
    TS32((uint32_t)(0x903FEACu), (uint32_t)((uint32_t)0x0u));
L_9011D4C:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xCF4u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x9011D5Cu; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xCF5u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x9011D70u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_9011D73:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    (void)sub32(ecx, ebx, &f);
    if (!f.zf) goto L_9011D87;
    goto L_9011D7D;
L_9011D7D:
    TS32((uint32_t)(0x903FEACu), (uint32_t)((uint32_t)0x0u));
L_9011D87:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011DD7;
    goto L_9011D90;
L_9011D90:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_9011DA2;
    goto L_9011D9D;
L_9011D9D:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_9011DD7;
    goto L_9011DA2;
L_9011DA2:
    esi = (uint32_t)((uint32_t)(ebx + 0x3B0u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x90373B0u);
    esp -= 4; M32(esp) = 0x9011DB3u; SPILL(); f_900D570(c); RELOAD();
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xD01u);
    ecx = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9011DC0u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xD02u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x9011DD4u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9011DD7:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011DF7;
    goto L_9011DE0;
L_9011DE0:
    { uint32_t v_ = 0xD08u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x9011DF4u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_9011DF7:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), esi, &f);
    if ((f.cf || f.zf)) goto L_9011E38;
    goto L_9011E01;
L_9011E01:
    edi = (uint32_t)(logic32(0, &f));
    goto L_9011E10;
L_9011E10:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    edx = (uint32_t)(TL32((uint32_t)(edi + ecx + 0x178u)));
    eax = (uint32_t)((uint32_t)(edi + ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011E23u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FDF4u), (uint32_t)(dec32(TL32((uint32_t)(0x903FDF4u)), &f)));
    esi = (uint32_t)(inc32(esi, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x180u, &f));
    (void)sub32(esi, TL32((uint32_t)(ebx + 0x124u)), &f);
    if (f.cf) goto L_9011E10;
    goto L_9011E38;
L_9011E38:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011E58;
    goto L_9011E41;
L_9011E41:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xD1Du);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x9011E55u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9011E58:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x15Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011E8A;
    goto L_9011E62;
L_9011E62:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_9011E78;
    goto L_9011E6C;
L_9011E6C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011E76u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9011E8A;
L_9011E78:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9011E8Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011E8A:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x17Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011EA3;
    goto L_9011E94;
L_9011E94:
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & (uint32_t)0x4000000u), &f);
    if (!f.zf) goto L_9011F24;
    goto L_9011EA1;
L_9011EA1:
    goto L_9011EFC;
L_9011EA3:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011EC3;
    goto L_9011EAC;
L_9011EAC:
    { uint32_t v_ = 0xD2Du; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x9011EC0u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_9011EC3:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x1A4u)));
    ecx = (uint32_t)((uint32_t)(ebx + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9011ED2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011EF2;
    goto L_9011EDB;
L_9011EDB:
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xD34u);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x9011EEFu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9011EF2:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x430u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011F24;
    goto L_9011EFC;
L_9011EFC:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_9011F12;
    goto L_9011F06;
L_9011F06:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9011F10u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9011F24;
L_9011F12:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9011F24u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011F24:
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_9011F6A;
    goto L_9011F2D;
L_9011F2D:
    eax = (uint32_t)((uint32_t)(ebx + 0x330u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011F6A;
    goto L_9011F37;
L_9011F37:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    esi = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(edx);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edi)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9011F6A;
    goto L_9011F4A;
L_9011F4A:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_9011F5B;
    goto L_9011F4F;
L_9011F4F:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9011F59u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9011F6A;
L_9011F5B:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_9011F6A;
    goto L_9011F60;
L_9011F60:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x9011F6Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011F6A:
    eax = (uint32_t)((uint32_t)(ebx + 0x2B0u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011FA7;
    goto L_9011F74;
L_9011F74:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    esi = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(edx);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edi)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9011FA7;
    goto L_9011F87;
L_9011F87:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_9011F98;
    goto L_9011F8C;
L_9011F8C:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9011F96u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9011FA7;
L_9011F98:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_9011FA7;
    goto L_9011F9D;
L_9011F9D:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x9011FA7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011FA7:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9011FFF;
    goto L_9011FB0;
L_9011FB0:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_9011FC2;
    goto L_9011FBD;
L_9011FBD:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_9011FFF;
    goto L_9011FC2;
L_9011FC2:
    eax = (uint32_t)((uint32_t)(ebx + 0x3B0u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9011FFF;
    goto L_9011FCC;
L_9011FCC:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    esi = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(edx);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edi)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9011FFF;
    goto L_9011FDF;
L_9011FDF:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_9011FF0;
    goto L_9011FE4;
L_9011FE4:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9011FEEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9011FFF;
L_9011FF0:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_9011FFF;
    goto L_9011FF5;
L_9011FF5:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x9011FFFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9011FFF:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x4E4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9012031;
    goto L_9012009;
L_9012009:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_901201F;
    goto L_9012013;
L_9012013:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901201Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9012031;
L_901201F:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9012031u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9012031:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9012063;
    goto L_901203B;
L_901203B:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_9012051;
    goto L_9012045;
L_9012045:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901204Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9012063;
L_9012051:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9012063u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9012063:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901209D;
    goto L_901206D;
L_901206D:
    (void)sub32(eax, TL32((uint32_t)(ebx + 0xD4u)), &f);
    if (f.zf) goto L_901209D;
    goto L_9012075;
L_9012075:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_901208B;
    goto L_901207F;
L_901207F:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9012089u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901209D;
L_901208B:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x901209Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901209D:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90120C6;
    goto L_90120A6;
L_90120A6:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    (void)sub32(TL32((uint32_t)(eax + 0x4Cu)), (uint32_t)0x0u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_90120C6;
    goto L_90120B2;
L_90120B2:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    ecx = (uint32_t)(~ecx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90120C3u; SPILL(); f_900DCD0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_90120C6:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    (void)logic32((uint32_t)(eax & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_9012120;
    goto L_90120D0;
L_90120D0:
    eax = (uint32_t)(shr32(eax, (uint8_t)0x6u, &f));
    eax = (uint32_t)(~eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    { uint32_t v_ = 0x566u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    edi = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x90120EEu; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    TS32((uint32_t)(0x903FEA8u), (uint32_t)(add32(TL32((uint32_t)(0x903FEA8u)), (uint32_t)0xFFFFFFFFu, &f)));
    edx = (uint32_t)(TL32((uint32_t)(0x903FEA8u)));
    if (!f.zf) goto L_9012109;
    goto L_9012100;
L_9012100:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9012109;
    goto L_9012104;
L_9012104:
    esp -= 4; M32(esp) = 0x9012109u; SPILL(); f_900EF60(c); RELOAD();
L_9012109:
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x56Du);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x901211Du; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9012120:
    { uint32_t v_ = 0x4F0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901212Du; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL8((uint32_t)(ebx + 0xFFFFFFFFu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)sub8(TL8((uint32_t)(ebx + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    if (!f.zf) goto L_901214B;
    goto L_901213C;
L_901213C:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0xFFFFFFF4u)));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9012146u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_901214B:
    ecx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x901215Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901215D:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9012170(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012170:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_90121BB;
    goto L_901217B;
L_901217B:
    if (f.zf) goto L_90121A6;
    goto L_901217D;
L_901217D:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_90121DD;
    goto L_9012182;
L_9012182:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDF8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90121DD;
    goto L_901218B;
L_901218B:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x90282C8u);
L_9012194:
    esp -= 4; M32(esp) = 0x9012199u; SPILL(); f_90274B0(c); RELOAD();
L_9012199:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90121DD;
    goto L_901219D;
L_901219D:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90121A6:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90121DD;
    goto L_90121B0;
L_90121B0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9028720u);
    goto L_9012194;
L_90121BB:
    (void)sub32(eax, (uint32_t)0x400u, &f);
    if ((f.sf != f.of)) goto L_90121DD;
    goto L_90121C2;
L_90121C2:
    (void)sub32(eax, (uint32_t)0x407u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_90121DD;
    goto L_90121C9;
L_90121C9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(eax + 0xFFFFFC00u));
    esp -= 4; M32(esp) = 0x90121D8u; SPILL(); f_9017A70(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_9012199;
L_90121DD:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90121F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90121F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9012207;
    goto L_90121FE;
L_90121FE:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9012207:
    (void)sub32(TL32((uint32_t)(esi + 0x460u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9012219;
    goto L_9012210;
L_9012210:
    (void)sub32(TL32((uint32_t)(esi + 0x108u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90121FE;
    goto L_9012219;
L_9012219:
    (void)sub32(TL32((uint32_t)(esi + 0x1Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90121FE;
    goto L_901221F;
L_901221F:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x474u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_9012235;
    goto L_901222A;
L_901222A:
    esp -= 4; M32(esp) = 0x901222Fu; SPILL(); f_900E040(c); RELOAD();
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x474u)));
L_9012235:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9012250;
    goto L_901223E;
L_901223E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    (void)sub32(TL32((uint32_t)(eax + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9012250;
    goto L_901224A;
L_901224A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9012250u; SPILL(); f_900DDF0(c); RELOAD();
L_9012250:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9012256u; SPILL(); f_90159C0(c); RELOAD();
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x470u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901227B;
    goto L_9012262;
L_9012262:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_901227B;
    goto L_9012267;
L_9012267:
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    TS32((uint32_t)(esi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x498u)), ecx, &f)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)((uint32_t)0x0u));
L_901227B:
    (void)sub32(TL32((uint32_t)(esi + 0x108u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901231F;
    goto L_9012288;
L_9012288:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901229E;
    goto L_9012291;
L_9012291:
    (void)sub32(TL32((uint32_t)(esi + 0x110u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901231F;
    goto L_901229E;
L_901229E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9012314;
    goto L_90122A5;
L_90122A5:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x478u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x3E8u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x154u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x3Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x10u);
    eax = (uint32_t)(shrd32(eax, edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sub32(edi, eax, &f));
    edi = (uint32_t)(sub32(edi, ebx, &f));
    if (f.sf) goto L_901231F;
    goto L_90122F5;
L_90122F5:
    (void)sub32(TL32((uint32_t)(esi + 0x124u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9012314;
    goto L_90122FE;
L_90122FE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x47Cu)));
    eax = (uint32_t)(add32(eax, eax, &f));
    (void)sub32(edi, eax, &f);
    if ((f.zf || f.sf != f.of)) goto L_9012314;
    goto L_901230A;
L_901230A:
    TS32((uint32_t)(esi + 0x474u), (uint32_t)((uint32_t)0x0u));
L_9012314:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_901231F:
    (void)sub32(TL32((uint32_t)(esi + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9012359;
    goto L_9012328;
L_9012328:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (f.zf) goto L_9012359;
    goto L_9012331;
L_9012331:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901234A;
    goto L_901233B;
L_901233B:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9012346u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9012359;
    goto L_901234A;
L_901234A:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1A0u)));
    edx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9012359u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9012359:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9012370(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012370:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    (void)sub32(edi, ebx, &f);
    if (!f.zf) goto L_901238C;
    goto L_9012382;
L_9012382:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901238C:
    esp -= 4; M32(esp) = 0x9012391u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x470u)));
    (void)sub32(ecx, ebx, &f);
    if (f.zf) goto L_90123AE;
    goto L_901239B;
L_901239B:
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90123AE;
    goto L_90123A0;
L_90123A0:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(edi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x498u)), eax, &f)));
    TS32((uint32_t)(edi + 0x470u), (uint32_t)(ebx));
L_90123AE:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x108u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(edi + 0x4B0u), (uint32_t)(ebx));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    TS32((uint32_t)(edi + 0x108u), (uint32_t)(ecx));
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), ebx, &f);
    if (f.zf) goto L_90123F9;
    goto L_90123CF;
L_90123CF:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)sub32(eax, ebx, &f);
    if ((f.zf || f.sf != f.of)) goto L_90123E1;
    goto L_90123DC;
L_90123DC:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_90123F9;
    goto L_90123E1;
L_90123E1:
    { uint32_t v_ = 0x28Au; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x3B0u));
    esp -= 4; M32(esp) = 0x90123F6u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
L_90123F9:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), ebx, &f);
    if ((f.cf || f.zf)) goto L_9012437;
    goto L_9012403;
L_9012403:
    goto L_9012410;
L_9012410:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + ebx + 0x170u)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9012426u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(inc32(esi, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x180u, &f));
    (void)sub32(esi, TL32((uint32_t)(edi + 0x124u)), &f);
    if (f.cf) goto L_9012410;
    goto L_9012435;
L_9012435:
    ebx = (uint32_t)(logic32(0, &f));
L_9012437:
    esp -= 4; M32(esp) = 0x901243Cu; SPILL(); f_90159C0(c); RELOAD();
    esi = (uint32_t)(eax);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    if (!f.zf) goto L_9012451;
    goto L_9012443;
L_9012443:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), ebx, &f);
    if (f.zf) goto L_9012472;
    goto L_9012448;
L_9012448:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x1u);
    goto L_9012472;
L_9012451:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), ebx, &f);
    if (!f.zf) goto L_9012472;
    goto L_9012456;
L_9012456:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x474u)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_901246C;
    goto L_9012460;
L_9012460:
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    TS32((uint32_t)(edi + 0x4CCu), (uint32_t)(ecx));
    goto L_9012472;
L_901246C:
    TS32((uint32_t)(edi + 0x4CCu), (uint32_t)(ebx));
L_9012472:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), ebx, &f);
    if (f.zf) goto L_90124BF;
    goto L_901247A;
L_901247A:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)sub32(eax, ebx, &f);
    if ((f.zf || f.sf != f.of)) goto L_901248C;
    goto L_9012487;
L_9012487:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_90124A5;
    goto L_901248C;
L_901248C:
    eax = (uint32_t)((uint32_t)(edi + 0x3B0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x290u);
    ecx = (uint32_t)((uint32_t)0x90373B0u);
    esp -= 4; M32(esp) = 0x90124A2u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_90124A5:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), ebx, &f);
    if (f.zf) goto L_90124BF;
    goto L_90124AD;
L_90124AD:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_90124BF;
    goto L_90124B9;
L_90124B9:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90124BFu; SPILL(); f_900DDF0(c); RELOAD();
L_90124BF:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), ebx, &f);
    if (f.zf) goto L_90124D0;
    goto L_90124C4;
L_90124C4:
    esi = (uint32_t)(sub32(esi, TL32((uint32_t)(edi + 0x4CCu)), &f));
    TS32((uint32_t)(edi + 0x474u), (uint32_t)(esi));
L_90124D0:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90124EC;
    goto L_90124DB;
L_90124DB:
    eax = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x90124ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90124EC:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x108u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9012500(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012500:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90126D6;
    goto L_9012510;
L_9012510:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_90126D5;
    goto L_901251C;
L_901251C:
    esp -= 4; M32(esp) = 0x9012521u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x470u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9012542;
    goto L_901252B;
L_901252B:
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9012542;
    goto L_9012530;
L_9012530:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x498u)), eax, &f)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)((uint32_t)0x0u));
L_9012542:
    { uint32_t v_ = 0x7Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901254Cu; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    TS32((uint32_t)(edi + 0x14u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    TS32((uint32_t)(edi + 0x18u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4C4u)));
    TS32((uint32_t)(edi + 0x2Cu), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x46Cu)));
    TS32((uint32_t)(edi + 0x30u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4A0u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4A4u)));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    TS32((uint32_t)(edi + 0x20u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(edi + 0x24u), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x9012593u; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(esi + 0x464u)), &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(eax));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x49Cu)));
    TS32((uint32_t)(edi + 0x1Cu), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x494u)));
    TS32((uint32_t)(edi + 0x40u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x490u)));
    TS32((uint32_t)(edi + 0x3Cu), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x498u)));
    TS32((uint32_t)(edi + 0x34u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x468u)));
    TS32((uint32_t)(edi + 0x68u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x68u)), eax, &f)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x458u)));
    TS32((uint32_t)(edi + 0x6Cu), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1E0u)));
    (void)sub32(edx, (uint32_t)0x3E8u, &f);
    if (!f.cf) goto L_90125FE;
    goto L_90125E0;
L_90125E0:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1E0u)));
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    eax = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1D8u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)eax; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    TS32((uint32_t)(edi + 0x4Cu), (uint32_t)(edx));
    goto L_9012622;
L_90125FE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1E0u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1D8u)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(ecx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(edi + 0x4Cu), (uint32_t)(eax));
L_9012622:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1E4u)));
    TS32((uint32_t)(edi + 0x38u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1E8u)));
    TS32((uint32_t)(edi + 0x44u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1ECu)));
    TS32((uint32_t)(edi + 0x48u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(esi + 0x4A4u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x158u)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4A0u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(edi + 0x60u), (uint32_t)(eax));
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ebx);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = TL32((uint32_t)(esi + 0x8u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(edi + 0x64u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xC8u)));
    TS32((uint32_t)(edi + 0x74u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCCu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(edi + 0x78u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x480u)));
    TS32((uint32_t)(edi + 0x50u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x488u)));
    TS32((uint32_t)(edi + 0x54u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x484u)));
    TS32((uint32_t)(edi + 0x58u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x48Cu)));
    TS32((uint32_t)(edi + 0x5Cu), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1F0u)));
    TS32((uint32_t)(edi + 0x6Cu), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1F4u)));
    TS32((uint32_t)(edi + 0x70u), (uint32_t)(eax));
L_90126D5:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_90126D6:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90126E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90126E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901285E;
    goto L_90126EF;
L_90126EF:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901285D;
    goto L_90126FB;
L_90126FB:
    esp -= 4; M32(esp) = 0x9012700u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x470u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9012721;
    goto L_901270A;
L_901270A:
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9012721;
    goto L_901270F;
L_901270F:
    eax = (uint32_t)(sub32(eax, ecx, &f));
    TS32((uint32_t)(esi + 0x498u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x498u)), eax, &f)));
    TS32((uint32_t)(esi + 0x470u), (uint32_t)((uint32_t)0x0u));
L_9012721:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_9012731;
    goto L_9012729;
L_9012729:
    (void)sub32(ebx, TL32((uint32_t)(esi + 0x450u)), &f);
    if (f.cf) goto L_9012738;
    goto L_9012731;
L_9012731:
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x450u)));
    ebx = (uint32_t)(dec32(ebx, &f));
L_9012738:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    (void)sub32(ebx, eax, &f);
    if ((f.cf || f.zf)) goto L_9012742;
    goto L_901273F;
L_901273F:
    ebx = (uint32_t)((uint32_t)(eax + 0xFFFFFFFFu));
L_9012742:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_901274B;
    goto L_9012746;
L_9012746:
    ebx = (uint32_t)((uint32_t)0x1u);
L_901274B:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    TS32((uint32_t)(edi + 0x2Cu), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1FCu)));
    TS32((uint32_t)(edi + 0x30u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4A4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4A0u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ebx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x158u)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx + eax*4)));
    edx = (uint32_t)(sub32(edx, ebx, &f));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ecx + edx*4)), &f));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(edi + 0x34u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x450u)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_90127BD;
    goto L_90127BB;
L_90127BB:
    eax = (uint32_t)(sub32(eax, ecx, &f));
L_90127BD:
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x434u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + ecx*4)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(edx + eax*4)), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(ecx));
    if (!f.zf) goto L_90127DF;
    goto L_90127D8;
L_90127D8:
    TS32((uint32_t)(edi + 0x10u), (uint32_t)((uint32_t)0x1u));
L_90127DF:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x43Cu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x14u), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x438u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x18u), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x440u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x28u), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x444u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x1Cu), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x448u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x20u), (uint32_t)(edx));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x44Cu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x454u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + edx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ecx + eax*4)), &f));
    TS32((uint32_t)(edi + 0x24u), (uint32_t)(edx));
L_901285D:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_901285E:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9012870(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9012870:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    eax = (uint32_t)(ecx);
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0x4u, &f));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)M32((uint32_t)(ebp + 0x10u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xCu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(esi);
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x4u, &f));
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(add32(ebx, edi, &f));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(esi);
    edi = (uint32_t)(ebx);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_90128F3;
    goto L_90128D6;
L_90128D6:
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.zf || f.sf != f.of)) goto L_90128EB;
    goto L_90128DC;
L_90128DC:
    esp = (uint32_t)((uint32_t)(esp));
L_90128E0:
    (void)sub8(TL8((uint32_t)(eax + edi)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_90128FC;
    goto L_90128E6;
L_90128E6:
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, esi, &f);
    if ((f.sf != f.of)) goto L_90128E0;
    goto L_90128EB;
L_90128EB:
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0x10u)), &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, ecx, &f);
    if ((f.sf != f.of)) goto L_90128D6;
    goto L_90128F3;
L_90128F3:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90128FC:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(edx);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)esi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(add32(ebx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(eax));
    if ((f.zf || f.sf != f.of)) goto L_9012953;
    goto L_9012923;
L_9012923:
    edx = (uint32_t)((uint32_t)(ecx + 0xFFFFFFFFu));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, ebx, &f));
    edi = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_9012946;
    goto L_9012931;
L_9012931:
    eax = (uint32_t)(logic32(0, &f));
L_9012933:
    (void)sub8(TL8((uint32_t)(eax + edx)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_9012946;
    goto L_9012939;
L_9012939:
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, M32((uint32_t)(ebp + 0xCu)), &f);
    if ((f.sf != f.of)) goto L_9012933;
    goto L_901293F;
L_901293F:
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(sub32(edx, esi, &f));
    (void)sub32(edi, ecx, &f);
    if ((f.sf != f.of)) goto L_9012931;
    goto L_9012946;
L_9012946:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(neg32(edi, &f));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x4u, &f));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(add32(TL32((uint32_t)(eax + 0xCu)), edi, &f)));
L_9012953:
    edx = (uint32_t)(logic32(0, &f));
L_9012955:
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(edx + ebx));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_901296C;
    goto L_901295E;
L_901295E:
    edi = (uint32_t)(edi);
L_9012960:
    (void)sub8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_9012972;
    goto L_9012965;
L_9012965:
    edi = (uint32_t)(inc32(edi, &f));
    eax = (uint32_t)(add32(eax, esi, &f));
    (void)sub32(edi, ecx, &f);
    if ((f.sf != f.of)) goto L_9012960;
    goto L_901296C;
L_901296C:
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, M32((uint32_t)(ebp + 0xCu)), &f);
    if ((f.sf != f.of)) goto L_9012955;
    goto L_9012972;
L_9012972:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xCu)), edx, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    TS32((uint32_t)(esi), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    if ((f.zf || f.sf != f.of)) goto L_90129CE;
    goto L_9012991;
L_9012991:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFFu, &f));
    if (f.sf) goto L_90129C2;
    goto L_9012999;
L_9012999:
    esp = (uint32_t)((uint32_t)(esp));
L_90129A0:
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(edi + ebx));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_90129BD;
    goto L_90129A9;
L_90129A9:
    esp = (uint32_t)((uint32_t)(esp));
L_90129B0:
    (void)sub8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_90129C2;
    goto L_90129B5;
L_90129B5:
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x10u)), &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, ecx, &f);
    if ((f.sf != f.of)) goto L_90129B0;
    goto L_90129BD;
L_90129BD:
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.sf) goto L_90129A0;
    goto L_90129C2;
L_90129C2:
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xCu)), &f));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x8u)), edi, &f)));
L_90129CE:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90129E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90129E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x34u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(esi + 0x8u)), (uint32_t)0x20u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if ((f.sf != f.of)) goto L_9012A7A;
    goto L_90129F5;
L_90129F5:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(sar32(edi, (uint8_t)0x1u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFu, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9012A2Du; SPILL(); f_9012870(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(add32(eax, edi, &f));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9012A5Cu; SPILL(); f_9012870(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)TL32((uint32_t)(ebx + 0x8u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)TL32((uint32_t)(esi + 0x8u)); ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edi + 0x8u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sub32(ebx, edx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    goto L_9012A7C;
L_9012A7A:
    ebx = (uint32_t)(logic32(0, &f));
L_9012A7C:
    (void)sub32(TL32((uint32_t)(esi + 0xCu)), (uint32_t)0x20u, &f);
    if ((f.sf != f.of)) goto L_9012B45;
    goto L_9012A86;
L_9012A86:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(sar32(edi, (uint8_t)0x1u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE0u));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9012ABEu; SPILL(); f_9012870(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(add32(eax, edi, &f));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    esp -= 4; M32(esp) = 0x9012AEDu; SPILL(); f_9012870(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(esi + 0x8u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(edx);
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)esi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(sub32(eax, ecx, &f));
    ecx = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)M32((uint32_t)(ebp + 0xFFFFFFE8u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(sub32(eax, ecx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)sub32(eax, ebx, &f);
    if ((f.zf || f.sf != f.of)) goto L_9012B45;
    goto L_9012B13;
L_9012B13:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    TS32((uint32_t)(ecx), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(ecx + 0xCu), (uint32_t)(edi));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD0u)));
    TS32((uint32_t)(ecx), (uint32_t)(edi));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xCu), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9012B45:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

