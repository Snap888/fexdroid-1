#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9019300(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019300:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(esi);
    esi = (uint32_t)(add32(esi, (uint32_t)0x140u, &f));
    ebx = (uint32_t)((uint32_t)0x10u);
L_9019316:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0xFFFFFFC0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9019325u; SPILL(); f_9018CA0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ebx = (uint32_t)(sub32(ebx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9019316;
    goto L_9019333;
L_9019333:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)(eax + 0x10u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(eax + 0x20u));
    ecx = (uint32_t)((uint32_t)(eax + 0x24u));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9019349u; SPILL(); f_9018CA0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(ecx + 0x180u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9019360(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019360:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x4u)), &f);
    if (!f.zf) goto L_90195A1;
    goto L_9019375;
L_9019375:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    (void)sub32(esi, eax, &f);
    if (!f.cf) goto L_90193C0;
    goto L_901938F;
L_901938F:
    ebx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ebx), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(add32(esi, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x4u, &f));
    goto L_90193D1;
L_90193C0:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
L_90193D1:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9019586;
    goto L_90193DC;
L_90193DC:
    (void)sub32(edx, TL32((uint32_t)(ebx + 0x2Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_9019586;
    goto L_90193E5;
L_90193E5:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x30u)));
    ecx = (uint32_t)((uint32_t)(eax + edx));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    TS32((uint32_t)(ebx), (uint32_t)(eax));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901940F;
    goto L_90193F7;
L_90193F7:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edi = (uint32_t)(TL32((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFE4u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9019414;
L_901940F:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9019414:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9019537;
    goto L_901941D;
L_901941D:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)((uint32_t)0x0u);
    goto L_901943A;
L_9019437:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_901943A:
    (void)sub32(esi, M32((uint32_t)(ebp + 0xFFFFFFECu)), &f);
    if (f.cf) goto L_9019467;
    goto L_901943F;
L_901943F:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFECu)), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    eax = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + ebx + 0x10u)));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_90194C4;
L_9019467:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    (void)sub32(eax, M32((uint32_t)(ebp + 0x10u)), &f);
    if (!f.cf) goto L_9019586;
    goto L_9019473;
L_9019473:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFECu)), &f));
    ebx = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & ebx), &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_90194AE;
    goto L_90194A8;
L_90194A8:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_90194C1;
L_90194AE:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(add32(esi, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x4u, &f));
L_90194C1:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
L_90194C4:
    (void)sub8(((uint8_t)ebx), (uint8_t)0xCu, &f);
    if (f.cf) goto L_901951C;
    goto L_90194C9;
L_90194C9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
    ecx = (uint32_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x903BD48u)));
    ebx = (uint32_t)(eax);
    M8((uint32_t)(ebp + 0xFFFFFFFFu)) = (uint8_t)(((uint8_t)ecx));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if ((!f.cf && !f.zf)) goto L_9019591;
    goto L_90194F2;
L_90194F2:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), ecx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFFFu)));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x3u), &f);
    if (f.zf) goto L_9019510;
    goto L_90194FD;
L_90194FD:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9019500:
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)eax)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0xFFu, &f));
    if (!f.zf) goto L_9019500;
    goto L_9019508;
L_9019508:
    goto L_9019528;
L_9019510:
    TS32((uint32_t)(edx), (uint32_t)(eax));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0xFCu, &f));
    if (!f.zf) goto L_9019510;
    goto L_901951A;
L_901951A:
    goto L_9019528;
L_901951C:
    eax = (uint32_t)(((uint8_t)ebx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
L_9019528:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    if (!f.zf) goto L_9019437;
    goto L_9019535;
L_9019535:
    goto L_9019591;
L_9019537:
    (void)sub32(esi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901956E;
    goto L_901953C;
L_901953C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x4u, &f));
    ebx = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Cu, &f));
    esp -= 4; M32(esp) = 0x9019569u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    goto L_9019591;
L_901956E:
    ebx = (uint32_t)(edi);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x4u, &f));
    esp -= 4; M32(esp) = 0x9019581u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    goto L_9019591;
L_9019586:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x30u)));
    edx = (uint32_t)((uint32_t)(eax + 0x4u));
    TS32((uint32_t)(ebx), (uint32_t)(edx));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(eax));
L_9019591:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_90195A1:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90195B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90195B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x4u)), &f);
    if (!f.zf) goto L_9019841;
    goto L_90195C4;
L_90195C4:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)((uint32_t)0x20u);
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9019612;
    goto L_90195E8;
L_90195E8:
    edx = (uint32_t)(TL32((uint32_t)(edx)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    eax = (uint32_t)(logic32((uint32_t)(eax & edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    goto L_901961A;
L_9019612:
    eax = (uint32_t)(logic32((uint32_t)(eax & edi), &f));
    ecx = (uint32_t)(ebx);
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, ebx, &f));
L_901961A:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9019825;
    goto L_9019622;
L_9019622:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x2Cu)), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9019828;
    goto L_901962E;
L_901962E:
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    TS32((uint32_t)(ecx), (uint32_t)(ebx));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(add32(ebx, eax, &f));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x180u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9019671;
    goto L_901965A;
L_901965A:
    edi = (uint32_t)(TL32((uint32_t)(edx)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9019676;
L_9019671:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9019676:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9019689;
    goto L_901967B;
L_901967B:
    ecx = (uint32_t)((uint32_t)0xFFFFFFECu);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(ecx);
    goto L_9019689;
L_9019686:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_9019689:
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + ebx*4 + 0x100u)));
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_90196D1;
    goto L_901969B;
L_901969B:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(eax + ebx*4 + 0x140u)));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + edx)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_9019735;
L_90196D1:
    (void)sub32(edx, M32((uint32_t)(ebp + 0x14u)), &f);
    if (!f.cf) goto L_9019825;
    goto L_90196DA;
L_90196DA:
    edx = (uint32_t)(TL32((uint32_t)(edx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ecx + ebx*4 + 0x140u)));
    eax = (uint32_t)(TL8((uint32_t)(eax + edx)));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x4u, &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + edx)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(eax);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_9019721;
    goto L_901971B;
L_901971B:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_9019735;
L_9019721:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x4u, &f));
L_9019735:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    (void)sub32(esi, edx, &f);
    if (f.cf) goto L_9019767;
    goto L_901973C;
L_901973C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(edx + eax)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(TL8((uint32_t)(edx + eax + 0x10u)));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_90197BA;
L_9019767:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & eax), &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(TL8((uint32_t)(edx + eax)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(TL8((uint32_t)(ecx + edx + 0x10u)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(eax);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_90197A6;
    goto L_90197A0;
L_90197A0:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_90197BA;
L_90197A6:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x4u, &f));
L_90197BA:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    (void)logic8((uint8_t)(((uint8_t)ecx) & ((uint8_t)ecx)), &f);
    if (!f.sf) goto L_90197D3;
    goto L_90197C9;
L_90197C9:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x7Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(neg8(((uint8_t)ecx), &f));
    ecx = (uint32_t)(((uint8_t)ecx));
    goto L_90197D6;
L_90197D3:
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7Fu), &f));
L_90197D6:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), (uint8_t)0x80u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9019686;
    goto L_90197EA;
L_90197EA:
    (void)sub32(eax, (uint32_t)0xFFFFFFEAu, &f);
    if ((f.sf == f.of)) goto L_9019807;
    goto L_90197EF;
L_90197EF:
    edx = (uint32_t)((uint32_t)0xFFFFFFEBu);
    edx = (uint32_t)(sub32(edx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9019804u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9019807:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(eax + 0x180u), (uint32_t)(ebx));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9019825:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_9019828:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(eax));
    ebx = (uint32_t)((uint32_t)(eax + 0x4u));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ecx), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9019841:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9019850(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019850:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x24u, &f));
    (void)sub32(ecx, TL32((uint32_t)(eax + 0x4u)), &f);
    if (!f.zf) goto L_9019AEA;
    goto L_9019864;
L_9019864:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x28u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    (void)sub32(esi, edx, &f);
    if (!f.cf) goto L_90198B8;
    goto L_9019883;
L_9019883:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & eax), &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x28u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    goto L_90198C6;
L_90198B8:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x28u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, ecx, &f));
L_90198C6:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9019AD1;
    goto L_90198CE;
L_90198CE:
    (void)sub32(edx, TL32((uint32_t)(eax + 0x2Cu)), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9019AD1;
    goto L_90198D7;
L_90198D7:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x30u)));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x20u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x180u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901991A;
    goto L_9019903;
L_9019903:
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFECu)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_901991F;
L_901991A:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_901991F:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9019930;
    goto L_9019924;
L_9019924:
    ecx = (uint32_t)((uint32_t)0xFFFFFFECu);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(ecx));
L_9019930:
    edx = (uint32_t)(dec32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + eax*4 + 0x100u)));
    (void)sub32(esi, edx, &f);
    if (f.cf) goto L_901997D;
    goto L_9019942;
L_9019942:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + eax*4 + 0x140u)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0x10u)), &f));
    edx = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_90199E6;
L_901997D:
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x14u)), &f);
    if (!f.cf) goto L_9019ACE;
    goto L_9019986;
L_9019986:
    ebx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ebx), &f));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + eax*4 + 0x140u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ebx)));
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + ebx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    ecx = (uint32_t)(edx);
    (void)sub32(esi, edx, &f);
    if (f.cf) goto L_90199D0;
    goto L_90199CA;
L_90199CA:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, edx, &f));
    goto L_90199E6;
L_90199D0:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
L_90199E6:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x20u);
    (void)sub32(esi, edx, &f);
    if (f.cf) goto L_9019A22;
    goto L_90199F5;
L_90199F5:
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + edx + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_9019A75;
L_9019A22:
    ebx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ebx), &f));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(edx);
    (void)sub32(esi, edx, &f);
    if (f.cf) goto L_9019A5F;
    goto L_9019A59;
L_9019A59:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, edx, &f));
    goto L_9019A75;
L_9019A5F:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
L_9019A75:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), (uint8_t)0x4u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) | M8((uint32_t)(ebp + 0xFFFFFFECu))), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS8((uint32_t)(ecx + 0xFFFFFFFFu), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9019930;
    goto L_9019A93;
L_9019A93:
    (void)sub32(edx, (uint32_t)0xFFFFFFEAu, &f);
    if ((f.sf == f.of)) goto L_9019AB0;
    goto L_9019A98;
L_9019A98:
    eax = (uint32_t)((uint32_t)0xFFFFFFEBu);
    eax = (uint32_t)(sub32(eax, edx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9019AADu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_9019AB0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(eax + 0x180u), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9019ACE:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_9019AD1:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x30u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(ecx + 0x4u));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9019AEA:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9019AF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019AF0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x4u)), &f);
    if (!f.zf) goto L_9019D00;
    goto L_9019B04;
L_9019B04:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    (void)sub32(esi, edx, &f);
    if (!f.cf) goto L_9019B58;
    goto L_9019B1F;
L_9019B1F:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    goto L_9019B69;
L_9019B58:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & edi), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, edx, &f));
L_9019B69:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9019CE7;
    goto L_9019B74;
L_9019B74:
    (void)sub32(eax, TL32((uint32_t)(edx + 0x2Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_9019CE7;
    goto L_9019B7D;
L_9019B7D:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9019BA5;
    goto L_9019B8E;
L_9019B8E:
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF0u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9019BAA;
L_9019BA5:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9019BAA:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9019C77;
    goto L_9019BB3;
L_9019BB3:
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
L_9019BC5:
    eax = (uint32_t)(dec32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_9019C00;
    goto L_9019BD0;
L_9019BD0:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(logic32((uint32_t)(eax & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + edx + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_9019C64;
L_9019C00:
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (!f.cf) goto L_9019CE7;
    goto L_9019C09;
L_9019C09:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & ebx), &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_9019C4F;
    goto L_9019C49;
L_9019C49:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_9019C64;
L_9019C4F:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(add32(esi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
L_9019C64:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9019CF2;
    goto L_9019C6F;
L_9019C6F:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    goto L_9019BC5;
L_9019C77:
    (void)sub32(esi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_9019CBC;
    goto L_9019C7C;
L_9019C7C:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)((uint32_t)0x4u);
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Cu, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esp -= 4; M32(esp) = 0x9019CA7u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9019CBC:
    edx = (uint32_t)(edi);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x4u, &f));
    esp -= 4; M32(esp) = 0x9019CD2u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9019CE7:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x30u)));
    ecx = (uint32_t)((uint32_t)(eax + 0x4u));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(eax));
L_9019CF2:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_9019D00:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9019D10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019D10:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x4u)), &f);
    if (!f.zf) goto L_9019EF2;
    goto L_9019D25;
L_9019D25:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ecx);
    (void)sub32(eax, edx, &f);
    if (!f.cf) goto L_9019D78;
    goto L_9019D3F;
L_9019D3F:
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | esi), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x4u, &f));
    goto L_9019D89;
L_9019D78:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    edi = (uint32_t)(logic32((uint32_t)(edi & esi), &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
L_9019D89:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9019ED7;
    goto L_9019D91;
L_9019D91:
    (void)sub32(edi, TL32((uint32_t)(ebx + 0x2Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_9019ED7;
    goto L_9019D9A;
L_9019D9A:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x30u)));
    edx = (uint32_t)((uint32_t)(ecx + edi));
    TS32((uint32_t)(ebx), (uint32_t)(ecx));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
L_9019DB4:
    edi = (uint32_t)(dec32(edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_9019DEB;
    goto L_9019DBC;
L_9019DBC:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & esi), &f));
    edi = (uint32_t)(TL8((uint32_t)(ecx + edi)));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(edi);
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    goto L_9019E47;
L_9019DEB:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (!f.cf) goto L_9019ED7;
    goto L_9019DF7;
L_9019DF7:
    edi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edi = (uint32_t)(logic32((uint32_t)(edi | esi), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & edx), &f));
    edi = (uint32_t)(TL8((uint32_t)(edi + ecx)));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(edi);
    (void)sub32(eax, edi, &f);
    if (f.cf) goto L_9019E33;
    goto L_9019E2D;
L_9019E2D:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    goto L_9019E47;
L_9019E33:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x4u, &f));
L_9019E47:
    (void)sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFE8u)), &f);
    if (f.cf) goto L_9019E6A;
    goto L_9019E4C;
L_9019E4C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)(logic32((uint32_t)(edx & esi), &f));
    edi = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    edx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(TL8((uint32_t)(edx + ebx + 0x10u)));
    ecx = (uint32_t)(edi);
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    goto L_9019EB6;
L_9019E6A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    edi = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | esi), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + edx)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(edx);
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_9019E9F;
    goto L_9019E99;
L_9019E99:
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
    goto L_9019EB3;
L_9019E9F:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x4u, &f));
L_9019EB3:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF4u)));
L_9019EB6:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), (uint8_t)0x4u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)edx) | M8((uint32_t)(ebp + 0xFFFFFFF0u))), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x0u, &f);
    TS8((uint32_t)(ecx + 0xFFFFFFFFu), (uint8_t)(((uint8_t)edx)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    if (f.zf) goto L_9019EE2;
    goto L_9019ECC;
L_9019ECC:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    goto L_9019DB4;
L_9019ED7:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x30u)));
    edx = (uint32_t)((uint32_t)(ecx + 0x4u));
    TS32((uint32_t)(ebx), (uint32_t)(edx));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(ecx));
L_9019EE2:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(ecx), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_9019EF2:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9019F00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9019F00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x18u, &f));
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x4u)), &f);
    if (!f.zf) goto L_901A158;
    goto L_9019F14;
L_9019F14:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    (void)sub32(esi, eax, &f);
    if (!f.cf) goto L_9019F6A;
    goto L_9019F2F;
L_9019F2F:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    goto L_9019F7B;
L_9019F6A:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
L_9019F7B:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_901A13F;
    goto L_9019F86;
L_9019F86:
    (void)sub32(edx, TL32((uint32_t)(eax + 0x2Cu)), &f);
    if ((!f.cf && !f.zf)) goto L_901A13F;
    goto L_9019F8F;
L_9019F8F:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9019FB7;
    goto L_9019FA0;
L_9019FA0:
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF4u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9019FBC;
L_9019FB7:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9019FBC:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_901A0C2;
    goto L_9019FC5;
L_9019FC5:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ebx = (uint32_t)((uint32_t)(ebx));
L_9019FE0:
    edx = (uint32_t)(dec32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_901A016;
    goto L_9019FE8;
L_9019FE8:
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    ecx = (uint32_t)(TL8((uint32_t)(edx + eax)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(TL8((uint32_t)(edx + eax + 0x10u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    esi = (uint32_t)(sub32(esi, ecx, &f));
    goto L_901A075;
L_901A016:
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (!f.cf) goto L_901A13C;
    goto L_901A01F;
L_901A01F:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & ebx), &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + ecx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + ebx + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_901A060;
    goto L_901A05A;
L_901A05A:
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    goto L_901A075;
L_901A060:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0x20u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    esi = (uint32_t)(add32(esi, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
L_901A075:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x0u, &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    if (f.zf) goto L_901A0A6;
    goto L_901A07E;
L_901A07E:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901A095;
    goto L_901A082;
L_901A082:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    edi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_901A09A;
L_901A095:
    eax = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_901A09A:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901A0A6;
    goto L_901A09E;
L_901A09E:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(neg32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
L_901A0A6:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)ecx)));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_901A14A;
    goto L_901A0BA;
L_901A0BA:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    goto L_9019FE0;
L_901A0C2:
    (void)sub32(esi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901A0E9;
    goto L_901A0C7;
L_901A0C7:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Cu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edi), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    goto L_901A0F4;
L_901A0E9:
    eax = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x4u, &f));
L_901A0F4:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901A11C;
    goto L_901A0F8;
L_901A0F8:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901A110;
    goto L_901A0FC;
L_901A0FC:
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFF4u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_901A115;
L_901A110:
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_901A115:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901A11C;
    goto L_901A11A;
L_901A11A:
    eax = (uint32_t)(neg32(eax, &f));
L_901A11C:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901A127u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901A13C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_901A13F:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x30u)));
    edx = (uint32_t)((uint32_t)(ecx + 0x4u));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
L_901A14A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_901A158:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901A160(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901A160:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    (void)sub32(eax, TL32((uint32_t)(ecx + 0x4u)), &f);
    if (!f.zf) goto L_901A48A;
    goto L_901A174;
L_901A174:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    (void)sub32(edx, edi, &f);
    if (!f.cf) goto L_901A1CA;
    goto L_901A18F;
L_901A18F:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & ecx), &f));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    goto L_901A1DB;
L_901A1CA:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(sub32(edx, edi, &f));
L_901A1DB:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901A471;
    goto L_901A1E9;
L_901A1E9:
    edi = (uint32_t)(TL32((uint32_t)(ecx + 0x2Cu)));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    (void)sub32(eax, edi, &f);
    if ((!f.cf && !f.zf)) goto L_901A471;
    goto L_901A1F6;
L_901A1F6:
    (void)sub32(TL32((uint32_t)(ecx + 0xCu)), (uint32_t)0x0u, &f);
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    if (f.zf) goto L_901A2A3;
    goto L_901A206;
L_901A206:
    edi = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    eax = (uint32_t)((uint32_t)(edi + 0xFFFFFFFFu));
    (void)sub32(edx, eax, &f);
    if (!f.cf) goto L_901A250;
    goto L_901A210;
L_901A210:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x21u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & eax), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    eax = (uint32_t)((uint32_t)0x21u);
    ecx = (uint32_t)(dec32(ecx, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    goto L_901A26F;
L_901A250:
    ecx = (uint32_t)((uint32_t)0x21u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)(edi + 0xFFFFFFFFu));
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    edx = (uint32_t)(add32(edx, ecx, &f));
L_901A26F:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901A2FD;
    goto L_901A279;
L_901A279:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_901A290;
    goto L_901A27D;
L_901A27D:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edx = (uint32_t)((uint32_t)0x1Fu);
    goto L_901A295;
L_901A290:
    eax = (uint32_t)(esi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edx = (uint32_t)(dec32(edx, &f));
L_901A295:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901A2FD;
    goto L_901A299;
L_901A299:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(neg32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    goto L_901A2FD;
L_901A2A3:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0xFFFFFFFFu), &f));
    (void)sub32(edx, eax, &f);
    if (!f.cf) goto L_901A2E9;
    goto L_901A2AD;
L_901A2AD:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | esi), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    goto L_901A2FD;
L_901A2E9:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(logic32((uint32_t)(edi & esi), &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, eax, &f));
L_901A2FD:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(M16((uint32_t)(ebp + 0xFFFFFFFCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    TS16((uint32_t)(eax), (uint16_t)(((uint16_t)ecx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(eax + edi*2));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(eax));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    if (f.zf) goto L_901A47C;
    goto L_901A32A;
L_901A32A:
    goto L_901A333;
L_901A330:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
L_901A333:
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)((uint32_t)0x8u);
    (void)sub32(edi, (uint32_t)0x8u, &f);
    if ((!f.cf && !f.zf)) goto L_901A342;
    goto L_901A33F;
L_901A33F:
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
L_901A342:
    (void)sub32(edx, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901A373;
    goto L_901A347;
L_901A347:
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x10u)), &f);
    if (!f.cf) goto L_901A46E;
    goto L_901A350;
L_901A350:
    eax = (uint32_t)(TL32((uint32_t)(ebx)));
    ecx = (uint32_t)(edx);
    edi = (uint32_t)(eax);
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | esi), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1Cu, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    goto L_901A37E;
L_901A373:
    edi = (uint32_t)(esi);
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFu), &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x4u, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x4u, &f));
L_901A37E:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901A421;
    goto L_901A386;
L_901A386:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901A450;
    goto L_901A394;
L_901A394:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_901A3A8;
L_901A3A5:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
L_901A3A8:
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), &f));
    (void)sub32(edx, edi, &f);
    if (!f.cf) goto L_901A3D6;
    goto L_901A3AF;
L_901A3AF:
    ebx = (uint32_t)(TL32((uint32_t)(ebx)));
    eax = (uint32_t)(ebx);
    ecx = (uint32_t)(edx);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & M32((uint32_t)(ebp + 0xFFFFFFE4u))), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x4u, &f));
    esi = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    goto L_901A3DE;
L_901A3D6:
    eax = (uint32_t)(logic32((uint32_t)(eax & esi), &f));
    ecx = (uint32_t)(edi);
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(sub32(edx, edi, &f));
L_901A3DE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901A405;
    goto L_901A3E2;
L_901A3E2:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_901A3F9;
    goto L_901A3E6;
L_901A3E6:
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    esi = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edx = (uint32_t)((uint32_t)0x1Fu);
    goto L_901A3FE;
L_901A3F9:
    ecx = (uint32_t)(esi);
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    edx = (uint32_t)(dec32(edx, &f));
L_901A3FE:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901A405;
    goto L_901A403;
L_901A403:
    eax = (uint32_t)(neg32(eax, &f));
L_901A405:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    TS16((uint32_t)(eax), (uint16_t)(((uint16_t)ecx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    if (!f.zf) goto L_901A3A5;
    goto L_901A41F;
L_901A41F:
    goto L_901A450;
L_901A421:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(M16((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    c->df = 0;
    eax = (eax & 0xFFFF0000u) | (uint16_t)(M16((uint32_t)(ebp + 0xFFFFFFFCu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f));
    while (ecx) { M16(edi) = (uint16_t)eax; edi += (c->df ? -2 : 2); ecx--; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)((uint32_t)(eax + ecx*2));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
L_901A450:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), ecx, &f));
    if (!f.zf) goto L_901A330;
    goto L_901A45C;
L_901A45C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901A46E:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_901A471:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x30u)));
    edi = (uint32_t)((uint32_t)(eax + 0x4u));
    TS32((uint32_t)(ecx), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(eax));
L_901A47C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_901A48A:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901A490(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901A490:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ecx);
    edx = (uint32_t)(edi);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20Fu, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    esi = (uint32_t)((uint32_t)(edx*8));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20Fu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    edi = (uint32_t)(esi);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x6u, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20Fu, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x40Fu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi*8));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20Fu, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20Fu, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(edi));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x40u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901A530(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901A530:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF0u), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x4A4u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(eax));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDCCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x1Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFDECu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFFFFFF8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDD4u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x18u)));
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x14u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)esi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDD4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDDCu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x30u)));
    TS32((uint32_t)(ebp + 0xFFFFFDC0u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(esi*8));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFDD4u)), &f));
    ecx = (uint32_t)((uint32_t)(ecx + edx + 0xFFFFFFF8u));
    edi = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    TS32((uint32_t)(ebp + 0xFFFFFDBCu), (uint32_t)(eax));
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x2Cu)) & (uint32_t)0x8000u), &f);
    TS32((uint32_t)(ebp + 0xFFFFFDC4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDCCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDC8u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDE0u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE08u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDD0u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDCCu), (uint32_t)((uint32_t)0x90195B0u));
    if (!f.zf) goto L_901A615;
    goto L_901A60B;
L_901A60B:
    TS32((uint32_t)(ebp + 0xFFFFFDCCu), (uint32_t)((uint32_t)0x9019850u));
L_901A615:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    edx = (uint32_t)((uint32_t)(ecx + 0x1FFu));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A64E;
    goto L_901A63C;
L_901A63C:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A650;
L_901A64E:
    edx = (uint32_t)(logic32(0, &f));
L_901A650:
    TS32((uint32_t)(ebp + 0xFFFFFEB8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC0u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20Fu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE90u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE94u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE98u), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(ebp + 0xFFFFFE9Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFEBCu), (uint32_t)(ecx));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A6C9;
    goto L_901A6B7;
L_901A6B7:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A6CB;
L_901A6C9:
    edx = (uint32_t)(logic32(0, &f));
L_901A6CB:
    TS32((uint32_t)(ebp + 0xFFFFFE84u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x20Fu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE88u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE8Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE5Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE60u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE64u), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(ebp + 0xFFFFFE68u), (uint32_t)(eax));
    if (f.zf) goto L_901A73D;
    goto L_901A72B;
L_901A72B:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A73F;
L_901A73D:
    edx = (uint32_t)(logic32(0, &f));
L_901A73F:
    TS32((uint32_t)(ebp + 0xFFFFFFF0u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE8u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x20Fu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(ebp + 0xFFFFFFF4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    TS32((uint32_t)(ebp + 0xFFFFFFF8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFFCCu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFFD0u), (uint32_t)((uint32_t)0x8u));
    TS32((uint32_t)(ebp + 0xFFFFFFD4u), (uint32_t)(eax));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A798;
    goto L_901A786;
L_901A786:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A79A;
L_901A798:
    edx = (uint32_t)(logic32(0, &f));
L_901A79A:
    TS32((uint32_t)(ebp + 0xFFFFFFBCu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE8u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x20Fu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFF0u), &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC0u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0xCu)));
    TS32((uint32_t)(ebp + 0xFFFFFFC4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF98u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF9Cu), (uint32_t)((uint32_t)0x8u));
    TS32((uint32_t)(ebp + 0xFFFFFFA0u), (uint32_t)(eax));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A7F6;
    goto L_901A7E4;
L_901A7E4:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A7F8;
L_901A7F6:
    edx = (uint32_t)(logic32(0, &f));
L_901A7F8:
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF34u), (uint32_t)((uint32_t)0x5u));
    TS32((uint32_t)(ebp + 0xFFFFFF38u), (uint32_t)((uint32_t)0x10u));
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ecx));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A855;
    goto L_901A843;
L_901A843:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A857;
L_901A855:
    edx = (uint32_t)(logic32(0, &f));
L_901A857:
    TS32((uint32_t)(ebp + 0xFFFFFF88u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    TS32((uint32_t)(ebp + 0xFFFFFF8Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x14u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x18u)));
    TS32((uint32_t)(ebp + 0xFFFFFF90u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)((uint32_t)0x5u));
    TS32((uint32_t)(ebp + 0xFFFFFF6Cu), (uint32_t)((uint32_t)0x10u));
    (void)sub32(ecx, eax, &f);
    if (f.zf) goto L_901A8AE;
    goto L_901A89C;
L_901A89C:
    { uint32_t v_ = ecx; f.zf = v_ == 0; if (v_) { ecx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(inc32(ecx, &f));
    goto L_901A8B0;
L_901A8AE:
    ecx = (uint32_t)(logic32(0, &f));
L_901A8B0:
    TS32((uint32_t)(ebp + 0xFFFFFEECu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEF4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x40Fu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFEC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFECCu), (uint32_t)((uint32_t)0xBu));
    TS32((uint32_t)(ebp + 0xFFFFFED0u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFEF0u), (uint32_t)(ecx));
    (void)sub32(edx, eax, &f);
    if (f.zf) goto L_901A915;
    goto L_901A903;
L_901A903:
    { uint32_t v_ = edx; f.zf = v_ == 0; if (v_) { edx = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(inc32(edx, &f));
    goto L_901A917;
L_901A915:
    edx = (uint32_t)(logic32(0, &f));
L_901A917:
    TS32((uint32_t)(ebp + 0xFFFFFE54u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x1Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x20u)));
    TS32((uint32_t)(ebp + 0xFFFFFE58u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    ecx = (uint32_t)((uint32_t)(ecx + ecx*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1FFu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE28u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE30u), (uint32_t)((uint32_t)0xBu));
    TS32((uint32_t)(ebp + 0xFFFFFE34u), (uint32_t)((uint32_t)0x400u));
    if (f.zf) goto L_901A979;
    goto L_901A969;
L_901A969:
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    { uint32_t v_ = ecx; f.zf = v_ == 0; if (v_) { eax = (uint32_t)(31 - __builtin_clz(v_)); } }
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    eax = (uint32_t)(inc32(eax, &f));
L_901A979:
    TS32((uint32_t)(ebp + 0xFFFFFF20u), (uint32_t)(eax));
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFEFCu), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFF04u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE8u)));
    ecx = (uint32_t)((uint32_t)(eax + eax*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20Fu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEA0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEB0u));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEB4u));
    TS32((uint32_t)(ebp + 0xFFFFFF00u), (uint32_t)((uint32_t)0x4u));
    esp -= 4; M32(esp) = 0x901A9E0u; SPILL(); f_9018CA0(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE6Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE7Cu));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE80u));
    esp -= 4; M32(esp) = 0x901A9FFu; SPILL(); f_9018CA0(c); RELOAD();
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFB68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AA16u; SPILL(); f_9019300(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFA4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB4u));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB8u));
    esp -= 4; M32(esp) = 0x901AA2Fu; SPILL(); f_9018CA0(c); RELOAD();
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF3Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF4Cu));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF50u));
    esp -= 4; M32(esp) = 0x901AA4Eu; SPILL(); f_9018CA0(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF70u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF80u));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF84u));
    esp -= 4; M32(esp) = 0x901AA67u; SPILL(); f_9018CA0(c); RELOAD();
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFF08u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF18u));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF1Cu));
    esp -= 4; M32(esp) = 0x901AA86u; SPILL(); f_9018CA0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
    (void)sub32(TL32((uint32_t)(ebx + 0x10u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)((uint32_t)0x0u));
    if ((f.cf || f.zf)) goto L_901CA90;
    goto L_901AA9D;
L_901AA9D:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE90u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAB7u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAD4u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFB68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(ebp + 0xFFFFFDCCu)); esp -= 4; M32(esp) = 0x901AAF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB0Du; SPILL(); f_9019D10(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF2Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB2Au; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB47u; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFF90u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB79u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB96u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901ABB3u; SPILL(); f_9019AF0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901ABC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDDCu)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABD7;
L_901ABD7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE90u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE94u)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABE9;
L_901ABE9:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE90u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFE90u)), &f)));
    (void)sub32(edx, (uint32_t)0x9u, &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901ABFB;
L_901ABFB:
    { jt_ = TL32((uint32_t)(edx*4 + 0x901CAB8u)); goto L_dispatch; }
L_901AC02:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(TL32((uint32_t)(ebx + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901ACB4;
    goto L_901ACA0;
L_901ACA0:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    (void)sub8(TL8((uint32_t)(ecx + edx)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901ACBA;
    goto L_901ACB4;
L_901ACB4:
    TS32((uint32_t)(ebp + 0xFFFFFDD0u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFDD0u)), &f)));
L_901ACBA:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901ACC6:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
L_901ACC9:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    ecx = (uint32_t)((uint32_t)0x8u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
L_901ACE5:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    if (!f.zf) goto L_901ABC5;
    goto L_901ACF8;
L_901ACF8:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDBCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), eax, &f)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD13;
L_901AD13:
    (void)sub32(TL32((uint32_t)(ebx + 0x24u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901AD22;
    goto L_901AD19;
L_901AD19:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD22;
L_901AD22:
    TS32((uint32_t)(ebp + 0xFFFFFDECu), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDECu)), eax, &f)));
L_901AD28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)(eax));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x10u)), &f);
    if (f.cf) goto L_901AA9D;
    goto L_901AD4A;
L_901AD4A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDC0u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    goto L_901CA9E;
L_901AD5D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901AD6A;
L_901AD6A:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (!f.zf) goto L_901BE76;
    goto L_901AD77;
L_901AD77:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE5Cu)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE60u)), &f);
    if (!f.cf) goto L_901BE76;
    goto L_901AD89;
L_901AD89:
    ecx = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE5Cu), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_901BE76;
    goto L_901AD9F;
L_901AD9F:
    { jt_ = TL32((uint32_t)(ecx*4 + 0x901CAE0u)); goto L_dispatch; }
L_901ADA6:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901ADB8;
L_901ADB8:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901AE19;
    goto L_901ADCF;
L_901ADCF:
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Cu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    goto L_901AE36;
L_901AE19:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
L_901AE36:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901AE53;
    goto L_901AE4A;
L_901AE4A:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AE53:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901AE6A;
    goto L_901AE61;
L_901AE61:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
L_901AE6A:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)((uint32_t)0x40u));
    goto L_901AE86;
L_901AE80:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901AE86:
    edi = (uint32_t)(TL8((uint32_t)(ecx)));
    edi = (uint32_t)(inc32(edi, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(edi, TL32((uint32_t)(ebp + 0xFFFFFDF8u)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(ecx));
    if ((!f.zf && f.sf == f.of)) goto L_901AF6B;
    goto L_901AE9D;
L_901AE9D:
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), edi, &f)));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901AED5;
    goto L_901AEAC;
L_901AEAC:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE10u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901AEED;
L_901AED5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(shr32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
L_901AEED:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFE1Cu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901AF31;
    goto L_901AEF6;
L_901AEF6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + 0xFFFFFDDBu), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF06;
L_901AF06:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDDBu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF06;
    goto L_901AF2F;
L_901AF2F:
    goto L_901AF5E;
L_901AF31:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF35;
L_901AF35:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF35;
    goto L_901AF5E;
L_901AF5E:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901AE80;
    goto L_901AF6B;
L_901AF6B:
    (void)sub32(edx, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901AF87;
    goto L_901AF70;
L_901AF70:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AF87:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFD74u));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901AFAB:
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFCu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x2u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x6u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x8u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xAu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xCu)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x10u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x12u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x14u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x16u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x18u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x1Au)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901AFAB;
    goto L_901B2D6;
L_901B2D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(ecx));
    goto L_901BE70;
L_901B2FF:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B311;
L_901B311:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901B328;
    goto L_901B31F;
L_901B31F:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901B328:
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)ecx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    esp -= 4; M32(esp) = 0x901B34Du; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901B398;
    goto L_901B358;
L_901B358:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901B3B5;
L_901B398:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901B3B5:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901B3CDu; SPILL(); f_90247D0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901BE76;
L_901B3D8:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B3EA;
L_901B3EA:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B3F8;
    goto L_901B3EF;
L_901B3EF:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B3F8:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    goto L_901BE70;
L_901B51B:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B52D;
L_901B52D:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B53B;
    goto L_901B532;
L_901B532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B53B:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901B579;
    goto L_901B573;
L_901B573:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901B579:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
    goto L_901B5A3;
L_901B5A0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
L_901B5A3:
    edi = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    if (!f.zf) goto L_901B5A0;
    goto L_901BA3B;
L_901BA3B:
    goto L_901BE70;
L_901BA40:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BA52;
L_901BA52:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    edx = (uint32_t)((uint32_t)(esi + ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901BA6F;
    goto L_901BA66;
L_901BA66:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901BA6F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f);
    if (f.zf) goto L_901BB72;
    goto L_901BA77;
L_901BA77:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x8u));
    esp = (uint32_t)((uint32_t)(esp));
L_901BA90:
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x3u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x5u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x7u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    if (!f.zf) goto L_901BA90;
    goto L_901BB6D;
L_901BB6D:
    goto L_901BE70;
L_901BB72:
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901BB7C:
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901BB7C;
    goto L_901BE70;
L_901BE70:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901BE76:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebx + 0x24u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    goto L_901ACE5;
L_901BEBE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901BEF9;
    goto L_901BEDE;
L_901BEDE:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901BEF9:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BF2E;
L_901BF2E:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901BF3A;
L_901BF3A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    goto L_901ACBA;
L_901BFCB:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C010;
    goto L_901BFDC;
L_901BFDC:
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    edx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    goto L_901C027;
L_901C010:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
L_901C027:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C04A;
    goto L_901C041;
L_901C041:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C04A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901C061;
    goto L_901C058;
L_901C058:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901C061:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(logic32(0, &f));
    TS8((uint32_t)(ecx + esi), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)((uint32_t)(edi + 0x40u));
    goto L_901C086;
L_901C080:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901C086:
    esi = (uint32_t)(TL8((uint32_t)(edx)));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(esi, ecx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(edx));
    if ((!f.zf && f.sf == f.of)) goto L_901C139;
    goto L_901C099;
L_901C099:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    if (!f.zf) goto L_901C0CB;
    goto L_901C0AA;
L_901C0AA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901C0DB;
L_901C0CB:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), &f)));
L_901C0DB:
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901C109;
    goto L_901C0E6;
L_901C0E6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C0F0;
L_901C0F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + edx)));
    esi = (uint32_t)(dec32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C0F0;
    goto L_901C107;
L_901C107:
    goto L_901C12A;
L_901C109:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C10D;
L_901C10D:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C10D;
    goto L_901C12A;
L_901C12A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901C080;
    goto L_901C139;
L_901C139:
    (void)sub32(edi, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901C155;
    goto L_901C13E;
L_901C13E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C155:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD70u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD74u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD78u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD7Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD80u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD84u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD88u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD8Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD90u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD94u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD98u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD9Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA0u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA8u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDACu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(edx));
    goto L_901ACBA;
L_901C229:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C264;
    goto L_901C249;
L_901C249:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C264:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C299;
L_901C299:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C2A5;
L_901C2A5:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(edx, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_901C2F0;
    goto L_901C2B0;
L_901C2B0:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x19u, &f)));
    ecx = (uint32_t)(edx);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x7u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    goto L_901C305;
L_901C2F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x7u, &f)));
L_901C305:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x901C31Cu; SPILL(); f_9025E00(c); RELOAD();
    goto L_901ACBA;
L_901C321:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901C34A;
    goto L_901C341;
L_901C341:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C34A:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C36Fu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C3BA;
    goto L_901C37A;
L_901C37A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901C3D7;
L_901C3BA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901C3D7:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C3EDu; SPILL(); f_90244C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901ACC6;
L_901C3F5:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C403;
    goto L_901C3FA;
L_901C3FA:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C403:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    eax = (uint32_t)(inc32(eax, &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    goto L_901ACC9;
L_901C4B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C4F1;
    goto L_901C4D6;
L_901C4D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C4F1:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C526;
L_901C526:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C532;
L_901C532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE28u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFE2Cu)), &f);
    if (f.cf) goto L_901C549;
    goto L_901C540;
L_901C540:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE58u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C549:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE28u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C56Eu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C5D1;
    goto L_901C579;
L_901C579:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C5CCu; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C5D1:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(ecx);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x901C603u; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C608:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C616;
    goto L_901C60D;
L_901C60D:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C616:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + edi), (uint8_t)((uint8_t)0x1u));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901C675;
    goto L_901C66C;
L_901C66C:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
L_901C675:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi), (uint32_t)(edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x3u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x5u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x7u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(esi + edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFF94u)), (uint32_t)0x8u, &f)));
    TS32((uint32_t)(esi + ecx + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    goto L_901ACC9;
L_901C9CE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C9F4;
    goto L_901C9EB;
L_901C9EB:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(edx));
L_901C9F4:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x40u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    goto L_901ACC9;
L_901CA90:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD0u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDC0u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
L_901CA9E:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901CAB0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x901A530u: goto L_901A530; case 0x901A60Bu: goto L_901A60B; case 0x901A615u: goto L_901A615; case 0x901A63Cu: goto L_901A63C; case 0x901A64Eu: goto L_901A64E; case 0x901A650u: goto L_901A650; case 0x901A6B7u: goto L_901A6B7; case 0x901A6C9u: goto L_901A6C9; case 0x901A6CBu: goto L_901A6CB; case 0x901A72Bu: goto L_901A72B; case 0x901A73Du: goto L_901A73D; case 0x901A73Fu: goto L_901A73F; case 0x901A786u: goto L_901A786; case 0x901A798u: goto L_901A798; case 0x901A79Au: goto L_901A79A; case 0x901A7E4u: goto L_901A7E4; case 0x901A7F6u: goto L_901A7F6; case 0x901A7F8u: goto L_901A7F8; case 0x901A843u: goto L_901A843; case 0x901A855u: goto L_901A855; case 0x901A857u: goto L_901A857; case 0x901A89Cu: goto L_901A89C; case 0x901A8AEu: goto L_901A8AE; case 0x901A8B0u: goto L_901A8B0; case 0x901A903u: goto L_901A903; case 0x901A915u: goto L_901A915; case 0x901A917u: goto L_901A917; case 0x901A969u: goto L_901A969; case 0x901A979u: goto L_901A979; case 0x901AA9Du: goto L_901AA9D; case 0x901ABC5u: goto L_901ABC5; case 0x901ABD7u: goto L_901ABD7; case 0x901ABE9u: goto L_901ABE9; case 0x901ABFBu: goto L_901ABFB; case 0x901AC02u: goto L_901AC02; case 0x901ACA0u: goto L_901ACA0; case 0x901ACB4u: goto L_901ACB4; case 0x901ACBAu: goto L_901ACBA; case 0x901ACC6u: goto L_901ACC6; case 0x901ACC9u: goto L_901ACC9; case 0x901ACE5u: goto L_901ACE5; case 0x901ACF8u: goto L_901ACF8; case 0x901AD13u: goto L_901AD13; case 0x901AD19u: goto L_901AD19; case 0x901AD22u: goto L_901AD22; case 0x901AD28u: goto L_901AD28; case 0x901AD4Au: goto L_901AD4A; case 0x901AD5Du: goto L_901AD5D; case 0x901AD6Au: goto L_901AD6A; case 0x901AD77u: goto L_901AD77; case 0x901AD89u: goto L_901AD89; case 0x901AD9Fu: goto L_901AD9F; case 0x901ADA6u: goto L_901ADA6; case 0x901ADB8u: goto L_901ADB8; case 0x901ADCFu: goto L_901ADCF; case 0x901AE19u: goto L_901AE19; case 0x901AE36u: goto L_901AE36; case 0x901AE4Au: goto L_901AE4A; case 0x901AE53u: goto L_901AE53; case 0x901AE61u: goto L_901AE61; case 0x901AE6Au: goto L_901AE6A; case 0x901AE80u: goto L_901AE80; case 0x901AE86u: goto L_901AE86; case 0x901AE9Du: goto L_901AE9D; case 0x901AEACu: goto L_901AEAC; case 0x901AED5u: goto L_901AED5; case 0x901AEEDu: goto L_901AEED; case 0x901AEF6u: goto L_901AEF6; case 0x901AF06u: goto L_901AF06; case 0x901AF2Fu: goto L_901AF2F; case 0x901AF31u: goto L_901AF31; case 0x901AF35u: goto L_901AF35; case 0x901AF5Eu: goto L_901AF5E; case 0x901AF6Bu: goto L_901AF6B; case 0x901AF70u: goto L_901AF70; case 0x901AF87u: goto L_901AF87; case 0x901AFABu: goto L_901AFAB; case 0x901B2D6u: goto L_901B2D6; case 0x901B2FFu: goto L_901B2FF; case 0x901B311u: goto L_901B311; case 0x901B31Fu: goto L_901B31F; case 0x901B328u: goto L_901B328; case 0x901B358u: goto L_901B358; case 0x901B398u: goto L_901B398; case 0x901B3B5u: goto L_901B3B5; case 0x901B3D8u: goto L_901B3D8; case 0x901B3EAu: goto L_901B3EA; case 0x901B3EFu: goto L_901B3EF; case 0x901B3F8u: goto L_901B3F8; case 0x901B51Bu: goto L_901B51B; case 0x901B52Du: goto L_901B52D; case 0x901B532u: goto L_901B532; case 0x901B53Bu: goto L_901B53B; case 0x901B573u: goto L_901B573; case 0x901B579u: goto L_901B579; case 0x901B5A0u: goto L_901B5A0; case 0x901B5A3u: goto L_901B5A3; case 0x901BA3Bu: goto L_901BA3B; case 0x901BA40u: goto L_901BA40; case 0x901BA52u: goto L_901BA52; case 0x901BA66u: goto L_901BA66; case 0x901BA6Fu: goto L_901BA6F; case 0x901BA77u: goto L_901BA77; case 0x901BA90u: goto L_901BA90; case 0x901BB6Du: goto L_901BB6D; case 0x901BB72u: goto L_901BB72; case 0x901BB7Cu: goto L_901BB7C; case 0x901BE70u: goto L_901BE70; case 0x901BE76u: goto L_901BE76; case 0x901BEBEu: goto L_901BEBE; case 0x901BEDEu: goto L_901BEDE; case 0x901BEF9u: goto L_901BEF9; case 0x901BF2Eu: goto L_901BF2E; case 0x901BF3Au: goto L_901BF3A; case 0x901BFCBu: goto L_901BFCB; case 0x901BFDCu: goto L_901BFDC; case 0x901C010u: goto L_901C010; case 0x901C027u: goto L_901C027; case 0x901C041u: goto L_901C041; case 0x901C04Au: goto L_901C04A; case 0x901C058u: goto L_901C058; case 0x901C061u: goto L_901C061; case 0x901C080u: goto L_901C080; case 0x901C086u: goto L_901C086; case 0x901C099u: goto L_901C099; case 0x901C0AAu: goto L_901C0AA; case 0x901C0CBu: goto L_901C0CB; case 0x901C0DBu: goto L_901C0DB; case 0x901C0E6u: goto L_901C0E6; case 0x901C0F0u: goto L_901C0F0; case 0x901C107u: goto L_901C107; case 0x901C109u: goto L_901C109; case 0x901C10Du: goto L_901C10D; case 0x901C12Au: goto L_901C12A; case 0x901C139u: goto L_901C139; case 0x901C13Eu: goto L_901C13E; case 0x901C155u: goto L_901C155; case 0x901C229u: goto L_901C229; case 0x901C249u: goto L_901C249; case 0x901C264u: goto L_901C264; case 0x901C299u: goto L_901C299; case 0x901C2A5u: goto L_901C2A5; case 0x901C2B0u: goto L_901C2B0; case 0x901C2F0u: goto L_901C2F0; case 0x901C305u: goto L_901C305; case 0x901C321u: goto L_901C321; case 0x901C341u: goto L_901C341; case 0x901C34Au: goto L_901C34A; case 0x901C37Au: goto L_901C37A; case 0x901C3BAu: goto L_901C3BA; case 0x901C3D7u: goto L_901C3D7; case 0x901C3F5u: goto L_901C3F5; case 0x901C3FAu: goto L_901C3FA; case 0x901C403u: goto L_901C403; case 0x901C4B6u: goto L_901C4B6; case 0x901C4D6u: goto L_901C4D6; case 0x901C4F1u: goto L_901C4F1; case 0x901C526u: goto L_901C526; case 0x901C532u: goto L_901C532; case 0x901C540u: goto L_901C540; case 0x901C549u: goto L_901C549; case 0x901C579u: goto L_901C579; case 0x901C5D1u: goto L_901C5D1; case 0x901C608u: goto L_901C608; case 0x901C60Du: goto L_901C60D; case 0x901C616u: goto L_901C616; case 0x901C66Cu: goto L_901C66C; case 0x901C675u: goto L_901C675; case 0x901C9CEu: goto L_901C9CE; case 0x901C9EBu: goto L_901C9EB; case 0x901C9F4u: goto L_901C9F4; case 0x901CA90u: goto L_901CA90; case 0x901CA9Eu: goto L_901CA9E; default: SPILL(); rt_call(c, jt_); return; }
}

