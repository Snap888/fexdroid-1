#include "funcs_bink.h"
#include "lift_prelude.h"

void f_901E170(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E170:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(TL32((uint32_t)(0x9036AF8u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_901E195;
    goto L_901E181;
L_901E181:
    esp -= 4; M32(esp) = 0x901E186u; SPILL(); f_9001550(c); RELOAD();
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x80000000u), &f));
    TS32((uint32_t)(0x9036AF8u), (uint32_t)(eax));
    TS32((uint32_t)(0x9036AFCu), (uint32_t)(eax));
L_901E195:
    esi = (uint32_t)((uint32_t)0x903FA40u);
    ebx = (uint32_t)((uint32_t)(ebx));
L_901E1A0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901E1B1;
    goto L_901E1A6;
L_901E1A6:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901E1AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901E1C6;
    goto L_901E1B1;
L_901E1B1:
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(esi, (uint32_t)0x903FA78u, &f);
    if ((f.sf != f.of)) goto L_901E1A0;
    goto L_901E1BC;
L_901E1BC:
    TS32((uint32_t)(0x9030A98u), (uint32_t)((uint32_t)0x0u));
L_901E1C6:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_901E1D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E1D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(logic32(0, &f));
    goto L_901E1E0;
L_901E1E0:
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7u), &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0xFFu; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x92492493u);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x3u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7u), &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0xFFu; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(sar32(edx, (uint8_t)0x2u, &f));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)0x92492493u);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x2u, &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1Fu, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x6u, &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0xFFu; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x55555556u);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Fu, &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
    esi = (uint32_t)(inc32(esi, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    (void)sub32(esi, (uint32_t)0x100u, &f);
    if ((f.sf != f.of)) goto L_901E1E0;
    goto L_901E252;
L_901E252:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_901E260(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E260:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)sub32(TL32((uint32_t)(eax + 0x18u)), esi, &f);
    if (!f.zf) goto L_901E26F;
    goto L_901E26E;
L_901E26E:
    SPILL(); rt_int3(c, 0x901E26Eu);
L_901E26F:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x10u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Fu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFE0u), &f));
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x5u, &f));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x5u, &f));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x1Fu), &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x5u, &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    TS32((uint32_t)(edx + esi*4), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x14u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(edx + ecx*4), (uint32_t)(esi));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(inc32(TL32((uint32_t)(eax + 0x14u)), &f)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_901E2B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E2B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901E2CE;
    goto L_901E2BB;
L_901E2BB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    esp -= 4; M32(esp) = 0x901E2C9u; SPILL(); f_9001070(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901E2CE:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Fu, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFE0u), &f));
    eax = (uint32_t)(add32(eax, edi, &f));
    esp -= 4; M32(esp) = 0x901E2E2u; SPILL(); f_9001070(c); RELOAD();
    TS32((uint32_t)(esi + 0x10u), (uint32_t)((uint32_t)0x0u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901E30B;
    goto L_901E2ED;
L_901E2ED:
    ecx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)((uint32_t)(eax + edi));
    (void)sub32(TL32((uint32_t)(esi + 0x14u)), ecx, &f);
    if ((f.cf || f.zf)) goto L_901E30B;
    goto L_901E2F7;
L_901E2F7:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + ecx*4)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(edi + ecx*4)), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(ecx, TL32((uint32_t)(esi + 0x14u)), &f);
    if (f.cf) goto L_901E2F7;
    goto L_901E30B;
L_901E30B:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x14u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_901E320(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E320:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x2u, &f));
    ecx = (uint32_t)((uint32_t)(ecx + ebx*4));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x901E342u; SPILL(); f_9024240(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E368;
    goto L_901E34A;
L_901E34A:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E355u; SPILL(); f_901E5D0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E363u; SPILL(); f_9024060(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    goto L_901E379;
L_901E368:
    if (!f.zf) goto L_901E379;
    goto L_901E36A;
L_901E36A:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E376u; SPILL(); f_901E5D0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901E379:
    c->xmm[1].u[0] = M32((uint32_t)(esi)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2] = c->xmm[1];
    eax = (uint32_t)((uint32_t)0x2u);
    (void)sub32(edi, eax, &f);
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(esi)) = c->xmm[0].u[0];
    if ((f.zf || f.sf != f.of)) goto L_901E3C8;
    goto L_901E39A;
L_901E39A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_901E3A0:
    c->xmm[1].u[0] = M32((uint32_t)(esi + eax*4)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(esi + eax*4 + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3] = c->xmm[1];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(esi + eax*4 + 0xFFFFFFFCu)) = c->xmm[3].u[0];
    M32((uint32_t)(esi + eax*4)) = c->xmm[0].u[0];
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    (void)sub32(eax, edi, &f);
    if ((f.sf != f.of)) goto L_901E3A0;
    goto L_901E3C8;
L_901E3C8:
    M32((uint32_t)(esi + edi*4 + 0xFFFFFFFCu)) = c->xmm[2].u[0];
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_901E3E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E3E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    (void)sub32(esi, (uint32_t)0x2u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E544;
    goto L_901E3F3;
L_901E3F3:
    c->xmm[1].u[0] = M32((uint32_t)(0x9031318u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    esi = (uint32_t)(sar32(esi, (uint8_t)0x1u, &f));
    (void)sub32(esi, (uint32_t)0x4u, &f);
    c->xmm[0].f[0] = (float)(int32_t)esi;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[5].u[0] = M32((uint32_t)(0x903BD5Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ST(1) = ST(1) * ST(0);
    M32((uint32_t)(edi)) = c->xmm[5].u[0];
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0xFFFFFFF4u)) = (float)ST(0);
    MF32((uint32_t)(edi + 0x4u)) = (float)ST(0); fpop(c);
    if ((f.sf != f.of)) goto L_901E458;
    goto L_901E432;
L_901E432:
    { double v_ = ST(0); fpush(c, v_); }
    ST(0) = ST(0) + ST(1);
    ST(0) = cos(ST(0)); c->c2 = 0;
    fpush(c, (double)MF32((uint32_t)(0x903C214u)));
    { double v_ = ST(0); fpush(c, v_); }
    ST(2) = ST(0) / ST(2); fpop(c);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    MF32((uint32_t)(edi + 0x8u)) = (float)ST(0); fpop(c);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = ST(0) * (double)MF32((uint32_t)(0x9031320u));
    ST(0) = cos(ST(0)); c->c2 = 0;
    ST(1) = ST(1) / ST(0); fpop(c);
    MF32((uint32_t)(edi + 0xCu)) = (float)ST(0); fpop(c);
    goto L_901E45A;
L_901E458:
    ST(0) = ST(0); fpop(c);
L_901E45A:
    ecx = (uint32_t)((uint32_t)0x4u);
    (void)sub32(esi, ecx, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E4AE;
    goto L_901E463;
L_901E463:
    c->xmm[2].u[0] = M32((uint32_t)(0x903131Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    eax = (uint32_t)((uint32_t)(edi + 0x18u));
    edi = (uint32_t)(edi);
L_901E470:
    c->xmm[0].f[0] = (float)(int32_t)ecx;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
    { double v_ = ST(0); fpush(c, v_); }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    ST(0) = cos(ST(0)); c->c2 = 0;
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    (void)sub32(ecx, esi, &f);
    MF32((uint32_t)(eax + 0xFFFFFFE8u)) = (float)ST(0); fpop(c);
    ST(0) = sin(ST(0)); c->c2 = 0;
    MF32((uint32_t)(eax + 0xFFFFFFECu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { double v_ = ST(0); fpush(c, v_); }
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(eax + 0xFFFFFFF0u)) = (float)ST(0); fpop(c);
    ST(0) = sin(ST(0)); c->c2 = 0;
    MF32((uint32_t)(eax + 0xFFFFFFF4u)) = (float)ST(0); fpop(c);
    if ((f.sf != f.of)) goto L_901E470;
    goto L_901E4AE;
L_901E4AE:
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(esi, (uint32_t)0x2u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E544;
    goto L_901E4B9;
L_901E4B9:
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(0x903C214u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_901E4C6:
    ebx = (uint32_t)((uint32_t)(ecx + esi));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x1u, &f));
    (void)sub32(esi, (uint32_t)0x4u, &f);
    M32((uint32_t)(edi + ebx*4)) = c->xmm[5].u[0];
    M32((uint32_t)(edi + ebx*4 + 0x4u)) = c->xmm[4].u[0];
    if ((f.sf != f.of)) goto L_901E53D;
    goto L_901E4DB;
L_901E4DB:
    c->xmm[0].u[0] = M32((uint32_t)(edi + ecx*4 + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] / MF32((uint32_t)(edi + ecx*4 + 0x10u));
    M32((uint32_t)(edi + ebx*4 + 0x8u)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[0].f[0];
    M32((uint32_t)(edi + ebx*4 + 0xCu)) = c->xmm[1].u[0];
    if ((f.zf || f.sf != f.of)) goto L_901E53D;
    goto L_901E4FF;
L_901E4FF:
    edx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFBu));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    eax = (uint32_t)((uint32_t)(edi + ebx*4 + 0x10u));
    ecx = (uint32_t)((uint32_t)(edi + ecx*4 + 0x28u));
    edx = (uint32_t)(inc32(edx, &f));
    edi = (uint32_t)(edi);
L_901E510:
    fpush(c, (double)MF32((uint32_t)(ecx + 0xFFFFFFF8u)));
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0xFFFFFFFCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    MF32((uint32_t)(eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(eax + 0x4u)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + 0x8u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0xCu)) = c->xmm[2].u[0];
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_901E510;
    goto L_901E53D;
L_901E53D:
    (void)sub32(esi, (uint32_t)0x2u, &f);
    ecx = (uint32_t)(ebx);
    if ((!f.zf && f.sf == f.of)) goto L_901E4C6;
    goto L_901E544;
L_901E544:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901E550(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E550:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)sub32(edx, (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E5CB;
    goto L_901E55B;
L_901E55B:
    c->xmm[1].u[0] = M32((uint32_t)(0x9031318u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    c->xmm[0].f[0] = (float)(int32_t)eax;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFFCu)));
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x1u);
    (void)sub32(eax, ecx, &f);
    ST(1) = ST(1) * ST(0);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(esi)) = (float)ST(0);
    ST(0) = ST(0) * (double)MF32((uint32_t)(0x903C214u));
    MF32((uint32_t)(esi + eax*4)) = (float)ST(0); fpop(c);
    if ((f.zf || f.sf != f.of)) goto L_901E5C9;
    goto L_901E59C;
L_901E59C:
    fpush(c, MF64((uint32_t)(0x9031310u)));
    edx = (uint32_t)((uint32_t)(esi + edx*4 + 0xFFFFFFFCu));
L_901E5A6:
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x4u, &f));
    (void)sub32(ecx, eax, &f);
    ST(0) = ST(0) * ST(2);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    { double v_ = ST(0); fpush(c, v_); }
    ST(0) = cos(ST(0)); c->c2 = 0;
    ST(0) = ST(0) * ST(2);
    MF32((uint32_t)(esi + ecx*4 + 0xFFFFFFFCu)) = (float)ST(0); fpop(c);
    ST(0) = sin(ST(0)); c->c2 = 0;
    ST(0) = ST(0) * ST(1);
    MF32((uint32_t)(edx + 0x4u)) = (float)ST(0); fpop(c);
    if ((f.sf != f.of)) goto L_901E5A6;
    goto L_901E5C7;
L_901E5C7:
    ST(0) = ST(0); fpop(c);
L_901E5C9:
    ST(0) = ST(0); fpop(c);
L_901E5CB:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901E5D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E5D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(ebx, (uint32_t)0x20u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E69E;
    goto L_901E5E0;
L_901E5E0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ebx);
    edi = (uint32_t)(sar32(edi, (uint8_t)0x2u, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    edx = (uint32_t)((uint32_t)(ecx + eax*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x901E5FBu; SPILL(); f_901F870(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E65D;
    goto L_901E606;
L_901E606:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E615u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + edi*4));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E627u; SPILL(); f_90212B0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + edi*8));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E639u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(edi + edi*2));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + ecx*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E64Eu; SPILL(); f_9021200(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x40u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EA20;
L_901E65D:
    (void)sub32(edi, (uint32_t)0x20u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E680;
    goto L_901E662;
L_901E662:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E671u; SPILL(); f_9021350(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EA20;
L_901E680:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E68Fu; SPILL(); f_9022810(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EA20;
L_901E69E:
    (void)sub32(ebx, (uint32_t)0x8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E70D;
    goto L_901E6A3;
L_901E6A3:
    (void)sub32(ebx, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_901E6C0;
    goto L_901E6A8;
L_901E6A8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(eax + ecx*4 + 0xFFFFFFE0u));
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E6B9u; SPILL(); f_9022890(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901F590;
L_901E6C0:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E6CAu; SPILL(); f_9023A80(c); RELOAD();
    fpush(c, (double)MF32((uint32_t)(esi + 0x20u)));
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(esi + 0x8u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(esi + 0x24u)));
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    MF32((uint32_t)(esi + 0xCu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(esi + 0x30u)));
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    MF32((uint32_t)(esi + 0x18u)) = (float)ST(0); fpop(c);
    M32((uint32_t)(esi + 0x20u)) = c->xmm[0].u[0];
    fpush(c, (double)MF32((uint32_t)(esi + 0x34u)));
    M32((uint32_t)(esi + 0x24u)) = c->xmm[1].u[0];
    MF32((uint32_t)(esi + 0x1Cu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(esi + 0x30u)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0x34u)) = c->xmm[3].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901E70D:
    if (!f.zf) goto L_901E7C8;
    goto L_901E713;
L_901E713:
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(esi)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(esi + 0x14u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[0] = c->xmm[2];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[5] = c->xmm[2];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[2].f[0];
    c->xmm[2] = c->xmm[5];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(esi)) = c->xmm[2].u[0];
    c->xmm[2] = c->xmm[7];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[1].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[7].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(esi + 0x14u)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x10u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(esi + 0x8u)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[3].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0xCu)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x18u)) = c->xmm[6].u[0];
    M32((uint32_t)(esi + 0x1Cu)) = c->xmm[3].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901E7C8:
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if (!f.zf) goto L_901E809;
    goto L_901E7CD;
L_901E7CD:
    c->xmm[0].u[0] = M32((uint32_t)(esi)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[2] = c->xmm[0];
    c->xmm[3] = c->xmm[1];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[4].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(esi)) = c->xmm[0].u[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x8u)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0xCu)) = c->xmm[3].u[0];
L_901E809:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901EA20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x12Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ecx);
    (void)sub32(edi, (uint32_t)0x8u, &f);
    ecx = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFED4u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    if ((f.zf || f.sf != f.of)) goto L_901EA77;
    goto L_901EA45;
L_901EA45:
    edi = (uint32_t)(sar32(edi, (uint8_t)0x1u, &f));
    edx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_901EA67;
    goto L_901EA4D;
L_901EA4D:
    esi = (uint32_t)((uint32_t)(ebp + ecx*4 + 0xFFFFFED4u));
L_901EA54:
    ebx = (uint32_t)(M32((uint32_t)(ebp + edx*4 + 0xFFFFFED4u)));
    ebx = (uint32_t)(add32(ebx, edi, &f));
    TS32((uint32_t)(esi), (uint32_t)(ebx));
    edx = (uint32_t)(inc32(edx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    (void)sub32(edx, ecx, &f);
    if ((f.sf != f.of)) goto L_901EA54;
    goto L_901EA67;
L_901EA67:
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)((uint32_t)(ecx*8));
    (void)sub32(edx, edi, &f);
    if ((f.sf != f.of)) goto L_901EA45;
    goto L_901EA74;
L_901EA74:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
L_901EA77:
    edx = (uint32_t)((uint32_t)(ecx*8));
    ebx = (uint32_t)((uint32_t)(ecx + ecx));
    (void)sub32(edx, edi, &f);
    if (!f.zf) goto L_901EC36;
    goto L_901EA89;
L_901EA89:
    edx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.zf || f.sf != f.of)) goto L_901EF6B;
    goto L_901EA96;
L_901EA96:
    goto L_901EAA0;
L_901EAA0:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.zf || f.sf != f.of)) goto L_901EBD0;
    goto L_901EAAF;
L_901EAAF:
    ecx = (uint32_t)(M32((uint32_t)(ebp + edx*4 + 0xFFFFFED4u)));
    esi = (uint32_t)((uint32_t)(ecx + ebx));
    edi = (uint32_t)((uint32_t)(ebx*4));
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
    esi = (uint32_t)((uint32_t)(ecx*4));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    goto L_901EAE3;
L_901EAE0:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
L_901EAE3:
    c->xmm[0].u[0] = M32((uint32_t)(esi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(esi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + ecx*4 + 0xFFFFFED4u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    MF32((uint32_t)(esi + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(esi + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)((uint32_t)(edi + esi));
    c->xmm[0].u[0] = M32((uint32_t)(edx + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    edx = (uint32_t)(add32(edx, edi, &f));
    c->xmm[0].u[0] = M32((uint32_t)(edx + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    edx = (uint32_t)(add32(edx, edi, &f));
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(edx + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edx + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ebx);
    edx = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    M32((uint32_t)(edx)) = c->xmm[2].u[0];
    edx = (uint32_t)((uint32_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    (void)sub32(ecx, edx, &f);
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_901EAE0;
    goto L_901EBCD;
L_901EBCD:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
L_901EBD0:
    esi = (uint32_t)(M32((uint32_t)(ebp + edx*4 + 0xFFFFFED4u)));
    esi = (uint32_t)((uint32_t)(esi + edx*2));
    ebx = (uint32_t)((uint32_t)(ecx + ecx));
    esi = (uint32_t)(add32(esi, ebx, &f));
    c->xmm[1].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(eax + esi*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    edi = (uint32_t)((uint32_t)(esi + ebx));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + esi*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edi*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    edi = (uint32_t)((uint32_t)(eax + edi*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    fpush(c, (double)MF32((uint32_t)(eax + edi*4)));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, ecx, &f);
    MF32((uint32_t)(eax + esi*4)) = (float)ST(0); fpop(c);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    M32((uint32_t)(esi)) = c->xmm[2].u[0];
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    M32((uint32_t)(eax + edi*4)) = c->xmm[0].u[0];
    M32((uint32_t)(esi)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    if ((f.sf != f.of)) goto L_901EAA0;
    goto L_901EC2F;
L_901EC2F:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901EC36:
    ebx = (uint32_t)((uint32_t)0x1u);
    (void)sub32(ecx, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    if ((f.zf || f.sf != f.of)) goto L_901EF6B;
    goto L_901EC46;
L_901EC46:
    edi = (uint32_t)((uint32_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    edi = (uint32_t)(edi);
L_901EC50:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if ((f.sf != f.of)) goto L_901EEA0;
    goto L_901EC5B;
L_901EC5B:
    ebx = (uint32_t)(M32((uint32_t)(ebp + ebx*4 + 0xFFFFFED4u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)((uint32_t)(ecx*4));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ebx + 0x2u));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0xFFFFFFF4u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0xFFFFFFFCu);
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(ebx + ecx + 0x4u));
    edx = (uint32_t)((uint32_t)0x4u);
    edi = (uint32_t)((uint32_t)(ebx*4));
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    ecx = (uint32_t)((uint32_t)(eax + ebx*4 + 0x14u));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edx);
    goto L_901ECB0;
L_901ECB0:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0xFFFFFFECu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF0u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED4u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(ecx + 0xFFFFFFECu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ecx + 0xFFFFFFF0u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    edi = (uint32_t)(add32(edi, ebx, &f));
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(edi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED8u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(ecx + 0xFFFFFFF4u)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ecx + 0xFFFFFFF8u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(edi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0xFFFFFFFCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFEDCu)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(ecx + 0xFFFFFFFCu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(edi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFEE0u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    MF32((uint32_t)(ecx + 0x4u)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ecx + 0x8u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(edi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    M32((uint32_t)(eax + edx*4)) = c->xmm[0].u[0];
    edx = (uint32_t)((uint32_t)0x8u);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), edx, &f));
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    edx = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFDu));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    (void)sub32(esi, edx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    if ((f.sf != f.of)) goto L_901ECB0;
    goto L_901EE98;
L_901EE98:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)0x2u);
L_901EEA0:
    (void)sub32(esi, ebx, &f);
    if ((f.sf == f.of)) goto L_901EF5C;
    goto L_901EEA8;
L_901EEA8:
    edx = (uint32_t)(M32((uint32_t)(ebp + ebx*4 + 0xFFFFFED4u)));
    edx = (uint32_t)((uint32_t)(edx + esi*2));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    edx = (uint32_t)(add32(edx, edx, &f));
L_901EEC0:
    c->xmm[0].u[0] = M32((uint32_t)(edx + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED4u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    edi = (uint32_t)((uint32_t)(edx + edi*4));
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    edi = (uint32_t)(add32(edi, edi, &f));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    c->xmm[0].u[0] = M32((uint32_t)(edi + eax)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    edi = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    edi = (uint32_t)((uint32_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), edi, &f));
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    (void)sub32(esi, ebx, &f);
    M32((uint32_t)(ecx)) = c->xmm[1].u[0];
    if ((f.sf != f.of)) goto L_901EEC0;
    goto L_901EF59;
L_901EF59:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
L_901EF5C:
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), edi, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, ecx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    if ((f.sf != f.of)) goto L_901EC50;
    goto L_901EF6B;
L_901EF6B:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901F590:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + 0x40u)));
    c->xmm[1].u[0] = M32((uint32_t)(eax + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    MF32((uint32_t)(eax + 0x8u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x44u)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x14u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    MF32((uint32_t)(eax + 0xCu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x20u)));
    c->xmm[4].u[0] = M32((uint32_t)(eax + 0x18u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x1Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    MF32((uint32_t)(eax + 0x10u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x24u)));
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x28u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x2Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x14u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x60u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x38u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x18u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x64u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x3Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x1Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x50u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x58u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x28u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x54u)));
    M32((uint32_t)(eax + 0x40u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(eax + 0x2Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x70u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x5Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x38u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x74u)));
    M32((uint32_t)(eax + 0x54u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(eax + 0x3Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x68u)));
    M32((uint32_t)(eax + 0x68u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(eax + 0x58u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x6Cu)));
    M32((uint32_t)(eax + 0x70u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(eax + 0x5Cu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(eax + 0x20u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + 0x24u)) = c->xmm[3].u[0];
    M32((uint32_t)(eax + 0x44u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0x50u)) = c->xmm[6].u[0];
    M32((uint32_t)(eax + 0x60u)) = c->xmm[4].u[0];
    M32((uint32_t)(eax + 0x64u)) = c->xmm[5].u[0];
    M32((uint32_t)(eax + 0x6Cu)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + 0x74u)) = c->xmm[0].u[0];
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901E810(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901E810:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(ebx, (uint32_t)0x20u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E8DE;
    goto L_901E820;
L_901E820:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ebx);
    edi = (uint32_t)(sar32(edi, (uint8_t)0x2u, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    edx = (uint32_t)((uint32_t)(ecx + eax*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x901E83Bu; SPILL(); f_9020500(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E89D;
    goto L_901E846;
L_901E846:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E855u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + edi*4));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E867u; SPILL(); f_90212B0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + edi*8));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E879u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(edi + edi*2));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + ecx*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E88Eu; SPILL(); f_9021200(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x40u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EF80;
L_901E89D:
    (void)sub32(edi, (uint32_t)0x20u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E8C0;
    goto L_901E8A2;
L_901E8A2:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901E8B1u; SPILL(); f_9021350(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EF80;
L_901E8C0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E8CFu; SPILL(); f_9022810(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901EF80;
L_901E8DE:
    (void)sub32(ebx, (uint32_t)0x8u, &f);
    if ((f.zf || f.sf != f.of)) goto L_901E911;
    goto L_901E8E3;
L_901E8E3:
    (void)sub32(ebx, (uint32_t)0x20u, &f);
    if (!f.zf) goto L_901E900;
    goto L_901E8E8;
L_901E8E8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(eax + ecx*4 + 0xFFFFFFE0u));
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E8F9u; SPILL(); f_9022890(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901F690;
L_901E900:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901E90Au; SPILL(); f_9023A80(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_901F800;
L_901E911:
    if (!f.zf) goto L_901E9D4;
    goto L_901E917;
L_901E917:
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x10u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(esi)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(esi + 0x14u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[1] = c->xmm[3];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    c->xmm[0] = c->xmm[2];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[4].f[0];
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5] = c->xmm[4];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[3].f[0];
    c->xmm[3] = c->xmm[6];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7] = c->xmm[5];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(esi + 0x10u)) = c->xmm[0].u[0];
    M32((uint32_t)(esi)) = c->xmm[7].u[0];
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[3].f[0];
    c->xmm[0] = c->xmm[6];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[2].f[0];
    M32((uint32_t)(esi + 0x14u)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x8u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[4].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[6].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[7].u[0];
    M32((uint32_t)(esi + 0xCu)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x18u)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0x1Cu)) = c->xmm[4].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901E9D4:
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if (!f.zf) goto L_901EA15;
    goto L_901E9D9;
L_901E9D9:
    c->xmm[4].u[0] = M32((uint32_t)(esi)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2] = c->xmm[4];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[3] = c->xmm[5];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[1].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(esi)) = c->xmm[0].u[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[1].u[0];
    M32((uint32_t)(esi + 0x8u)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0xCu)) = c->xmm[3].u[0];
L_901EA15:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901EF80:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x12Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    (void)sub32(esi, (uint32_t)0x8u, &f);
    edi = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFED4u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    if ((f.zf || f.sf != f.of)) goto L_901EFD7;
    goto L_901EFA5;
L_901EFA5:
    esi = (uint32_t)(sar32(esi, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.zf || f.sf != f.of)) goto L_901EFC7;
    goto L_901EFAD;
L_901EFAD:
    edx = (uint32_t)((uint32_t)(ebp + edi*4 + 0xFFFFFED4u));
L_901EFB4:
    ebx = (uint32_t)(M32((uint32_t)(ebp + ecx*4 + 0xFFFFFED4u)));
    ebx = (uint32_t)(add32(ebx, esi, &f));
    TS32((uint32_t)(edx), (uint32_t)(ebx));
    ecx = (uint32_t)(inc32(ecx, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    (void)sub32(ecx, edi, &f);
    if ((f.sf != f.of)) goto L_901EFB4;
    goto L_901EFC7;
L_901EFC7:
    edi = (uint32_t)(add32(edi, edi, &f));
    ecx = (uint32_t)((uint32_t)(edi*8));
    (void)sub32(ecx, esi, &f);
    if ((f.sf != f.of)) goto L_901EFA5;
    goto L_901EFD4;
L_901EFD4:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
L_901EFD7:
    edx = (uint32_t)((uint32_t)(edi*8));
    ecx = (uint32_t)((uint32_t)(edi + edi));
    (void)sub32(edx, esi, &f);
    if (!f.zf) goto L_901F1CF;
    goto L_901EFE9;
L_901EFE9:
    edx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(edi & edi), &f);
    if ((f.zf || f.sf != f.of)) goto L_901F584;
    goto L_901EFF6;
L_901EFF6:
    c->xmm[0].u[0] = M32((uint32_t)(0x9031300u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    edi = (uint32_t)(edi);
L_901F000:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x0u);
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.zf || f.sf != f.of)) goto L_901F14D;
    goto L_901F00F;
L_901F00F:
    edi = (uint32_t)(M32((uint32_t)(ebp + edx*4 + 0xFFFFFED4u)));
    esi = (uint32_t)((uint32_t)(edi + ecx));
    ebx = (uint32_t)((uint32_t)(ecx*4));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    esi = (uint32_t)((uint32_t)(edi*4));
    goto L_901F040;
L_901F040:
    c->xmm[3].u[0] = M32((uint32_t)(esi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(esi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + ecx*4 + 0xFFFFFED4u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)(add32(edx, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    MF32((uint32_t)(esi + eax)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(add32(edi, edi, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(esi + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    edi = (uint32_t)(add32(edi, edi, &f));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    edx = (uint32_t)((uint32_t)(ebx + esi));
    c->xmm[3].u[0] = M32((uint32_t)(edx + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)(add32(edx, ebx, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(edx + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edi = (uint32_t)(add32(edi, edi, &f));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)(add32(edx, ebx, &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(edx + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ecx = (uint32_t)(add32(ecx, edi, &f));
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    edi = (uint32_t)((uint32_t)(edx + eax + 0x4u));
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
    edx = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edx)) = c->xmm[2].u[0];
    edx = (uint32_t)((uint32_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    (void)sub32(ecx, edx, &f);
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_901F040;
    goto L_901F14A;
L_901F14A:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_901F14D:
    ecx = (uint32_t)(M32((uint32_t)(ebp + edx*4 + 0xFFFFFED4u)));
    esi = (uint32_t)((uint32_t)(ecx + edx*2));
    c->xmm[1].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + esi*4 + 0x4u)) = c->xmm[1].u[0];
    ecx = (uint32_t)((uint32_t)(edi + edi));
    ebx = (uint32_t)((uint32_t)(esi + ecx));
    c->xmm[3].u[0] = M32((uint32_t)(eax + ebx*4)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(eax + ebx*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    esi = (uint32_t)((uint32_t)(ebx + ecx));
    c->xmm[2].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + esi*4)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + ebx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    MF32((uint32_t)(eax + ebx*4)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebx)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + esi*4 + 0x4u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + esi*4)) = c->xmm[3].u[0];
    esi = (uint32_t)(add32(esi, ecx, &f));
    c->xmm[1].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, edi, &f);
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + esi*4 + 0x4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    if ((f.sf != f.of)) goto L_901F000;
    goto L_901F1C8;
L_901F1C8:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901F1CF:
    c->xmm[0].u[0] = M32((uint32_t)(0x9031300u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    edx = (uint32_t)((uint32_t)(ecx*4));
    M32((uint32_t)(eax + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edx + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ebx = (uint32_t)((uint32_t)0x1u);
    (void)sub32(edi, ebx, &f);
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    M32((uint32_t)(edx + eax + 0x4u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    if ((f.zf || f.sf != f.of)) goto L_901F584;
    goto L_901F20D;
L_901F20D:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x2u);
L_901F214:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(ebx, (uint32_t)0x4u, &f);
    if ((f.sf != f.of)) goto L_901F477;
    goto L_901F21F;
L_901F21F:
    ebx = (uint32_t)(M32((uint32_t)(ebp + ebx*4 + 0xFFFFFED4u)));
    edx = (uint32_t)((uint32_t)(ebx + 0x2u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ebx*4));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0xFFFFFFF4u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)0xFFFFFFFCu);
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(ebx + ecx + 0x4u));
    edx = (uint32_t)((uint32_t)0x4u);
    edx = (uint32_t)(sub32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(eax + ebx*4 + 0x14u));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edx);
L_901F260:
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xFFFFFFECu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF0u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED4u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    MF32((uint32_t)(ecx + 0xFFFFFFECu)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx + 0xFFFFFFF0u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(edi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED8u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    MF32((uint32_t)(ecx + 0xFFFFFFF4u)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx + 0xFFFFFFF8u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(edi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFEDCu)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[1].u[0] = M32((uint32_t)(ecx)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    MF32((uint32_t)(ecx + 0xFFFFFFFCu)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(edi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    edi = (uint32_t)((uint32_t)(edx + ecx));
    edx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFEE0u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), (uint32_t)0x20u, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    MF32((uint32_t)(ecx + 0x4u)) = (float)ST(0); fpop(c);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx + 0x8u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(edi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    edx = (uint32_t)(add32(edx, ebx, &f));
    fpush(c, (double)MF32((uint32_t)(eax + edx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    ebx = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    edi = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[3].u[0];
    edx = (uint32_t)((uint32_t)0x8u);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), edx, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebx)) = c->xmm[1].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    edx = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFDu));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    (void)sub32(esi, edx, &f);
    if ((f.sf != f.of)) goto L_901F260;
    goto L_901F474;
L_901F474:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_901F477:
    (void)sub32(esi, ebx, &f);
    if ((f.sf == f.of)) goto L_901F541;
    goto L_901F47F;
L_901F47F:
    ecx = (uint32_t)(M32((uint32_t)(ebp + ebx*4 + 0xFFFFFED4u)));
    ecx = (uint32_t)((uint32_t)(ecx + esi*2));
    edx = (uint32_t)((uint32_t)(edi + edi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    edx = (uint32_t)((uint32_t)(ecx*4));
    goto L_901F4A0;
L_901F4A0:
    c->xmm[3].u[0] = M32((uint32_t)(edx + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(eax + edx + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + esi*4 + 0xFFFFFED4u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    MF32((uint32_t)(edx + eax)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(add32(edi, edi, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx + 0x4u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + ecx*4 + 0x4u)) = c->xmm[1].u[0];
    ecx = (uint32_t)(add32(ecx, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    fpush(c, (double)MF32((uint32_t)(eax + ecx*4)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    edi = (uint32_t)(add32(edi, edx, &f));
    c->xmm[3].u[0] = M32((uint32_t)(edi + eax)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(edi + eax + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edi = (uint32_t)((uint32_t)(edi + eax + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)(add32(edi, edx, &f));
    MF32((uint32_t)(edi + eax)) = (float)ST(0); fpop(c);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    { Xmm s_ = c->xmm[0]; c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edi)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[3].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ecx)) = c->xmm[1].u[0];
    ecx = (uint32_t)((uint32_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), ecx, &f));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    (void)sub32(esi, ebx, &f);
    if ((f.sf != f.of)) goto L_901F4A0;
    goto L_901F53E;
L_901F53E:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_901F541:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + ebx*4 + 0xFFFFFED4u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    c->xmm[1].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[1].u[0];
    ecx = (uint32_t)((uint32_t)(edi + edi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    c->xmm[1].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    edx = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    ebx = (uint32_t)(inc32(ebx, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    (void)sub32(ebx, edi, &f);
    { Xmm s_ = c->xmm[0]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(edx)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    if ((f.sf != f.of)) goto L_901F214;
    goto L_901F584;
L_901F584:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901F690:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x28u, &f));
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + 0x78u)));
    c->xmm[1].u[0] = M32((uint32_t)(eax + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    MF32((uint32_t)(eax + 0x8u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x7Cu)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x24u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0xCu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x38u)));
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x14u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(eax + 0x18u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    MF32((uint32_t)(eax + 0x10u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x3Cu)));
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x1Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    MF32((uint32_t)(eax + 0x14u)) = (float)ST(0); fpop(c);
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x20u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    fpush(c, (double)MF32((uint32_t)(eax + 0x58u)));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x28u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x18u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x5Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x2Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x1Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x68u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x30u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x28u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x6Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x34u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x2Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x48u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x40u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x38u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x4Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x44u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x3Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x70u)));
    M32((uint32_t)(eax + 0x40u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    MF32((uint32_t)(eax + 0x48u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x74u)));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x50u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    MF32((uint32_t)(eax + 0x4Cu)) = (float)ST(0); fpop(c);
    M32((uint32_t)(eax + 0x50u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x54u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(eax + 0x54u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x58u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x60u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x5Cu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[7].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x64u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(eax + 0x68u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x20u)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(eax + 0x74u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x30u)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(eax + 0x78u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(eax + 0x24u)) = c->xmm[5].u[0];
    M32((uint32_t)(eax + 0x34u)) = c->xmm[4].u[0];
    M32((uint32_t)(eax + 0x44u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0x60u)) = c->xmm[2].u[0];
    M32((uint32_t)(eax + 0x64u)) = c->xmm[3].u[0];
    M32((uint32_t)(eax + 0x6Cu)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + 0x70u)) = c->xmm[6].u[0];
    M32((uint32_t)(eax + 0x7Cu)) = c->xmm[0].u[0];
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901F800:
    fpush(c, (double)MF32((uint32_t)(eax + 0x38u)));
    c->xmm[0].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(eax + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    MF32((uint32_t)(eax + 0x8u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x3Cu)));
    c->xmm[2].u[0] = M32((uint32_t)(eax + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x14u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    MF32((uint32_t)(eax + 0xCu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x18u)));
    c->xmm[4].u[0] = M32((uint32_t)(eax + 0x20u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x24u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    MF32((uint32_t)(eax + 0x10u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x1Cu)));
    M32((uint32_t)(eax + 0x20u)) = c->xmm[0].u[0];
    MF32((uint32_t)(eax + 0x14u)) = (float)ST(0); fpop(c);
    M32((uint32_t)(eax + 0x24u)) = c->xmm[1].u[0];
    fpush(c, (double)MF32((uint32_t)(eax + 0x28u)));
    M32((uint32_t)(eax + 0x38u)) = c->xmm[4].u[0];
    MF32((uint32_t)(eax + 0x18u)) = (float)ST(0); fpop(c);
    M32((uint32_t)(eax + 0x3Cu)) = c->xmm[5].u[0];
    fpush(c, (double)MF32((uint32_t)(eax + 0x2Cu)));
    MF32((uint32_t)(eax + 0x1Cu)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x30u)));
    M32((uint32_t)(eax + 0x30u)) = c->xmm[2].u[0];
    MF32((uint32_t)(eax + 0x28u)) = (float)ST(0); fpop(c);
    fpush(c, (double)MF32((uint32_t)(eax + 0x34u)));
    M32((uint32_t)(eax + 0x34u)) = c->xmm[3].u[0];
    MF32((uint32_t)(eax + 0x2Cu)) = (float)ST(0); fpop(c);
    esp += 4; SPILL(); return;
}

