#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9003000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9003000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9003018u; SPILL(); f_9001FE0(c); RELOAD();
    TS32((uint32_t)(esi), (uint32_t)(add32(TL32((uint32_t)(esi)), edi, &f)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x4u)), edi, &f)));
    edi = (uint32_t)(inc32(edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    (void)logic8((uint8_t)(TL8((uint32_t)(esi + 0x28u)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9003048;
    goto L_9003029;
L_9003029:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9003037u; SPILL(); f_9001FE0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9003045u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
L_9003048:
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x8u)), edi, &f)));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(esi + 0xCu)), edi, &f)));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x14u)), edi, &f)));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x18u)), edi, &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9003060(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9003060:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90030D6;
    goto L_900307A;
L_900307A:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    goto L_9003080;
L_9003080:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    ebp = (uint32_t)(eax);
    edx = (uint32_t)(eax);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)edx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(ebp));
    ebp = (uint32_t)(ebx);
    edx = (uint32_t)(ebx);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebx));
    ebx = (ebx & 0xFFFF0000u) | (uint16_t)(((uint16_t)edx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    ebx = (ebx & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebx), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9003080;
    goto L_90030D5;
L_90030D5:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_90030D6:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9003109;
    goto L_90030DE;
L_90030DE:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_9003109:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_900312C;
    goto L_9003111;
L_9003111:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_900312C:
    (void)logic32((uint32_t)(edx & (uint32_t)0x1u), &f);
    if (f.zf) goto L_9003143;
    goto L_9003134;
L_9003134:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1u, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)eax)) << 8);
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
L_9003143:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9003150(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9003150:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9003168u; SPILL(); f_9003060(c); RELOAD();
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x4u)), edi, &f)));
    edx = (uint32_t)((uint32_t)(edi + edi));
    TS32((uint32_t)(esi), (uint32_t)(add32(TL32((uint32_t)(esi)), edx, &f)));
    edi = (uint32_t)(inc32(edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    (void)logic8((uint8_t)(TL8((uint32_t)(esi + 0x28u)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_900319B;
    goto L_900317C;
L_900317C:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900318Au; SPILL(); f_9003060(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9003198u; SPILL(); f_9003060(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
L_900319B:
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x8u)), edi, &f)));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(esi + 0xCu)), edi, &f)));
    eax = (uint32_t)((uint32_t)(edi + edi));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x14u)), eax, &f)));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x18u)), eax, &f)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_9004039;
    goto L_9004029;
L_9004029:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9004045;
    goto L_900402E;
L_900402E:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_9004045;
L_9004039:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_90040C0;
    goto L_9004045;
L_9004045:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9004090;
    goto L_900404C;
L_900404C:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->mm[5] = (uint64_t)eax;
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x1u, &f));
    c->mm[5] = mmx_pslld(c->mm[5], (uint64_t)4u);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ecx))) << 8);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    c->mm[6] = (uint64_t)eax;
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[6]);
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[6]);
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    c->mm[1] = mmx_psrld(c->mm[1], c->mm[5]);
    (void)logic32((uint32_t)(ebp & ebp), &f);
    eax = (uint32_t)((uint32_t)c->mm[1]);
    TS16((uint32_t)(edi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (f.zf) goto L_90040C0;
    goto L_9004085;
L_9004085:
    goto L_9004090;
L_9004090:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ecx))) << 8);
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[6] = (uint64_t)eax;
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[6]);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[1]));
    if (!f.zf) goto L_9004090;
    goto L_90040B1;
L_90040B1:
    goto L_90040C0;
L_90040C0:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_900410B;
    goto L_90040CA;
L_90040CA:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    goto L_90040E0;
L_90040E0:
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[1] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[6] = M64((uint32_t)(edx));
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[2]);
    c->mm[7] = c->mm[1];
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[6]);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M64((uint32_t)(edi)) = c->mm[1];
    c->mm[7] = mmx_punpckhbw(c->mm[7], c->mm[6]);
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0x8u)) = c->mm[7];
    edi = (uint32_t)((uint32_t)(edi + 0x10u));
    if (!f.zf) goto L_90040E0;
    goto L_900410B;
L_900410B:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(esi), (uint32_t)(edi));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004130(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004130:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_90041B5;
    goto L_900414B;
L_900414B:
    goto L_9004150;
L_9004150:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrlw(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[4] = c->mm[0];
    c->mm[5] = mmx_punpcklbw(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[5]);
    c->mm[6] = c->mm[1];
    c->mm[1] &= M64((uint32_t)(0x903F830u));
    c->mm[6] = mmx_psrlw(c->mm[6], (uint64_t)8u);
    c->mm[1] = mmx_packuswb(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[6] = mmx_packuswb(c->mm[6], c->mm[6]);
    c->mm[5] = c->mm[1];
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[6]);
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[6]);
    c->mm[5] = mmx_punpckhbw(c->mm[5], c->mm[6]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    M64((uint32_t)(edi + 0x10u)) = c->mm[1];
    M64((uint32_t)(edi + 0x18u)) = c->mm[5];
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9004150;
    goto L_90041B5;
L_90041B5:
    (void)logic32((uint32_t)(edx & (uint32_t)0x8u), &f);
    if (f.zf) goto L_90041F7;
    goto L_90041BD;
L_90041BD:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrld(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[5] &= M64((uint32_t)(0x903F830u));
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[4] = c->mm[0];
    c->mm[5] = mmx_punpcklbw(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[5]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
L_90041F7:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_900422F;
    goto L_90041FF;
L_90041FF:
    c->mm[0] = (uint64_t)TL32((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrld(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[5] &= M64((uint32_t)(0x903F830u));
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[5] = mmx_punpcklbw(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_900422F:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_900424B;
    goto L_9004237;
L_9004237:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_900424B:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004260(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004260:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_9004299;
    goto L_9004289;
L_9004289:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_90042A5;
    goto L_900428E;
L_900428E:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_90042A5;
L_9004299:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_9004320;
    goto L_90042A5;
L_90042A5:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_90042F0;
    goto L_90042AC;
L_90042AC:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->mm[5] = (uint64_t)eax;
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x1u, &f));
    c->mm[5] = mmx_pslld(c->mm[5], (uint64_t)4u);
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ecx))) << 8);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    c->mm[6] = (uint64_t)eax;
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[6]);
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[1]);
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    c->mm[6] = mmx_psrld(c->mm[6], c->mm[5]);
    (void)logic32((uint32_t)(ebp & ebp), &f);
    eax = (uint32_t)((uint32_t)c->mm[6]);
    TS16((uint32_t)(edi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (f.zf) goto L_9004320;
    goto L_90042E5;
L_90042E5:
    goto L_90042F0;
L_90042F0:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ecx))) << 8);
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[6] = (uint64_t)eax;
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[1]);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[6]));
    if (!f.zf) goto L_90042F0;
    goto L_9004311;
L_9004311:
    goto L_9004320;
L_9004320:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_900436B;
    goto L_900432A;
L_900432A:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    goto L_9004340;
L_9004340:
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[1] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[6] = M64((uint32_t)(edx));
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[1]);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    M64((uint32_t)(edi)) = c->mm[6];
    c->mm[7] = mmx_punpckhbw(c->mm[7], c->mm[1]);
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0x8u)) = c->mm[7];
    edi = (uint32_t)((uint32_t)(edi + 0x10u));
    if (!f.zf) goto L_9004340;
    goto L_900436B;
L_900436B:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(esi), (uint32_t)(edi));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

