#include "funcs_bink.h"
#include "lift_prelude.h"

void f_90161A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90161A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1FFFFu, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x11u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x11u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1000u, &f));
    (void)sub32(eax, (uint32_t)0x41000u, &f);
    if (!f.cf) goto L_90161C2;
    goto L_90161BD;
L_90161BD:
    eax = (uint32_t)((uint32_t)0x41000u);
L_90161C2:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90161D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90161D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90161E1;
    goto L_90161DE;
L_90161DE:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90161E1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90161E1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(eax + 0xFFFu));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFF000u), &f));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x10u)), &f));
    TS32((uint32_t)(esi + 0x90u), (uint32_t)(ecx));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x11u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x11u, &f));
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    TS32((uint32_t)(esi + 0x94u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x9Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901623C;
    goto L_9016239;
L_9016239:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901623Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901623C:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

void f_9016250(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016250:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016261;
    goto L_901625E;
L_901625E:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016261u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016261:
    (void)sub32(TL32((uint32_t)(esi + 0x98u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9016277;
    goto L_901626A;
L_901626A:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9016277u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016277:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016281;
    goto L_901627E;
L_901627E:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016281u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016281:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9016290(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016290:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x7Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ esp), &f));
    M32((uint32_t)(esp + 0x78u)) = (uint32_t)(eax);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x40u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_90162D4;
    goto L_90162BE;
L_90162BE:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x78u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x90162CEu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90162D4:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_90162BE;
    goto L_90162DB;
L_90162DB:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_90165F4;
    goto L_90162E6;
L_90162E6:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90162E9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_90165F4;
    goto L_90162F1;
L_90162F1:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x9Cu)));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    if (!f.zf) goto L_90163F3;
    goto L_9016305;
L_9016305:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xB0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_90163F3;
    goto L_9016313;
L_9016313:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    (void)logic8((uint8_t)(TL8((uint32_t)(edx + 0x20u)) & (uint8_t)0x80u), &f);
    if (f.zf) goto L_90163F3;
    goto L_9016320;
L_9016320:
    ecx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)(ecx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x20u)) & (uint32_t)0xFFFFFF7Fu), &f)));
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    TS32((uint32_t)(esi + 0x44u), (uint32_t)(ecx));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9016386;
    goto L_9016341;
L_9016341:
    { uint32_t v_ = 0x903C33Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902885Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016351u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9016386;
    goto L_901635D;
L_901635D:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x903C350u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028858u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x19Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9016383u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_9016386:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x158u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFFEu), &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x20u, &f));
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(esi + 0x80u)), &f));
    edx = (uint32_t)(adc32(edx, TL32((uint32_t)(esi + 0x84u)), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x90163B5u; SPILL(); f_9015B60(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x14u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x20u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x2Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310DCu)); esp -= 4; M32(esp) = 0x90163D2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_90163EC;
    goto L_90163DB;
L_90163DB:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x1A5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x90163ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90163EC:
    TS32((uint32_t)(esi + 0x44u), (uint32_t)(edi));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edi);
L_90163F3:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xA8u)));
    (void)sub32(edx, (uint32_t)0x20000u, &f);
    if (f.cf) goto L_90165EC;
    goto L_9016405;
L_9016405:
    (void)sub32(ebx, edi, &f);
    if (f.zf) goto L_90165EC;
    goto L_901640D;
L_901640D:
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)((uint32_t)0x20000u);
    (void)sub32(ebx, (uint32_t)0x20000u, &f);
    if (!f.cf) goto L_9016421;
    goto L_901641D;
L_901641D:
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(ebx);
L_9016421:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9016430;
    goto L_9016428;
L_9016428:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901642Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    goto L_9016434;
L_9016430:
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(edi);
L_9016434:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xA4u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1FFFFu), &f));
    (void)sub32(edi, eax, &f);
    if ((!f.cf && !f.zf)) goto L_901644C;
    goto L_9016448;
L_9016448:
    (void)sub32(eax, ebx, &f);
    if (!f.zf) goto L_9016450;
    goto L_901644C;
L_901644C:
    edi = (uint32_t)(logic32(0, &f));
    goto L_901646D;
L_9016450:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901646D;
    goto L_9016454;
L_9016454:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016467;
    goto L_901645B;
L_901645B:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0xA0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016465u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901646D;
L_9016467:
    TS32((uint32_t)(esi + 0xA0u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA0u)), edi, &f)));
L_901646D:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xB0u)));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0x14u)), edi, &f));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_901648F;
    goto L_901647B;
L_901647B:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x20u)) & (uint32_t)0xFFFFFF7Fu), &f)));
    TS32((uint32_t)(esi + 0xB0u), (uint32_t)((uint32_t)0x0u));
L_901648F:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90164C3;
    goto L_9016498;
L_9016498:
    { uint32_t v_ = 0x903C364u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028850u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1CBu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90164C0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
L_90164C3:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0x44u), (uint32_t)(ebx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xACu)));
    ecx = (uint32_t)((uint32_t)(esp + 0x14u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, edi, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310DCu)); esp -= 4; M32(esp) = 0x90164EDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    TS32((uint32_t)(esi + 0x44u), (uint32_t)((uint32_t)0x0u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016508;
    goto L_90164FB;
L_90164FB:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016508u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016508:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    (void)sub32(eax, M32((uint32_t)(esp + 0x14u)), &f);
    if (f.zf) goto L_9016515;
    goto L_9016512;
L_9016512:
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(ebx));
L_9016515:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90165C3;
    goto L_901651D;
L_901651D:
    TS32((uint32_t)(esi + 0x48u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x48u)), eax, &f)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(esi + 0xA4u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xA4u)), edx, &f)));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(add32(TL32((uint32_t)(esi + 0xACu)), (uint32_t)0x20000u, &f)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xACu)));
    (void)sub32(eax, TL32((uint32_t)(esi + 0x94u)), &f);
    if (f.cf) goto L_901654E;
    goto L_9016542;
L_9016542:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x90u)));
    TS32((uint32_t)(esi + 0xACu), (uint32_t)(ecx));
L_901654E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016567;
    goto L_9016555;
L_9016555:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(neg32(edx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0xA8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016565u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9016571;
L_9016567:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(esi + 0xA8u), (uint32_t)(sub32(TL32((uint32_t)(esi + 0xA8u)), eax, &f)));
L_9016571:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    edi = (uint32_t)((uint32_t)(esi + 0x6Cu));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016585;
    goto L_901657B;
L_901657B:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016583u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901658B;
L_9016585:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(edi), (uint32_t)(add32(TL32((uint32_t)(edi)), edx, &f)));
L_901658B:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    (void)sub32(eax, ecx, &f);
    if ((f.cf || f.zf)) goto L_9016599;
    goto L_9016594;
L_9016594:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(esi + 0x64u), (uint32_t)(edx));
L_9016599:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90165A4;
    goto L_90165A0;
L_90165A0:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90165A2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_90165A6;
L_90165A4:
    eax = (uint32_t)(logic32(0, &f));
L_90165A6:
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(esp + 0x18u)), &f));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x50u)), eax, &f)));
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_90165C0;
    goto L_90165B4;
L_90165B4:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4Cu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_90165C0;
    goto L_90165BB;
L_90165BB:
    TS32((uint32_t)(esi + 0x58u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x58u)), eax, &f)));
    goto L_90165C3;
L_90165C0:
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(add32(TL32((uint32_t)(esi + 0x5Cu)), eax, &f)));
L_90165C3:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90165DE;
    goto L_90165CC;
L_90165CC:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x1F3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C2B8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90165DEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90165DE:
    edi = (uint32_t)(logic32(0, &f));
L_90165E0:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9016606;
    goto L_90165E7;
L_90165E7:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90165EAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_9016606;
L_90165EC:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    goto L_90165E0;
L_90165F4:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_90165FE;
    goto L_90165FB;
L_90165FB:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90165FEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90165FE:
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)((uint32_t)0xFFFFFFFFu);
L_9016606:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x84u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x901661Bu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9016630(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016630:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901666E;
    goto L_901663C;
L_901663C:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_901664D;
    goto L_9016646;
L_9016646:
    TS32((uint32_t)(esi + 0x70u), (uint32_t)((uint32_t)0x1u));
L_901664D:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.sf) goto L_9016665;
    goto L_9016651;
L_9016651:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901665B;
    goto L_9016658;
L_9016658:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901665Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901665B:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016665;
    goto L_9016662;
L_9016662:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016665u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016665:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901666E:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x2u), &f);
    if (f.zf) goto L_9016697;
    goto L_9016672;
L_9016672:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    (void)sub32(edx, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9016684;
    goto L_901667D;
L_901667D:
    TS32((uint32_t)(esi + 0x70u), (uint32_t)((uint32_t)0x0u));
L_9016684:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.sf) goto L_9016665;
    goto L_9016688;
L_9016688:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901668Eu; SPILL(); f_9016290(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9016697:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x70u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90166B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90166B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(ebx & (uint32_t)0x800000u), &f);
    if (f.zf) goto L_90166FC;
    goto L_90166C8;
L_90166C8:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x98u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x20u), &f);
    if (!f.zf) goto L_901675C;
    goto L_90166E1;
L_90166E1:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90166EBu; SPILL(); f_9015B60(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(edx));
    goto L_9016757;
L_90166FC:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ebx = (uint32_t)(TL32((uint32_t)(0x90310D4u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000080u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80000000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x901671Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9016740;
    goto L_9016725;
L_9016725:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000080u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x80000000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x901673Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
L_9016740:
    (void)sub32(TL32((uint32_t)(esi + 0x88u)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9016754;
    goto L_9016749;
L_9016749:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9016754:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
L_9016757:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_901678D;
    goto L_901675C;
L_901675C:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xFFFFFF30u)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xFFFFFF34u)));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    TS32((uint32_t)(esi + 0x84u), (uint32_t)(ecx));
    if (f.zf) goto L_901678D;
    goto L_901677A;
L_901677A:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x901678Au; SPILL(); f_9015B60(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901678D:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x9015BB0u));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)((uint32_t)0x9015CD0u));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)((uint32_t)0x90161A0u));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)((uint32_t)0x90161D0u));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)((uint32_t)0x9016290u));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)((uint32_t)0x9016250u));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)((uint32_t)0x9016630u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_90167D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90167D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90167DCu; SPILL(); f_90179B0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90167F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90167F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp -= 4; M32(esp) = 0x90167FBu; SPILL(); f_9017B30(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9016800(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016800:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp -= 4; M32(esp) = 0x901680Bu; SPILL(); f_9017BA0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9016810(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016810:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
L_901682C:
    edi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
L_9016830:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_9016835:
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_901685B;
    goto L_9016839;
L_9016839:
    { uint32_t v_ = 0x903C37Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028860u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x66u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C394u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016853u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_901685B:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FAECu)));
    TS32((uint32_t)(0x903FCD4u), (uint32_t)(ebx));
    (void)logic32((uint32_t)(M32((uint32_t)(esp + 0xCu)) & ecx), &f);
    if (!f.zf) goto L_901687B;
    goto L_901686D;
L_901686D:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
    esi = (uint32_t)(logic32(0, &f));
    goto L_90168AD;
L_901687B:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0x6D0u; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)((uint32_t)(esp + 0x10u));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(add32(esi, (uint32_t)0x90290C8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    esp -= 4; M32(esp) = 0x9016899u; SPILL(); f_9017800(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    esi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(sbb32(esi, esi, &f));
    esi = (uint32_t)(neg32(esi, &f));
L_90168AD:
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_90168C4;
    goto L_90168B1;
L_90168B1:
    { uint32_t v_ = 0x68u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903C394u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90168BFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_90168C4:
    (void)sub32(esi, ebx, &f);
    if (f.zf) goto L_9016835;
    goto L_90168CC;
L_90168CC:
    (void)sub32(edi, ebx, &f);
    if (f.zf) goto L_9016933;
    goto L_90168D0;
L_90168D0:
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    esi = (uint32_t)(edi);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF8u), &f));
    esp -= 4; M32(esp) = 0x90168E2u; SPILL(); f_90114E0(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(0x903FAECu)));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF9u), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(edi);
    TS32((uint32_t)(0x903FCD4u), (uint32_t)(ebx));
    (void)logic32((uint32_t)(M32((uint32_t)(esp + 0xCu)) & edx), &f);
    if (!f.zf) goto L_9016911;
    goto L_9016902;
L_9016902:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
    goto L_9016830;
L_9016911:
    eax = (uint32_t)((uint32_t)(esp + 0x10u));
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x6D0u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x902C748u, &f));
    esp -= 4; M32(esp) = 0x901692Bu; SPILL(); f_90176E0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901682C;
L_9016933:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9016940(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016940:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9016A6A;
    goto L_901694F;
L_901694F:
    (void)sub32(TL32((uint32_t)(esi + 0x100u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9016A60;
    goto L_901695C;
L_901695C:
    (void)sub32(TL32((uint32_t)(esi + 0x104u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9016A60;
    goto L_9016969;
L_9016969:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xD8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901697B;
    goto L_9016973;
L_9016973:
    (void)sub32(eax, TL32((uint32_t)(esi + 0xD4u)), &f);
    if (!f.zf) goto L_90169AE;
    goto L_901697B;
L_901697B:
    (void)sub32(TL32((uint32_t)(esi + 0xD4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90169AE;
    goto L_9016984;
L_9016984:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    TS32((uint32_t)(esi + 0x468u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x468u)), eax, &f)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Fu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFE0u), &f));
    esp -= 4; M32(esp) = 0x901699Eu; SPILL(); f_9001070(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xF4u)));
    TS32((uint32_t)(esi + 0xD8u), (uint32_t)(eax));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x0u));
L_90169AE:
    esp -= 4; M32(esp) = 0x90169B3u; SPILL(); f_90159C0(c); RELOAD();
    ecx = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x90169BAu; SPILL(); f_9010CC0(c); RELOAD();
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9016A6A;
    goto L_90169C4;
L_90169C4:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(ebx, edi, &f);
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(f.zf);
    eax = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(ebx);
    TS32((uint32_t)(0x903FEB4u), (uint32_t)((uint32_t)0x9016CB0u));
    edx = (uint32_t)((uint32_t)(edx*4 + 0x2u));
    edx = (uint32_t)(logic32((uint32_t)(edx | esi), &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90169F4u; SPILL(); f_9017AE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016A09;
    goto L_90169FB;
L_90169FB:
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0x300u), &f));
    TS32((uint32_t)(esi + 0x100u), (uint32_t)(ecx));
L_9016A09:
    eax = (uint32_t)(TL32((uint32_t)(0x903FCD4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016A18;
    goto L_9016A12;
L_9016A12:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9016A18u; SPILL(); f_900D100(c); RELOAD();
L_9016A18:
    edx = (uint32_t)(esi);
    edx = (uint32_t)(logic32((uint32_t)(edx | (uint32_t)0x5u), &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    (void)sub32(ebx, edi, &f);
    if (f.zf) goto L_9016A42;
    goto L_9016A24;
L_9016A24:
    eax = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9016A2Fu; SPILL(); f_9017AE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016A42;
    goto L_9016A36;
L_9016A36:
    edi = (uint32_t)(logic32((uint32_t)(edi | (uint32_t)0x300u), &f));
    TS32((uint32_t)(esi + 0x104u), (uint32_t)(edi));
L_9016A42:
    (void)sub32(TL32((uint32_t)(esi + 0x100u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    if (!f.zf) goto L_9016A56;
    goto L_9016A4D;
L_9016A4D:
    (void)sub32(TL32((uint32_t)(esi + 0x104u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9016A6A;
    goto L_9016A56;
L_9016A56:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9016A60:
    { uint32_t v_ = 0x903C3D0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9016A6Au; SPILL(); f_900D100(c); RELOAD();
L_9016A6A:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9016A80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016A80:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(eax, ebx, &f);
    if (!f.zf) goto L_9016A9A;
    goto L_9016A90;
L_9016A90:
    eax = (uint32_t)((uint32_t)(ebx + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9016A9A:
    (void)sub32(TL32((uint32_t)(eax + 0x100u)), ebx, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(eax + 0x100u));
    if (!f.zf) goto L_9016ABE;
    goto L_9016AA9;
L_9016AA9:
    (void)sub32(TL32((uint32_t)(eax + 0x104u)), ebx, &f);
    if (!f.zf) goto L_9016ABE;
    goto L_9016AB1;
L_9016AB1:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9016ABE:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(esi, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    if ((f.zf || f.sf != f.of)) goto L_9016AD1;
    goto L_9016AC9;
L_9016AC9:
    esp -= 4; M32(esp) = 0x9016ACEu; SPILL(); f_90159C0(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
L_9016AD1:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x2u);
    goto L_9016AE3;
L_9016AE0:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
L_9016AE3:
    (void)logic32((uint32_t)(TL32((uint32_t)(edi)) & (uint32_t)0x100u), &f);
    if (f.zf) goto L_9016C18;
    goto L_9016AEF;
L_9016AEF:
    eax = (uint32_t)(esi);
L_9016AF1:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFCFFu), &f));
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x903FCD4u), (uint32_t)(ebx));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & edx), &f);
    if (f.zf) goto L_9016BD4;
    goto L_9016B12;
L_9016B12:
    esi = (uint32_t)(ecx);
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0x6D0u; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(add32(esi, (uint32_t)0x902C748u, &f));
    esp -= 4; M32(esp) = 0x9016B2Bu; SPILL(); f_9017800(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016BE0;
    goto L_9016B36;
L_9016B36:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    esi = (uint32_t)(eax);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFFEu), &f));
    (void)sub32(esi, M32((uint32_t)(ebp + 0x8u)), &f);
    if (f.zf) goto L_9016BB8;
    goto L_9016B43;
L_9016B43:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ecx*4 + 0x100u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFCFFu), &f));
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(0x903FAECu)) & edx), &f);
    if (!f.zf) goto L_9016B70;
    goto L_9016B64;
L_9016B64:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C4D0u));
    goto L_9016BB8;
L_9016B70:
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0x6D0u; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x902C748u, &f));
    (void)sub32(TL32((uint32_t)(ecx + 0xCCu)), ebx, &f);
    if (!f.zf) goto L_9016B90;
    goto L_9016B84;
L_9016B84:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C478u));
    goto L_9016BB8;
L_9016B90:
    eax = (uint32_t)((uint32_t)(ecx + 0xC0u));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if (!f.cf) goto L_9016BB5;
    goto L_9016B9D;
L_9016B9D:
    edx = (uint32_t)((uint32_t)0x1u);
    { uint32_t s_ = edx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(eax)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); edx = (uint32_t)(o_); }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x3Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x9016BB5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016BB5:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
L_9016BB8:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    TS32((uint32_t)(esi + eax*4 + 0x100u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + eax*4 + 0x100u)) & (uint32_t)0xFFFFFEFFu), &f)));
    eax = (uint32_t)((uint32_t)(esi + eax*4 + 0x100u));
    eax = (uint32_t)(logic32(0, &f));
    goto L_9016AF1;
L_9016BD4:
    eax = (uint32_t)((uint32_t)0x903C4D0u);
    TS32((uint32_t)(0x903FCD4u), (uint32_t)(eax));
    goto L_9016BE9;
L_9016BE0:
    eax = (uint32_t)(TL32((uint32_t)(0x903FCD4u)));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9016C18;
    goto L_9016BE9;
L_9016BE9:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    esi = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x9028598u);
    TS8((uint32_t)(0x9028598u), (uint8_t)(((uint8_t)edx)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    ecx = (uint32_t)((uint32_t)(ecx));
L_9016C00:
    (void)sub8(TL8((uint32_t)(eax)), ((uint8_t)ebx), &f);
    if (f.zf) goto L_9016C18;
    goto L_9016C04;
L_9016C04:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax + 0x1u)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)((uint32_t)(esi + eax));
    (void)sub32(edx, (uint32_t)0xFFu, &f);
    if (!f.zf) goto L_9016C00;
    goto L_9016C16;
L_9016C16:
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
L_9016C18:
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9016AE0;
    goto L_9016C25;
L_9016C25:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x100u)) & (uint32_t)0x100u), &f);
    edi = (uint32_t)((uint32_t)(esi + 0x100u));
    if (!f.zf) goto L_9016C46;
    goto L_9016C3A;
L_9016C3A:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x104u)) & (uint32_t)0x100u), &f);
    if (f.zf) goto L_9016C6E;
    goto L_9016C46;
L_9016C46:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(esi, ebx, &f);
    if (f.zf) goto L_9016C63;
    goto L_9016C4D;
L_9016C4D:
    if ((f.zf || f.sf != f.of)) goto L_9016AD1;
    goto L_9016C53;
L_9016C53:
    esp -= 4; M32(esp) = 0x9016C58u; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    (void)sub32(eax, esi, &f);
    if (f.cf) goto L_9016AD1;
    goto L_9016C63;
L_9016C63:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9016C6E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xD4u)));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x104u), (uint32_t)(ebx));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9016C96;
    goto L_9016C80;
L_9016C80:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xD8u)));
    (void)sub32(ecx, ebx, &f);
    if (f.zf) goto L_9016C96;
    goto L_9016C8A;
L_9016C8A:
    TS32((uint32_t)(esi + 0xD4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0xD8u), (uint32_t)(eax));
L_9016C96:
    esp -= 4; M32(esp) = 0x9016C9Bu; SPILL(); f_90159C0(c); RELOAD();
    esp -= 4; M32(esp) = 0x9016CA0u; SPILL(); f_9010DC0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9016CB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016CB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9016CBEu; SPILL(); f_9016A80(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9016CC0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016CC0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x24u, &f));
    (void)sub32(TL32((uint32_t)(ecx + 0x84u)), eax, &f);
    if (f.zf) goto L_9016D11;
    goto L_9016CD0;
L_9016CD0:
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x7Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)M32((uint32_t)(ebp + 0x8u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ecx + 0x88u)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x84u)));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFDCu));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x54u)));
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9016D11u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016D11:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9016D20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016D20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(esi + 0x24u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(esi + 0x28u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    (void)sub32(TL32((uint32_t)(0x903FCD8u)), ebx, &f);
    if (f.zf) goto L_9016E4F;
    goto L_9016D44;
L_9016D44:
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0x3E8u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * edi; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)0x10624DD3u);
    { uint64_t r_ = (uint64_t)eax * edi; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x78u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0xAu, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1Fu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Fu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFE0u), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFE0u), &f));
    TS32((uint32_t)(esi + 0x7Cu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(edx));
    (void)sub32(edx, eax, &f);
    if ((f.cf || f.zf)) goto L_9016D7C;
    goto L_9016D79;
L_9016D79:
    TS32((uint32_t)(esi + 0x74u), (uint32_t)(eax));
L_9016D7C:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(ebx));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
    (void)sub32(TL32((uint32_t)(esi + 0x88u)), ebx, &f);
    if (!f.zf) goto L_9016DAB;
    goto L_9016D93;
L_9016D93:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    esp -= 4; M32(esp) = 0x9016D9Du; SPILL(); f_9001070(c); RELOAD();
    TS32((uint32_t)(esi + 0x88u), (uint32_t)(eax));
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_9016E4F;
    goto L_9016DAB;
L_9016DAB:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x10u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(neg32(ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x80u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9016DCFu; SPILL(); f_9001EB0(c); RELOAD();
    fpush(c, 1.0);
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL8((uint32_t)(esi + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    eax = (uint32_t)((uint32_t)0x1u);
    M16((uint32_t)(ebp + 0xFFFFFFECu)) = (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi + 0x24u)));
    edi = (uint32_t)(((uint16_t)eax));
    ebx = (uint32_t)(((uint16_t)ecx));
    M16((uint32_t)(ebp + 0xFFFFFFFAu)) = (uint16_t)(((uint16_t)eax));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x3u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(shr16(((uint16_t)eax), (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)ebx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int16_t)((uint16_t)eax) * (int16_t)((uint16_t)ecx); eax = (eax & 0xFFFF0000u) | (uint16_t)(r_); f.cf = f.of = r_ != (int16_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)edx; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    M16((uint32_t)(ebp + 0xFFFFFFEEu)) = (uint16_t)(((uint16_t)ecx));
    M16((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint16_t)(((uint16_t)eax));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(esi + 0x84u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    M16((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint16_t)(((uint16_t)ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x903FCD8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFECu));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x20u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016E3Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016E57;
    goto L_9016E43;
L_9016E43:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9016E4Fu; SPILL(); f_9001100(c); RELOAD();
L_9016E4F:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9016E57:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9016E70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016E70:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    c->xmm[0].f[0] = (float)(int32_t)TL32((uint32_t)(eax + 0x58u));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x28u)), (uint32_t)0x1u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9016EF0;
    goto L_9016E81;
L_9016E81:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    (void)sub32(ecx, (uint32_t)0x7FFFu, &f);
    c->xmm[1].u[0] = M32((uint32_t)(0x9031324u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    if ((!f.zf && f.sf == f.of)) goto L_9016EB0;
    goto L_9016E98;
L_9016E98:
    c->xmm[2].f[0] = (float)(int32_t)ecx;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[2].u[0];
    goto L_9016ECD;
L_9016EB0:
    edx = (uint32_t)((uint32_t)0x10000u);
    edx = (uint32_t)(sub32(edx, ecx, &f));
    c->xmm[2].f[0] = (float)(int32_t)edx;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[2].u[0];
L_9016ECD:
    (void)sub32(TL32((uint32_t)(eax + 0x84u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9016F1C;
    goto L_9016ED6;
L_9016ED6:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x38u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016EECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9016EF0:
    (void)sub32(TL32((uint32_t)(eax + 0x84u)), (uint32_t)0x0u, &f);
    c->xmm[0].f[0] = c->xmm[0].f[0] * MF32((uint32_t)(0x9031324u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[0].u[0];
    if (f.zf) goto L_9016F1C;
    goto L_9016F06;
L_9016F06:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x38u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016F1Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9016F1C:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9016F20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016F20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x64u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9016F76;
    goto L_9016F30;
L_9016F30:
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9016F76;
    goto L_9016F36;
L_9016F36:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9016F76;
    goto L_9016F40;
L_9016F40:
    (void)sub32(TL32((uint32_t)(esi + 0x60u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9016F84;
    goto L_9016F46;
L_9016F46:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x10u);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x64u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9016F59u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9016F7F;
    goto L_9016F60;
L_9016F60:
    TS32((uint32_t)(esi + 0x60u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(eax));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(eax));
L_9016F76:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9016F7F:
    (void)sub32(eax, (uint32_t)0x10u, &f);
    if (f.zf) goto L_9016F76;
    goto L_9016F84;
L_9016F84:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    ecx = (uint32_t)(inc32(ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000000Fu), &f));
    if (!f.sf) goto L_9016F95;
    goto L_9016F90;
L_9016F90:
    ecx = (uint32_t)(dec32(ecx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFF0u), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
L_9016F95:
    TS32((uint32_t)(esi + 0x68u), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9016FB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016FB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x68u)));
    (void)sub32(ecx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9016FC4;
    goto L_9016FBE;
L_9016FBE:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
L_9016FC4:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(eax + 0x88u)), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9016FF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9016FF0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x68u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9017006;
    goto L_9016FFF;
L_9016FFF:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9017006:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(esi + 0x70u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x70u)), edx, &f)));
    (void)sub32(TL32((uint32_t)(esi + 0x60u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(esi + 0x6Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x70u)));
    TS32((uint32_t)(esi + 0x68u), (uint32_t)((uint32_t)0xFFFFFFFFu));
    if (!f.zf) goto L_9017068;
    goto L_901701F;
L_901701F:
    (void)sub32(eax, TL32((uint32_t)(esi + 0x74u)), &f);
    if (f.cf) goto L_9017076;
    goto L_9017024;
L_9017024:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x6Cu)), edi, &f);
    TS32((uint32_t)(esi + 0x60u), (uint32_t)((uint32_t)0x1u));
    if ((f.sf != f.of)) goto L_9017047;
    goto L_9017033;
L_9017033:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901703Eu; SPILL(); f_9016CC0(c); RELOAD();
    edi = (uint32_t)(inc32(edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(edi, TL32((uint32_t)(esi + 0x6Cu)), &f);
    if ((f.zf || f.sf != f.of)) goto L_9017033;
    goto L_9017047;
L_9017047:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9017076;
    goto L_9017052;
L_9017052:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x901705Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9017068:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x6Cu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9017073u; SPILL(); f_9016CC0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_9017076:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9017080(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017080:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, (uint32_t)0x10000u, &f);
    if ((f.sf != f.of)) goto L_9017092;
    goto L_901708D;
L_901708D:
    eax = (uint32_t)((uint32_t)0xFFFFu);
L_9017092:
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)0x7FFFu);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x8000u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx + 0x58u), (uint32_t)(eax));
    eax = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x90170B4u; SPILL(); f_9016E70(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90170C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90170C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(ecx, (uint32_t)0x10000u, &f);
    if ((f.zf || f.sf != f.of)) goto L_90170D3;
    goto L_90170CE;
L_90170CE:
    ecx = (uint32_t)((uint32_t)0x10000u);
L_90170D3:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x90170DEu; SPILL(); f_9016E70(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90170F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90170F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9017155;
    goto L_90170FC;
L_90170FC:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901714D;
    goto L_9017105;
L_9017105:
    esp -= 4; M32(esp) = 0x901710Au; SPILL(); f_9016D20(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901714D;
    goto L_901710E;
L_901710E:
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9017115u; SPILL(); f_9016E70(c); RELOAD();
    (void)sub32(TL32((uint32_t)(esi + 0x8Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9017146;
    goto L_901711E;
L_901711E:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017146;
    goto L_9017128;
L_9017128:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0x90u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x80u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x40u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9017146u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9017146:
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x1u));
L_901714D:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_9017155:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901718D;
    goto L_9017159;
L_9017159:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(esi + 0x34u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901714D;
    goto L_9017162;
L_9017162:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901717E;
    goto L_901716C;
L_901716C:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x48u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9017174u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x84u), (uint32_t)((uint32_t)0x0u));
L_901717E:
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_901718D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_90171A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90171A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    if (f.zf) goto L_90171D2;
    goto L_90171B3;
L_90171B3:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90171C3;
    goto L_90171B7;
L_90171B7:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x50u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90171C3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90171C3:
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_90171D2:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90171E2;
    goto L_90171D6;
L_90171D6:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x4Cu)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90171E2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90171E2:
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x64u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_9017200(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017200:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(edi, (uint32_t)0x8u, &f);
    if ((f.cf || f.zf)) goto L_9017213;
    goto L_901720E;
L_901720E:
    edi = (uint32_t)((uint32_t)0x8u);
L_9017213:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = 0x40u; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(esi + 0x90u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x8Cu), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x9017230u; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)((uint32_t)(edi*8));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017242u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)sub32(edi, TL32((uint32_t)(esi + 0x80u)), &f);
    if ((f.cf || f.zf)) goto L_9017253;
    goto L_901724D;
L_901724D:
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(edi));
L_9017253:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9017275;
    goto L_901725D;
L_901725D:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x80u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x40u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9017275u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9017275:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_9017280(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017280:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x84u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90172A3;
    goto L_9017291;
L_9017291:
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x48u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9017299u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x84u), (uint32_t)((uint32_t)0x0u));
L_90172A3:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x88u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90172EC;
    goto L_90172AD;
L_90172AD:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_90172D0;
    goto L_90172B7;
L_90172B7:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90172C1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90172D0:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x90172E2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x88u), (uint32_t)((uint32_t)0x0u));
L_90172EC:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9017300(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017300:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x430u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = 0x180u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017329u; SPILL(); f_9001EB0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(edx));
    TS32((uint32_t)(esi + 0x20u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x903FCD8u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFBD0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x50u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901735Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M16((uint32_t)(ebp + 0xFFFFFFD6u)));
    TS32((uint32_t)(esi + 0x80u), (uint32_t)(eax));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0x14u)));
    TS32((uint32_t)(edi + 0x4E8u), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x3u, &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(esi + 0x28u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(esi + 0x20u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_90173A5;
    goto L_9017380;
L_9017380:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x18u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90173A5;
    goto L_9017387;
L_9017387:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    { uint64_t r_ = (uint64_t)eax * edx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017396u; SPILL(); f_9001B90(c); RELOAD();
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90173A0u; SPILL(); f_9001BD0(c); RELOAD();
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(eax));
    goto L_90173A8;
L_90173A5:
    TS32((uint32_t)(esi + 0x78u), (uint32_t)(ecx));
L_90173A8:
    eax = (uint32_t)((uint32_t)0x7FFFu);
    TS32((uint32_t)(esi + 0x58u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x5Cu), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x64u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(esi + 0x34u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x15Cu), (uint32_t)((uint32_t)0x9016F20u));
    TS32((uint32_t)(esi + 0x160u), (uint32_t)((uint32_t)0x9016FB0u));
    TS32((uint32_t)(esi + 0x164u), (uint32_t)((uint32_t)0x9016FF0u));
    TS32((uint32_t)(esi + 0x168u), (uint32_t)((uint32_t)0x9017080u));
    TS32((uint32_t)(esi + 0x16Cu), (uint32_t)((uint32_t)0x90170C0u));
    TS32((uint32_t)(esi + 0x170u), (uint32_t)((uint32_t)0x90171A0u));
    TS32((uint32_t)(esi + 0x174u), (uint32_t)((uint32_t)0x90170F0u));
    TS32((uint32_t)(esi + 0x178u), (uint32_t)((uint32_t)0x9017280u));
    TS32((uint32_t)(esi + 0x17Cu), (uint32_t)((uint32_t)0x9017200u));
    esp -= 4; M32(esp) = 0x9017420u; SPILL(); f_9016D20(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9017437;
    goto L_9017424;
L_9017424:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x9017431u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
L_9017437:
    (void)sub32(TL32((uint32_t)(esi + 0x24u)), (uint32_t)0x10u, &f);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x7Cu)));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(eax));
    if (f.zf) goto L_9017449;
    goto L_9017443;
L_9017443:
    ecx = (uint32_t)((uint32_t)(eax + eax));
    TS32((uint32_t)(esi + 0x2Cu), (uint32_t)(ecx));
L_9017449:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x38u), (uint32_t)((uint32_t)0x0u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9017462u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
}

void f_9017470(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017470:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901748B;
    goto L_901747B;
L_901747B:
    TS32((uint32_t)(0x903FCD8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x9017300u);
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_901748B:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    { uint32_t t_ = TL32((uint32_t)(0x90311A8u)); esp -= 4; M32(esp) = 0x90174A4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90174ADu; SPILL(); f_9001010(c); RELOAD();
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90174DF;
    goto L_90174B7;
L_90174B7:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90174CDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x903FCD8u), (uint32_t)(esi));
    eax = (uint32_t)((uint32_t)0x9017300u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90174DF:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90174F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90174F0:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + 0xFu));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0xCCu), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031044u)); esp -= 4; M32(esp) = 0x9017510u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)sub32(TL32((uint32_t)(edx)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_901752B;
    goto L_901751D;
L_901751D:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C414u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901752B:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + 0x40u));
    esp -= 4; M32(esp) = 0x9017534u; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9017560;
    goto L_9017538;
L_9017538:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C42Cu));
    if (f.zf) goto L_901755C;
    goto L_901754A;
L_901754A:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9017553u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_901755C:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017560:
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0xC4u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0xC8u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0xC0u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0xCCu), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9017580(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017580:
    (void)sub32(TL32((uint32_t)(esi + 0xCCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90175FF;
    goto L_9017589;
L_9017589:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90175A3;
    goto L_9017591;
L_9017591:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x901759Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_90175A3:
    eax = (uint32_t)((uint32_t)(esi + 0x40u));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90175EF;
    goto L_90175AA;
L_90175AA:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(ecx);
    eax = (uint32_t)(edx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)edi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)sub32(eax, edx, &f);
    if (!f.zf) goto L_90175EF;
    goto L_90175C1;
L_90175C1:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_90175E0;
    goto L_90175C6;
L_90175C6:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x90175D0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0xCCu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)((uint32_t)0x1u);
    esp += 4; SPILL(); return;
L_90175E0:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_90175EF;
    goto L_90175E5;
L_90175E5:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x90175EFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90175EF:
    TS32((uint32_t)(esi + 0xCCu), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)((uint32_t)0x1u);
    esp += 4; SPILL(); return;
L_90175FF:
    eax = (uint32_t)(logic32(0, &f));
    esp += 4; SPILL(); return;
}

void f_9017610(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017610:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901763F;
    goto L_9017620;
L_9017620:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x58u)));
    ecx = (uint32_t)(esi);
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0x10Cu; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x9028968u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028864u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x901763Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_901763F:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017645u; SPILL(); f_9016810(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9017660(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9017660:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(TL32((uint32_t)(0x903C440u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)((uint32_t)(esi + 0x100u));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(0x903C444u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(0x903C448u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x14000u; esp -= 4; M32(esp) = v_; }
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ebx));
    { uint32_t v_ = 0x9017610u; esp -= 4; M32(esp) = v_; }
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x30u, &f));
    TS8((uint32_t)(eax + 0x8u), (uint8_t)(((uint8_t)ecx)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS8((uint32_t)(esi + 0x107u), (uint8_t)(((uint8_t)edx)));
    esp -= 4; M32(esp) = 0x90176A4u; SPILL(); f_9027170(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90176B5;
    goto L_90176A8;
L_90176A8:
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C44Cu));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90176B5:
    esp -= 4; M32(esp) = 0x90176BAu; SPILL(); f_90011C0(c); RELOAD();
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(ebx);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = TL32((uint32_t)(0x9033028u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    eax = (uint32_t)(esi);
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(edx + 0x9036AA0u)));
    esp -= 4; M32(esp) = 0x90176D2u; SPILL(); f_9027400(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90176E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90176E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(esi + 0x40u));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901771B;
    goto L_90176F4;
L_90176F4:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_901770C;
    goto L_90176FE;
L_90176FE:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x901770Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_901771B;
L_901770C:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_901771B;
    goto L_9017711;
L_9017711:
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031034u)); esp -= 4; M32(esp) = 0x901771Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_901771B:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xC8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xC4u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9017732;
    goto L_901772D;
L_901772D:
    eax = (uint32_t)(add32(eax, (uint32_t)0x180u, &f));
L_9017732:
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFFCu, &f));
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_9017749;
    goto L_9017739;
L_9017739:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(0x903FCD4u), (uint32_t)((uint32_t)0x903C464u));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9017749:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x180u);
    edi = (uint32_t)(sub32(edi, ecx, &f));
    (void)sub32(edi, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_9017779;
    goto L_9017755;
L_9017755:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + ecx*4 + 0xD0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017767u; SPILL(); f_9001FE0(c); RELOAD();
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x8u)), edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    TS32((uint32_t)(esi + 0xC8u), (uint32_t)((uint32_t)0x0u));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
L_9017779:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xC8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + edx*4 + 0xD0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9017791u; SPILL(); f_9001FE0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(esi + 0xC8u), (uint32_t)(add32(TL32((uint32_t)(esi + 0xC8u)), ebx, &f)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x90177AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(add32(esi, (uint32_t)0xC0u, &f));
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(esi)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90177EB;
    goto L_90177C1;
L_90177C1:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_90177DD;
    goto L_90177CA;
L_90177CA:
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031078u)); esp -= 4; M32(esp) = 0x90177D4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90177DD:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_90177EB;
    goto L_90177E1;
L_90177E1:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031048u)); esp -= 4; M32(esp) = 0x90177EBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90177EB:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

