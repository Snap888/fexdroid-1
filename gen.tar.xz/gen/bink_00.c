#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9001000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001000:
    eax = (uint32_t)((uint32_t)0x9033030u);
    esp += 4; SPILL(); return;
}

void f_9001010(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001010:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90312BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90312ACu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90311A4u)); esp -= 4; M32(esp) = 0x900102Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf != f.of)) goto L_9001060;
    goto L_9001030;
L_9001030:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9001040u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((f.sf != f.of)) goto L_9001055;
    goto L_9001049;
L_9001049:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001055:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900105Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_9001060:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001070(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001070:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90010F0;
    goto L_9001077;
L_9001077:
    (void)sub32(esi, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90010F0;
    goto L_900107C;
L_900107C:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9001098;
    goto L_9001085;
L_9001085:
    ecx = (uint32_t)((uint32_t)(esi + 0x40u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900108Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9001098;
    goto L_900108F;
L_900108F:
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90010F0;
    goto L_9001094;
L_9001094:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x3u);
    goto L_90010CA;
L_9001098:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90010B7;
    goto L_90010A1;
L_90010A1:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031060u)); esp -= 4; M32(esp) = 0x90010AEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9036AE0u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90010F0;
    goto L_90010B7;
L_90010B7:
    esi = (uint32_t)(add32(esi, (uint32_t)0x40u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F4u)); esp -= 4; M32(esp) = 0x90010C4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90010F0;
    goto L_90010C8;
L_90010C8:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(logic8(0, &f));
L_90010CA:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1Fu), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)((uint8_t)0x40u);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    esi = (uint32_t)(((uint8_t)ecx));
    eax = (uint32_t)(add32(eax, esi, &f));
    TS8((uint32_t)(eax + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ecx)));
    TS8((uint32_t)(eax + 0xFFFFFFFEu), (uint8_t)(((uint8_t)edx)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)sub8(((uint8_t)edx), (uint8_t)0x3u, &f);
    if (!f.zf) goto L_90010F2;
    goto L_90010E5;
L_90010E5:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE8u)));
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90010F0:
    eax = (uint32_t)(logic32(0, &f));
L_90010F2:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001100(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001100:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9001134;
    goto L_900110A;
L_900110A:
    (void)sub8(TL8((uint32_t)(eax + 0xFFFFFFFEu)), (uint8_t)0x3u, &f);
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0xFFFFFFFFu)));
    if (!f.zf) goto L_9001122;
    goto L_9001114;
L_9001114:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900111Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9001122:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AE0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031064u)); esp -= 4; M32(esp) = 0x9001134u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9001134:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9001140(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001140:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x9040018u);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    fpush(c, (double)(int64_t)M64((uint32_t)(eax)));
    M64((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint64_t)fist64(c, ST(0)); fpop(c);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
L_900115E:
    ebx = (uint32_t)(esi);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x1u, &f));
    ecx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    ecx = (uint32_t)(adc32(ecx, (uint32_t)0x0u, &f));
    eax = (uint32_t)(esi);
    edi = (uint32_t)((uint32_t)0x9040018u);
    { uint64_t exp_ = ((uint64_t)edx << 32) | eax, des_ = ((uint64_t)ecx << 32) | ebx; if (__atomic_compare_exchange_n((uint64_t *)(MEM + (uint32_t)(edi)), &exp_, des_, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)) f.zf = 1; else { f.zf = 0; eax = (uint32_t)exp_; edx = (uint32_t)(exp_ >> 32); } }
    (void)sub32(esi, eax, &f);
    if (!f.zf) goto L_9001181;
    goto L_900117A;
L_900117A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    (void)sub32(ecx, edx, &f);
    if (f.zf) goto L_9001185;
    goto L_9001181;
L_9001181:
    esi = (uint32_t)(eax);
    goto L_900115E;
L_9001185:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(esi);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    edx = (uint32_t)(ecx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001190(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001190:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    (void)sub32(TL32((uint32_t)(ecx)), (uint32_t)0xC000001Du, &f);
    if (!f.zf) goto L_90011B1;
    goto L_90011A0;
L_90011A0:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(eax + 0xB8u), (uint32_t)(add32(TL32((uint32_t)(eax + 0xB8u)), (uint32_t)0x2u, &f)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90011B1:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90011C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90011C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x240u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(0x9036AF4u)), edi, &f);
    if (!f.zf) goto L_9001529;
    goto L_90011E4;
L_90011E4:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC0u));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC0u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFDC0u));
    TS32((uint32_t)(0x9036AF4u), (uint32_t)((uint32_t)0x1u));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(edi);
    { uint32_t t_ = TL32((uint32_t)(0x90310B8u)); esp -= 4; M32(esp) = 0x900120Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9001216;
    goto L_9001211;
L_9001211:
    TS32((uint32_t)(0x9033028u), (uint32_t)(eax));
L_9001216:
    eax = (uint32_t)((uint32_t)0x40u);
    (void)sub32(TL32((uint32_t)(0x9033028u)), eax, &f);
    if ((f.cf || f.zf)) goto L_9001228;
    goto L_9001223;
L_9001223:
    TS32((uint32_t)(0x9033028u), (uint32_t)(eax));
L_9001228:
    { uint32_t v_ = 0x90312CCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90312ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x9001238u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x900123Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
    (void)sub32(ebx, edi, &f);
    if (f.zf) goto L_9001320;
    goto L_9001249;
L_9001249:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edi);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9001253u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9001320;
    goto L_900125E;
L_900125E:
    esp -= 4; M32(esp) = 0x9001263u; SPILL(); f_9001E50(c); RELOAD();
    edi = (uint32_t)(esp);
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_9001320;
    goto L_900126D;
L_900126D:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9001274u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9001320;
    goto L_900127C;
L_900127C:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), (uint32_t)0x18u, &f);
    ebx = (uint32_t)(TL32((uint32_t)(0x9033028u)));
    if (f.cf) goto L_90012E1;
    goto L_9001288;
L_9001288:
    ecx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)((uint32_t)(esp));
L_9001290:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90012B1;
    goto L_9001297;
L_9001297:
    (void)sub32(eax, (uint32_t)0x3u, &f);
    if (!f.zf) goto L_90012D0;
    goto L_900129C;
L_900129C:
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_90012D0;
    goto L_90012A5;
L_90012A5:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(esi), (uint32_t)(eax));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    goto L_90012D0;
L_90012B1:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    (void)sub32(eax, ebx, &f);
    if (!f.cf) goto L_90012D0;
    goto L_90012BA;
L_90012BA:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(eax), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x9033028u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
L_90012D0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x18u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x18u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    (void)sub32(eax, (uint32_t)0x18u, &f);
    if (!f.cf) goto L_9001290;
    goto L_90012E1;
L_90012E1:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDC0u));
    esi = (uint32_t)(sub32(esi, edx, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    ecx = (uint32_t)((uint32_t)(ebx + 0x9036A9Fu));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)((uint32_t)0x9036AA0u);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
    if (!f.sf) goto L_900144F;
    goto L_9001308;
L_9001308:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC0u));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f);
    if (!f.zf) goto L_9001423;
    goto L_9001320;
L_9001320:
    esi = (uint32_t)(TL32((uint32_t)(0x9031058u)));
    { uint32_t v_ = 0x9001190u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x0u);
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9001334u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x0u);
    eax = (uint32_t)((uint32_t)0x1u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x900134Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1Cu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    if (f.zf) goto L_90013F7;
    goto L_900135C;
L_900135C:
    eax = (uint32_t)(TL32((uint32_t)(0x9033028u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x9036AA0u);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
    TS32((uint32_t)(0x9036AF0u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9001385;
    goto L_9001377;
L_9001377:
    eax = (uint32_t)(dec32(eax, &f));
    esi = (uint32_t)((uint32_t)0x9036AA1u);
    TS8((uint32_t)(0x9036AA0u), (uint8_t)(((uint8_t)eax)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
L_9001385:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f);
    if (!f.zf) goto L_90013BD;
    goto L_900138D;
L_900138D:
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x0u);
    if (f.zf) goto L_90013D4;
    goto L_9001398;
L_9001398:
    ebx = (uint32_t)((uint32_t)(edi + esi));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(sub32(edx, ebx, &f));
L_90013A0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    esi = (uint32_t)(add32(esi, edi, &f));
    esi = (uint32_t)(add32(esi, eax, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)ebx), &f));
    TS8((uint32_t)(edx + esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    (void)sub32(eax, edi, &f);
    if (f.cf) goto L_90013A0;
    goto L_90013BB;
L_90013BB:
    goto L_90013D4;
L_90013BD:
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_90013CF;
    goto L_90013C3;
L_90013C3:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)edx), &f));
    TS8((uint32_t)(eax + esi), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_90013C3;
    goto L_90013CF;
L_90013CF:
    TS8((uint32_t)(ecx + esi + 0xFFFFFFFFu), (uint8_t)((uint8_t)0x0u));
L_90013D4:
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_9001419;
    goto L_90013DA;
L_90013DA:
    esi = (uint32_t)(add32(esi, ecx, &f));
    edi = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
L_90013E0:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(esi + eax), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(dec32(edi, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_90013E0;
    goto L_90013ED;
L_90013ED:
    eax = (uint32_t)((uint32_t)0x1u);
    goto L_900152B;
L_90013F7:
    ecx = (uint32_t)(TL32((uint32_t)(0x9033028u)));
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_9001412;
    goto L_9001403;
L_9001403:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(inc8(((uint8_t)edx), &f));
    TS8((uint32_t)(eax + 0x9036AA0u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_9001403;
    goto L_9001412;
L_9001412:
    TS8((uint32_t)(ecx + 0x9036A9Fu), (uint8_t)((uint8_t)0x0u));
L_9001419:
    eax = (uint32_t)((uint32_t)0x1u);
    goto L_900152B;
L_9001423:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC0u));
    ecx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(ebp + 0xFFFFFDC0u)) = (uint32_t)(ecx);
    (void)sub32(esi, edx, &f);
    if (!f.cf) goto L_900144F;
    goto L_900143E;
L_900143E:
    edi = (uint32_t)(edi);
L_9001440:
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(eax))), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_9001440;
    goto L_9001449;
L_9001449:
    M32((uint32_t)(ebp + 0xFFFFFDC0u)) = (uint32_t)(ecx);
L_900144F:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    TS32((uint32_t)(0x9036AF0u), (uint32_t)((uint32_t)0x0u));
    edi = (uint32_t)((uint32_t)(ebp + edi*4 + 0xFFFFFDC0u));
L_9001463:
    ebx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
L_9001468:
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90014BA;
    goto L_900146E;
L_900146E:
    esi = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(ebx);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(esi & eax), &f);
    if (f.zf) goto L_90014B1;
    goto L_900147B;
L_900147B:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFECu)), ecx, &f);
    if ((!f.cf && !f.zf)) goto L_900148C;
    goto L_9001483;
L_9001483:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
L_900148C:
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(~ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & ecx), &f));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC0u));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    ebx = (uint32_t)(edx);
    (void)sub32(ebx, eax, &f);
    if (!f.cf) goto L_90014AE;
    goto L_90014A3;
L_90014A3:
    (void)logic32((uint32_t)(TL32((uint32_t)(edx)) & esi), &f);
    if (!f.zf) goto L_90014E1;
    goto L_90014A7;
L_90014A7:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    (void)sub32(edx, eax, &f);
    if (f.cf) goto L_90014A3;
    goto L_90014AE;
L_90014AE:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
L_90014B1:
    ebx = (uint32_t)(inc32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    (void)sub32(ebx, (uint32_t)0x20u, &f);
    if (f.cf) goto L_9001468;
    goto L_90014BA;
L_90014BA:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(dec32(eax, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_9001463;
    goto L_90014C8;
L_90014C8:
    eax = (uint32_t)((uint32_t)0x40u);
    (void)sub32(TL32((uint32_t)(0x9036AF0u)), eax, &f);
    if ((f.cf || f.zf)) goto L_90014DA;
    goto L_90014D5;
L_90014D5:
    TS32((uint32_t)(0x9036AF0u), (uint32_t)(eax));
L_90014DA:
    eax = (uint32_t)((uint32_t)0x1u);
    goto L_900152B;
L_90014E1:
    TS32((uint32_t)(edx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edx)) & ecx), &f)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)((uint32_t)0x1Fu);
    (void)sub32(ebx, ecx, &f);
    if (!f.cf) goto L_90014B1;
    goto L_90014EF;
L_90014EF:
L_90014F0:
    esi = (uint32_t)(TL32((uint32_t)(edx)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90014B1;
    goto L_90014F6;
L_90014F6:
    eax = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    (void)logic32((uint32_t)(esi & eax), &f);
    if (f.zf) goto L_9001522;
    goto L_9001501;
L_9001501:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFECu)), ebx, &f);
    if ((!f.cf && !f.zf)) goto L_900150F;
    goto L_9001509;
L_9001509:
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(dec32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ebx);
L_900150F:
    TS32((uint32_t)(0x9036AF0u), (uint32_t)(inc32(TL32((uint32_t)(0x9036AF0u)), &f)));
    eax = (uint32_t)(~eax);
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & esi), &f));
    TS32((uint32_t)(edi), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edi)) & eax), &f)));
    TS32((uint32_t)(edx), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
L_9001522:
    ecx = (uint32_t)(dec32(ecx, &f));
    (void)sub32(ecx, ebx, &f);
    if ((!f.cf && !f.zf)) goto L_90014F0;
    goto L_9001527;
L_9001527:
    goto L_90014B1;
L_9001529:
    eax = (uint32_t)(logic32(0, &f));
L_900152B:
    esp = (uint32_t)((uint32_t)(ebp + 0xFFFFFDB4u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x900153Eu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001550(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001550:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7) | (c->df << 10) | (f.of << 11) | 0x200 | c->eflags_hi;
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax ^ (uint32_t)0x200000u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    esp -= 4; M32(esp) = f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7) | (c->df << 10) | (f.of << 11) | 0x200 | c->eflags_hi;
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32(esp); esp += 4; f.cf = v_ & 1; f.pf = (v_ >> 2) & 1; f.zf = (v_ >> 6) & 1; f.sf = (v_ >> 7) & 1; c->df = (v_ >> 10) & 1; f.of = (v_ >> 11) & 1; c->eflags_hi = v_ & 0x00200000u; }
    (void)sub32(eax, ebx, &f);
    if (f.zf) goto L_90015BD;
    goto L_9001570;
L_9001570:
    eax = (uint32_t)((uint32_t)0x1u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    (void)logic32((uint32_t)(edx & (uint32_t)0x800000u), &f);
    if (f.zf) goto L_90015BD;
    goto L_900157F;
L_900157F:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)) | (uint32_t)0x1u), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    (void)logic32((uint32_t)(edx & (uint32_t)0x2000000u), &f);
    if (f.zf) goto L_900159C;
    goto L_900158C;
L_900158C:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)) | (uint32_t)0x4u), &f));
    (void)logic32((uint32_t)(edx & (uint32_t)0x4000000u), &f);
    if (f.zf) goto L_900159C;
    goto L_9001598;
L_9001598:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)) | (uint32_t)0x8u), &f));
L_900159C:
    eax = (uint32_t)((uint32_t)0x80000000u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    (void)sub32(eax, (uint32_t)0x80000000u, &f);
    if ((f.cf || f.zf)) goto L_90015BD;
    goto L_90015AA;
L_90015AA:
    eax = (uint32_t)((uint32_t)0x80000001u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    (void)logic32((uint32_t)(edx & (uint32_t)0x80000000u), &f);
    if (f.zf) goto L_90015BD;
    goto L_90015B9;
L_90015B9:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)) | (uint32_t)0x2u), &f));
L_90015BD:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90015D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90015D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_900170A;
    goto L_90015E5;
L_90015E5:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(dec32(eax, &f));
    (void)sub32(eax, (uint32_t)0x5u, &f);
    if ((!f.cf && !f.zf)) goto L_900170A;
    goto L_90015F7;
L_90015F7:
    { jt_ = TL32((uint32_t)(eax*4 + 0x9001714u)); goto L_dispatch; }
L_90015FE:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
L_9001608:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9001613u; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x90083B0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008450u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    goto L_9001692;
L_900163D:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    goto L_9001608;
L_9001649:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    goto L_900165F;
L_9001655:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
L_900165F:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x900166Au; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x90085F0u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008510u));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x3u));
L_9001692:
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008000u));
    esp -= 4; M32(esp) = 0x9001700u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900170A:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90015D0u: goto L_90015D0; case 0x90015E5u: goto L_90015E5; case 0x90015F7u: goto L_90015F7; case 0x90015FEu: goto L_90015FE; case 0x9001608u: goto L_9001608; case 0x900163Du: goto L_900163D; case 0x9001649u: goto L_9001649; case 0x9001655u: goto L_9001655; case 0x900165Fu: goto L_900165F; case 0x9001692u: goto L_9001692; case 0x900170Au: goto L_900170A; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9001730(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001730:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_9001748;
    goto L_9001741;
L_9001741:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001748:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9001741;
    goto L_900174E;
L_900174E:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x5u, &f));
    if (f.zf) goto L_9001769;
    goto L_900175B;
L_900175B:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9001741;
    goto L_9001760;
L_9001760:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    goto L_9001773;
L_9001769:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
L_9001773:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x900177Eu; SPILL(); f_901CE90(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x90083B0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008450u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x90086F0u));
    esp -= 4; M32(esp) = 0x9001814u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001820(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001820:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (f.zf) goto L_9001901;
    goto L_9001835;
L_9001835:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFF9u, &f));
    (void)sub32(eax, (uint32_t)0x5u, &f);
    if ((!f.cf && !f.zf)) goto L_9001901;
    goto L_9001849;
L_9001849:
    { jt_ = TL32((uint32_t)(eax*4 + 0x9001908u)); goto L_dispatch; }
L_9001850:
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_90018A5;
L_9001863:
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_90018A5;
L_9001876:
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_900189F;
L_9001883:
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_90018A3;
L_9001894:
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x6u);
L_900189F:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xBu; esp -= 4; M32(esp) = v_; }
L_90018A3:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
L_90018A5:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x90018ACu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006370u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006420u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006000u));
    esp -= 4; M32(esp) = 0x90018F7u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001901:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9001820u: goto L_9001820; case 0x9001835u: goto L_9001835; case 0x9001849u: goto L_9001849; case 0x9001850u: goto L_9001850; case 0x9001863u: goto L_9001863; case 0x9001876u: goto L_9001876; case 0x9001883u: goto L_9001883; case 0x9001894u: goto L_9001894; case 0x900189Fu: goto L_900189F; case 0x90018A3u: goto L_90018A3; case 0x90018A5u: goto L_90018A5; case 0x9001901u: goto L_9001901; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9001920(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001920:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_9001938;
    goto L_9001931;
L_9001931:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001938:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9001931;
    goto L_900193E;
L_900193E:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x7u, &f));
    if (f.zf) goto L_9001961;
    goto L_900194B;
L_900194B:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9001931;
    goto L_9001950;
L_9001950:
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(eax + 0x5u));
    goto L_9001972;
L_9001961:
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
L_9001972:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9001979u; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006370u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006420u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006520u));
    esp -= 4; M32(esp) = 0x90019C4u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90019D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90019D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90019E0;
    goto L_90019DC;
L_90019DC:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90019E0:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xFu), &f);
    if (f.zf) goto L_90019EE;
    goto L_90019E9;
L_90019E9:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90019EE:
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x6u);
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(eax + 0xFFFFFFFDu));
    esp -= 4; M32(esp) = 0x9001A07u; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(ebx);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9005370u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9005400u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9005000u));
    esp -= 4; M32(esp) = 0x9001A52u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001A60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001A60:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9001A70;
    goto L_9001A6C;
L_9001A6C:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001A70:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0xDu, &f));
    if (f.zf) goto L_9001A98;
    goto L_9001A7D;
L_9001A7D:
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9001A6C;
    goto L_9001A82;
L_9001A82:
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9004000u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9004130u));
    goto L_9001AAC;
L_9001A98:
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9004260u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9004390u));
L_9001AAC:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x90044C0u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x9001ADEu; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001AF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001AF0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    (void)sub8(((uint8_t)eax), (uint8_t)0xFu, &f);
    if (f.zf) goto L_9001B03;
    goto L_9001AFF;
L_9001AFF:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9001B03:
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x70000000u), &f));
    eax = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x9030AACu), (uint32_t)(eax));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)(edx));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)(edx));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(edx));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x30000000u, &f);
    if (f.zf) goto L_9001B51;
    goto L_9001B35;
L_9001B35:
    (void)sub32(ecx, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_9001B51;
    goto L_9001B3D;
L_9001B3D:
    (void)sub32(ecx, (uint32_t)0x50000000u, &f);
    if (f.zf) goto L_9001B51;
    goto L_9001B45;
L_9001B45:
    edx = (uint32_t)((uint32_t)0x9003000u);
    TS32((uint32_t)(0x9030AB8u), (uint32_t)(eax));
    goto L_9001B60;
L_9001B51:
    edx = (uint32_t)((uint32_t)0x9003150u);
    TS32((uint32_t)(0x9030AB8u), (uint32_t)((uint32_t)0x2u));
L_9001B60:
    TS32((uint32_t)(0x9030AA4u), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x10000000u, &f);
    if (f.zf) goto L_9001B7C;
    goto L_9001B6E;
L_9001B6E:
    TS32((uint32_t)(0x9030A98u), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x40000000u, &f);
    if (!f.zf) goto L_9001B86;
    goto L_9001B7C;
L_9001B7C:
    TS32((uint32_t)(0x9030A98u), (uint32_t)((uint32_t)0x901D4A0u));
L_9001B86:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001B90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001B90:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    if (!f.zf) goto L_9001BB0;
    goto L_9001B9C;
L_9001B9C:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    esp += 20; SPILL(); return;
L_9001BB0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x8u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(add32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * M32((uint32_t)(esp + 0x4u)); eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    esp += 20; SPILL(); return;
}

void f_9001BD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001BD0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
    if (!f.zf) goto L_9001C00;
    goto L_9001BDE;
L_9001BDE:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_9001CE0;
    goto L_9001BEE;
L_9001BEE:
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(logic32(0, &f));
    esp += 20; SPILL(); return;
L_9001C00:
    (void)sub32(edx, ecx, &f);
    if (f.cf) goto L_9001CE0;
    goto L_9001C08;
L_9001C08:
    (void)sub32(ecx, (uint32_t)0xFu, &f);
    if ((!f.cf && !f.zf)) goto L_9001C51;
    goto L_9001C0D;
L_9001C0D:
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ecx), &f));
    if (f.zf) goto L_9001CF0;
    goto L_9001C15;
L_9001C15:
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp)) = (uint32_t)(ebx);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(rcr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(rcr32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ecx), &f));
    if (f.zf) goto L_9001C78;
    goto L_9001C2F;
L_9001C2F:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(rcr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(rcr32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ecx), &f));
    if (f.zf) goto L_9001C78;
    goto L_9001C3B;
L_9001C3B:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(rcr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(rcr32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ecx), &f));
    if (f.zf) goto L_9001C78;
    goto L_9001C47;
L_9001C47:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    ebx = (uint32_t)(rcr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(rcr32(eax, (uint8_t)0x1u, &f));
    goto L_9001C78;
L_9001C51:
    eax = (uint32_t)(edx);
    edx = (uint32_t)(logic32(0, &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp)) = (uint32_t)(ebx);
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    if (f.cf) goto L_9001C78;
    goto L_9001C61;
L_9001C61:
    { uint32_t v_ = ecx; f.zf = v_ == 0; if (v_) { ecx = (uint32_t)(31 - __builtin_clz(v_)); } }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    edx = (uint32_t)(shrd32(edx, ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(shrd32(eax, edx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
L_9001C78:
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ebx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint64_t r_ = (uint64_t)eax * ebx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(logic32((uint32_t)(edx | edx), &f));
    if (!f.zf) goto L_9001CD0;
    goto L_9001C8A;
L_9001C8A:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint64_t r_ = (uint64_t)eax * ebx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(add32(edx, ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(sbb32(ebx, edx, &f));
    if (f.sf) goto L_9001CD0;
    goto L_9001CA2;
L_9001CA2:
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0x1Cu)), &f));
    ebx = (uint32_t)(sbb32(ebx, M32((uint32_t)(esp + 0x20u)), &f));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    if (!f.cf) goto L_9001CC0;
    goto L_9001CB0;
L_9001CB0:
    edx = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(M32((uint32_t)(esp)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    esp += 20; SPILL(); return;
L_9001CC0:
    eax = (uint32_t)(inc32(eax, &f));
    edx = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(M32((uint32_t)(esp)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    esp += 20; SPILL(); return;
L_9001CD0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    edx = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(M32((uint32_t)(esp)));
    eax = (uint32_t)(dec32(eax, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    esp += 20; SPILL(); return;
L_9001CE0:
    eax = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32(0, &f));
    esp += 20; SPILL(); return;
L_9001CF0:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

void f_9001D3B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001D3B:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001D3D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001D3D:
    goto L_9001D4F;
L_9001D4F:
    SPILL(); rt_int3(c, 0x9001D4Fu);
    { SPILL(); f_9001D50(c); return; }
}

void f_9001D50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9001D50;
L_9001D10:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2011u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x903128Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031218u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9001D2Fu; SPILL(); f_900226E(c); RELOAD();
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_9001D3F;
    goto L_9001D34;
L_9001D34:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    SPILL(); rt_int3(c, 0x9001D3Au);
    { SPILL(); f_9001D3B(c); return; }
L_9001D3F:
    { uint32_t v_ = 0xFFu; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9001D49u; SPILL(); f_9002286(c); RELOAD();
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9001D4Fu; SPILL(); f_9002280(c); RELOAD();
    SPILL(); rt_int3(c, 0x9001D4Fu);
L_9001D50:
    (void)sub32(ecx, TL32((uint32_t)(0x9033000u)), &f);
    if (!f.zf) goto L_9001D5A;
    goto L_9001D58;
L_9001D58:
    esp += 4; SPILL(); return;
L_9001D5A:
    goto L_9001D10;
}

void f_9001D60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001D60:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(0x9033004u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9001DFF;
    goto L_9001D73;
L_9001D73:
    TS32((uint32_t)(0x9033004u), (uint32_t)((uint32_t)0x0u));
    { uint64_t t_ = rt_rdtsc(); eax = (uint32_t)t_; edx = (uint32_t)(t_ >> 32); }
    eax = (uint32_t)(rol32(eax, (uint8_t)0x3u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    edx = (uint32_t)(rol32(edx, (uint8_t)0x11u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ edx), &f)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9001D9Au; SPILL(); f_9002274(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(rol32(eax, (uint8_t)0x5u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(rol32(eax, (uint8_t)0xFu, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    eax = (uint32_t)(M32((uint32_t)(0x20u + c->fs_base)));
    eax = (uint32_t)(rol32(eax, (uint8_t)0x9u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    eax = (uint32_t)(M32((uint32_t)(0x24u + c->fs_base)));
    eax = (uint32_t)(rol32(eax, (uint8_t)0xBu, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    esp -= 4; M32(esp) = 0x9001DD5u; SPILL(); f_900227A(c); RELOAD();
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    goto L_9001DE0;
L_9001DE0:
    { uint64_t t_ = rt_rdtsc(); eax = (uint32_t)t_; edx = (uint32_t)(t_ >> 32); }
    eax = (uint32_t)(rol32(eax, (uint8_t)0x9u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ eax), &f)));
    eax = (uint32_t)(rol32(eax, (uint8_t)0x17u, &f));
    TS32((uint32_t)(0x9033000u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(0x9033000u)) ^ edx), &f)));
    ecx = (uint32_t)(TL16((uint32_t)(0x9033000u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9001DE0;
    goto L_9001DFF;
L_9001DFF:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001E10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001E10:
    (void)sub32(eax, (uint32_t)0x1000u, &f);
    if (!f.cf) goto L_9001E25;
    goto L_9001E17;
L_9001E17:
    eax = (uint32_t)(neg32(eax, &f));
    eax = (uint32_t)(add32(eax, esp, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax)) & eax), &f);
    { uint32_t t_ = esp; esp = (uint32_t)(eax); eax = (uint32_t)(t_); }
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
L_9001E25:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x8u));
L_9001E2A:
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1000u, &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1000u, &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ecx)) & eax), &f);
    (void)sub32(eax, (uint32_t)0x1000u, &f);
    if (!f.cf) goto L_9001E2A;
    goto L_9001E3E;
L_9001E3E:
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(esp);
    (void)logic32((uint32_t)(TL32((uint32_t)(ecx)) & eax), &f);
    esp = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_9001E50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001E50:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x8u));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    ecx = (uint32_t)(sbb32(ecx, ecx, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { SPILL(); f_9001E10(c); return; }
}

void f_9001EA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9001EA0;
L_9001E70:
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M16((uint32_t)(esp)) = c->fpu_cw;
    eax = (uint32_t)(M32((uint32_t)(esp)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xC00u), &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(eax);
    c->fpu_cw = M16((uint32_t)(esp + 0x4u));
    M64((uint32_t)(esp + 0x8u)) = (uint64_t)fist64(c, ST(0)); fpop(c);
    c->fpu_cw = M16((uint32_t)(esp));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    esp += 4; SPILL(); return;
L_9001EA0:
    goto L_9001E70;
}

void f_9001EB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001EB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M8((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esi = (uint32_t)(eax);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(ecx);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    (void)sub32(ecx, (uint32_t)0x100u, &f);
    if ((!f.cf && !f.zf)) goto L_9001F00;
    goto L_9001EDB;
L_9001EDB:
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    (void)sub32(edx, ecx, &f);
    if (f.cf) goto L_9001EF7;
    goto L_9001EE9;
L_9001EE9:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    while (ecx) { M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1); ecx--; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
L_9001EF7:
    ecx = (uint32_t)(edx);
    while (ecx) { M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1); ecx--; }
    goto L_9001FD1;
L_9001F00:
    (void)sub32(TL32((uint32_t)(0x9036A88u)), (uint32_t)0x0u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9001F2A;
    goto L_9001F09;
L_9001F09:
    if ((f.sf != f.of)) goto L_9001EDB;
    goto L_9001F0B;
L_9001F0B:
    esi = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)0x1u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x18u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x2u), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    TS32((uint32_t)(0x9036A88u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(esi);
    if ((f.sf != f.of)) goto L_9001EDB;
    goto L_9001F2A;
L_9001F2A:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x80u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (uint32_t)(ebx);
    while (ecx) { M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1); ecx--; }
    c->xmm[0].u[0] = M32((uint32_t)(esp)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    { Xmm d_ = c->xmm[0], s_ = c->xmm[0]; c->xmm[0].u[0] = d_.u[0]; c->xmm[0].u[1] = d_.u[0]; c->xmm[0].u[2] = s_.u[0]; c->xmm[0].u[3] = s_.u[0]; }
    (void)sub32(edx, TL32((uint32_t)(0x903301Cu)), &f);
    if (!f.cf) goto L_9001F90;
    goto L_9001F5D;
L_9001F5D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9001F60:
    memcpy(MEM + (uint32_t)(edi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x10u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x20u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x30u), &c->xmm[0], 16);
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + 0x40u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x50u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x60u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x70u), &c->xmm[0], 16);
    edi = (uint32_t)((uint32_t)(edi + 0x80u));
    if ((f.sf == f.of)) goto L_9001F60;
    goto L_9001F8D;
L_9001F8D:
    goto L_9001FBD;
L_9001F90:
    memcpy(MEM + (uint32_t)(edi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x10u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x20u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x30u), &c->xmm[0], 16);
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + 0x40u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x50u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x60u), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + 0x70u), &c->xmm[0], 16);
    edi = (uint32_t)((uint32_t)(edi + 0x80u));
    if ((f.sf == f.of)) goto L_9001F90;
    goto L_9001FBD;
L_9001FBD:
    edx = (uint32_t)(add32(edx, (uint32_t)0x80u, &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
    ecx = (uint32_t)(edx);
    while (ecx) { M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1); ecx--; }
L_9001FD1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9001FE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9001FE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9002238;
    goto L_9001FF1;
L_9001FF1:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(esi, edi, &f);
    if (f.zf) goto L_9002238;
    goto L_9001FFF;
L_9001FFF:
    edx = (uint32_t)(ecx);
    (void)sub32(ecx, (uint32_t)0x100u, &f);
    if ((!f.cf && !f.zf)) goto L_900202E;
    goto L_9002009;
L_9002009:
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    (void)sub32(edx, ecx, &f);
    if (f.cf) goto L_9002025;
    goto L_9002017;
L_9002017:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    while (ecx) { M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1); ecx--; }
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
L_9002025:
    ecx = (uint32_t)(edx);
    while (ecx) { M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1); ecx--; }
    goto L_9002238;
L_900202E:
    (void)sub32(TL32((uint32_t)(0x9036A88u)), (uint32_t)0x0u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9002054;
    goto L_9002037;
L_9002037:
    if ((f.sf != f.of)) goto L_9002009;
    goto L_9002039;
L_9002039:
    eax = (uint32_t)((uint32_t)0x1u);
    rt_cpuid(c, &eax, &ebx, &ecx, &edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x18u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x2u), &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    TS32((uint32_t)(0x9036A88u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    if ((f.sf != f.of)) goto L_9002009;
    goto L_9002054;
L_9002054:
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    while (ecx) { M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1); ecx--; }
    ecx = (uint32_t)((uint32_t)0x80u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    edi = (uint32_t)(sub32(edi, esi, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    (void)logic32((uint32_t)(esi & (uint32_t)0xFu), &f);
    if (!f.zf) goto L_9002157;
    goto L_9002087;
L_9002087:
    (void)sub32(edx, TL32((uint32_t)(0x9033018u)), &f);
    if (!f.cf) goto L_90020F0;
    goto L_900208F;
L_900208F:
L_9002090:
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(esi)));
    c->xmm[1] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x10u)));
    c->xmm[2] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x20u)));
    c->xmm[3] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x30u)));
    memcpy(MEM + (uint32_t)(edi + esi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x10u), &c->xmm[1], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x20u), &c->xmm[2], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x30u), &c->xmm[3], 16);
    c->xmm[4] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x40u)));
    c->xmm[5] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x50u)));
    c->xmm[6] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x60u)));
    c->xmm[7] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x70u)));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + esi + 0x40u), &c->xmm[4], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x50u), &c->xmm[5], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x60u), &c->xmm[6], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x70u), &c->xmm[7], 16);
    esi = (uint32_t)((uint32_t)(esi + 0x80u));
    if ((f.sf == f.of)) goto L_9002090;
    goto L_90020E4;
L_90020E4:
    goto L_9002222;
L_90020F0:
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(esi)));
    c->xmm[1] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x10u)));
    c->xmm[2] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x20u)));
    c->xmm[3] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x30u)));
    c->xmm[4] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x40u)));
    c->xmm[5] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x50u)));
    c->xmm[6] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x60u)));
    c->xmm[7] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x70u)));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + esi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x10u), &c->xmm[1], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x20u), &c->xmm[2], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x30u), &c->xmm[3], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x40u), &c->xmm[4], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x50u), &c->xmm[5], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x60u), &c->xmm[6], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x70u), &c->xmm[7], 16);
    esi = (uint32_t)((uint32_t)(esi + 0x80u));
    if ((f.sf == f.of)) goto L_90020F0;
    goto L_9002152;
L_9002152:
    goto L_9002222;
L_9002157:
    (void)sub32(edx, TL32((uint32_t)(0x9033018u)), &f);
    if (!f.cf) goto L_90021C0;
    goto L_900215F;
L_900215F:
L_9002160:
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(esi)));
    c->xmm[1] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x10u)));
    c->xmm[2] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x20u)));
    c->xmm[3] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x30u)));
    memcpy(MEM + (uint32_t)(edi + esi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x10u), &c->xmm[1], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x20u), &c->xmm[2], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x30u), &c->xmm[3], 16);
    c->xmm[4] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x40u)));
    c->xmm[5] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x50u)));
    c->xmm[6] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x60u)));
    c->xmm[7] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x70u)));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + esi + 0x40u), &c->xmm[4], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x50u), &c->xmm[5], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x60u), &c->xmm[6], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x70u), &c->xmm[7], 16);
    esi = (uint32_t)((uint32_t)(esi + 0x80u));
    if ((f.sf == f.of)) goto L_9002160;
    goto L_90021B4;
L_90021B4:
    goto L_9002222;
L_90021C0:
    c->xmm[0] = (*(Xmm *)(MEM + (uint32_t)(esi)));
    c->xmm[1] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x10u)));
    c->xmm[2] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x20u)));
    c->xmm[3] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x30u)));
    c->xmm[4] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x40u)));
    c->xmm[5] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x50u)));
    c->xmm[6] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x60u)));
    c->xmm[7] = (*(Xmm *)(MEM + (uint32_t)(esi + 0x70u)));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x80u, &f));
    memcpy(MEM + (uint32_t)(edi + esi), &c->xmm[0], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x10u), &c->xmm[1], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x20u), &c->xmm[2], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x30u), &c->xmm[3], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x40u), &c->xmm[4], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x50u), &c->xmm[5], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x60u), &c->xmm[6], 16);
    memcpy(MEM + (uint32_t)(edi + esi + 0x70u), &c->xmm[7], 16);
    esi = (uint32_t)((uint32_t)(esi + 0x80u));
    if ((f.sf == f.of)) goto L_90021C0;
    goto L_9002222;
L_9002222:
    edi = (uint32_t)(add32(edi, esi, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x80u, &f));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    ecx = (uint32_t)(edx);
    while (ecx) { M8(edi) = M8(esi); esi += (c->df ? -1 : 1); edi += (c->df ? -1 : 1); ecx--; }
L_9002238:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9002240(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002240:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_900225C;
    goto L_9002250;
L_9002250:
    esp -= 4; M32(esp) = 0x9002255u; SPILL(); f_9001D60(c); RELOAD();
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310F0u)); esp -= 4; M32(esp) = 0x900225Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900225C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9002267u; SPILL(); f_900A000(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900226E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900226E:
    { SPILL(); rt_call(c, M32(0x9031168u)); return; }
}

void f_9002274(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002274:
    { SPILL(); rt_call(c, M32(0x9031150u)); return; }
}

void f_900227A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900227A:
    { SPILL(); rt_call(c, M32(0x90310C8u)); return; }
}

void f_9002280(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002280:
    { SPILL(); rt_call(c, M32(0x90310E8u)); return; }
}

void f_9002286(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002286:
    { SPILL(); rt_call(c, M32(0x90310ECu)); return; }
}

void f_900228C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900228C:
    eax = (uint32_t)((uint32_t)0x9036A30u);
    goto L_9002296;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x900228Cu: goto L_900228C; case 0x9002296u: goto L_9002296; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022A7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022A7:
    { jt_ = TL32((uint32_t)(0x9036A30u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022A7u: goto L_90022A7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022AD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022AD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022AD:
    eax = (uint32_t)((uint32_t)0x9036A34u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022ADu: goto L_90022AD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022B7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022B7:
    { jt_ = TL32((uint32_t)(0x9036A34u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022B7u: goto L_90022B7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022BD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022BD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022BD:
    eax = (uint32_t)((uint32_t)0x9036A38u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022BDu: goto L_90022BD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022C7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022C7:
    { jt_ = TL32((uint32_t)(0x9036A38u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022C7u: goto L_90022C7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022CD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022CD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022CD:
    eax = (uint32_t)((uint32_t)0x9036A3Cu);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022CDu: goto L_90022CD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022D7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022D7:
    { jt_ = TL32((uint32_t)(0x9036A3Cu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022D7u: goto L_90022D7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022DD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022DD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022DD:
    eax = (uint32_t)((uint32_t)0x9036A40u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022DDu: goto L_90022DD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022E7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022E7:
    { jt_ = TL32((uint32_t)(0x9036A40u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022E7u: goto L_90022E7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022ED(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022ED;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022ED:
    eax = (uint32_t)((uint32_t)0x9036A44u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022EDu: goto L_90022ED; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022F7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90022F7:
    { jt_ = TL32((uint32_t)(0x9036A44u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90022F7u: goto L_90022F7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90022FD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90022FD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90022FD:
    eax = (uint32_t)((uint32_t)0x9036A48u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90022FDu: goto L_90022FD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002307(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002307:
    { jt_ = TL32((uint32_t)(0x9036A48u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002307u: goto L_9002307; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900230D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900230D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900230D:
    eax = (uint32_t)((uint32_t)0x9036A4Cu);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900230Du: goto L_900230D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002317(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002317:
    { jt_ = TL32((uint32_t)(0x9036A4Cu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002317u: goto L_9002317; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900231D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900231D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900231D:
    eax = (uint32_t)((uint32_t)0x9036A50u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900231Du: goto L_900231D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002327(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002327:
    { jt_ = TL32((uint32_t)(0x9036A50u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002327u: goto L_9002327; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900232D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900232D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900232D:
    eax = (uint32_t)((uint32_t)0x9036A54u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900232Du: goto L_900232D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002337(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002337:
    { jt_ = TL32((uint32_t)(0x9036A54u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002337u: goto L_9002337; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900233D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900233D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900233D:
    eax = (uint32_t)((uint32_t)0x9036A58u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900233Du: goto L_900233D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002347(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002347:
    { jt_ = TL32((uint32_t)(0x9036A58u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002347u: goto L_9002347; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900234D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900234D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900234D:
    eax = (uint32_t)((uint32_t)0x9036A5Cu);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900234Du: goto L_900234D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002357(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002357:
    { jt_ = TL32((uint32_t)(0x9036A5Cu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002357u: goto L_9002357; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900235D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900235D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900235D:
    eax = (uint32_t)((uint32_t)0x9036A60u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900235Du: goto L_900235D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002367(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002367:
    { jt_ = TL32((uint32_t)(0x9036A60u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002367u: goto L_9002367; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900236D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900236D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900236D:
    eax = (uint32_t)((uint32_t)0x9036A64u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900236Du: goto L_900236D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002377(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002377:
    { jt_ = TL32((uint32_t)(0x9036A64u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002377u: goto L_9002377; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900237D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900237D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900237D:
    eax = (uint32_t)((uint32_t)0x9036A68u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900237Du: goto L_900237D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002387(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002387:
    { jt_ = TL32((uint32_t)(0x9036A68u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002387u: goto L_9002387; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900238D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900238D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900238D:
    eax = (uint32_t)((uint32_t)0x9036A6Cu);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900238Du: goto L_900238D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9002397(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9002397:
    { jt_ = TL32((uint32_t)(0x9036A6Cu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9002397u: goto L_9002397; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900239D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_900239D;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_900239D:
    eax = (uint32_t)((uint32_t)0x9036A70u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x900239Du: goto L_900239D; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023A7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90023A7:
    { jt_ = TL32((uint32_t)(0x9036A70u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90023A7u: goto L_90023A7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023AD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90023AD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90023AD:
    eax = (uint32_t)((uint32_t)0x9036A74u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90023ADu: goto L_90023AD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023B7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90023B7:
    { jt_ = TL32((uint32_t)(0x9036A74u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90023B7u: goto L_90023B7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023BD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90023BD;
L_9002296:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9031338u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90022A3u; SPILL(); f_90023CD(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { jt_ = eax; goto L_dispatch; }
L_90023BD:
    eax = (uint32_t)((uint32_t)0x9036A78u);
    goto L_9002296;
L_dispatch:
    switch (jt_) { case 0x9002296u: goto L_9002296; case 0x90023BDu: goto L_90023BD; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023C7(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90023C7:
    { jt_ = TL32((uint32_t)(0x9036A78u)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x90023C7u: goto L_90023C7; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90023CD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90023CD:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x44u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)0x9000000u);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(add32(edx, eax, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(add32(ebx, eax, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(esi)) & (uint32_t)0x1u), &f);
    edi = (uint32_t)((uint32_t)(ebp + 0xFFFFFFD0u));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)((uint32_t)0x24u);
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(ecx);
    M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4);
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ecx);
    if (!f.zf) goto L_9002453;
    goto L_9002434;
L_9002434:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xC06D0057u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031038u)); esp -= 4; M32(esp) = 0x900244Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(logic32(0, &f));
    goto L_9002603;
L_9002453:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(sub32(eax, ebx, &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x2u, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(~eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(edx + 0x9000002u));
    if (!f.zf) goto L_9002482;
    goto L_900247F;
L_900247F:
    eax = (uint32_t)(((uint16_t)edx));
L_9002482:
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036A98u)));
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(eax, ecx, &f);
    if (f.zf) goto L_90024A1;
    goto L_9002490;
L_9002490:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9002497u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90025E6;
    goto L_90024A1;
L_90024A1:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_900254B;
    goto L_90024A9;
L_90024A9:
    eax = (uint32_t)(TL32((uint32_t)(0x9036A98u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90024C0;
    goto L_90024B2;
L_90024B2:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90024BAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9002510;
    goto L_90024C0;
L_90024C0:
    { uint32_t v_ = M32((uint32_t)(ebp + 0xFFFFFFC8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310ACu)); esp -= 4; M32(esp) = 0x90024C9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9002510;
    goto L_90024CF;
L_90024CF:
    { uint32_t t_ = TL32((uint32_t)(0x90310E0u)); esp -= 4; M32(esp) = 0x90024D5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036A94u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90024EF;
    goto L_90024E1;
L_90024E1:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90024E9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edi = (uint32_t)(eax);
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_9002510;
    goto L_90024EF;
L_90024EF:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xC06D007Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031038u)); esp -= 4; M32(esp) = 0x9002508u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    goto L_9002603;
L_9002510:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0xFFFFFFE8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310D8u)); esp -= 4; M32(esp) = 0x900251Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_9002544;
    goto L_900251E;
L_900251E:
    (void)sub32(TL32((uint32_t)(esi + 0x18u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900254B;
    goto L_9002524;
L_9002524:
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x40u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031088u)); esp -= 4; M32(esp) = 0x900252Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900254B;
    goto L_9002532;
L_9002532:
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(esi));
    ecx = (uint32_t)(TL32((uint32_t)(0x9036A90u)));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    TS32((uint32_t)(0x9036A90u), (uint32_t)(eax));
    goto L_900254B;
L_9002544:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A4u)); esp -= 4; M32(esp) = 0x900254Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900254B:
    eax = (uint32_t)(TL32((uint32_t)(0x9036A98u)));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(edi);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9002561;
    goto L_9002557;
L_9002557:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900255Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
L_9002561:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90025E1;
    goto L_9002565;
L_9002565:
    (void)sub32(TL32((uint32_t)(esi + 0x14u)), ebx, &f);
    if (f.zf) goto L_9002596;
    goto L_900256A;
L_900256A:
    (void)sub32(TL32((uint32_t)(esi + 0x1Cu)), ebx, &f);
    if (f.zf) goto L_9002596;
    goto L_900256F;
L_900256F:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x3Cu)));
    eax = (uint32_t)(add32(eax, edi, &f));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0x4550u, &f);
    if (!f.zf) goto L_9002596;
    goto L_900257C;
L_900257C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(TL32((uint32_t)(eax + 0x8u)), ecx, &f);
    if (!f.zf) goto L_9002596;
    goto L_9002584;
L_9002584:
    (void)sub32(edi, TL32((uint32_t)(eax + 0x34u)), &f);
    if (!f.zf) goto L_9002596;
    goto L_9002589;
L_9002589:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + eax)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90025E1;
    goto L_9002596;
L_9002596:
    { uint32_t v_ = M32((uint32_t)(ebp + 0xFFFFFFD0u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x90025A0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90025E1;
    goto L_90025A6;
L_90025A6:
    { uint32_t t_ = TL32((uint32_t)(0x90310E0u)); esp -= 4; M32(esp) = 0x90025ACu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9036A94u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90025C2;
    goto L_90025B8;
L_90025B8:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90025C0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(eax);
L_90025C2:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (!f.zf) goto L_90025E1;
    goto L_90025C6;
L_90025C6:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0x8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xC06D007Fu; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031038u)); esp -= 4; M32(esp) = 0x90025DEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
L_90025E1:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(eax), (uint32_t)(ebx));
L_90025E6:
    eax = (uint32_t)(TL32((uint32_t)(0x9036A98u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9002601;
    goto L_90025EF;
L_90025EF:
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)) & (uint32_t)0x0u), &f));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x5u; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(ebx);
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9002601u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9002601:
    eax = (uint32_t)(ebx);
L_9002603:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = ebp; ebp = M32(esp); esp += 4;
    esp += 12; SPILL(); return;
}

