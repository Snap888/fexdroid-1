#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9006000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_9006038;
    goto L_9006028;
L_9006028:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9006048;
    goto L_900602D;
L_900602D:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_9006048;
L_9006038:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_90061DC;
    goto L_9006048;
L_9006048:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    c->mm[5] ^= c->mm[5];
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[7] = M64((uint32_t)(0x903F800u));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9006130;
    goto L_900606B;
L_900606B:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->mm[5] = (uint64_t)eax;
    c->mm[5] = mmx_psllw(c->mm[5], (uint64_t)4u);
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_pslld(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], c->mm[5]);
    c->mm[0] = mmx_pslld(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_pslld(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrld(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_psrld(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_psrld(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    c->mm[1] |= c->mm[0];
    (void)logic32((uint32_t)(ebp & ebp), &f);
    eax = (uint32_t)((uint32_t)c->mm[1]);
    TS16((uint32_t)(edi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (f.zf) goto L_90061DC;
    goto L_900612C;
L_900612C:
    c->mm[5] ^= c->mm[5];
L_9006130:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    c->mm[1] |= c->mm[0];
    ebp = (uint32_t)(dec32(ebp, &f));
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[1]));
    if (!f.zf) goto L_9006130;
    goto L_90061DC;
L_90061DC:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_9006342;
    goto L_90061EA;
L_90061EA:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    goto L_9006200;
L_9006200:
    c->mm[5] ^= c->mm[5];
    c->mm[6] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[0] = M64((uint32_t)(edx));
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[5]);
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[6] = mmx_psllw(c->mm[6], (uint64_t)4u);
    c->mm[1] = c->mm[0];
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[6] = mmx_pmulhw(c->mm[6], c->mm[3]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)5u);
    c->mm[4] = c->mm[6];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[7] = M64((uint32_t)(0x903F800u));
    c->mm[1] = mmx_punpckhbw(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[6]);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)6u);
    c->mm[6] = mmx_paddw(c->mm[6], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[2]);
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[5] = c->mm[4];
    c->mm[3] = c->mm[2];
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[4]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[7]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[3]);
    c->mm[2] = mmx_paddsw(c->mm[2], M64((uint32_t)(0x902FE20u)));
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[5] = mmx_paddw(c->mm[5], c->mm[1]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[3] = mmx_paddw(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_psubusw(c->mm[2], c->mm[6]);
    c->mm[1] = mmx_psubw(c->mm[1], c->mm[7]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_paddsw(c->mm[5], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_paddsw(c->mm[3], M64((uint32_t)(0x902FE20u)));
    c->mm[5] = mmx_psubusw(c->mm[5], c->mm[6]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE30u)));
    c->mm[3] = mmx_psubusw(c->mm[3], c->mm[6]);
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[2] = mmx_psrlw(c->mm[2], M64((uint32_t)(0x902FE00u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    c->mm[2] = mmx_psllw(c->mm[2], M64((uint32_t)(0x902FDE0u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    c->mm[2] |= c->mm[0];
    c->mm[2] |= c->mm[4];
    c->mm[3] = mmx_psrlw(c->mm[3], M64((uint32_t)(0x902FE00u)));
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE08u)));
    c->mm[5] = mmx_psrlw(c->mm[5], M64((uint32_t)(0x902FE10u)));
    c->mm[3] = mmx_psllw(c->mm[3], M64((uint32_t)(0x902FDE0u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE8u)));
    c->mm[5] = mmx_psllw(c->mm[5], M64((uint32_t)(0x902FDF0u)));
    c->mm[3] |= c->mm[1];
    c->mm[3] |= c->mm[5];
    M64((uint32_t)(edi + 0xFFFFFFF0u)) = c->mm[2];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[3];
    if (!f.zf) goto L_9006200;
    goto L_9006342;
L_9006342:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006370(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006370:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    if (f.zf) goto L_90063D7;
    goto L_900638A;
L_900638A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9006390:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    c->mm[4] = M64((uint32_t)(esi + 0x20u));
    c->mm[5] = M64((uint32_t)(esi + 0x28u));
    c->mm[6] = M64((uint32_t)(esi + 0x30u));
    c->mm[7] = M64((uint32_t)(esi + 0x38u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x40u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[2];
    M64((uint32_t)(edi + 0x18u)) = c->mm[3];
    M64((uint32_t)(edi + 0x20u)) = c->mm[4];
    M64((uint32_t)(edi + 0x28u)) = c->mm[5];
    M64((uint32_t)(edi + 0x30u)) = c->mm[6];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9006390;
    goto L_90063D7;
L_90063D7:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90063F0;
    goto L_90063E1;
L_90063E1:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90063E1;
    goto L_90063F0;
L_90063F0:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9006402;
    goto L_90063F8;
L_90063F8:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_9006402:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_9006416;
    goto L_900640A;
L_900640A:
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
L_9006416:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006420(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006420:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    if (f.zf) goto L_900649B;
    goto L_900643B;
L_900643B:
    goto L_9006440;
L_9006440:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x20u, &f));
    c->mm[4] = c->mm[0];
    c->mm[5] = c->mm[1];
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[0]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[3] = mmx_punpcklwd(c->mm[3], c->mm[3]);
    c->mm[4] = mmx_punpckhwd(c->mm[4], c->mm[4]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[6] = mmx_punpckhwd(c->mm[6], c->mm[6]);
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    M64((uint32_t)(edi + 0x10u)) = c->mm[1];
    M64((uint32_t)(edi + 0x18u)) = c->mm[5];
    M64((uint32_t)(edi + 0x20u)) = c->mm[2];
    M64((uint32_t)(edi + 0x28u)) = c->mm[6];
    M64((uint32_t)(edi + 0x30u)) = c->mm[3];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9006440;
    goto L_900649B;
L_900649B:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90064C1;
    goto L_90064A5;
L_90064A5:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[4] = c->mm[0];
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[0]);
    c->mm[4] = mmx_punpckhwd(c->mm[4], c->mm[4]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90064A5;
    goto L_90064C1;
L_90064C1:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_90064F2;
    goto L_90064C9;
L_90064C9:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0xFFFF0000u);
    ebx = (uint32_t)((uint32_t)0xFFFFu);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & eax), &f));
    ecx = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx & eax), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_90064F2:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_900650E;
    goto L_90064FA;
L_90064FA:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_900650E:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006520(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006520:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_900655C;
    goto L_900654C;
L_900654C:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900656C;
    goto L_9006551;
L_9006551:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_900656C;
L_900655C:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_9006739;
    goto L_900656C;
L_900656C:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    c->mm[5] ^= c->mm[5];
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[7] = M64((uint32_t)(0x903F800u));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9006670;
    goto L_900658F;
L_900658F:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->mm[5] = (uint64_t)eax;
    c->mm[5] = mmx_psllw(c->mm[5], (uint64_t)4u);
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_pslld(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], c->mm[5]);
    c->mm[0] = mmx_pslld(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_pslld(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    eax = (uint32_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(inc32(esi, &f));
    c->mm[2] = (uint64_t)eax;
    c->mm[1] = mmx_psrld(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_psrld(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_psrld(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[2] = mmx_psrlw(c->mm[2], M64((uint32_t)(0x902FE18u)));
    c->mm[2] = mmx_psllw(c->mm[2], M64((uint32_t)(0x902FDF8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    c->mm[1] |= c->mm[2];
    c->mm[1] |= c->mm[0];
    (void)logic32((uint32_t)(ebp & ebp), &f);
    eax = (uint32_t)((uint32_t)c->mm[1]);
    TS16((uint32_t)(edi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (f.zf) goto L_9006739;
    goto L_9006668;
L_9006668:
    c->mm[5] ^= c->mm[5];
    goto L_9006670;
L_9006670:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    eax = (uint32_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    c->mm[2] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[2] = mmx_psrlw(c->mm[2], M64((uint32_t)(0x902FE18u)));
    c->mm[2] = mmx_psllw(c->mm[2], M64((uint32_t)(0x902FDF8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    c->mm[1] |= c->mm[2];
    c->mm[1] |= c->mm[0];
    ebp = (uint32_t)(dec32(ebp, &f));
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[1]));
    if (!f.zf) goto L_9006670;
    goto L_9006739;
L_9006739:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_90068CC;
    goto L_9006747;
L_9006747:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
L_9006750:
    c->mm[5] ^= c->mm[5];
    c->mm[6] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[0] = M64((uint32_t)(edx));
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[5]);
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[6] = mmx_psllw(c->mm[6], (uint64_t)4u);
    c->mm[1] = c->mm[0];
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[6] = mmx_pmulhw(c->mm[6], c->mm[3]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)5u);
    c->mm[4] = c->mm[6];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[7] = M64((uint32_t)(0x903F800u));
    c->mm[1] = mmx_punpckhbw(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[6]);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)6u);
    c->mm[6] = mmx_paddw(c->mm[6], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[2]);
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[5] = c->mm[4];
    c->mm[3] = c->mm[2];
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[4]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[7]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[3]);
    c->mm[2] = mmx_paddsw(c->mm[2], M64((uint32_t)(0x902FE20u)));
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[5] = mmx_paddw(c->mm[5], c->mm[1]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[3] = mmx_paddw(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_psubusw(c->mm[2], c->mm[6]);
    c->mm[1] = mmx_psubw(c->mm[1], c->mm[7]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_paddsw(c->mm[5], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_paddsw(c->mm[3], M64((uint32_t)(0x902FE20u)));
    c->mm[5] = mmx_psubusw(c->mm[5], c->mm[6]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE30u)));
    c->mm[3] = mmx_psubusw(c->mm[3], c->mm[6]);
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[2] = mmx_psrlw(c->mm[2], M64((uint32_t)(0x902FE00u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    c->mm[2] = mmx_psllw(c->mm[2], M64((uint32_t)(0x902FDE0u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    c->mm[2] |= c->mm[0];
    c->mm[2] |= c->mm[4];
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[3] = mmx_psrlw(c->mm[3], M64((uint32_t)(0x902FE00u)));
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE08u)));
    c->mm[5] = mmx_psrlw(c->mm[5], M64((uint32_t)(0x902FE10u)));
    c->mm[3] = mmx_psllw(c->mm[3], M64((uint32_t)(0x902FDE0u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE8u)));
    c->mm[5] = mmx_psllw(c->mm[5], M64((uint32_t)(0x902FDF0u)));
    c->mm[3] |= c->mm[1];
    c->mm[3] |= c->mm[5];
    c->mm[1] = M64((uint32_t)(esi + 0xFFFFFFF8u));
    c->mm[5] = c->mm[1];
    c->mm[1] = mmx_punpcklbw(c->mm[1], M64((uint32_t)(0x903F818u)));
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE18u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDF8u)));
    c->mm[2] |= c->mm[1];
    M64((uint32_t)(edi + 0xFFFFFFF0u)) = c->mm[2];
    c->mm[5] = mmx_punpckhbw(c->mm[5], M64((uint32_t)(0x903F818u)));
    c->mm[5] = mmx_psrlw(c->mm[5], M64((uint32_t)(0x902FE18u)));
    c->mm[5] = mmx_psllw(c->mm[5], M64((uint32_t)(0x902FDF8u)));
    c->mm[3] |= c->mm[5];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[3];
    if (!f.zf) goto L_9006750;
    goto L_90068CC;
L_90068CC:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(esi));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006900(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006900:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebp);
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9006933;
    goto L_900692A;
L_900692A:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_9006933:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebp);
    if (!f.cf) goto L_90069D9;
    goto L_9006943;
L_9006943:
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(edx + 0xFFFFFFFFu)));
    esi = (uint32_t)(TL8((uint32_t)(esi)));
    ebp = (uint32_t)(M8((uint32_t)(ebp)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx + 0x902FE20u)), &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x9030270u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A84u)));
    ebp = (uint32_t)(shl32(ebp, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edx*4 + 0x9030274u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | edx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A88u)));
    edx = (uint32_t)(TL32((uint32_t)(eax*4 + 0x903027Cu)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | edx), &f));
    TS32((uint32_t)(edi), (uint32_t)(esi));
    TS16((uint32_t)(esi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)ebp)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(edi + 0xCu)), (uint32_t)0x1u, &f)));
L_90069D9:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9006AD8;
    goto L_90069E4;
L_90069E4:
    edx = (uint32_t)(logic32(0, &f));
    goto L_90069F0;
L_90069F0:
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(M16((uint32_t)(ebp + edx*2 + 0xFFFFFFFEu)));
    esi = (uint32_t)(TL8((uint32_t)(edx + ecx + 0xFFFFFFFFu)));
    ebp = (uint32_t)(TL8((uint32_t)(edx + ebx + 0xFFFFFFFFu)));
    M32((uint32_t)(esp)) = (uint32_t)(edx);
    ebx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(eax >> 8)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + 0x903F938u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    ebx = (uint32_t)(add32(ebx, TL32((uint32_t)(0x902FE24u)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(0x902FE20u)), &f));
    edi = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ebx = (uint32_t)(sub32(ebx, ebp, &f));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x9030270u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A84u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(esi*4 + 0x903026Eu))), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi*4 + 0x9030274u)));
    ebp = (uint32_t)(shl32(ebp, ((uint8_t)ecx), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | TL32((uint32_t)(edx*4 + 0x9030272u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    eax = (uint32_t)(TL32((uint32_t)(eax*4 + 0x903027Cu)));
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebx*4 + 0x903027Au))), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | esi), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A88u)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(M32((uint32_t)(esp)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | eax), &f));
    (void)sub32(M32((uint32_t)(esp + 0x4u)), edx, &f);
    TS32((uint32_t)(esi + edx*4 + 0xFFFFFFFCu), (uint32_t)(ebp));
    if (!f.zf) goto L_90069F0;
    goto L_9006AB4;
L_9006AB4:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebp = (uint32_t)(add32(ebp, edx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
L_9006AD8:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006AF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006AF0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9006B08u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)((uint32_t)(esi + edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006B20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006B20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_9006B7A;
    goto L_9006B3C;
L_9006B3C:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_9006B40:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    edx = (uint32_t)(eax);
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x10u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebp));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    ebp = (uint32_t)(ebx);
    eax = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x10u, &f));
    ebx = (ebx & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebp));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebp));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9006B40;
    goto L_9006B79;
L_9006B79:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9006B7A:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9006B9F;
    goto L_9006B82;
L_9006B82:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x10u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebp));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebx));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_9006B9F:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_9006BBB;
    goto L_9006BA7;
L_9006BA7:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_9006BBB:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006BD0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006BD0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFF9u, &f));
    (void)sub32(eax, (uint32_t)0x5u, &f);
    if ((!f.cf && !f.zf)) goto L_9006CD3;
    goto L_9006BEC;
L_9006BEC:
    esi = (uint32_t)(logic32(0, &f));
    { jt_ = TL32((uint32_t)(eax*4 + 0x9006CDCu)); goto L_dispatch; }
L_9006BF5:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_9006C47;
L_9006C08:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_9006C47;
L_9006C1B:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_9006C43;
L_9006C28:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_9006C46;
L_9006C38:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x6u);
L_9006C43:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xBu; esp -= 4; M32(esp) = v_; }
L_9006C46:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
L_9006C47:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9006CD3:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9006BD0u: goto L_9006BD0; case 0x9006BECu: goto L_9006BEC; case 0x9006BF5u: goto L_9006BF5; case 0x9006C08u: goto L_9006C08; case 0x9006C1Bu: goto L_9006C1B; case 0x9006C28u: goto L_9006C28; case 0x9006C38u: goto L_9006C38; case 0x9006C43u: goto L_9006C43; case 0x9006C46u: goto L_9006C46; case 0x9006C47u: goto L_9006C47; case 0x9006CD3u: goto L_9006CD3; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9006BF5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006BF5:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_9006C47;
L_9006C47:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006C08(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006C08:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_9006C47;
L_9006C47:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006C1B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006C1B:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x5u);
    goto L_9006C43;
L_9006C43:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xBu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006C28(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006C28:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
    goto L_9006C46;
L_9006C46:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006C38(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006C38:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x6u);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xBu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006C4Eu; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(edi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006900u));
    esp -= 4; M32(esp) = 0x9006C95u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006C9Au; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006CDC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006CDC:
    TS8((uint32_t)(eax + eax + 0x9u), (uint8_t)(logic8((uint8_t)(TL8((uint32_t)(eax + eax + 0x9u)) | ((uint8_t)(ecx >> 8))), &f)));
    f.cf = !f.cf;
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax)) * (int32_t)(uint32_t)0x9u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    f.cf = !f.cf;
    { int64_t r_ = (int64_t)(int32_t)TL32((uint32_t)(eax)) * (int32_t)(uint32_t)0x9u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebp = (uint32_t)(sbb32(ebp, TL32((uint32_t)(eax + eax + 0x9u)), &f));
    (void)sub8(TL8((uint32_t)(eax + eax + 0x9u)), ((uint8_t)(ecx >> 8)), &f);
    TS8((uint32_t)(eax + eax + 0x9u), (uint8_t)(sub8(TL8((uint32_t)(eax + eax + 0x9u)), ((uint8_t)(ecx >> 8)), &f)));
    SPILL(); rt_int3(c, 0x9006CF4u);
    { SPILL(); rt_call(c, 0x9006CF5u); return; }
}

void f_9006D00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006D00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebp);
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9006D33;
    goto L_9006D2A;
L_9006D2A:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_9006D33:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebp);
    if (!f.cf) goto L_9006DF6;
    goto L_9006D43;
L_9006D43:
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(edx + 0xFFFFFFFFu)));
    esi = (uint32_t)(TL8((uint32_t)(esi)));
    ebp = (uint32_t)(M8((uint32_t)(ebp)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx + 0x902FE20u)), &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x9030270u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A84u)));
    ebp = (uint32_t)(shl32(ebp, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edx*4 + 0x9030274u)));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | edx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A88u)));
    edx = (uint32_t)(TL32((uint32_t)(eax*4 + 0x903027Cu)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | edx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(ecx + 0xFFFFFFFFu)));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A90u)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & TL32((uint32_t)(0x9030A94u))), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | eax), &f));
    TS32((uint32_t)(edi), (uint32_t)(esi));
    TS16((uint32_t)(esi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)ebp)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(edi + 0xCu)), (uint32_t)0x1u, &f)));
L_9006DF6:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9006F1B;
    goto L_9006E01;
L_9006E01:
    edx = (uint32_t)(logic32(0, &f));
    goto L_9006E10;
L_9006E10:
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(M16((uint32_t)(ebp + edx*2 + 0xFFFFFFFEu)));
    esi = (uint32_t)(TL8((uint32_t)(edx + ecx + 0xFFFFFFFFu)));
    ebp = (uint32_t)(TL8((uint32_t)(edx + ebx + 0xFFFFFFFFu)));
    M32((uint32_t)(esp)) = (uint32_t)(edx);
    ebx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(eax >> 8)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + 0x903F938u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    ebx = (uint32_t)(add32(ebx, TL32((uint32_t)(0x902FE24u)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(0x902FE20u)), &f));
    edi = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ebx = (uint32_t)(sub32(ebx, ebp, &f));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x9030270u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A84u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(esi*4 + 0x903026Eu))), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi*4 + 0x9030274u)));
    ebp = (uint32_t)(shl32(ebp, ((uint8_t)ecx), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | TL32((uint32_t)(edx*4 + 0x9030272u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    eax = (uint32_t)(TL32((uint32_t)(eax*4 + 0x903027Cu)));
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebx*4 + 0x903027Au))), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | esi), &f));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A88u)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(M32((uint32_t)(esp)));
    ebx = (uint32_t)(TL16((uint32_t)(ecx + edx*2 + 0xFFFFFFFEu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A90u)));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | eax), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(ebx >> 8)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & TL32((uint32_t)(0x9030A94u))), &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | ebx), &f));
    (void)sub32(M32((uint32_t)(esp + 0x4u)), edx, &f);
    TS32((uint32_t)(esi + edx*4 + 0xFFFFFFFCu), (uint32_t)(ebp));
    if (!f.zf) goto L_9006E10;
    goto L_9006EF1;
L_9006EF1:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebp = (uint32_t)(add32(ebp, edx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
L_9006F1B:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9006F30(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9006F30:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x0u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    if (!f.zf) goto L_9006F45;
    goto L_9006F3E;
L_9006F3E:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9006F45:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x7u, &f));
    if (f.zf) goto L_9006F68;
    goto L_9006F52;
L_9006F52:
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9006F3E;
    goto L_9006F57;
L_9006F57:
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x3u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x7u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xFu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(eax + 0x5u));
    goto L_9006F79;
L_9006F68:
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xCu; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x4u);
L_9006F79:
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9006F80u; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9006AF0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9006B20u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9006D00u));
    esp -= 4; M32(esp) = 0x9006FCBu; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9006FD0u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9030A78u)));
    edx = (uint32_t)(TL32((uint32_t)(0x9030A80u)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9030A7Cu)));
    ecx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | esi), &f));
    eax = (uint32_t)((uint32_t)(esi + 0x1u));
    TS32((uint32_t)(0x902FE20u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

