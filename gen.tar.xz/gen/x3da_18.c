#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A002F93(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002F93:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A002FA7;
L_A002FA7:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x2u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FBCu; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A002FDD;
L_A002FDD:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A002FE9;
L_A002FE9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x3u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FFFu; SPILL(); f_A0035C3(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A003020;
L_A003020:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A00302D;
L_A00302D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A003036;
L_A003036:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x4u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003047u; SPILL(); f_A0035C3(c); RELOAD();
    goto L_A003062;
L_A003062:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x5u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003076u; SPILL(); f_A002D7E(c); RELOAD();
    goto L_A003091;
L_A003091:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x6u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A0030C9:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A002FC1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002FC1:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFDCu), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FD2u; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A002FD5(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002FD5:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A002FE9;
L_A002FE9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x3u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FFFu; SPILL(); f_A0035C3(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A003020;
L_A003020:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A00302D;
L_A00302D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A003036;
L_A003036:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x4u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003047u; SPILL(); f_A0035C3(c); RELOAD();
    goto L_A003062;
L_A003062:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x5u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003076u; SPILL(); f_A002D7E(c); RELOAD();
    goto L_A003091;
L_A003091:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x6u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A0030C9:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A003004(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003004:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFD8u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003015u; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A003018(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003018:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A00302D;
L_A00302D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A003036;
L_A003036:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x4u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003047u; SPILL(); f_A0035C3(c); RELOAD();
    goto L_A003062;
L_A003062:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x5u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003076u; SPILL(); f_A002D7E(c); RELOAD();
    goto L_A003091;
L_A003091:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x6u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A0030C9:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A003049(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003049:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFD4u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00305Au; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A00305D(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00305D:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x5u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003076u; SPILL(); f_A002D7E(c); RELOAD();
    goto L_A003091;
L_A003091:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x6u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A0030C9:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A003078(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003078:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFD0u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003089u; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A00308C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00308C:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x6u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A0030C9:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A0030AD(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0030AD:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFCCu), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030BEu; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A0030C1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0030C1:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(TL32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x7u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00310A;
L_A00310A:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A0030EE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0030EE:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030FFu; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A003102(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003102:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0x8u));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(eax));
    goto L_A00314E;
L_A00314E:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
L_A003151:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

void f_A003132(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003132:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC4u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003143u; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A003146(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003146:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFE4u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
}

