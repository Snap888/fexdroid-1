#include "funcs_bink.h"
#include "lift_prelude.h"

void f_90247D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90247D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x130u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(ecx);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(esi);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFED0u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)((uint32_t)(esp));
L_9024800:
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x70u)));
    edi = (uint32_t)(TL16((uint32_t)(eax + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x50u)));
    ebx = (uint32_t)(TL16((uint32_t)(eax + 0x60u)));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x40u)));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(esi);
    esi = (uint32_t)(logic32((uint32_t)(esi | edi), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFFCu))), &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xCu))), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFD8u))), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | ebx), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFF8u))), &f));
    (void)logic16((uint16_t)(((uint16_t)esi) & ((uint16_t)esi)), &f);
    esi = (uint32_t)((uint32_t)(int16_t)TL16((uint32_t)(eax)));
    if (!f.zf) goto L_9024871;
    goto L_9024846;
L_9024846:
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    TS32((uint32_t)(ecx), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x20u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x40u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x80u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xA0u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xC0u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xE0u), (uint32_t)(esi));
    goto L_90249A5;
L_9024871:
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xCu)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(edx + 0x80u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFECu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edx + 0x40u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)((uint32_t)(int16_t)((uint16_t)ebx));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)TL32((uint32_t)(edx + 0xC0u)); ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ebx);
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    ebx = (uint32_t)((uint32_t)(edi + esi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0xB50u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(edi + ebx));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edi = (uint32_t)((uint32_t)(eax + esi));
    esi = (uint32_t)(sub32(esi, eax, &f));
    eax = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFDCu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edx + 0x20u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFF8u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)TL32((uint32_t)(edx + 0xE0u)); ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFFCu)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(edx + 0x60u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(esi);
    esi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFD8u)));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx + 0xA0u)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    ebx = (uint32_t)((uint32_t)(esi + edi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xCu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(add32(ebx, edi, &f));
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + esi));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0xFFFFEB18u; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x8A9u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)(uint32_t)0xEC8u; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0xB50u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sub32(esi, M32((uint32_t)(ebp + 0xCu)), &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebx, &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sub32(edi, esi, &f));
    eax = (uint32_t)(add32(eax, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ebx = (uint32_t)(sub32(ebx, M32((uint32_t)(ebp + 0xCu)), &f));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0xE0u), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    eax = (uint32_t)((uint32_t)(esi + ebx));
    ebx = (uint32_t)(sub32(ebx, esi, &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    TS32((uint32_t)(ecx + 0x20u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0xC0u), (uint32_t)(ebx));
    eax = (uint32_t)((uint32_t)(edi + esi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    TS32((uint32_t)(ecx + 0x40u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(ecx + 0xA0u), (uint32_t)(esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)(eax + esi));
    esi = (uint32_t)(sub32(esi, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    TS32((uint32_t)(ecx + 0x80u), (uint32_t)(edi));
L_90249A5:
    TS32((uint32_t)(ecx + 0x60u), (uint32_t)(esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(esi);
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9024800;
    goto L_90249C3;
L_90249C3:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFEE8u));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x8u);
    esp = (uint32_t)((uint32_t)(esp));
L_90249E0:
    esi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFE8u)));
    edx = (uint32_t)((uint32_t)(ecx + esi));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(TL32((uint32_t)(eax)));
    esi = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF0u)));
    edi = (uint32_t)((uint32_t)(ebx + ecx));
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0xB50u; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)((uint32_t)(edi + edx));
    edx = (uint32_t)(sub32(edx, edi, &f));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0xBu, &f));
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ecx + esi));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFFCu)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(ecx + edx));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ecx = (uint32_t)((uint32_t)(esi + edi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)((uint32_t)(ecx + ebx));
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)(uint32_t)0xB50u; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(esi + edx));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0xFFFFEB18u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0x8A9u; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0xEC8u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0xBu, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0xBu, &f));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xCu)), &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    edx = (uint32_t)(add32(edx, edi, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sub32(esi, edi, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ecx = (uint32_t)((uint32_t)(edx + ebx + 0x7Fu));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(((uint8_t)ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)((uint32_t)(ecx + esi + 0x7Fu));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(((uint8_t)ecx));
    ebx = (uint32_t)(sub32(ebx, edx, &f));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(ebp + 0xCu)), &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x7Fu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x7Fu, &f));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(((uint8_t)ecx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x7Fu, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    esi = (uint32_t)(((uint8_t)edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ebx = (uint32_t)((uint32_t)(ebx + edx + 0x7Fu));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(((uint8_t)ebx));
    esi = (uint32_t)(shl32(esi, (uint8_t)0x10u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | ebx), &f));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x7Fu, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edx = (uint32_t)((uint32_t)(edx + ebx + 0x7Fu));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(((uint8_t)edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebx), &f));
    ebx = (uint32_t)(edi);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | ebx), &f));
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | ebx), &f));
    ebx = (uint32_t)(esi);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | ebx), &f));
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebx), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(ebx + 0xFFFFFFF8u), (uint32_t)(edi));
    TS32((uint32_t)(ebx + 0xFFFFFFFCu), (uint32_t)(edx));
    TS32((uint32_t)(ebx), (uint32_t)(esi));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    TS32((uint32_t)(ebx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD0u)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x8u)), ecx, &f));
    TS32((uint32_t)(ebx), (uint32_t)(edi));
    TS32((uint32_t)(ebx + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(ebx + 0x8u), (uint32_t)(esi));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x20u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(ebx);
    if (!f.zf) goto L_90249E0;
    goto L_9024B49;
L_9024B49:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9024B50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9024B50:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x12Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9038CC0u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFED4u));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)((uint32_t)0x8u);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
L_9024B75:
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x70u)));
    edi = (uint32_t)(TL16((uint32_t)(eax + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x50u)));
    ebx = (uint32_t)(TL16((uint32_t)(eax + 0x60u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x40u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL16((uint32_t)(eax + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(esi);
    esi = (uint32_t)(logic32((uint32_t)(esi | edi), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFF8u))), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFF4u))), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFF0u))), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | ebx), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | M32((uint32_t)(ebp + 0xFFFFFFD4u))), &f));
    (void)logic16((uint16_t)(((uint16_t)esi) & ((uint16_t)esi)), &f);
    esi = (uint32_t)((uint32_t)(int16_t)TL16((uint32_t)(eax)));
    if (!f.zf) goto L_9024BE6;
    goto L_9024BBB;
L_9024BBB:
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    TS32((uint32_t)(ecx), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x20u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x40u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0x80u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xA0u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xC0u), (uint32_t)(esi));
    TS32((uint32_t)(ecx + 0xE0u), (uint32_t)(esi));
    goto L_9024D1A;
L_9024BE6:
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFF4u)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(edx + 0x80u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFE8u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edx + 0x40u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)((uint32_t)(int16_t)((uint16_t)ebx));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)TL32((uint32_t)(edx + 0xC0u)); ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    ebx = (uint32_t)((uint32_t)(edi + esi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFECu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0xB50u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    eax = (uint32_t)(sub32(eax, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(edi + ebx));
    ebx = (uint32_t)(sub32(ebx, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edi = (uint32_t)((uint32_t)(eax + esi));
    esi = (uint32_t)(sub32(esi, eax, &f));
    eax = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFDCu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edx + 0x20u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFD4u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)TL32((uint32_t)(edx + 0xE0u)); ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFF8u)));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)TL32((uint32_t)(edx + 0x60u)); edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
    esi = (uint32_t)((uint32_t)(int16_t)M16((uint32_t)(ebp + 0xFFFFFFF0u)));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)TL32((uint32_t)(edx + 0xA0u)); esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    ebx = (uint32_t)((uint32_t)(esi + edi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(add32(ebx, edi, &f));
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(eax + esi));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)(uint32_t)0xFFFFEB18u; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x8A9u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)(uint32_t)0xEC8u; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0xB50u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0xBu, &f));
    esi = (uint32_t)(sub32(esi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0xBu, &f));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebx, &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sub32(edi, esi, &f));
    eax = (uint32_t)(add32(eax, edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ebx = (uint32_t)(sub32(ebx, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0xE0u), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)((uint32_t)(esi + ebx));
    ebx = (uint32_t)(sub32(ebx, esi, &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    TS32((uint32_t)(ecx + 0x20u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0xC0u), (uint32_t)(ebx));
    eax = (uint32_t)((uint32_t)(edi + esi));
    esi = (uint32_t)(sub32(esi, edi, &f));
    TS32((uint32_t)(ecx + 0x40u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(ecx + 0xA0u), (uint32_t)(esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edi = (uint32_t)((uint32_t)(eax + esi));
    esi = (uint32_t)(sub32(esi, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    TS32((uint32_t)(ecx + 0x80u), (uint32_t)(edi));
L_9024D1A:
    TS32((uint32_t)(ecx + 0x60u), (uint32_t)(esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(esi);
    (void)logic32((uint32_t)(esi & esi), &f);
    if ((!f.zf && f.sf == f.of)) goto L_9024B75;
    goto L_9024D38;
L_9024D38:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    esi = (uint32_t)(inc32(esi, &f));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFEECu));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)((uint32_t)0x8u);
    ecx = (uint32_t)((uint32_t)(ecx));
L_9024D50:
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF8u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFE8u)));
    edi = (uint32_t)((uint32_t)(edx + ebx));
    edx = (uint32_t)(sub32(edx, ebx, &f));
    ebx = (uint32_t)(TL32((uint32_t)(eax)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF0u)));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(eax)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ebx);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0xB50u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(sar32(edx, (uint8_t)0xBu, &f));
    edx = (uint32_t)(sub32(edx, ebx, &f));
    ebx = (uint32_t)(add32(ebx, edi, &f));
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)((uint32_t)(edx + edi));
    edi = (uint32_t)(sub32(edi, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFFCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    edi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFF4u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)((uint32_t)(edi + edx));
    edx = (uint32_t)(sub32(edx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x4u)));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(sub32(edi, ebx, &f));
    ebx = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    edi = (uint32_t)(add32(edi, edx, &f));
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)(uint32_t)0xB50u; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(add32(ebx, edi, &f));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0xFFFFEB18u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)(uint32_t)0xEC8u; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0xBu, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
    edx = (uint32_t)(sar32(edx, (uint8_t)0xBu, &f));
    { int64_t r_ = (int64_t)(int32_t)edi * (int32_t)(uint32_t)0x8A9u; edi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(sub32(edx, ebx, &f));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(edx);
    edi = (uint32_t)(sar32(edi, (uint8_t)0xBu, &f));
    edi = (uint32_t)(sub32(edi, M32((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    edi = (uint32_t)(add32(edi, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    edx = (uint32_t)((uint32_t)(edx + edi + 0x7Fu));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), TL8((uint32_t)(esi + 0xFFFFFFFFu)), &f));
    TS8((uint32_t)(ecx + 0xFFFFFFFFu), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x7Fu, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), TL8((uint32_t)(esi + 0x6u)), &f));
    TS8((uint32_t)(ecx + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)((uint32_t)(ebx + edi + 0x7Fu));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), TL8((uint32_t)(esi)), &f));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, ebx, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x7Fu, &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), TL8((uint32_t)(esi + 0x5u)), &f));
    TS8((uint32_t)(ecx + 0x5u), (uint8_t)(((uint8_t)edx)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)((uint32_t)(edx + edi + 0x7Fu));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x8u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), TL8((uint32_t)(esi + 0x1u)), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x20u, &f));
    TS8((uint32_t)(ecx + 0x1u), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ebx = (uint32_t)(sub32(ebx, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x7Fu, &f));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x8u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), TL8((uint32_t)(esi + 0x4u)), &f));
    TS8((uint32_t)(ecx + 0x4u), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(edi);
    ebx = (uint32_t)(sub32(ebx, edx, &f));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x7Fu, &f));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x8u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), TL8((uint32_t)(esi + 0x2u)), &f));
    edx = (uint32_t)((uint32_t)(edx + edi + 0x7Fu));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x8u, &f));
    TS8((uint32_t)(ecx + 0x2u), (uint8_t)(((uint8_t)ebx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), TL8((uint32_t)(esi + 0x3u)), &f));
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x14u)), &f));
    TS8((uint32_t)(ecx + 0x3u), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xCu)), &f));
    M32((uint32_t)(ebp + 0x10u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0x10u)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_9024D50;
    goto L_9024E98;
L_9024E98:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

void f_9024EB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9024EB0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x150u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF38u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(ecx);
    { uint32_t v_ = 0x78u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEBCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFF3Cu)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFEB4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFEB8u)) = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x9024EF4u; SPILL(); f_9001EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_9024F40;
    goto L_9024F0A;
L_9024F0A:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    ebx = (uint32_t)(((uint8_t)ecx));
    M32((uint32_t)(ebp + 0xFFFFFF4Cu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(eax);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)ebx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1Cu, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF4Cu)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    esi = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    goto L_9024F4C;
L_9024F40:
    esi = (uint32_t)(((uint8_t)edx));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFu), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
L_9024F4C:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB0u));
    M32((uint32_t)(ebp + 0xFFFFFF40u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    esi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    ebx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB6u));
    M8((uint32_t)(ebp + 0xFFFFFFB0u)) = (uint8_t)((uint8_t)0x10u);
    M8((uint32_t)(ebp + 0xFFFFFFB1u)) = (uint8_t)((uint8_t)0x60u);
    M32((uint32_t)(ebp + 0xFFFFFF44u)) = (uint32_t)(esi);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF40u)));
    M8((uint32_t)(ebp + 0xFFFFFFB2u)) = (uint8_t)((uint8_t)0xB0u);
    M8((uint32_t)(ebp + 0xFFFFFFB3u)) = (uint8_t)((uint8_t)0x7u);
    M8((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint8_t)((uint8_t)0xBu);
    M8((uint32_t)(ebp + 0xFFFFFFB5u)) = (uint8_t)((uint8_t)0xFu);
    M32((uint32_t)(ebp + 0xFFFFFF60u)) = (uint32_t)(ebx);
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((f.cf || f.zf)) goto L_90254AB;
    goto L_9024F9B;
L_9024F9B:
    goto L_9024FA0;
L_9024FA0:
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF48u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9025495;
    goto L_9024FCA;
L_9024FCA:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025483;
    goto L_9024FDB;
L_9024FDB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9024FF5;
    goto L_9024FDF;
L_9024FDF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9024FFA;
L_9024FF5:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9024FFA:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902547D;
    goto L_9025003;
L_9025003:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902547D;
    goto L_9025011;
L_9025011:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258ACu)); goto L_dispatch; }
L_9025018:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(ecx);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    goto L_90250A0;
L_9025038:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    M8((uint32_t)(ebp + 0xFFFFFF53u)) = (uint8_t)(((uint8_t)ecx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(M8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(M8((uint32_t)(ebp + 0xFFFFFF53u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x22u, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF60u)) = (uint32_t)(ebx);
    goto L_9025489;
L_9025087:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)((uint8_t)0x0u));
    ebx = (uint32_t)(inc32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(ebx);
L_90250A0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902523C;
    goto L_90250A8;
L_90250A8:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_90250C1;
L_90250C1:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF4Cu)) = (uint32_t)(ebx);
L_90250D2:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | M32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_90250F9;
    goto L_90250F7;
L_90250F7:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90250F9:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    M16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)ecx));
L_9025107:
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFF64u)), &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902529F;
    goto L_9025115;
L_9025115:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_902512E;
L_902512E:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025139:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | M32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_9025154;
    goto L_9025152;
L_9025152:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025154:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    M16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)ecx));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF54u)));
L_9025168:
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFF64u)), &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025303;
    goto L_9025176;
L_9025176:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_902518F;
L_902518F:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_902519A:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | M32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_90251B5;
    goto L_90251B3;
L_90251B3:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90251B5:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    M16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)ecx));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF54u)));
L_90251C9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(ecx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025367;
    goto L_90251DE;
L_90251DE:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_90251F7;
L_90251F7:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025202:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | M32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_902521D;
    goto L_902521B;
L_902521B:
    ecx = (uint32_t)(neg32(ecx, &f));
L_902521D:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    M16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)ecx));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF54u)));
    goto L_9025489;
L_902523C:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_9025242;
L_9025242:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90250C1;
    goto L_902524A;
L_902524A:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFF4Cu)) = (uint32_t)(ebx);
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_90250D2;
L_9025283:
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFF68u)), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    goto L_9025107;
L_902529F:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_90252A5;
L_90252A5:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902512E;
    goto L_90252AD;
L_90252AD:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025139;
L_90252E0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(ecx);
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025168;
L_9025303:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_9025309;
L_9025309:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902518F;
    goto L_9025311;
L_9025311:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_902519A;
L_9025344:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(ecx);
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_90251C9;
L_9025367:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_902536D;
L_902536D:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90251F7;
    goto L_9025375;
L_9025375:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025202;
L_90253A8:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(ebx);
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    goto L_9025489;
L_90253CB:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0xFFFFFFFFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFF64u)) = (uint32_t)(ecx);
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9025428;
    goto L_90253DB;
L_90253DB:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF58u)));
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF54u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF54u)) = (uint32_t)(edi);
    goto L_9025439;
L_9025428:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025439:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF4Cu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | M32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    M32((uint32_t)(ebp + 0xFFFFFF58u)) = (uint32_t)(ebx);
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_9025466;
    goto L_9025464;
L_9025464:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025466:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF64u)));
    M16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_902547D:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025483:
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f));
L_9025489:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFF5Cu)), ebx, &f);
    if (f.cf) goto L_9024FCA;
    goto L_9025495;
L_9025495:
    M32((uint32_t)(ebp + 0xFFFFFF44u)) = (uint32_t)(sar32(M32((uint32_t)(ebp + 0xFFFFFF44u)), (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9024FA0;
    goto L_90254A5;
L_90254A5:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF40u)));
L_90254AB:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9025762;
    goto L_90254B3;
L_90254B3:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(esi);
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9025762;
    goto L_90254C7;
L_90254C7:
    goto L_90254D0;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    M32((uint32_t)(ebp + 0xFFFFFF60u)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFF60u)), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF60u)) = (uint32_t)(ebx);
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(esi);
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFF68u)), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    M16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)esi));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFF68u)), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    M16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)esi));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFF68u)), &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    M16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)esi));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF68u)) = (uint32_t)(esi);
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    M16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    M16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u)) = (uint16_t)(((uint16_t)esi));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF5Cu)) = (uint32_t)(esi);
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(M16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9024EB0u: goto L_9024EB0; case 0x9024F0Au: goto L_9024F0A; case 0x9024F40u: goto L_9024F40; case 0x9024F4Cu: goto L_9024F4C; case 0x9024F9Bu: goto L_9024F9B; case 0x9024FA0u: goto L_9024FA0; case 0x9024FCAu: goto L_9024FCA; case 0x9024FDBu: goto L_9024FDB; case 0x9024FDFu: goto L_9024FDF; case 0x9024FF5u: goto L_9024FF5; case 0x9024FFAu: goto L_9024FFA; case 0x9025003u: goto L_9025003; case 0x9025011u: goto L_9025011; case 0x9025018u: goto L_9025018; case 0x9025038u: goto L_9025038; case 0x9025087u: goto L_9025087; case 0x90250A0u: goto L_90250A0; case 0x90250A8u: goto L_90250A8; case 0x90250C1u: goto L_90250C1; case 0x90250D2u: goto L_90250D2; case 0x90250F7u: goto L_90250F7; case 0x90250F9u: goto L_90250F9; case 0x9025107u: goto L_9025107; case 0x9025115u: goto L_9025115; case 0x902512Eu: goto L_902512E; case 0x9025139u: goto L_9025139; case 0x9025152u: goto L_9025152; case 0x9025154u: goto L_9025154; case 0x9025168u: goto L_9025168; case 0x9025176u: goto L_9025176; case 0x902518Fu: goto L_902518F; case 0x902519Au: goto L_902519A; case 0x90251B3u: goto L_90251B3; case 0x90251B5u: goto L_90251B5; case 0x90251C9u: goto L_90251C9; case 0x90251DEu: goto L_90251DE; case 0x90251F7u: goto L_90251F7; case 0x9025202u: goto L_9025202; case 0x902521Bu: goto L_902521B; case 0x902521Du: goto L_902521D; case 0x902523Cu: goto L_902523C; case 0x9025242u: goto L_9025242; case 0x902524Au: goto L_902524A; case 0x9025283u: goto L_9025283; case 0x902529Fu: goto L_902529F; case 0x90252A5u: goto L_90252A5; case 0x90252ADu: goto L_90252AD; case 0x90252E0u: goto L_90252E0; case 0x9025303u: goto L_9025303; case 0x9025309u: goto L_9025309; case 0x9025311u: goto L_9025311; case 0x9025344u: goto L_9025344; case 0x9025367u: goto L_9025367; case 0x902536Du: goto L_902536D; case 0x9025375u: goto L_9025375; case 0x90253A8u: goto L_90253A8; case 0x90253CBu: goto L_90253CB; case 0x90253DBu: goto L_90253DB; case 0x9025428u: goto L_9025428; case 0x9025439u: goto L_9025439; case 0x9025464u: goto L_9025464; case 0x9025466u: goto L_9025466; case 0x902547Du: goto L_902547D; case 0x9025483u: goto L_9025483; case 0x9025489u: goto L_9025489; case 0x9025495u: goto L_9025495; case 0x90254A5u: goto L_90254A5; case 0x90254ABu: goto L_90254AB; case 0x90254B3u: goto L_90254B3; case 0x90254C7u: goto L_90254C7; case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025018(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025018;
L_9024FA0:
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF48u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9025495;
    goto L_9024FCA;
L_9024FCA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025483;
    goto L_9024FDB;
L_9024FDB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9024FF5;
    goto L_9024FDF;
L_9024FDF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(ebx);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9024FFA;
L_9024FF5:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9024FFA:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902547D;
    goto L_9025003;
L_9025003:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902547D;
    goto L_9025011;
L_9025011:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258ACu)); goto L_dispatch; }
L_9025018:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    goto L_90250A0;
L_9025038:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(ebp + 0xFFFFFF53u), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x22u, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_9025489;
L_9025087:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)((uint8_t)0x0u));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ebx));
L_90250A0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902523C;
    goto L_90250A8;
L_90250A8:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_90250C1;
L_90250C1:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
L_90250D2:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_90250F9;
    goto L_90250F7;
L_90250F7:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90250F9:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
L_9025107:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902529F;
    goto L_9025115;
L_9025115:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_902512E;
L_902512E:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025139:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_9025154;
    goto L_9025152;
L_9025152:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025154:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_9025168:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025303;
    goto L_9025176;
L_9025176:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_902518F;
L_902518F:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_902519A:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_90251B5;
    goto L_90251B3;
L_90251B3:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90251B5:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_90251C9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025367;
    goto L_90251DE;
L_90251DE:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_90251F7;
L_90251F7:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025202:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_902521D;
    goto L_902521B;
L_902521B:
    ecx = (uint32_t)(neg32(ecx, &f));
L_902521D:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    goto L_9025489;
L_902523C:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_9025242;
L_9025242:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90250C1;
    goto L_902524A;
L_902524A:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_90250D2;
L_9025283:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    goto L_9025107;
L_902529F:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_90252A5;
L_90252A5:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902512E;
    goto L_90252AD;
L_90252AD:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025139;
L_90252E0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025168;
L_9025303:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_9025309;
L_9025309:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902518F;
    goto L_9025311;
L_9025311:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_902519A;
L_9025344:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_90251C9;
L_9025367:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_902536D;
L_902536D:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90251F7;
    goto L_9025375;
L_9025375:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025202;
L_90253A8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ebx));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    goto L_9025489;
L_90253CB:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9025428;
    goto L_90253DB;
L_90253DB:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    goto L_9025439;
L_9025428:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025439:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_9025466;
    goto L_9025464;
L_9025464:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025466:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_902547D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025483:
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f)));
L_9025489:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), ebx, &f);
    if (f.cf) goto L_9024FCA;
    goto L_9025495;
L_9025495:
    TS32((uint32_t)(ebp + 0xFFFFFF44u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF44u)), (uint8_t)0x1u, &f)));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9024FA0;
    goto L_90254A5;
L_90254A5:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF40u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9025762;
    goto L_90254B3;
L_90254B3:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9025762;
    goto L_90254C7;
L_90254C7:
    goto L_90254D0;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9024FA0u: goto L_9024FA0; case 0x9024FCAu: goto L_9024FCA; case 0x9024FDBu: goto L_9024FDB; case 0x9024FDFu: goto L_9024FDF; case 0x9024FF5u: goto L_9024FF5; case 0x9024FFAu: goto L_9024FFA; case 0x9025003u: goto L_9025003; case 0x9025011u: goto L_9025011; case 0x9025018u: goto L_9025018; case 0x9025038u: goto L_9025038; case 0x9025087u: goto L_9025087; case 0x90250A0u: goto L_90250A0; case 0x90250A8u: goto L_90250A8; case 0x90250C1u: goto L_90250C1; case 0x90250D2u: goto L_90250D2; case 0x90250F7u: goto L_90250F7; case 0x90250F9u: goto L_90250F9; case 0x9025107u: goto L_9025107; case 0x9025115u: goto L_9025115; case 0x902512Eu: goto L_902512E; case 0x9025139u: goto L_9025139; case 0x9025152u: goto L_9025152; case 0x9025154u: goto L_9025154; case 0x9025168u: goto L_9025168; case 0x9025176u: goto L_9025176; case 0x902518Fu: goto L_902518F; case 0x902519Au: goto L_902519A; case 0x90251B3u: goto L_90251B3; case 0x90251B5u: goto L_90251B5; case 0x90251C9u: goto L_90251C9; case 0x90251DEu: goto L_90251DE; case 0x90251F7u: goto L_90251F7; case 0x9025202u: goto L_9025202; case 0x902521Bu: goto L_902521B; case 0x902521Du: goto L_902521D; case 0x902523Cu: goto L_902523C; case 0x9025242u: goto L_9025242; case 0x902524Au: goto L_902524A; case 0x9025283u: goto L_9025283; case 0x902529Fu: goto L_902529F; case 0x90252A5u: goto L_90252A5; case 0x90252ADu: goto L_90252AD; case 0x90252E0u: goto L_90252E0; case 0x9025303u: goto L_9025303; case 0x9025309u: goto L_9025309; case 0x9025311u: goto L_9025311; case 0x9025344u: goto L_9025344; case 0x9025367u: goto L_9025367; case 0x902536Du: goto L_902536D; case 0x9025375u: goto L_9025375; case 0x90253A8u: goto L_90253A8; case 0x90253CBu: goto L_90253CB; case 0x90253DBu: goto L_90253DB; case 0x9025428u: goto L_9025428; case 0x9025439u: goto L_9025439; case 0x9025464u: goto L_9025464; case 0x9025466u: goto L_9025466; case 0x902547Du: goto L_902547D; case 0x9025483u: goto L_9025483; case 0x9025489u: goto L_9025489; case 0x9025495u: goto L_9025495; case 0x90254A5u: goto L_90254A5; case 0x90254B3u: goto L_90254B3; case 0x90254C7u: goto L_90254C7; case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025038(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025038;
L_9024FA0:
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF48u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9025495;
    goto L_9024FCA;
L_9024FCA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025483;
    goto L_9024FDB;
L_9024FDB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9024FF5;
    goto L_9024FDF;
L_9024FDF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(ebx);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9024FFA;
L_9024FF5:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9024FFA:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902547D;
    goto L_9025003;
L_9025003:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902547D;
    goto L_9025011;
L_9025011:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258ACu)); goto L_dispatch; }
L_9025018:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    goto L_90250A0;
L_9025038:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(ebp + 0xFFFFFF53u), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x22u, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_9025489;
L_9025087:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)((uint8_t)0x0u));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ebx));
L_90250A0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902523C;
    goto L_90250A8;
L_90250A8:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_90250C1;
L_90250C1:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
L_90250D2:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_90250F9;
    goto L_90250F7;
L_90250F7:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90250F9:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
L_9025107:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902529F;
    goto L_9025115;
L_9025115:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_902512E;
L_902512E:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025139:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_9025154;
    goto L_9025152;
L_9025152:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025154:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_9025168:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025303;
    goto L_9025176;
L_9025176:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_902518F;
L_902518F:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_902519A:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_90251B5;
    goto L_90251B3;
L_90251B3:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90251B5:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_90251C9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025367;
    goto L_90251DE;
L_90251DE:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_90251F7;
L_90251F7:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025202:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_902521D;
    goto L_902521B;
L_902521B:
    ecx = (uint32_t)(neg32(ecx, &f));
L_902521D:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    goto L_9025489;
L_902523C:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_9025242;
L_9025242:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90250C1;
    goto L_902524A;
L_902524A:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_90250D2;
L_9025283:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    goto L_9025107;
L_902529F:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_90252A5;
L_90252A5:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902512E;
    goto L_90252AD;
L_90252AD:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025139;
L_90252E0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025168;
L_9025303:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_9025309;
L_9025309:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902518F;
    goto L_9025311;
L_9025311:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_902519A;
L_9025344:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_90251C9;
L_9025367:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_902536D;
L_902536D:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90251F7;
    goto L_9025375;
L_9025375:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025202;
L_90253A8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ebx));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    goto L_9025489;
L_90253CB:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9025428;
    goto L_90253DB;
L_90253DB:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    goto L_9025439;
L_9025428:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025439:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_9025466;
    goto L_9025464;
L_9025464:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025466:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_902547D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025483:
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f)));
L_9025489:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), ebx, &f);
    if (f.cf) goto L_9024FCA;
    goto L_9025495;
L_9025495:
    TS32((uint32_t)(ebp + 0xFFFFFF44u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF44u)), (uint8_t)0x1u, &f)));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9024FA0;
    goto L_90254A5;
L_90254A5:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF40u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9025762;
    goto L_90254B3;
L_90254B3:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9025762;
    goto L_90254C7;
L_90254C7:
    goto L_90254D0;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9024FA0u: goto L_9024FA0; case 0x9024FCAu: goto L_9024FCA; case 0x9024FDBu: goto L_9024FDB; case 0x9024FDFu: goto L_9024FDF; case 0x9024FF5u: goto L_9024FF5; case 0x9024FFAu: goto L_9024FFA; case 0x9025003u: goto L_9025003; case 0x9025011u: goto L_9025011; case 0x9025018u: goto L_9025018; case 0x9025038u: goto L_9025038; case 0x9025087u: goto L_9025087; case 0x90250A0u: goto L_90250A0; case 0x90250A8u: goto L_90250A8; case 0x90250C1u: goto L_90250C1; case 0x90250D2u: goto L_90250D2; case 0x90250F7u: goto L_90250F7; case 0x90250F9u: goto L_90250F9; case 0x9025107u: goto L_9025107; case 0x9025115u: goto L_9025115; case 0x902512Eu: goto L_902512E; case 0x9025139u: goto L_9025139; case 0x9025152u: goto L_9025152; case 0x9025154u: goto L_9025154; case 0x9025168u: goto L_9025168; case 0x9025176u: goto L_9025176; case 0x902518Fu: goto L_902518F; case 0x902519Au: goto L_902519A; case 0x90251B3u: goto L_90251B3; case 0x90251B5u: goto L_90251B5; case 0x90251C9u: goto L_90251C9; case 0x90251DEu: goto L_90251DE; case 0x90251F7u: goto L_90251F7; case 0x9025202u: goto L_9025202; case 0x902521Bu: goto L_902521B; case 0x902521Du: goto L_902521D; case 0x902523Cu: goto L_902523C; case 0x9025242u: goto L_9025242; case 0x902524Au: goto L_902524A; case 0x9025283u: goto L_9025283; case 0x902529Fu: goto L_902529F; case 0x90252A5u: goto L_90252A5; case 0x90252ADu: goto L_90252AD; case 0x90252E0u: goto L_90252E0; case 0x9025303u: goto L_9025303; case 0x9025309u: goto L_9025309; case 0x9025311u: goto L_9025311; case 0x9025344u: goto L_9025344; case 0x9025367u: goto L_9025367; case 0x902536Du: goto L_902536D; case 0x9025375u: goto L_9025375; case 0x90253A8u: goto L_90253A8; case 0x90253CBu: goto L_90253CB; case 0x90253DBu: goto L_90253DB; case 0x9025428u: goto L_9025428; case 0x9025439u: goto L_9025439; case 0x9025464u: goto L_9025464; case 0x9025466u: goto L_9025466; case 0x902547Du: goto L_902547D; case 0x9025483u: goto L_9025483; case 0x9025489u: goto L_9025489; case 0x9025495u: goto L_9025495; case 0x90254A5u: goto L_90254A5; case 0x90254B3u: goto L_90254B3; case 0x90254C7u: goto L_90254C7; case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025087(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025087;
L_9024FA0:
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF48u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9025495;
    goto L_9024FCA;
L_9024FCA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025483;
    goto L_9024FDB;
L_9024FDB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9024FF5;
    goto L_9024FDF;
L_9024FDF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(ebx);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9024FFA;
L_9024FF5:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9024FFA:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902547D;
    goto L_9025003;
L_9025003:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902547D;
    goto L_9025011;
L_9025011:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258ACu)); goto L_dispatch; }
L_9025018:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    goto L_90250A0;
L_9025038:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(ebp + 0xFFFFFF53u), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x22u, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_9025489;
L_9025087:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)((uint8_t)0x0u));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ebx));
L_90250A0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902523C;
    goto L_90250A8;
L_90250A8:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_90250C1;
L_90250C1:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
L_90250D2:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_90250F9;
    goto L_90250F7;
L_90250F7:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90250F9:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
L_9025107:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902529F;
    goto L_9025115;
L_9025115:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_902512E;
L_902512E:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025139:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_9025154;
    goto L_9025152;
L_9025152:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025154:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_9025168:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025303;
    goto L_9025176;
L_9025176:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_902518F;
L_902518F:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_902519A:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_90251B5;
    goto L_90251B3;
L_90251B3:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90251B5:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_90251C9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025367;
    goto L_90251DE;
L_90251DE:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_90251F7;
L_90251F7:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025202:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_902521D;
    goto L_902521B;
L_902521B:
    ecx = (uint32_t)(neg32(ecx, &f));
L_902521D:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    goto L_9025489;
L_902523C:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_9025242;
L_9025242:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90250C1;
    goto L_902524A;
L_902524A:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_90250D2;
L_9025283:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    goto L_9025107;
L_902529F:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_90252A5;
L_90252A5:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902512E;
    goto L_90252AD;
L_90252AD:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025139;
L_90252E0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025168;
L_9025303:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_9025309;
L_9025309:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902518F;
    goto L_9025311;
L_9025311:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_902519A;
L_9025344:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_90251C9;
L_9025367:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_902536D;
L_902536D:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90251F7;
    goto L_9025375;
L_9025375:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025202;
L_90253A8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ebx));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    goto L_9025489;
L_90253CB:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9025428;
    goto L_90253DB;
L_90253DB:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    goto L_9025439;
L_9025428:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025439:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_9025466;
    goto L_9025464;
L_9025464:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025466:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_902547D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025483:
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f)));
L_9025489:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), ebx, &f);
    if (f.cf) goto L_9024FCA;
    goto L_9025495;
L_9025495:
    TS32((uint32_t)(ebp + 0xFFFFFF44u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF44u)), (uint8_t)0x1u, &f)));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9024FA0;
    goto L_90254A5;
L_90254A5:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF40u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9025762;
    goto L_90254B3;
L_90254B3:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9025762;
    goto L_90254C7;
L_90254C7:
    goto L_90254D0;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9024FA0u: goto L_9024FA0; case 0x9024FCAu: goto L_9024FCA; case 0x9024FDBu: goto L_9024FDB; case 0x9024FDFu: goto L_9024FDF; case 0x9024FF5u: goto L_9024FF5; case 0x9024FFAu: goto L_9024FFA; case 0x9025003u: goto L_9025003; case 0x9025011u: goto L_9025011; case 0x9025018u: goto L_9025018; case 0x9025038u: goto L_9025038; case 0x9025087u: goto L_9025087; case 0x90250A0u: goto L_90250A0; case 0x90250A8u: goto L_90250A8; case 0x90250C1u: goto L_90250C1; case 0x90250D2u: goto L_90250D2; case 0x90250F7u: goto L_90250F7; case 0x90250F9u: goto L_90250F9; case 0x9025107u: goto L_9025107; case 0x9025115u: goto L_9025115; case 0x902512Eu: goto L_902512E; case 0x9025139u: goto L_9025139; case 0x9025152u: goto L_9025152; case 0x9025154u: goto L_9025154; case 0x9025168u: goto L_9025168; case 0x9025176u: goto L_9025176; case 0x902518Fu: goto L_902518F; case 0x902519Au: goto L_902519A; case 0x90251B3u: goto L_90251B3; case 0x90251B5u: goto L_90251B5; case 0x90251C9u: goto L_90251C9; case 0x90251DEu: goto L_90251DE; case 0x90251F7u: goto L_90251F7; case 0x9025202u: goto L_9025202; case 0x902521Bu: goto L_902521B; case 0x902521Du: goto L_902521D; case 0x902523Cu: goto L_902523C; case 0x9025242u: goto L_9025242; case 0x902524Au: goto L_902524A; case 0x9025283u: goto L_9025283; case 0x902529Fu: goto L_902529F; case 0x90252A5u: goto L_90252A5; case 0x90252ADu: goto L_90252AD; case 0x90252E0u: goto L_90252E0; case 0x9025303u: goto L_9025303; case 0x9025309u: goto L_9025309; case 0x9025311u: goto L_9025311; case 0x9025344u: goto L_9025344; case 0x9025367u: goto L_9025367; case 0x902536Du: goto L_902536D; case 0x9025375u: goto L_9025375; case 0x90253A8u: goto L_90253A8; case 0x90253CBu: goto L_90253CB; case 0x90253DBu: goto L_90253DB; case 0x9025428u: goto L_9025428; case 0x9025439u: goto L_9025439; case 0x9025464u: goto L_9025464; case 0x9025466u: goto L_9025466; case 0x902547Du: goto L_902547D; case 0x9025483u: goto L_9025483; case 0x9025489u: goto L_9025489; case 0x9025495u: goto L_9025495; case 0x90254A5u: goto L_90254A5; case 0x90254B3u: goto L_90254B3; case 0x90254C7u: goto L_90254C7; case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90253CB(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_90253CB;
L_9024FA0:
    ecx = (uint32_t)((uint32_t)(esi + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF48u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, ebx, &f);
    if (!f.cf) goto L_9025495;
    goto L_9024FCA;
L_9024FCA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025483;
    goto L_9024FDB;
L_9024FDB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9024FF5;
    goto L_9024FDF;
L_9024FDF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(ebx);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9024FFA;
L_9024FF5:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9024FFA:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902547D;
    goto L_9025003;
L_9025003:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902547D;
    goto L_9025011;
L_9025011:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258ACu)); goto L_dispatch; }
L_9025018:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    goto L_90250A0;
L_9025038:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    TS8((uint32_t)(ebp + 0xFFFFFF53u), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x22u, &f));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF53u)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_9025489;
L_9025087:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)((uint8_t)0x0u));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(ebx));
L_90250A0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902523C;
    goto L_90250A8;
L_90250A8:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_90250C1;
L_90250C1:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
L_90250D2:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_90250F9;
    goto L_90250F7;
L_90250F7:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90250F9:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
L_9025107:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902529F;
    goto L_9025115;
L_9025115:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_902512E;
L_902512E:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025139:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_9025154;
    goto L_9025152;
L_9025152:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025154:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_9025168:
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025303;
    goto L_9025176;
L_9025176:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_902518F;
L_902518F:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_902519A:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_90251B5;
    goto L_90251B3;
L_90251B3:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90251B5:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
L_90251C9:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025367;
    goto L_90251DE;
L_90251DE:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)((uint32_t)0x1Fu);
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_90251F7;
L_90251F7:
    ebx = (uint32_t)(edx);
    ecx = (uint32_t)((uint32_t)(esi + 0x1u));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025202:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    edi = (uint32_t)(dec32(edi, &f));
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & edi), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)) & ebx), &f);
    if (f.zf) goto L_902521D;
    goto L_902521B;
L_902521B:
    ecx = (uint32_t)(neg32(ecx, &f));
L_902521D:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS16((uint32_t)(ebp + edi*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    goto L_9025489;
L_902523C:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025283;
    goto L_9025242;
L_9025242:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90250C1;
    goto L_902524A;
L_902524A:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_90250D2;
L_9025283:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    goto L_9025107;
L_902529F:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90252E0;
    goto L_90252A5;
L_90252A5:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902512E;
    goto L_90252AD;
L_90252AD:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025139;
L_90252E0:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025168;
L_9025303:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_9025344;
    goto L_9025309;
L_9025309:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_902518F;
    goto L_9025311;
L_9025311:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_902519A;
L_9025344:
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFF64u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ecx));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)ebx)));
    goto L_90251C9;
L_9025367:
    eax = (uint32_t)(dec32(eax, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_90253A8;
    goto L_902536D;
L_902536D:
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90251F7;
    goto L_9025375;
L_9025375:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, ecx, &f));
    goto L_9025202;
L_90253A8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (uint32_t)(dec32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(ebx));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    goto L_9025489;
L_90253CB:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF64u), (uint32_t)(ecx));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_9025428;
    goto L_90253DB;
L_90253DB:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF58u)));
    ecx = (uint32_t)(ebx);
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF54u)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(add32(eax, ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF54u), (uint32_t)(edi));
    goto L_9025439;
L_9025428:
    ecx = (uint32_t)((uint32_t)0x20u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    ebx = (uint32_t)(shr32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(esi);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edx), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    eax = (uint32_t)(sub32(eax, esi, &f));
L_9025439:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF4Cu), (uint32_t)(ebx));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | TL32((uint32_t)(ebp + 0xFFFFFF44u))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF48u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF4Cu)) & ecx), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF58u), (uint32_t)(ebx));
    ecx = (uint32_t)(ebx);
    if (f.zf) goto L_9025466;
    goto L_9025464;
L_9025464:
    ecx = (uint32_t)(neg32(ecx, &f));
L_9025466:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF64u)));
    TS16((uint32_t)(ebp + ebx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_902547D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025483:
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f)));
L_9025489:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), ebx, &f);
    if (f.cf) goto L_9024FCA;
    goto L_9025495;
L_9025495:
    TS32((uint32_t)(ebp + 0xFFFFFF44u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF44u)), (uint8_t)0x1u, &f)));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9024FA0;
    goto L_90254A5;
L_90254A5:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF40u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_9025762;
    goto L_90254B3;
L_90254B3:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
    (void)sub32(esi, ebx, &f);
    if (!f.cf) goto L_9025762;
    goto L_90254C7;
L_90254C7:
    goto L_90254D0;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9024FA0u: goto L_9024FA0; case 0x9024FCAu: goto L_9024FCA; case 0x9024FDBu: goto L_9024FDB; case 0x9024FDFu: goto L_9024FDF; case 0x9024FF5u: goto L_9024FF5; case 0x9024FFAu: goto L_9024FFA; case 0x9025003u: goto L_9025003; case 0x9025011u: goto L_9025011; case 0x9025018u: goto L_9025018; case 0x9025038u: goto L_9025038; case 0x9025087u: goto L_9025087; case 0x90250A0u: goto L_90250A0; case 0x90250A8u: goto L_90250A8; case 0x90250C1u: goto L_90250C1; case 0x90250D2u: goto L_90250D2; case 0x90250F7u: goto L_90250F7; case 0x90250F9u: goto L_90250F9; case 0x9025107u: goto L_9025107; case 0x9025115u: goto L_9025115; case 0x902512Eu: goto L_902512E; case 0x9025139u: goto L_9025139; case 0x9025152u: goto L_9025152; case 0x9025154u: goto L_9025154; case 0x9025168u: goto L_9025168; case 0x9025176u: goto L_9025176; case 0x902518Fu: goto L_902518F; case 0x902519Au: goto L_902519A; case 0x90251B3u: goto L_90251B3; case 0x90251B5u: goto L_90251B5; case 0x90251C9u: goto L_90251C9; case 0x90251DEu: goto L_90251DE; case 0x90251F7u: goto L_90251F7; case 0x9025202u: goto L_9025202; case 0x902521Bu: goto L_902521B; case 0x902521Du: goto L_902521D; case 0x902523Cu: goto L_902523C; case 0x9025242u: goto L_9025242; case 0x902524Au: goto L_902524A; case 0x9025283u: goto L_9025283; case 0x902529Fu: goto L_902529F; case 0x90252A5u: goto L_90252A5; case 0x90252ADu: goto L_90252AD; case 0x90252E0u: goto L_90252E0; case 0x9025303u: goto L_9025303; case 0x9025309u: goto L_9025309; case 0x9025311u: goto L_9025311; case 0x9025344u: goto L_9025344; case 0x9025367u: goto L_9025367; case 0x902536Du: goto L_902536D; case 0x9025375u: goto L_9025375; case 0x90253A8u: goto L_90253A8; case 0x90253CBu: goto L_90253CB; case 0x90253DBu: goto L_90253DB; case 0x9025428u: goto L_9025428; case 0x9025439u: goto L_9025439; case 0x9025464u: goto L_9025464; case 0x9025466u: goto L_9025466; case 0x902547Du: goto L_902547D; case 0x9025483u: goto L_9025483; case 0x9025489u: goto L_9025489; case 0x9025495u: goto L_9025495; case 0x90254A5u: goto L_90254A5; case 0x90254B3u: goto L_90254B3; case 0x90254C7u: goto L_90254C7; case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025512(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025512;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025522(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025522;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_902556A(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_902556A;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025716(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025716;
L_90254D0:
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025753;
    goto L_90254DB;
L_90254DB:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90254EF;
    goto L_90254DF;
L_90254DF:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90254F4;
L_90254EF:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90254F4:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902574D;
    goto L_90254FD;
L_90254FD:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_902574D;
    goto L_902550B;
L_902550B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x90258BCu)); goto L_dispatch; }
L_9025512:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025577;
L_9025522:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ebx = (uint32_t)(inc32(ebx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ebx));
    goto L_902575A;
L_902556A:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(esi), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_9025577:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902558B;
    goto L_902557B;
L_902557B:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025590;
L_902558B:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025590:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90255AE;
    goto L_9025595;
L_9025595:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_90255D7;
L_90255AE:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255C2;
    goto L_90255B2;
L_90255B2:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255C7;
L_90255C2:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255C7:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_90255D7:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90255EC;
    goto L_90255DC;
L_90255DC:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90255F1;
L_90255EC:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90255F1:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_902560F;
    goto L_90255F6;
L_90255F6:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025638;
L_902560F:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025623;
    goto L_9025613;
L_9025613:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025628;
L_9025623:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025628:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025638:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902564D;
    goto L_902563D;
L_902563D:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025652;
L_902564D:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025652:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025670;
    goto L_9025657;
L_9025657:
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFF68u)), &f)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ebx)));
    goto L_9025699;
L_9025670:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9025684;
    goto L_9025674;
L_9025674:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025689;
L_9025684:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025689:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
L_9025699:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256AE;
    goto L_902569E;
L_902569E:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256B3;
L_90256AE:
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256B3:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_90256DF;
    goto L_90256B8;
L_90256B8:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF68u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    esi = (uint32_t)(dec32(esi, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF68u), (uint32_t)(esi));
    TS8((uint32_t)(esi), (uint8_t)(((uint8_t)ecx)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_90256DF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90256F3;
    goto L_90256E3;
L_90256E3:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_90256F8;
L_90256F3:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_90256F8:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    goto L_902575A;
L_9025716:
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902572D;
    goto L_902571D;
L_902571D:
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    edx = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025732;
L_902572D:
    esi = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(dec32(eax, &f));
L_9025732:
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    esi = (uint32_t)(neg32(esi, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | (uint32_t)0x1u), &f));
    TS16((uint32_t)(ebp + ecx*2 + 0xFFFFFEB4u), (uint16_t)(((uint16_t)esi)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
    esi = (uint32_t)(ecx);
L_902574D:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
L_9025753:
    esi = (uint32_t)(inc32(esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF5Cu), (uint32_t)(esi));
L_902575A:
    (void)sub32(esi, ebx, &f);
    if (f.cf) goto L_90254D0;
    goto L_9025762;
L_9025762:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF3Cu)));
    TS32((uint32_t)(ecx), (uint32_t)(edx));
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(ebp + 0xFFFFFEB6u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF38u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEBCu)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFECCu)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC0u)));
    TS16((uint32_t)(eax + 0x2u), (uint16_t)(((uint16_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED0u)));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEB8u)));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF0Cu)));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC8u)));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEDCu)));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE4u)));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED4u)));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE0u)));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEE8u)));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFED8u)));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEECu)));
    TS32((uint32_t)(eax + 0x4Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF0u)));
    TS32((uint32_t)(eax + 0x5Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF04u)));
    TS32((uint32_t)(eax + 0x50u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF18u)));
    TS32((uint32_t)(eax + 0x64u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS32((uint32_t)(eax + 0x58u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEFCu)));
    TS32((uint32_t)(eax + 0x6Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF08u)));
    TS32((uint32_t)(eax + 0x60u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    TS32((uint32_t)(eax + 0x74u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    TS32((uint32_t)(eax + 0x68u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF00u)));
    TS32((uint32_t)(eax + 0x7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(eax + 0x70u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    TS32((uint32_t)(eax + 0x78u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x90258A5u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90254D0u: goto L_90254D0; case 0x90254DBu: goto L_90254DB; case 0x90254DFu: goto L_90254DF; case 0x90254EFu: goto L_90254EF; case 0x90254F4u: goto L_90254F4; case 0x90254FDu: goto L_90254FD; case 0x902550Bu: goto L_902550B; case 0x9025512u: goto L_9025512; case 0x9025522u: goto L_9025522; case 0x902556Au: goto L_902556A; case 0x9025577u: goto L_9025577; case 0x902557Bu: goto L_902557B; case 0x902558Bu: goto L_902558B; case 0x9025590u: goto L_9025590; case 0x9025595u: goto L_9025595; case 0x90255AEu: goto L_90255AE; case 0x90255B2u: goto L_90255B2; case 0x90255C2u: goto L_90255C2; case 0x90255C7u: goto L_90255C7; case 0x90255D7u: goto L_90255D7; case 0x90255DCu: goto L_90255DC; case 0x90255ECu: goto L_90255EC; case 0x90255F1u: goto L_90255F1; case 0x90255F6u: goto L_90255F6; case 0x902560Fu: goto L_902560F; case 0x9025613u: goto L_9025613; case 0x9025623u: goto L_9025623; case 0x9025628u: goto L_9025628; case 0x9025638u: goto L_9025638; case 0x902563Du: goto L_902563D; case 0x902564Du: goto L_902564D; case 0x9025652u: goto L_9025652; case 0x9025657u: goto L_9025657; case 0x9025670u: goto L_9025670; case 0x9025674u: goto L_9025674; case 0x9025684u: goto L_9025684; case 0x9025689u: goto L_9025689; case 0x9025699u: goto L_9025699; case 0x902569Eu: goto L_902569E; case 0x90256AEu: goto L_90256AE; case 0x90256B3u: goto L_90256B3; case 0x90256B8u: goto L_90256B8; case 0x90256DFu: goto L_90256DF; case 0x90256E3u: goto L_90256E3; case 0x90256F3u: goto L_90256F3; case 0x90256F8u: goto L_90256F8; case 0x9025716u: goto L_9025716; case 0x902571Du: goto L_902571D; case 0x902572Du: goto L_902572D; case 0x9025732u: goto L_9025732; case 0x902574Du: goto L_902574D; case 0x9025753u: goto L_9025753; case 0x902575Au: goto L_902575A; case 0x9025762u: goto L_9025762; default: SPILL(); rt_call(c, jt_); return; }
}

void f_90258AC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90258AC:
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(sbb8(TL8((uint32_t)(eax + 0x2u)), ((uint8_t)edx), &f)));
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) | edi), &f)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    { uint32_t o_ = __atomic_exchange_n((uint32_t *)(MEM + (uint32_t)(eax + 0x2u)), (uint32_t)edx, __ATOMIC_SEQ_CST); edx = (uint32_t)(o_); }
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)edx), TL8((uint32_t)(ebp + 0x2u)), &f));
    TS32((uint32_t)(edx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edx)) | esp), &f)));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    { uint32_t v_ = 0x55u; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    esp -= 4; M16(esp) = ((uint16_t)0x2B);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    SPILL(); rt_int3(c, 0x90258CCu);
    { SPILL(); rt_call(c, 0x90258CDu); return; }
}

void f_90258BC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90258BC:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(adc8(((uint8_t)edx), TL8((uint32_t)(ebp + 0x2u)), &f));
    TS32((uint32_t)(edx), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(edx)) | esp), &f)));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    { uint32_t v_ = 0x55u; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    esp -= 4; M16(esp) = ((uint16_t)0x2B);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    SPILL(); rt_int3(c, 0x90258CCu);
    { SPILL(); rt_call(c, 0x90258CDu); return; }
}

void f_90258D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90258D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xF0u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    M32((uint32_t)(ebp + 0xFFFFFF20u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFF14u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)((uint32_t)0x0u);
    (void)sub32(esi, (uint32_t)0x3u, &f);
    if (!f.cf) goto L_9025930;
    goto L_902590C;
L_902590C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    ebx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(esi);
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)ebx), ((uint8_t)ecx), &f));
    ecx = (uint32_t)(((uint8_t)eax));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    ecx = (uint32_t)((uint32_t)0x3u);
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x7u), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1Du, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(edx);
    goto L_902593C;
L_9025930:
    ebx = (uint32_t)(((uint8_t)eax));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x7u), &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x3u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x3u, &f));
L_902593C:
    ebx = (uint32_t)(inc32(ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF18u)) = (uint32_t)(ebx);
    ecx = (uint32_t)((uint32_t)(ebx + 0xFFFFFFFFu));
    ebx = (uint32_t)((uint32_t)0x1u);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF18u)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF7Cu));
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF80u));
    M8((uint32_t)(ebp + 0xFFFFFF7Cu)) = (uint8_t)((uint8_t)0x10u);
    M8((uint32_t)(ebp + 0xFFFFFF7Du)) = (uint8_t)((uint8_t)0x60u);
    M8((uint32_t)(ebp + 0xFFFFFF7Eu)) = (uint8_t)((uint8_t)0xB0u);
    M8((uint32_t)(ebp + 0xFFFFFF7Fu)) = (uint8_t)((uint8_t)0x2u);
    M32((uint32_t)(ebp + 0xFFFFFF1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFF34u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFF18u)) = (uint32_t)(ecx);
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_9025DC5;
    goto L_90259A2;
L_90259A2:
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFF2Cu)), ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = (uint32_t)(ebx);
    if ((f.zf || f.sf != f.of)) goto L_9025A29;
    goto L_90259B2;
L_90259B2:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90259C6;
    goto L_90259B6;
L_90259B6:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ecx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_90259CB;
L_90259C6:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_90259CB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025A1A;
    goto L_90259D0;
L_90259D0:
    ecx = (uint32_t)(M8((uint32_t)(ebp + ebx + 0xFFFFFFBCu)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFF10u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.sf == f.of)) goto L_90259F2;
    goto L_90259F0;
L_90259F0:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90259F2:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(ecx);
    (void)sub32(ebx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025A14;
L_9025A14:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
L_9025A1A:
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, M32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f);
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = (uint32_t)(ebx);
    if ((f.sf != f.of)) goto L_90259B2;
    goto L_9025A29;
L_9025A29:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = (uint32_t)(ebx);
    (void)sub32(ecx, edx, &f);
    if (!f.cf) goto L_9025DB2;
    goto L_9025A3F;
L_9025A3F:
L_9025A40:
    ecx = (uint32_t)(TL8((uint32_t)(ebx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A4B;
L_9025A4B:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025A5F;
    goto L_9025A4F;
L_9025A4F:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025A64;
L_9025A5F:
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025A64:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A6D;
L_9025A6D:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_9025D9E;
    goto L_9025A7B;
L_9025A7B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x9025DE4u)); goto L_dispatch; }
L_9025A82:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    goto L_9025AE6;
L_9025A98:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF1Cu)) = (uint32_t)(edx);
    goto L_9025DA4;
L_9025AD3:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(edx), (uint8_t)((uint8_t)0x0u));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = (uint32_t)(edx);
L_9025AE6:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025AFA;
    goto L_9025AEA;
L_9025AEA:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025AFF;
L_9025AFA:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025AFF:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025B1E;
    goto L_9025B04;
L_9025B04:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = (uint32_t)(edx);
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025B76;
L_9025B1E:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    M8((uint32_t)(ebp + edx + 0xFFFFFFBCu)) = (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B43;
    goto L_9025B33;
L_9025B33:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B48;
L_9025B43:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B48:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025B55;
    goto L_9025B53;
L_9025B53:
    edx = (uint32_t)(neg32(edx, &f));
L_9025B55:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(edx);
    (void)sub32(ebx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025B76;
L_9025B76:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B8B;
    goto L_9025B7B;
L_9025B7B:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B90;
L_9025B8B:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B90:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025BAF;
    goto L_9025B95;
L_9025B95:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = (uint32_t)(edx);
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C07;
L_9025BAF:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    M8((uint32_t)(ebp + edx + 0xFFFFFFBCu)) = (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025BD4;
    goto L_9025BC4;
L_9025BC4:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025BD9;
L_9025BD4:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025BD9:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025BE6;
    goto L_9025BE4;
L_9025BE4:
    edx = (uint32_t)(neg32(edx, &f));
L_9025BE6:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(edx);
    (void)sub32(ebx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C07;
L_9025C07:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C1C;
    goto L_9025C0C;
L_9025C0C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C21;
L_9025C1C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C21:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025C40;
    goto L_9025C26;
L_9025C26:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = (uint32_t)(edx);
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C98;
L_9025C40:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    M8((uint32_t)(ebp + edx + 0xFFFFFFBCu)) = (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C65;
    goto L_9025C55;
L_9025C55:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C6A;
L_9025C65:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C6A:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025C77;
    goto L_9025C75;
L_9025C75:
    edx = (uint32_t)(neg32(edx, &f));
L_9025C77:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(edx);
    (void)sub32(ebx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C98;
L_9025C98:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CAD;
    goto L_9025C9D;
L_9025C9D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025CB2;
L_9025CAD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025CB2:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025CD8;
    goto L_9025CB7;
L_9025CB7:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF24u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF24u)) = (uint32_t)(edx);
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025CD8:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    M8((uint32_t)(ebp + edx + 0xFFFFFFBCu)) = (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CFD;
    goto L_9025CED;
L_9025CED:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D02;
L_9025CFD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D02:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D0F;
    goto L_9025D0D;
L_9025D0D:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D0F:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(ecx);
    (void)sub32(edx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D30;
L_9025D30:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025D38:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    M8((uint32_t)(ebp + edx + 0xFFFFFFBCu)) = (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF2Cu)) = (uint32_t)(edx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025D60;
    goto L_9025D50;
L_9025D50:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D65;
L_9025D60:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D65:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D72;
    goto L_9025D70;
L_9025D70:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D72:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF30u)) = (uint32_t)(ecx);
    (void)sub32(edx, M32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D8F;
L_9025D8F:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_9025D9E:
    M32((uint32_t)(ebp + 0xFFFFFF28u)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFF28u)), &f));
L_9025DA4:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF28u)));
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_9025A40;
    goto L_9025DB2;
L_9025DB2:
    M32((uint32_t)(ebp + 0xFFFFFF34u)) = (uint32_t)(sar32(M32((uint32_t)(ebp + 0xFFFFFF34u)), (uint8_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFF18u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFF18u)), (uint32_t)0x1u, &f));
    if (!f.zf) goto L_90259A2;
    goto L_9025DC5;
L_9025DC5:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9025DE0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90258D0u: goto L_90258D0; case 0x902590Cu: goto L_902590C; case 0x9025930u: goto L_9025930; case 0x902593Cu: goto L_902593C; case 0x90259A2u: goto L_90259A2; case 0x90259B2u: goto L_90259B2; case 0x90259B6u: goto L_90259B6; case 0x90259C6u: goto L_90259C6; case 0x90259CBu: goto L_90259CB; case 0x90259D0u: goto L_90259D0; case 0x90259F0u: goto L_90259F0; case 0x90259F2u: goto L_90259F2; case 0x9025A14u: goto L_9025A14; case 0x9025A1Au: goto L_9025A1A; case 0x9025A29u: goto L_9025A29; case 0x9025A3Fu: goto L_9025A3F; case 0x9025A40u: goto L_9025A40; case 0x9025A4Bu: goto L_9025A4B; case 0x9025A4Fu: goto L_9025A4F; case 0x9025A5Fu: goto L_9025A5F; case 0x9025A64u: goto L_9025A64; case 0x9025A6Du: goto L_9025A6D; case 0x9025A7Bu: goto L_9025A7B; case 0x9025A82u: goto L_9025A82; case 0x9025A98u: goto L_9025A98; case 0x9025AD3u: goto L_9025AD3; case 0x9025AE6u: goto L_9025AE6; case 0x9025AEAu: goto L_9025AEA; case 0x9025AFAu: goto L_9025AFA; case 0x9025AFFu: goto L_9025AFF; case 0x9025B04u: goto L_9025B04; case 0x9025B1Eu: goto L_9025B1E; case 0x9025B33u: goto L_9025B33; case 0x9025B43u: goto L_9025B43; case 0x9025B48u: goto L_9025B48; case 0x9025B53u: goto L_9025B53; case 0x9025B55u: goto L_9025B55; case 0x9025B76u: goto L_9025B76; case 0x9025B7Bu: goto L_9025B7B; case 0x9025B8Bu: goto L_9025B8B; case 0x9025B90u: goto L_9025B90; case 0x9025B95u: goto L_9025B95; case 0x9025BAFu: goto L_9025BAF; case 0x9025BC4u: goto L_9025BC4; case 0x9025BD4u: goto L_9025BD4; case 0x9025BD9u: goto L_9025BD9; case 0x9025BE4u: goto L_9025BE4; case 0x9025BE6u: goto L_9025BE6; case 0x9025C07u: goto L_9025C07; case 0x9025C0Cu: goto L_9025C0C; case 0x9025C1Cu: goto L_9025C1C; case 0x9025C21u: goto L_9025C21; case 0x9025C26u: goto L_9025C26; case 0x9025C40u: goto L_9025C40; case 0x9025C55u: goto L_9025C55; case 0x9025C65u: goto L_9025C65; case 0x9025C6Au: goto L_9025C6A; case 0x9025C75u: goto L_9025C75; case 0x9025C77u: goto L_9025C77; case 0x9025C98u: goto L_9025C98; case 0x9025C9Du: goto L_9025C9D; case 0x9025CADu: goto L_9025CAD; case 0x9025CB2u: goto L_9025CB2; case 0x9025CB7u: goto L_9025CB7; case 0x9025CD8u: goto L_9025CD8; case 0x9025CEDu: goto L_9025CED; case 0x9025CFDu: goto L_9025CFD; case 0x9025D02u: goto L_9025D02; case 0x9025D0Du: goto L_9025D0D; case 0x9025D0Fu: goto L_9025D0F; case 0x9025D30u: goto L_9025D30; case 0x9025D38u: goto L_9025D38; case 0x9025D50u: goto L_9025D50; case 0x9025D60u: goto L_9025D60; case 0x9025D65u: goto L_9025D65; case 0x9025D70u: goto L_9025D70; case 0x9025D72u: goto L_9025D72; case 0x9025D8Fu: goto L_9025D8F; case 0x9025D9Eu: goto L_9025D9E; case 0x9025DA4u: goto L_9025DA4; case 0x9025DB2u: goto L_9025DB2; case 0x9025DC5u: goto L_9025DC5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025A82(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025A82;
L_90259A2:
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), ebx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.zf || f.sf != f.of)) goto L_9025A29;
    goto L_90259B2;
L_90259B2:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90259C6;
    goto L_90259B6;
L_90259B6:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ecx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_90259CB;
L_90259C6:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_90259CB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025A1A;
    goto L_90259D0;
L_90259D0:
    ecx = (uint32_t)(TL8((uint32_t)(ebp + ebx + 0xFFFFFFBCu)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFF10u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.sf == f.of)) goto L_90259F2;
    goto L_90259F0;
L_90259F0:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90259F2:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025A14;
L_9025A14:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
L_9025A1A:
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.sf != f.of)) goto L_90259B2;
    goto L_9025A29;
L_9025A29:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (uint32_t)(ecx);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    (void)sub32(ecx, edx, &f);
    if (!f.cf) goto L_9025DB2;
    goto L_9025A3F;
L_9025A3F:
L_9025A40:
    ecx = (uint32_t)(TL8((uint32_t)(ebx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A4B;
L_9025A4B:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025A5F;
    goto L_9025A4F;
L_9025A4F:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025A64;
L_9025A5F:
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025A64:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A6D;
L_9025A6D:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_9025D9E;
    goto L_9025A7B;
L_9025A7B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x9025DE4u)); goto L_dispatch; }
L_9025A82:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    goto L_9025AE6;
L_9025A98:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF1Cu), (uint32_t)(edx));
    goto L_9025DA4;
L_9025AD3:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(edx), (uint8_t)((uint8_t)0x0u));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(edx));
L_9025AE6:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025AFA;
    goto L_9025AEA;
L_9025AEA:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025AFF;
L_9025AFA:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025AFF:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025B1E;
    goto L_9025B04;
L_9025B04:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025B76;
L_9025B1E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B43;
    goto L_9025B33;
L_9025B33:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B48;
L_9025B43:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B48:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025B55;
    goto L_9025B53;
L_9025B53:
    edx = (uint32_t)(neg32(edx, &f));
L_9025B55:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025B76;
L_9025B76:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B8B;
    goto L_9025B7B;
L_9025B7B:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B90;
L_9025B8B:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B90:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025BAF;
    goto L_9025B95;
L_9025B95:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C07;
L_9025BAF:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025BD4;
    goto L_9025BC4;
L_9025BC4:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025BD9;
L_9025BD4:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025BD9:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025BE6;
    goto L_9025BE4;
L_9025BE4:
    edx = (uint32_t)(neg32(edx, &f));
L_9025BE6:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C07;
L_9025C07:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C1C;
    goto L_9025C0C;
L_9025C0C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C21;
L_9025C1C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C21:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025C40;
    goto L_9025C26;
L_9025C26:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C98;
L_9025C40:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C65;
    goto L_9025C55;
L_9025C55:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C6A;
L_9025C65:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C6A:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025C77;
    goto L_9025C75;
L_9025C75:
    edx = (uint32_t)(neg32(edx, &f));
L_9025C77:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C98;
L_9025C98:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CAD;
    goto L_9025C9D;
L_9025C9D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025CB2;
L_9025CAD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025CB2:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025CD8;
    goto L_9025CB7;
L_9025CB7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025CD8:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CFD;
    goto L_9025CED;
L_9025CED:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D02;
L_9025CFD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D02:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D0F;
    goto L_9025D0D;
L_9025D0D:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D0F:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D30;
L_9025D30:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025D38:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025D60;
    goto L_9025D50;
L_9025D50:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D65;
L_9025D60:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D65:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D72;
    goto L_9025D70;
L_9025D70:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D72:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D8F;
L_9025D8F:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_9025D9E:
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF28u)), &f)));
L_9025DA4:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_9025A40;
    goto L_9025DB2;
L_9025DB2:
    TS32((uint32_t)(ebp + 0xFFFFFF34u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF34u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF18u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFF18u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_90259A2;
    goto L_9025DC5;
L_9025DC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9025DE0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90259A2u: goto L_90259A2; case 0x90259B2u: goto L_90259B2; case 0x90259B6u: goto L_90259B6; case 0x90259C6u: goto L_90259C6; case 0x90259CBu: goto L_90259CB; case 0x90259D0u: goto L_90259D0; case 0x90259F0u: goto L_90259F0; case 0x90259F2u: goto L_90259F2; case 0x9025A14u: goto L_9025A14; case 0x9025A1Au: goto L_9025A1A; case 0x9025A29u: goto L_9025A29; case 0x9025A3Fu: goto L_9025A3F; case 0x9025A40u: goto L_9025A40; case 0x9025A4Bu: goto L_9025A4B; case 0x9025A4Fu: goto L_9025A4F; case 0x9025A5Fu: goto L_9025A5F; case 0x9025A64u: goto L_9025A64; case 0x9025A6Du: goto L_9025A6D; case 0x9025A7Bu: goto L_9025A7B; case 0x9025A82u: goto L_9025A82; case 0x9025A98u: goto L_9025A98; case 0x9025AD3u: goto L_9025AD3; case 0x9025AE6u: goto L_9025AE6; case 0x9025AEAu: goto L_9025AEA; case 0x9025AFAu: goto L_9025AFA; case 0x9025AFFu: goto L_9025AFF; case 0x9025B04u: goto L_9025B04; case 0x9025B1Eu: goto L_9025B1E; case 0x9025B33u: goto L_9025B33; case 0x9025B43u: goto L_9025B43; case 0x9025B48u: goto L_9025B48; case 0x9025B53u: goto L_9025B53; case 0x9025B55u: goto L_9025B55; case 0x9025B76u: goto L_9025B76; case 0x9025B7Bu: goto L_9025B7B; case 0x9025B8Bu: goto L_9025B8B; case 0x9025B90u: goto L_9025B90; case 0x9025B95u: goto L_9025B95; case 0x9025BAFu: goto L_9025BAF; case 0x9025BC4u: goto L_9025BC4; case 0x9025BD4u: goto L_9025BD4; case 0x9025BD9u: goto L_9025BD9; case 0x9025BE4u: goto L_9025BE4; case 0x9025BE6u: goto L_9025BE6; case 0x9025C07u: goto L_9025C07; case 0x9025C0Cu: goto L_9025C0C; case 0x9025C1Cu: goto L_9025C1C; case 0x9025C21u: goto L_9025C21; case 0x9025C26u: goto L_9025C26; case 0x9025C40u: goto L_9025C40; case 0x9025C55u: goto L_9025C55; case 0x9025C65u: goto L_9025C65; case 0x9025C6Au: goto L_9025C6A; case 0x9025C75u: goto L_9025C75; case 0x9025C77u: goto L_9025C77; case 0x9025C98u: goto L_9025C98; case 0x9025C9Du: goto L_9025C9D; case 0x9025CADu: goto L_9025CAD; case 0x9025CB2u: goto L_9025CB2; case 0x9025CB7u: goto L_9025CB7; case 0x9025CD8u: goto L_9025CD8; case 0x9025CEDu: goto L_9025CED; case 0x9025CFDu: goto L_9025CFD; case 0x9025D02u: goto L_9025D02; case 0x9025D0Du: goto L_9025D0D; case 0x9025D0Fu: goto L_9025D0F; case 0x9025D30u: goto L_9025D30; case 0x9025D38u: goto L_9025D38; case 0x9025D50u: goto L_9025D50; case 0x9025D60u: goto L_9025D60; case 0x9025D65u: goto L_9025D65; case 0x9025D70u: goto L_9025D70; case 0x9025D72u: goto L_9025D72; case 0x9025D8Fu: goto L_9025D8F; case 0x9025D9Eu: goto L_9025D9E; case 0x9025DA4u: goto L_9025DA4; case 0x9025DB2u: goto L_9025DB2; case 0x9025DC5u: goto L_9025DC5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025A98(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025A98;
L_90259A2:
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), ebx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.zf || f.sf != f.of)) goto L_9025A29;
    goto L_90259B2;
L_90259B2:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90259C6;
    goto L_90259B6;
L_90259B6:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ecx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_90259CB;
L_90259C6:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_90259CB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025A1A;
    goto L_90259D0;
L_90259D0:
    ecx = (uint32_t)(TL8((uint32_t)(ebp + ebx + 0xFFFFFFBCu)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFF10u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.sf == f.of)) goto L_90259F2;
    goto L_90259F0;
L_90259F0:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90259F2:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025A14;
L_9025A14:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
L_9025A1A:
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.sf != f.of)) goto L_90259B2;
    goto L_9025A29;
L_9025A29:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (uint32_t)(ecx);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    (void)sub32(ecx, edx, &f);
    if (!f.cf) goto L_9025DB2;
    goto L_9025A3F;
L_9025A3F:
L_9025A40:
    ecx = (uint32_t)(TL8((uint32_t)(ebx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A4B;
L_9025A4B:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025A5F;
    goto L_9025A4F;
L_9025A4F:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025A64;
L_9025A5F:
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025A64:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A6D;
L_9025A6D:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_9025D9E;
    goto L_9025A7B;
L_9025A7B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x9025DE4u)); goto L_dispatch; }
L_9025A82:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    goto L_9025AE6;
L_9025A98:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF1Cu), (uint32_t)(edx));
    goto L_9025DA4;
L_9025AD3:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(edx), (uint8_t)((uint8_t)0x0u));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(edx));
L_9025AE6:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025AFA;
    goto L_9025AEA;
L_9025AEA:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025AFF;
L_9025AFA:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025AFF:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025B1E;
    goto L_9025B04;
L_9025B04:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025B76;
L_9025B1E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B43;
    goto L_9025B33;
L_9025B33:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B48;
L_9025B43:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B48:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025B55;
    goto L_9025B53;
L_9025B53:
    edx = (uint32_t)(neg32(edx, &f));
L_9025B55:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025B76;
L_9025B76:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B8B;
    goto L_9025B7B;
L_9025B7B:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B90;
L_9025B8B:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B90:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025BAF;
    goto L_9025B95;
L_9025B95:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C07;
L_9025BAF:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025BD4;
    goto L_9025BC4;
L_9025BC4:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025BD9;
L_9025BD4:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025BD9:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025BE6;
    goto L_9025BE4;
L_9025BE4:
    edx = (uint32_t)(neg32(edx, &f));
L_9025BE6:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C07;
L_9025C07:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C1C;
    goto L_9025C0C;
L_9025C0C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C21;
L_9025C1C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C21:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025C40;
    goto L_9025C26;
L_9025C26:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C98;
L_9025C40:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C65;
    goto L_9025C55;
L_9025C55:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C6A;
L_9025C65:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C6A:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025C77;
    goto L_9025C75;
L_9025C75:
    edx = (uint32_t)(neg32(edx, &f));
L_9025C77:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C98;
L_9025C98:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CAD;
    goto L_9025C9D;
L_9025C9D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025CB2;
L_9025CAD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025CB2:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025CD8;
    goto L_9025CB7;
L_9025CB7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025CD8:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CFD;
    goto L_9025CED;
L_9025CED:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D02;
L_9025CFD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D02:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D0F;
    goto L_9025D0D;
L_9025D0D:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D0F:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D30;
L_9025D30:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025D38:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025D60;
    goto L_9025D50;
L_9025D50:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D65;
L_9025D60:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D65:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D72;
    goto L_9025D70;
L_9025D70:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D72:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D8F;
L_9025D8F:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_9025D9E:
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF28u)), &f)));
L_9025DA4:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_9025A40;
    goto L_9025DB2;
L_9025DB2:
    TS32((uint32_t)(ebp + 0xFFFFFF34u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF34u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF18u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFF18u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_90259A2;
    goto L_9025DC5;
L_9025DC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9025DE0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90259A2u: goto L_90259A2; case 0x90259B2u: goto L_90259B2; case 0x90259B6u: goto L_90259B6; case 0x90259C6u: goto L_90259C6; case 0x90259CBu: goto L_90259CB; case 0x90259D0u: goto L_90259D0; case 0x90259F0u: goto L_90259F0; case 0x90259F2u: goto L_90259F2; case 0x9025A14u: goto L_9025A14; case 0x9025A1Au: goto L_9025A1A; case 0x9025A29u: goto L_9025A29; case 0x9025A3Fu: goto L_9025A3F; case 0x9025A40u: goto L_9025A40; case 0x9025A4Bu: goto L_9025A4B; case 0x9025A4Fu: goto L_9025A4F; case 0x9025A5Fu: goto L_9025A5F; case 0x9025A64u: goto L_9025A64; case 0x9025A6Du: goto L_9025A6D; case 0x9025A7Bu: goto L_9025A7B; case 0x9025A82u: goto L_9025A82; case 0x9025A98u: goto L_9025A98; case 0x9025AD3u: goto L_9025AD3; case 0x9025AE6u: goto L_9025AE6; case 0x9025AEAu: goto L_9025AEA; case 0x9025AFAu: goto L_9025AFA; case 0x9025AFFu: goto L_9025AFF; case 0x9025B04u: goto L_9025B04; case 0x9025B1Eu: goto L_9025B1E; case 0x9025B33u: goto L_9025B33; case 0x9025B43u: goto L_9025B43; case 0x9025B48u: goto L_9025B48; case 0x9025B53u: goto L_9025B53; case 0x9025B55u: goto L_9025B55; case 0x9025B76u: goto L_9025B76; case 0x9025B7Bu: goto L_9025B7B; case 0x9025B8Bu: goto L_9025B8B; case 0x9025B90u: goto L_9025B90; case 0x9025B95u: goto L_9025B95; case 0x9025BAFu: goto L_9025BAF; case 0x9025BC4u: goto L_9025BC4; case 0x9025BD4u: goto L_9025BD4; case 0x9025BD9u: goto L_9025BD9; case 0x9025BE4u: goto L_9025BE4; case 0x9025BE6u: goto L_9025BE6; case 0x9025C07u: goto L_9025C07; case 0x9025C0Cu: goto L_9025C0C; case 0x9025C1Cu: goto L_9025C1C; case 0x9025C21u: goto L_9025C21; case 0x9025C26u: goto L_9025C26; case 0x9025C40u: goto L_9025C40; case 0x9025C55u: goto L_9025C55; case 0x9025C65u: goto L_9025C65; case 0x9025C6Au: goto L_9025C6A; case 0x9025C75u: goto L_9025C75; case 0x9025C77u: goto L_9025C77; case 0x9025C98u: goto L_9025C98; case 0x9025C9Du: goto L_9025C9D; case 0x9025CADu: goto L_9025CAD; case 0x9025CB2u: goto L_9025CB2; case 0x9025CB7u: goto L_9025CB7; case 0x9025CD8u: goto L_9025CD8; case 0x9025CEDu: goto L_9025CED; case 0x9025CFDu: goto L_9025CFD; case 0x9025D02u: goto L_9025D02; case 0x9025D0Du: goto L_9025D0D; case 0x9025D0Fu: goto L_9025D0F; case 0x9025D30u: goto L_9025D30; case 0x9025D38u: goto L_9025D38; case 0x9025D50u: goto L_9025D50; case 0x9025D60u: goto L_9025D60; case 0x9025D65u: goto L_9025D65; case 0x9025D70u: goto L_9025D70; case 0x9025D72u: goto L_9025D72; case 0x9025D8Fu: goto L_9025D8F; case 0x9025D9Eu: goto L_9025D9E; case 0x9025DA4u: goto L_9025DA4; case 0x9025DB2u: goto L_9025DB2; case 0x9025DC5u: goto L_9025DC5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025AD3(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025AD3;
L_90259A2:
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), ebx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.zf || f.sf != f.of)) goto L_9025A29;
    goto L_90259B2;
L_90259B2:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90259C6;
    goto L_90259B6;
L_90259B6:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ecx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_90259CB;
L_90259C6:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_90259CB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025A1A;
    goto L_90259D0;
L_90259D0:
    ecx = (uint32_t)(TL8((uint32_t)(ebp + ebx + 0xFFFFFFBCu)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFF10u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.sf == f.of)) goto L_90259F2;
    goto L_90259F0;
L_90259F0:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90259F2:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025A14;
L_9025A14:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
L_9025A1A:
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.sf != f.of)) goto L_90259B2;
    goto L_9025A29;
L_9025A29:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (uint32_t)(ecx);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    (void)sub32(ecx, edx, &f);
    if (!f.cf) goto L_9025DB2;
    goto L_9025A3F;
L_9025A3F:
L_9025A40:
    ecx = (uint32_t)(TL8((uint32_t)(ebx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A4B;
L_9025A4B:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025A5F;
    goto L_9025A4F;
L_9025A4F:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025A64;
L_9025A5F:
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025A64:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A6D;
L_9025A6D:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_9025D9E;
    goto L_9025A7B;
L_9025A7B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x9025DE4u)); goto L_dispatch; }
L_9025A82:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    goto L_9025AE6;
L_9025A98:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF1Cu), (uint32_t)(edx));
    goto L_9025DA4;
L_9025AD3:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(edx), (uint8_t)((uint8_t)0x0u));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(edx));
L_9025AE6:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025AFA;
    goto L_9025AEA;
L_9025AEA:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025AFF;
L_9025AFA:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025AFF:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025B1E;
    goto L_9025B04;
L_9025B04:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025B76;
L_9025B1E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B43;
    goto L_9025B33;
L_9025B33:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B48;
L_9025B43:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B48:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025B55;
    goto L_9025B53;
L_9025B53:
    edx = (uint32_t)(neg32(edx, &f));
L_9025B55:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025B76;
L_9025B76:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B8B;
    goto L_9025B7B;
L_9025B7B:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B90;
L_9025B8B:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B90:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025BAF;
    goto L_9025B95;
L_9025B95:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C07;
L_9025BAF:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025BD4;
    goto L_9025BC4;
L_9025BC4:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025BD9;
L_9025BD4:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025BD9:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025BE6;
    goto L_9025BE4;
L_9025BE4:
    edx = (uint32_t)(neg32(edx, &f));
L_9025BE6:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C07;
L_9025C07:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C1C;
    goto L_9025C0C;
L_9025C0C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C21;
L_9025C1C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C21:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025C40;
    goto L_9025C26;
L_9025C26:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C98;
L_9025C40:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C65;
    goto L_9025C55;
L_9025C55:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C6A;
L_9025C65:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C6A:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025C77;
    goto L_9025C75;
L_9025C75:
    edx = (uint32_t)(neg32(edx, &f));
L_9025C77:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C98;
L_9025C98:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CAD;
    goto L_9025C9D;
L_9025C9D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025CB2;
L_9025CAD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025CB2:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025CD8;
    goto L_9025CB7;
L_9025CB7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025CD8:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CFD;
    goto L_9025CED;
L_9025CED:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D02;
L_9025CFD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D02:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D0F;
    goto L_9025D0D;
L_9025D0D:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D0F:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D30;
L_9025D30:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025D38:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025D60;
    goto L_9025D50;
L_9025D50:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D65;
L_9025D60:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D65:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D72;
    goto L_9025D70;
L_9025D70:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D72:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D8F;
L_9025D8F:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_9025D9E:
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF28u)), &f)));
L_9025DA4:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_9025A40;
    goto L_9025DB2;
L_9025DB2:
    TS32((uint32_t)(ebp + 0xFFFFFF34u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF34u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF18u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFF18u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_90259A2;
    goto L_9025DC5;
L_9025DC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9025DE0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90259A2u: goto L_90259A2; case 0x90259B2u: goto L_90259B2; case 0x90259B6u: goto L_90259B6; case 0x90259C6u: goto L_90259C6; case 0x90259CBu: goto L_90259CB; case 0x90259D0u: goto L_90259D0; case 0x90259F0u: goto L_90259F0; case 0x90259F2u: goto L_90259F2; case 0x9025A14u: goto L_9025A14; case 0x9025A1Au: goto L_9025A1A; case 0x9025A29u: goto L_9025A29; case 0x9025A3Fu: goto L_9025A3F; case 0x9025A40u: goto L_9025A40; case 0x9025A4Bu: goto L_9025A4B; case 0x9025A4Fu: goto L_9025A4F; case 0x9025A5Fu: goto L_9025A5F; case 0x9025A64u: goto L_9025A64; case 0x9025A6Du: goto L_9025A6D; case 0x9025A7Bu: goto L_9025A7B; case 0x9025A82u: goto L_9025A82; case 0x9025A98u: goto L_9025A98; case 0x9025AD3u: goto L_9025AD3; case 0x9025AE6u: goto L_9025AE6; case 0x9025AEAu: goto L_9025AEA; case 0x9025AFAu: goto L_9025AFA; case 0x9025AFFu: goto L_9025AFF; case 0x9025B04u: goto L_9025B04; case 0x9025B1Eu: goto L_9025B1E; case 0x9025B33u: goto L_9025B33; case 0x9025B43u: goto L_9025B43; case 0x9025B48u: goto L_9025B48; case 0x9025B53u: goto L_9025B53; case 0x9025B55u: goto L_9025B55; case 0x9025B76u: goto L_9025B76; case 0x9025B7Bu: goto L_9025B7B; case 0x9025B8Bu: goto L_9025B8B; case 0x9025B90u: goto L_9025B90; case 0x9025B95u: goto L_9025B95; case 0x9025BAFu: goto L_9025BAF; case 0x9025BC4u: goto L_9025BC4; case 0x9025BD4u: goto L_9025BD4; case 0x9025BD9u: goto L_9025BD9; case 0x9025BE4u: goto L_9025BE4; case 0x9025BE6u: goto L_9025BE6; case 0x9025C07u: goto L_9025C07; case 0x9025C0Cu: goto L_9025C0C; case 0x9025C1Cu: goto L_9025C1C; case 0x9025C21u: goto L_9025C21; case 0x9025C26u: goto L_9025C26; case 0x9025C40u: goto L_9025C40; case 0x9025C55u: goto L_9025C55; case 0x9025C65u: goto L_9025C65; case 0x9025C6Au: goto L_9025C6A; case 0x9025C75u: goto L_9025C75; case 0x9025C77u: goto L_9025C77; case 0x9025C98u: goto L_9025C98; case 0x9025C9Du: goto L_9025C9D; case 0x9025CADu: goto L_9025CAD; case 0x9025CB2u: goto L_9025CB2; case 0x9025CB7u: goto L_9025CB7; case 0x9025CD8u: goto L_9025CD8; case 0x9025CEDu: goto L_9025CED; case 0x9025CFDu: goto L_9025CFD; case 0x9025D02u: goto L_9025D02; case 0x9025D0Du: goto L_9025D0D; case 0x9025D0Fu: goto L_9025D0F; case 0x9025D30u: goto L_9025D30; case 0x9025D38u: goto L_9025D38; case 0x9025D50u: goto L_9025D50; case 0x9025D60u: goto L_9025D60; case 0x9025D65u: goto L_9025D65; case 0x9025D70u: goto L_9025D70; case 0x9025D72u: goto L_9025D72; case 0x9025D8Fu: goto L_9025D8F; case 0x9025D9Eu: goto L_9025D9E; case 0x9025DA4u: goto L_9025DA4; case 0x9025DB2u: goto L_9025DB2; case 0x9025DC5u: goto L_9025DC5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025D38(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9025D38;
L_90259A2:
    ebx = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), ebx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.zf || f.sf != f.of)) goto L_9025A29;
    goto L_90259B2;
L_90259B2:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_90259C6;
    goto L_90259B6;
L_90259B6:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ecx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_90259CB;
L_90259C6:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_90259CB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025A1A;
    goto L_90259D0;
L_90259D0:
    ecx = (uint32_t)(TL8((uint32_t)(ebp + ebx + 0xFFFFFFBCu)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFF10u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if ((f.sf == f.of)) goto L_90259F2;
    goto L_90259F0;
L_90259F0:
    ecx = (uint32_t)(neg32(ecx, &f));
L_90259F2:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ebx), &f));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF10u)));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025A14;
L_9025A14:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
L_9025A1A:
    ebx = (uint32_t)(inc32(ebx, &f));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    if ((f.sf != f.of)) goto L_90259B2;
    goto L_9025A29;
L_9025A29:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (uint32_t)(ecx);
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(ebx));
    (void)sub32(ecx, edx, &f);
    if (!f.cf) goto L_9025DB2;
    goto L_9025A3F;
L_9025A3F:
L_9025A40:
    ecx = (uint32_t)(TL8((uint32_t)(ebx)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A4B;
L_9025A4B:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025A5F;
    goto L_9025A4F;
L_9025A4F:
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(ebx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025A64;
L_9025A5F:
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025A64:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025D9E;
    goto L_9025A6D;
L_9025A6D:
    ebx = (uint32_t)(ecx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x3u), &f));
    (void)sub32(ebx, (uint32_t)0x3u, &f);
    if ((!f.cf && !f.zf)) goto L_9025D9E;
    goto L_9025A7B;
L_9025A7B:
    { jt_ = TL32((uint32_t)(ebx*4 + 0x9025DE4u)); goto L_dispatch; }
L_9025A82:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)edx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x11u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    goto L_9025AE6;
L_9025A98:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x12u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    edx = (uint32_t)(inc32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x22u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x32u, &f));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF1Cu), (uint32_t)(edx));
    goto L_9025DA4;
L_9025AD3:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(edx), (uint8_t)((uint8_t)0x0u));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(edx));
L_9025AE6:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025AFA;
    goto L_9025AEA;
L_9025AEA:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025AFF;
L_9025AFA:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025AFF:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025B1E;
    goto L_9025B04;
L_9025B04:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025B76;
L_9025B1E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B43;
    goto L_9025B33;
L_9025B33:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B48;
L_9025B43:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B48:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025B55;
    goto L_9025B53;
L_9025B53:
    edx = (uint32_t)(neg32(edx, &f));
L_9025B55:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025B76;
L_9025B76:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025B8B;
    goto L_9025B7B;
L_9025B7B:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025B90;
L_9025B8B:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025B90:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025BAF;
    goto L_9025B95;
L_9025B95:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C07;
L_9025BAF:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025BD4;
    goto L_9025BC4;
L_9025BC4:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025BD9;
L_9025BD4:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025BD9:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025BE6;
    goto L_9025BE4;
L_9025BE4:
    edx = (uint32_t)(neg32(edx, &f));
L_9025BE6:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C07;
L_9025C07:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C1C;
    goto L_9025C0C;
L_9025C0C:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C21;
L_9025C1C:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C21:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025C40;
    goto L_9025C26;
L_9025C26:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), ((uint8_t)ebx), &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ebx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ebx)));
    goto L_9025C98;
L_9025C40:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025C65;
    goto L_9025C55;
L_9025C55:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025C6A;
L_9025C65:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025C6A:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025C77;
    goto L_9025C75;
L_9025C75:
    edx = (uint32_t)(neg32(edx, &f));
L_9025C77:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(edx));
    (void)sub32(ebx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025C98;
L_9025C98:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CAD;
    goto L_9025C9D;
L_9025C9D:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025CB2;
L_9025CAD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025CB2:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_9025CD8;
    goto L_9025CB7;
L_9025CB7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF24u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    edx = (uint32_t)(dec32(edx, &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)ecx), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), (uint8_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF24u), (uint32_t)(edx));
    TS8((uint32_t)(edx), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025CD8:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025CFD;
    goto L_9025CED;
L_9025CED:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D02;
L_9025CFD:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D02:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D0F;
    goto L_9025D0D;
L_9025D0D:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D0F:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D30;
L_9025D30:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    goto L_9025DA4;
L_9025D38:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFFBCu), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_9025D60;
    goto L_9025D50;
L_9025D50:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)((uint32_t)0x1Fu);
    goto L_9025D65;
L_9025D60:
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(dec32(esi, &f));
L_9025D65:
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF34u)));
    if (f.zf) goto L_9025D72;
    goto L_9025D70;
L_9025D70:
    edx = (uint32_t)(neg32(edx, &f));
L_9025D72:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF20u)));
    TS8((uint32_t)(ebx + ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF30u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(inc32(ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF30u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xCu)), &f);
    if (f.zf) goto L_9025DC5;
    goto L_9025D8F;
L_9025D8F:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF1Cu)));
    TS8((uint32_t)(ecx), (uint8_t)((uint8_t)0x0u));
L_9025D9E:
    TS32((uint32_t)(ebp + 0xFFFFFF28u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF28u)), &f)));
L_9025DA4:
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    (void)sub32(ebx, edx, &f);
    if (f.cf) goto L_9025A40;
    goto L_9025DB2;
L_9025DB2:
    TS32((uint32_t)(ebp + 0xFFFFFF34u), (uint32_t)(sar32(TL32((uint32_t)(ebp + 0xFFFFFF34u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF18u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFF18u)), (uint32_t)0x1u, &f)));
    if (!f.zf) goto L_90259A2;
    goto L_9025DC5;
L_9025DC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF14u)));
    TS32((uint32_t)(ecx + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(ecx + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x9025DE0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x90259A2u: goto L_90259A2; case 0x90259B2u: goto L_90259B2; case 0x90259B6u: goto L_90259B6; case 0x90259C6u: goto L_90259C6; case 0x90259CBu: goto L_90259CB; case 0x90259D0u: goto L_90259D0; case 0x90259F0u: goto L_90259F0; case 0x90259F2u: goto L_90259F2; case 0x9025A14u: goto L_9025A14; case 0x9025A1Au: goto L_9025A1A; case 0x9025A29u: goto L_9025A29; case 0x9025A3Fu: goto L_9025A3F; case 0x9025A40u: goto L_9025A40; case 0x9025A4Bu: goto L_9025A4B; case 0x9025A4Fu: goto L_9025A4F; case 0x9025A5Fu: goto L_9025A5F; case 0x9025A64u: goto L_9025A64; case 0x9025A6Du: goto L_9025A6D; case 0x9025A7Bu: goto L_9025A7B; case 0x9025A82u: goto L_9025A82; case 0x9025A98u: goto L_9025A98; case 0x9025AD3u: goto L_9025AD3; case 0x9025AE6u: goto L_9025AE6; case 0x9025AEAu: goto L_9025AEA; case 0x9025AFAu: goto L_9025AFA; case 0x9025AFFu: goto L_9025AFF; case 0x9025B04u: goto L_9025B04; case 0x9025B1Eu: goto L_9025B1E; case 0x9025B33u: goto L_9025B33; case 0x9025B43u: goto L_9025B43; case 0x9025B48u: goto L_9025B48; case 0x9025B53u: goto L_9025B53; case 0x9025B55u: goto L_9025B55; case 0x9025B76u: goto L_9025B76; case 0x9025B7Bu: goto L_9025B7B; case 0x9025B8Bu: goto L_9025B8B; case 0x9025B90u: goto L_9025B90; case 0x9025B95u: goto L_9025B95; case 0x9025BAFu: goto L_9025BAF; case 0x9025BC4u: goto L_9025BC4; case 0x9025BD4u: goto L_9025BD4; case 0x9025BD9u: goto L_9025BD9; case 0x9025BE4u: goto L_9025BE4; case 0x9025BE6u: goto L_9025BE6; case 0x9025C07u: goto L_9025C07; case 0x9025C0Cu: goto L_9025C0C; case 0x9025C1Cu: goto L_9025C1C; case 0x9025C21u: goto L_9025C21; case 0x9025C26u: goto L_9025C26; case 0x9025C40u: goto L_9025C40; case 0x9025C55u: goto L_9025C55; case 0x9025C65u: goto L_9025C65; case 0x9025C6Au: goto L_9025C6A; case 0x9025C75u: goto L_9025C75; case 0x9025C77u: goto L_9025C77; case 0x9025C98u: goto L_9025C98; case 0x9025C9Du: goto L_9025C9D; case 0x9025CADu: goto L_9025CAD; case 0x9025CB2u: goto L_9025CB2; case 0x9025CB7u: goto L_9025CB7; case 0x9025CD8u: goto L_9025CD8; case 0x9025CEDu: goto L_9025CED; case 0x9025CFDu: goto L_9025CFD; case 0x9025D02u: goto L_9025D02; case 0x9025D0Du: goto L_9025D0D; case 0x9025D0Fu: goto L_9025D0F; case 0x9025D30u: goto L_9025D30; case 0x9025D38u: goto L_9025D38; case 0x9025D50u: goto L_9025D50; case 0x9025D60u: goto L_9025D60; case 0x9025D65u: goto L_9025D65; case 0x9025D70u: goto L_9025D70; case 0x9025D72u: goto L_9025D72; case 0x9025D8Fu: goto L_9025D8F; case 0x9025D9Eu: goto L_9025D9E; case 0x9025DA4u: goto L_9025DA4; case 0x9025DB2u: goto L_9025DB2; case 0x9025DC5u: goto L_9025DC5; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9025DE4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9025DE4:
    TS8((uint32_t)(edx + 0x2u), (uint8_t)(sbb8(TL8((uint32_t)(edx + 0x2u)), (uint8_t)0x9u, &f)));
    eax = (uint32_t)(int32_t)(int16_t)eax;
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    TS32((uint32_t)(edx + 0x2u), (uint32_t)(rcr32(TL32((uint32_t)(edx + 0x2u)), ((uint8_t)ecx), &f)));
    TS32((uint32_t)(eax), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax)) | edi), &f)));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), TL8((uint32_t)(ecx)), &f));
    SPILL(); rt_int3(c, 0x9025DF4u);
    { SPILL(); rt_call(c, 0x9025DF5u); return; }
}

void f_9025E00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9025E00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x44u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = 0x38u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9025E1Eu; SPILL(); f_9001EB0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9025E2Eu; SPILL(); f_90258D0(c); RELOAD();
    ecx = (uint32_t)(TL8((uint32_t)(esi)));
    edx = (uint32_t)(TL8((uint32_t)(esi + 0x1u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFC0u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(eax >> 8)), &f));
    TS8((uint32_t)(edi + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(esi + 0x3u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)eax), &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), ((uint8_t)(eax >> 8)), &f));
    TS8((uint32_t)(edi + 0x3u), (uint8_t)(((uint8_t)edx)));
    TS8((uint32_t)(edi), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(esi + 0x2u)));
    edx = (uint32_t)(TL8((uint32_t)(esi + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFCCu)), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), ((uint8_t)eax), &f));
    eax = (uint32_t)(TL8((uint32_t)(esi + 0x4u)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), M8((uint32_t)(ebp + 0xFFFFFFC8u)), &f));
    TS8((uint32_t)(edi + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(esi + ebx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFC2u)), &f));
    TS8((uint32_t)(edi + 0x2u), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(TL8((uint32_t)(esi + 0x5u)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), M8((uint32_t)(ebp + 0xFFFFFFC9u)), &f));
    TS8((uint32_t)(edi + 0x4u), (uint8_t)(((uint8_t)eax)));
    eax = (uint32_t)(TL8((uint32_t)(esi + 0x7u)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), M8((uint32_t)(ebp + 0xFFFFFFCDu)), &f));
    TS8((uint32_t)(edi + 0x5u), (uint8_t)(((uint8_t)ecx)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS8((uint32_t)(edi + 0x7u), (uint8_t)(((uint8_t)eax)));
    TS8((uint32_t)(edi + ecx), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(esi + ebx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFC3u)), &f));
    eax = (uint32_t)((uint32_t)(edi + ecx));
    ecx = (uint32_t)((uint32_t)(esi + ebx));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFC6u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFC7u)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFCAu)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFCBu)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFCEu)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFCFu)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD8u)), &f));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD9u)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFECu)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFEDu)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD0u)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD1u)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD4u)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD5u)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDAu)), &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDBu)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFEEu)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFEFu)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD2u)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD3u)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD6u)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFD7u)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDCu)), &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDDu)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE0u)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE1u)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF1u)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF5u)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDEu)), &f));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFDFu)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE2u)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE3u)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF2u)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF3u)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF6u)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF7u)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE4u)), &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE5u)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE8u)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE9u)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF8u)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFF9u)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFFDu)), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0x8u)), &f));
    edx = (uint32_t)(TL8((uint32_t)(ecx)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE6u)), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFE7u)), &f));
    TS8((uint32_t)(eax + 0x1u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x2u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFEAu)), &f));
    TS8((uint32_t)(eax + 0x2u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x3u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFEBu)), &f));
    TS8((uint32_t)(eax + 0x3u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x4u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFFAu)), &f));
    TS8((uint32_t)(eax + 0x4u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x5u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFFBu)), &f));
    TS8((uint32_t)(eax + 0x5u), (uint8_t)(((uint8_t)edx)));
    edx = (uint32_t)(TL8((uint32_t)(ecx + 0x6u)));
    ecx = (uint32_t)(TL8((uint32_t)(ecx + 0x7u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)edx), M8((uint32_t)(ebp + 0xFFFFFFFEu)), &f));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)ecx), M8((uint32_t)(ebp + 0xFFFFFFFFu)), &f));
    TS8((uint32_t)(eax + 0x6u), (uint8_t)(((uint8_t)edx)));
    TS8((uint32_t)(eax + 0x7u), (uint8_t)(((uint8_t)ecx)));
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 20; SPILL(); return;
}

