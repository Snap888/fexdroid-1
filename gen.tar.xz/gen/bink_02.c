#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9004390(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004390:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_9004415;
    goto L_90043AB;
L_90043AB:
    goto L_90043B0;
L_90043B0:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrlw(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[4] = c->mm[0];
    c->mm[5] = mmx_punpcklwd(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[5]);
    c->mm[6] = c->mm[1];
    c->mm[1] &= M64((uint32_t)(0x903F830u));
    c->mm[6] = mmx_psrlw(c->mm[6], (uint64_t)8u);
    c->mm[1] = mmx_packuswb(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[1]);
    c->mm[6] = mmx_packuswb(c->mm[6], c->mm[6]);
    c->mm[5] = c->mm[1];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[6]);
    c->mm[5] = mmx_punpckhbw(c->mm[5], c->mm[6]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    M64((uint32_t)(edi + 0x10u)) = c->mm[1];
    M64((uint32_t)(edi + 0x18u)) = c->mm[5];
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90043B0;
    goto L_9004415;
L_9004415:
    (void)logic32((uint32_t)(edx & (uint32_t)0x8u), &f);
    if (f.zf) goto L_9004457;
    goto L_900441D;
L_900441D:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrld(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[5] &= M64((uint32_t)(0x903F830u));
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[4] = c->mm[0];
    c->mm[5] = mmx_punpcklwd(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[5]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
L_9004457:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_900448F;
    goto L_900445F;
L_900445F:
    c->mm[0] = (uint64_t)TL32((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    c->mm[5] = c->mm[0];
    c->mm[0] &= M64((uint32_t)(0x903F830u));
    c->mm[5] = mmx_psrld(c->mm[5], (uint64_t)8u);
    c->mm[0] = mmx_packuswb(c->mm[0], c->mm[0]);
    c->mm[5] &= M64((uint32_t)(0x903F830u));
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[0]);
    c->mm[5] = mmx_packuswb(c->mm[5], c->mm[5]);
    c->mm[5] = mmx_punpcklwd(c->mm[5], c->mm[5]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_900448F:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_90044AB;
    goto L_9004497;
L_9004497:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_90044AB:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90044C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90044C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    if (f.zf) goto L_9004527;
    goto L_90044DA;
L_90044DA:
    ebx = (uint32_t)((uint32_t)(ebx));
L_90044E0:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    c->mm[4] = M64((uint32_t)(esi + 0x20u));
    c->mm[5] = M64((uint32_t)(esi + 0x28u));
    c->mm[6] = M64((uint32_t)(esi + 0x30u));
    c->mm[7] = M64((uint32_t)(esi + 0x38u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x40u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[2];
    M64((uint32_t)(edi + 0x18u)) = c->mm[3];
    M64((uint32_t)(edi + 0x20u)) = c->mm[4];
    M64((uint32_t)(edi + 0x28u)) = c->mm[5];
    M64((uint32_t)(edi + 0x30u)) = c->mm[6];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90044E0;
    goto L_9004527;
L_9004527:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_9004540;
    goto L_9004531;
L_9004531:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9004531;
    goto L_9004540;
L_9004540:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9004552;
    goto L_9004548;
L_9004548:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_9004552:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_9004566;
    goto L_900455A;
L_900455A:
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
L_9004566:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004570(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004570:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    (void)sub32(ebx, (uint32_t)0x1u, &f);
    if (f.zf) goto L_90045AE;
    goto L_90045A5;
L_90045A5:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_90045AE:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebx, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebx);
    if (!f.cf) goto L_90045DB;
    goto L_90045BA;
L_90045BA:
    ebx = (uint32_t)(ebp);
    (void)logic32((uint32_t)(eax & (uint32_t)0x1u), &f);
    if (f.zf) goto L_90045C5;
    goto L_90045C3;
L_90045C3:
    ebx = (uint32_t)(ecx);
L_90045C5:
    eax = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebx)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(edi + 0xFFFFFFFFu))) << 8);
    TS16((uint32_t)(esi), (uint16_t)(((uint16_t)eax)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    ebp = (uint32_t)(add32(ebp, (uint32_t)0x1u, &f));
L_90045DB:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900460F;
    goto L_90045E2;
L_90045E2:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    goto L_90045F0;
L_90045F0:
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(edi + 0x1u))) << 8);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(edi))) << 8);
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(M8((uint32_t)(ebp)));
    ebp = (uint32_t)(add32(ebp, (uint32_t)0x1u, &f));
    edx = (uint32_t)(dec32(edx, &f));
    TS32((uint32_t)(esi + 0xFFFFFFFCu), (uint32_t)(eax));
    if (!f.zf) goto L_90045F0;
    goto L_900460F;
L_900460F:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebp));
    TS32((uint32_t)(eax), (uint32_t)(esi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004630(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004630:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    if (f.zf) goto L_900467E;
    goto L_900464C;
L_900464C:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_9004650:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x10u, &f));
    { uint8_t t_ = ((uint8_t)(edx >> 8)); edx = (edx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)(eax >> 8))) << 8); eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(t_) << 8); }
    { uint8_t t_ = ((uint8_t)(ebx >> 8)); ebx = (ebx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)(ecx >> 8))) << 8); ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(t_) << 8); }
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    if (!f.zf) goto L_9004650;
    goto L_900467D;
L_900467D:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_900467E:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_900469D;
    goto L_9004686;
L_9004686:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    { uint8_t t_ = ((uint8_t)(eax >> 8)); eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)(ecx >> 8))) << 8); ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(t_) << 8); }
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_900469D:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_90046B9;
    goto L_90046A5;
L_90046A5:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_90046B9:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90046D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90046D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebx);
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    (void)sub32(ebx, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900470E;
    goto L_9004705;
L_9004705:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebx), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(sub32(ebx, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_900470E:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebx, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebx);
    if (!f.cf) goto L_900473B;
    goto L_900471A;
L_900471A:
    ebx = (uint32_t)(ebp);
    (void)logic32((uint32_t)(eax & (uint32_t)0x1u), &f);
    if (f.zf) goto L_9004725;
    goto L_9004723;
L_9004723:
    ebx = (uint32_t)(ecx);
L_9004725:
    eax = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi + 0xFFFFFFFFu)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ebx))) << 8);
    TS16((uint32_t)(esi), (uint16_t)(((uint16_t)eax)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    ebp = (uint32_t)(add32(ebp, (uint32_t)0x1u, &f));
L_900473B:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900476F;
    goto L_9004742;
L_9004742:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    goto L_9004750;
L_9004750:
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi + 0x1u)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(ecx))) << 8);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(M8((uint32_t)(ebp))) << 8);
    ebp = (uint32_t)(add32(ebp, (uint32_t)0x1u, &f));
    edx = (uint32_t)(dec32(edx, &f));
    TS32((uint32_t)(esi + 0xFFFFFFFCu), (uint32_t)(eax));
    if (!f.zf) goto L_9004750;
    goto L_900476F;
L_900476F:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebp));
    TS32((uint32_t)(eax), (uint32_t)(esi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004790(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004790:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90047DE;
    goto L_90047AC;
L_90047AC:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_90047B0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(ebx);
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x10u, &f));
    { uint8_t t_ = ((uint8_t)edx); edx = (edx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)eax)); eax = (eax & 0xFFFFFF00u) | (uint8_t)(t_); }
    { uint8_t t_ = ((uint8_t)ebx); ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx)); ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(t_); }
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ebp = (uint32_t)(dec32(ebp, &f));
    if (!f.zf) goto L_90047B0;
    goto L_90047DD;
L_90047DD:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_90047DE:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_90047FD;
    goto L_90047E6;
L_90047E6:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    { uint8_t t_ = ((uint8_t)eax); eax = (eax & 0xFFFFFF00u) | (uint8_t)(((uint8_t)ecx)); ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(t_); }
    eax = (uint32_t)(ror32(eax, (uint8_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_90047FD:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_9004819;
    goto L_9004805;
L_9004805:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_9004819:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004830(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004830:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9004848u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)((uint32_t)(esi + edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9004860(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9004860:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0xDu, &f));
    if (f.zf) goto L_900488F;
    goto L_9004870;
L_9004870:
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x1u, &f));
    if (f.zf) goto L_9004879;
    goto L_9004875;
L_9004875:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9004879:
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9004570u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9004630u));
    goto L_90048A3;
L_900488F:
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x90046D0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9004790u));
L_90048A3:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9004830u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x90048D5u; SPILL(); f_901D550(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9005000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9005000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_9005038;
    goto L_9005028;
L_9005028:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9005048;
    goto L_900502D;
L_900502D:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_9005048;
L_9005038:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_90051E2;
    goto L_9005048;
L_9005048:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    c->mm[5] ^= c->mm[5];
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[7] = M64((uint32_t)(0x903F800u));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9005130;
    goto L_900506B;
L_900506B:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->mm[5] = (uint64_t)eax;
    c->mm[5] = mmx_psllw(c->mm[5], (uint64_t)4u);
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_pslld(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], c->mm[5]);
    c->mm[0] = mmx_pslld(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_pslld(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrld(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_psrld(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_psrld(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(inc32(edi, &f));
    c->mm[1] |= c->mm[0];
    (void)logic32((uint32_t)(ebp & ebp), &f);
    eax = (uint32_t)((uint32_t)c->mm[1]);
    TS8((uint32_t)(edi + 0xFFFFFFFFu), (uint8_t)(((uint8_t)eax)));
    if (f.zf) goto L_90051E2;
    goto L_9005129;
L_9005129:
    c->mm[5] ^= c->mm[5];
    esp = (uint32_t)((uint32_t)(esp));
L_9005130:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE00u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    c->mm[1] |= c->mm[0];
    ebp = (uint32_t)(dec32(ebp, &f));
    c->mm[1] = mmx_packuswb(c->mm[1], c->mm[1]);
    eax = (uint32_t)((uint32_t)c->mm[1]);
    TS16((uint32_t)(edi + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (!f.zf) goto L_9005130;
    goto L_90051E2;
L_90051E2:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_9005341;
    goto L_90051F0;
L_90051F0:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    goto L_9005200;
L_9005200:
    c->mm[5] ^= c->mm[5];
    c->mm[6] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[0] = M64((uint32_t)(edx));
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[5]);
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[6] = mmx_psllw(c->mm[6], (uint64_t)4u);
    c->mm[1] = c->mm[0];
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[6] = mmx_pmulhw(c->mm[6], c->mm[3]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)5u);
    c->mm[4] = c->mm[6];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[7] = M64((uint32_t)(0x903F800u));
    c->mm[1] = mmx_punpckhbw(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[6]);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)6u);
    c->mm[6] = mmx_paddw(c->mm[6], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[2]);
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[5] = c->mm[4];
    c->mm[3] = c->mm[2];
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[4]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[7]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[3]);
    c->mm[2] = mmx_paddsw(c->mm[2], M64((uint32_t)(0x902FE20u)));
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[5] = mmx_paddw(c->mm[5], c->mm[1]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[3] = mmx_paddw(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_psubusw(c->mm[2], c->mm[6]);
    c->mm[1] = mmx_psubw(c->mm[1], c->mm[7]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_paddsw(c->mm[5], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_paddsw(c->mm[3], M64((uint32_t)(0x902FE20u)));
    c->mm[5] = mmx_psubusw(c->mm[5], c->mm[6]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE30u)));
    c->mm[3] = mmx_psubusw(c->mm[3], c->mm[6]);
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[2] = mmx_psrlw(c->mm[2], M64((uint32_t)(0x902FE00u)));
    c->mm[0] = mmx_psrlw(c->mm[0], M64((uint32_t)(0x902FE08u)));
    c->mm[4] = mmx_psrlw(c->mm[4], M64((uint32_t)(0x902FE10u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    c->mm[2] = mmx_psllw(c->mm[2], M64((uint32_t)(0x902FDE0u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    c->mm[0] = mmx_psllw(c->mm[0], M64((uint32_t)(0x902FDE8u)));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    c->mm[4] = mmx_psllw(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    c->mm[2] |= c->mm[0];
    c->mm[2] |= c->mm[4];
    c->mm[3] = mmx_psrlw(c->mm[3], M64((uint32_t)(0x902FE00u)));
    c->mm[1] = mmx_psrlw(c->mm[1], M64((uint32_t)(0x902FE08u)));
    c->mm[5] = mmx_psrlw(c->mm[5], M64((uint32_t)(0x902FE10u)));
    c->mm[3] = mmx_psllw(c->mm[3], M64((uint32_t)(0x902FDE0u)));
    c->mm[1] = mmx_psllw(c->mm[1], M64((uint32_t)(0x902FDE8u)));
    c->mm[5] = mmx_psllw(c->mm[5], M64((uint32_t)(0x902FDF0u)));
    c->mm[3] |= c->mm[1];
    c->mm[3] |= c->mm[5];
    ebp = (uint32_t)(dec32(ebp, &f));
    c->mm[2] = mmx_packuswb(c->mm[2], c->mm[3]);
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[2];
    if (!f.zf) goto L_9005200;
    goto L_9005341;
L_9005341:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9005370(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9005370:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    if (f.zf) goto L_90053D7;
    goto L_900538A;
L_900538A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9005390:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    c->mm[4] = M64((uint32_t)(esi + 0x20u));
    c->mm[5] = M64((uint32_t)(esi + 0x28u));
    c->mm[6] = M64((uint32_t)(esi + 0x30u));
    c->mm[7] = M64((uint32_t)(esi + 0x38u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x40u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[2];
    M64((uint32_t)(edi + 0x18u)) = c->mm[3];
    M64((uint32_t)(edi + 0x20u)) = c->mm[4];
    M64((uint32_t)(edi + 0x28u)) = c->mm[5];
    M64((uint32_t)(edi + 0x30u)) = c->mm[6];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9005390;
    goto L_90053D7;
L_90053D7:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90053F0;
    goto L_90053E1;
L_90053E1:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90053E1;
    goto L_90053F0;
L_90053F0:
    ecx = (uint32_t)(edx);
    while (ecx) { M8(edi) = (uint8_t)eax; edi += (c->df ? -1 : 1); ecx--; }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9005400(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9005400:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    if (f.zf) goto L_900547B;
    goto L_900541A;
L_900541A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9005420:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x20u, &f));
    c->mm[4] = c->mm[0];
    c->mm[5] = c->mm[1];
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[0]);
    c->mm[1] = mmx_punpcklbw(c->mm[1], c->mm[1]);
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[2]);
    c->mm[3] = mmx_punpcklbw(c->mm[3], c->mm[3]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[4]);
    c->mm[5] = mmx_punpckhbw(c->mm[5], c->mm[5]);
    c->mm[6] = mmx_punpckhbw(c->mm[6], c->mm[6]);
    c->mm[7] = mmx_punpckhbw(c->mm[7], c->mm[7]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    M64((uint32_t)(edi + 0x10u)) = c->mm[1];
    M64((uint32_t)(edi + 0x18u)) = c->mm[5];
    M64((uint32_t)(edi + 0x20u)) = c->mm[2];
    M64((uint32_t)(edi + 0x28u)) = c->mm[6];
    M64((uint32_t)(edi + 0x30u)) = c->mm[3];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9005420;
    goto L_900547B;
L_900547B:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90054A1;
    goto L_9005485;
L_9005485:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[4] = c->mm[0];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[0]);
    c->mm[4] = mmx_punpckhbw(c->mm[4], c->mm[4]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9005485;
    goto L_90054A1;
L_90054A1:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90054B5;
    goto L_90054A5;
L_90054A5:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(esi)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)eax)) << 8);
    esi = (uint32_t)(inc32(esi, &f));
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    edx = (uint32_t)(dec32(edx, &f));
    if (!f.zf) goto L_90054A5;
    goto L_90054B5;
L_90054B5:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90054C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90054C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebp);
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_90054F3;
    goto L_90054EA;
L_90054EA:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_90054F3:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebp);
    if (!f.cf) goto L_9005587;
    goto L_9005503;
L_9005503:
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(edx + 0xFFFFFFFFu)));
    esi = (uint32_t)(TL8((uint32_t)(esi)));
    ebp = (uint32_t)(M8((uint32_t)(ebp)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebx + 0x902FE20u)), &f));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebx + 0x902FE40u)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebx + 0x902FE30u)), &f));
    ebx = (uint32_t)(logic32(0, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x902FF76u)));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) | TL8((uint32_t)(edx + 0x9030577u))), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1u, &f));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)ebx) | TL8((uint32_t)(eax + 0x9030279u))), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    TS32((uint32_t)(edi), (uint32_t)(esi));
    TS8((uint32_t)(esi + 0xFFFFFFFFu), (uint8_t)(((uint8_t)ebx)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(edi + 0xCu)), (uint32_t)0x1u, &f)));
L_9005587:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900567F;
    goto L_9005592;
L_9005592:
    edx = (uint32_t)(logic32(0, &f));
    goto L_90055A0;
L_90055A0:
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(M16((uint32_t)(ebp + edx*2 + 0xFFFFFFFEu)));
    esi = (uint32_t)(TL8((uint32_t)(edx + ecx + 0xFFFFFFFFu)));
    ebp = (uint32_t)(TL8((uint32_t)(edx + ebx + 0xFFFFFFFFu)));
    M32((uint32_t)(esp)) = (uint32_t)(edx);
    ebx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(eax >> 8)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + 0x903F938u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    edi = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ebx = (uint32_t)(sub32(ebx, ebp, &f));
    ebp = (uint32_t)(eax);
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(0x902FE20u)), &f));
    esi = (uint32_t)(add32(esi, TL32((uint32_t)(0x902FE24u)), &f));
    edi = (uint32_t)(add32(edi, TL32((uint32_t)(0x902FE40u)), &f));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(0x902FE44u)), &f));
    ebp = (uint32_t)(add32(ebp, TL32((uint32_t)(0x902FE30u)), &f));
    ebx = (uint32_t)(add32(ebx, TL32((uint32_t)(0x902FE34u)), &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x902FF76u)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(TL8((uint32_t)(esi + 0x902FF76u))) << 8);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) | TL8((uint32_t)(edi + 0x9030577u))), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(eax >> 8)) | TL8((uint32_t)(edx + 0x9030577u))), &f)) << 8);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(logic8((uint8_t)(((uint8_t)eax) | M8((uint32_t)(ebp + 0x9030279u))), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(logic8((uint8_t)(((uint8_t)(eax >> 8)) | TL8((uint32_t)(ebx + 0x9030279u))), &f)) << 8);
    edx = (uint32_t)(M32((uint32_t)(esp)));
    (void)sub32(M32((uint32_t)(esp + 0x4u)), edx, &f);
    TS16((uint32_t)(esi + edx*2 + 0xFFFFFFFEu), (uint16_t)(((uint16_t)eax)));
    if (!f.zf) goto L_90055A0;
    goto L_900565D;
L_900565D:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebp = (uint32_t)(add32(ebp, edx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
L_900567F:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9005690(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9005690:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90056A8u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)((uint32_t)(esi + edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90056C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90056C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_9005736;
    goto L_90056DC;
L_90056DC:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_90056E0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    ebp = (uint32_t)(eax);
    edx = (uint32_t)(eax);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)edx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(ebp));
    ebp = (uint32_t)(ebx);
    edx = (uint32_t)(ebx);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebx));
    ebx = (ebx & 0xFFFF0000u) | (uint16_t)(((uint16_t)edx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    ebx = (ebx & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebx), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    ebx = (uint32_t)(ror32(ebx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90056E0;
    goto L_9005735;
L_9005735:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9005736:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9005769;
    goto L_900573E;
L_900573E:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(eax);
    ebx = (uint32_t)(eax);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x10u, &f));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(((uint16_t)eax));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(((uint16_t)ebx));
    ebp = (ebp & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)ebp), (uint8_t)0x8u, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    ebp = (uint32_t)(ror32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_9005769:
    (void)logic32((uint32_t)(edx & (uint32_t)0x2u), &f);
    if (f.zf) goto L_900578C;
    goto L_9005771;
L_9005771:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    eax = (eax & 0xFFFF0000u) | (uint16_t)(ror16(((uint16_t)eax), (uint8_t)0x8u, &f));
    eax = (uint32_t)(ror32(eax, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_900578C:
    (void)logic32((uint32_t)(edx & (uint32_t)0x1u), &f);
    if (f.zf) goto L_90057A3;
    goto L_9005794;
L_9005794:
    eax = (uint32_t)(logic32(0, &f));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x1u, &f));
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(((uint8_t)eax)) << 8);
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
L_90057A3:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90057B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90057B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xFu), &f);
    if (f.zf) goto L_90057C1;
    goto L_90057BC;
L_90057BC:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90057C1:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x6u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x5u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = 0x5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + 0x6u));
    ecx = (uint32_t)((uint32_t)(esi + 0x3u));
    esp -= 4; M32(esp) = 0x90057D9u; SPILL(); f_901D000(c); RELOAD();
    eax = (uint32_t)(ebx);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9005690u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x90056C0u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)(esi));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x90054C0u));
    esp -= 4; M32(esp) = 0x900581Cu; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9005821u; SPILL(); f_901D170(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE00u)));
    esi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(shld32(edx, eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x1Fu, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    edi = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE08u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    esi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(edi));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(shld32(edx, eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x1Fu, &f));
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(edx));
    edx = (uint32_t)((int32_t)eax >> 31);
    edi = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE10u)));
    esi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(edi));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    edx = (uint32_t)(shld32(edx, eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x1Fu, &f));
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(edx));
    edx = (uint32_t)((int32_t)eax >> 31);
    ecx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(0x902FE48u), (uint32_t)(ecx));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

