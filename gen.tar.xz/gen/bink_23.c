#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9027000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ecx)), (uint32_t)0x406D1388u, &f);
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(!f.zf);
    eax = (uint32_t)(dec32(eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9027020(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027020:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x9040010u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)((uint32_t)0x1000u);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x0u);
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_902707E;
    goto L_9027046;
L_9027046:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90270E7;
    goto L_902704E;
L_902704E:
    { uint32_t v_ = 0x9041000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x902705Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x9027065u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040010u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902707E;
    goto L_902706E;
L_902706E:
    TS32((uint32_t)(0x9040010u), (uint32_t)((uint32_t)0x1u));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_902707E:
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9027080u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90270E7;
    goto L_9027084;
L_9027084:
    edx = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x9040030u);
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ecx)), &exp_, (uint32_t)edx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90270B8;
    goto L_9027098;
L_9027098:
    esi = (uint32_t)(TL32((uint32_t)(0x90310B4u)));
    edi = (uint32_t)(edi);
L_90270A0:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x90270A4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x9040030u);
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ecx)), &exp_, (uint32_t)edx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90270A0;
    goto L_90270B8;
L_90270B8:
    esi = (uint32_t)(TL32((uint32_t)(0x9031058u)));
    { uint32_t v_ = 0x9027000u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x90270C5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x406D1388u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9031038u)); esp -= 4; M32(esp) = 0x90270DAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x90270DDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040030u), (uint32_t)((uint32_t)0x0u));
L_90270E7:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90270F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90270F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax + 0xFCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903108Cu)); esp -= 4; M32(esp) = 0x902710Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9027129;
    goto L_9027113;
L_9027113:
    (void)sub8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f);
    if (f.zf) goto L_9027129;
    goto L_9027118;
L_9027118:
    (void)sub32(TL32((uint32_t)(0x904002Cu)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9027129;
    goto L_9027121;
L_9027121:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x48u)));
    esp -= 4; M32(esp) = 0x9027129u; SPILL(); f_9027020(c); RELOAD();
L_9027129:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9027132u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)(edi + 0x3Cu));
L_9027138:
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(edx);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9027138;
    goto L_902714D;
L_902714D:
    (void)sub32(ecx, (uint32_t)0x3u, &f);
    if (!f.zf) goto L_9027157;
    goto L_9027152;
L_9027152:
    esp -= 4; M32(esp) = 0x9027157u; SPILL(); f_90274F0(c); RELOAD();
L_9027157:
    ecx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903108Cu)); esp -= 4; M32(esp) = 0x9027166u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9027170(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027170:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x2Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ esp), &f));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(eax + 0xFu));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
    TS32((uint32_t)(eax + 0xFCu), (uint32_t)(esi));
    esp -= 4; M32(esp) = 0x902719Fu; SPILL(); f_9001140(c); RELOAD();
    ebx = (uint32_t)(TL32((uint32_t)(0x9031050u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax | edx), &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    if (!f.zf) goto L_90271C6;
    goto L_90271B1;
L_90271B1:
    { uint32_t o_ = __atomic_exchange_n((uint32_t *)(MEM + (uint32_t)(esp + 0xCu)), (uint32_t)eax, __ATOMIC_SEQ_CST); eax = (uint32_t)(o_); }
    { uint32_t t_ = TL32((uint32_t)(0x903107Cu)); esp -= 4; M32(esp) = 0x90271BCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040014u), (uint32_t)(eax));
    goto L_902725C;
L_90271C6:
    eax = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_90271FA;
    goto L_90271D0;
L_90271D0:
    edi = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903302Cu), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x90271E0u; SPILL(); f_90011C0(c); RELOAD();
    (void)sub32(TL32((uint32_t)(0x9033028u)), edi, &f);
    if (!f.zf) goto L_90271F0;
    goto L_90271E8;
L_90271E8:
    TS32((uint32_t)(0x903302Cu), (uint32_t)(edi));
    goto L_90271FA;
L_90271F0:
    TS32((uint32_t)(0x903302Cu), (uint32_t)((uint32_t)0x1F4u));
L_90271FA:
    eax = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_9027222;
    goto L_9027206;
L_9027206:
    goto L_9027210;
L_9027210:
    edx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    (void)sub32(edx, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_902725C;
    goto L_902721D;
L_902721D:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(ecx, eax, &f);
    if ((f.sf != f.of)) goto L_9027210;
    goto L_9027222;
L_9027222:
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9027224u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x902722Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9027231u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x9027238u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x9027240u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(edi, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_9027252;
    goto L_9027248;
L_9027248:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x902724Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x9027252u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027252:
    eax = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9027222;
    goto L_902725C;
L_902725C:
    (void)sub32(TL32((uint32_t)(0x904002Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9027296;
    goto L_9027265;
L_9027265:
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x28u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041020u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x904002Cu), (uint32_t)((uint32_t)0x1u));
    { uint32_t t_ = TL32((uint32_t)(0x90310CCu)); esp -= 4; M32(esp) = 0x9027281u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9027296;
    goto L_9027285;
L_9027285:
    (void)sub8(M8((uint32_t)(esp + 0x24u)), (uint8_t)0x31u, &f);
    if (!f.zf) goto L_9027296;
    goto L_902728C;
L_902728C:
    TS32((uint32_t)(0x904002Cu), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_9027296:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)((uint32_t)0x0u);
    edi = (uint32_t)((uint32_t)0x9040020u);
L_90272A3:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(~eax);
    { uint32_t v_ = eax; f.zf = v_ == 0; if (v_) { ecx = (uint32_t)(__builtin_ctz(v_)); } }
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    if (f.zf) goto L_90272D8;
    goto L_90272B2;
L_90272B2:
    eax = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ebx = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax | edx), &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(edx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)ecx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, edx, &f);
    if (f.zf) goto L_90272FD;
    goto L_90272C9;
L_90272C9:
    edx = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(~eax);
    { uint32_t v_ = eax; f.zf = v_ == 0; if (v_) { ecx = (uint32_t)(__builtin_ctz(v_)); } }
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    if (!f.zf) goto L_90272B2;
    goto L_90272D8;
L_90272D8:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(inc32(M32((uint32_t)(esp + 0xCu)), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    (void)sub32(edi, (uint32_t)0x9040028u, &f);
    if ((f.sf != f.of)) goto L_90272A3;
    goto L_90272E7;
L_90272E7:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x90272F7u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
L_90272FD:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    edi = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + 0x48u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = 0x90270F0u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(shl32(edi, (uint8_t)0x5u, &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(esp + 0x20u)), &f));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(eax));
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x44u), (uint32_t)(edi));
    TS32((uint32_t)(esi + 0x38u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(eax));
    { uint32_t t_ = TL32((uint32_t)(0x9031084u)); esp -= 4; M32(esp) = 0x9027354u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(esi + 0x34u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027399;
    goto L_902735B;
L_902735B:
    ecx = (uint32_t)(edi);
    edx = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(esi + 0x40u), (uint32_t)(edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1Fu), &f));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0x5u, &f));
    TS32((uint32_t)(esi + 0x3Cu), (uint32_t)(eax));
    esi = (uint32_t)((uint32_t)(edi*4 + 0x9040020u));
    edx = (uint32_t)(~edx);
    esp = (uint32_t)((uint32_t)(esp));
L_9027380:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & ecx), &f));
    edi = (uint32_t)(eax);
    ebx = (uint32_t)(esi);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(ebx)), &exp_, (uint32_t)edi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_9027380;
    goto L_9027394;
L_9027394:
    goto L_90272E7;
L_9027399:
    edi = (uint32_t)(TL32((uint32_t)(ebx + 0xFCu)));
    { uint32_t t_ = TL32((uint32_t)(0x9031050u)); esp -= 4; M32(esp) = 0x90273A5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x90273ACu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x34u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x90273B7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)((uint32_t)0x9040028u);
    { uint32_t s_ = edx; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(eax)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); edx = (uint32_t)(o_); }
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_90273D1;
    goto L_90273C9;
L_90273C9:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031190u)); esp -= 4; M32(esp) = 0x90273D1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90273D1:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031080u)); esp -= 4; M32(esp) = 0x90273DBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    eax = (uint32_t)((uint32_t)0x1u);
    esp -= 4; M32(esp) = 0x90273EEu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

void f_9027400(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027400:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027426;
    goto L_9027407;
L_9027407:
    eax = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90274A2;
    goto L_9027415;
L_9027415:
    ecx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903105Cu)); esp -= 4; M32(esp) = 0x9027422u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90274A2;
    goto L_9027426;
L_9027426:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(eax + 0xFCu)));
    (void)sub32(esi, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_902744B;
    goto L_9027432;
L_9027432:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x44u)));
    esp -= 4; M32(esp) = 0x902743Au; SPILL(); f_90011C0(c); RELOAD();
    eax = (uint32_t)(esi);
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = TL32((uint32_t)(0x9033028u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(edx + 0x9036AA0u)));
L_902744B:
    eax = (uint32_t)(TL32((uint32_t)(0x9040008u)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_902749A;
    goto L_9027455;
L_9027455:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027483;
    goto L_9027459;
L_9027459:
    { uint32_t v_ = 0x9041038u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x9027469u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x9027470u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040008u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902749A;
    goto L_9027479;
L_9027479:
    TS32((uint32_t)(0x9040008u), (uint32_t)((uint32_t)0x1u));
L_9027483:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x34u)));
    ecx = (uint32_t)(esi);
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031074u)); esp -= 4; M32(esp) = 0x9027497u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_902749A:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x34u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90274A1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_90274A2:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90274B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90274B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90274D8;
    goto L_90274B7;
L_90274B7:
    eax = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_90274D2;
    goto L_90274C1;
L_90274C1:
    ecx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903105Cu)); esp -= 4; M32(esp) = 0x90274CEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90274D8;
    goto L_90274D2;
L_90274D2:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90274D8:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0xFCu)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x34u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(ecx), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90274F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90274F0:
    eax = (uint32_t)((uint32_t)(edi + 0x34u));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(eax);
    TS32((uint32_t)(edi + 0x40u), (uint32_t)((uint32_t)0xFFFFFFFFu));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0xFFFFFFFFu), &f));
    eax = (uint32_t)(ebx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edx)), &exp_, (uint32_t)ecx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, ebx, &f);
    if (!f.zf) goto L_9027597;
    goto L_9027510;
L_9027510:
    (void)sub32(ebx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9027597;
    goto L_9027519;
L_9027519:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    ecx = (uint32_t)((uint32_t)0x9040028u);
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(ecx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_9027531;
    goto L_902752A;
L_902752A:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903118Cu)); esp -= 4; M32(esp) = 0x9027531u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027531:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
L_9027532:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x44u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1Fu), &f));
    eax = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x5u, &f));
    esi = (uint32_t)((uint32_t)(edx*4 + 0x9040020u));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(~eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & edx), &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(edx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(esi)), &exp_, (uint32_t)ecx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(eax, edx, &f);
    if (!f.zf) goto L_9027532;
    goto L_902755D;
L_902755D:
    edx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(edx, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_9027590;
    goto L_9027569;
L_9027569:
    eax = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903105Cu)); esp -= 4; M32(esp) = 0x9027575u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9027590;
    goto L_9027579;
L_9027579:
    (void)sub32(TL32((uint32_t)(eax + 0xFCu)), edi, &f);
    if (!f.zf) goto L_9027590;
    goto L_9027581;
L_9027581:
    ecx = (uint32_t)(TL32((uint32_t)(0x9040014u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903108Cu)); esp -= 4; M32(esp) = 0x9027590u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027590:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x9027597u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027597:
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90275A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90275A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_90275DF;
    goto L_90275B5;
L_90275B5:
    esi = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903302Cu), (uint32_t)(esi));
    esp -= 4; M32(esp) = 0x90275C5u; SPILL(); f_90011C0(c); RELOAD();
    (void)sub32(TL32((uint32_t)(0x9033028u)), esi, &f);
    if (!f.zf) goto L_90275D5;
    goto L_90275CD;
L_90275CD:
    TS32((uint32_t)(0x903302Cu), (uint32_t)(esi));
    goto L_90275DF;
L_90275D5:
    TS32((uint32_t)(0x903302Cu), (uint32_t)((uint32_t)0x1F4u));
L_90275DF:
    ecx = (uint32_t)(TL32((uint32_t)(0x903302Cu)));
    esi = (uint32_t)((uint32_t)(edi + 0xFu));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF0u), &f));
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x2u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    TS32((uint32_t)(edi + 0x7Cu), (uint32_t)(esi));
    if (f.zf) goto L_9027639;
    goto L_90275F7;
L_90275F7:
    eax = (uint32_t)(TL32((uint32_t)(0x9040004u)));
    edi = (uint32_t)(TL32((uint32_t)(0x90310A8u)));
    ebx = (uint32_t)(TL32((uint32_t)(0x90310B0u)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_902766A;
    goto L_902760D;
L_902760D:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027633;
    goto L_9027611;
L_9027611:
    { uint32_t v_ = 0x9041050u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x902761Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x9027620u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040004u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902766A;
    goto L_9027629;
L_9027629:
    TS32((uint32_t)(0x9040004u), (uint32_t)((uint32_t)0x1u));
L_9027633:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_902766A;
    goto L_9027639;
L_9027639:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x0u));
    { uint32_t t_ = TL32((uint32_t)(0x903106Cu)); esp -= 4; M32(esp) = 0x902764Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | M32((uint32_t)(ebp + 0x8u))), &f));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(eax));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0x20u), &f));
    { uint32_t o_ = __atomic_exchange_n((uint32_t *)(MEM + (uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)eax, __ATOMIC_SEQ_CST); eax = (uint32_t)(o_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_902766A:
    eax = (uint32_t)(TL32((uint32_t)(0x9040000u)));
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x0u));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_90276AC;
    goto L_902767A;
L_902767A:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90276A0;
    goto L_902767E;
L_902767E:
    { uint32_t v_ = 0x9041068u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x902768Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x902768Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x9040000u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90276AC;
    goto L_9027696;
L_9027696:
    TS32((uint32_t)(0x9040000u), (uint32_t)((uint32_t)0x1u));
L_90276A0:
    edx = (uint32_t)((uint32_t)(esi + 0x4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903104Cu)); esp -= 4; M32(esp) = 0x90276AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_90276B6;
L_90276AC:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esi + 0x4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x90276B6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90276B6:
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | M32((uint32_t)(ebp + 0x8u))), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | (uint32_t)0x40u), &f));
    { uint32_t o_ = __atomic_exchange_n((uint32_t *)(MEM + (uint32_t)(ebp + 0xFFFFFFF4u)), (uint32_t)eax, __ATOMIC_SEQ_CST); eax = (uint32_t)(o_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_90276E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90276E0:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_902771A;
    goto L_90276E4;
L_90276E4:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(edx);
    eax = (uint32_t)(ecx);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(edi)), &exp_, (uint32_t)esi, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(eax, ecx, &f);
    if (!f.zf) goto L_902771A;
    goto L_90276FB;
L_90276FB:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_902770B;
    goto L_9027700;
L_9027700:
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x902770Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp += 4; SPILL(); return;
L_902770B:
    (void)logic8((uint8_t)(((uint8_t)ecx) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_902771A;
    goto L_9027710;
L_9027710:
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031070u)); esp -= 4; M32(esp) = 0x902771Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_902771A:
    esp += 4; SPILL(); return;
}

void f_9027720(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027720:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_902772E;
    goto L_9027728;
L_9027728:
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_902772E:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(eax + 0x7Cu)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_9027761;
    goto L_9027738;
L_9027738:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9027742;
    goto L_9027740;
L_9027740:
    eax = (uint32_t)(logic32((uint32_t)(eax | eax), &f));
L_9027742:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x902774Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9027775;
    goto L_9027751;
L_9027751:
    (void)sub32(eax, (uint32_t)0x80u, &f);
    if (f.zf) goto L_9027775;
    goto L_9027758;
L_9027758:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9027761:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x40u), &f);
    if (f.zf) goto L_9027758;
    goto L_9027765;
L_9027765:
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_9027781;
    goto L_902776B;
L_902776B:
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031034u)); esp -= 4; M32(esp) = 0x9027775u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027775:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_9027781:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(0x9031188u)));
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x902778Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x902779Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90277F0;
    goto L_902779E;
L_902779E:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90277FE;
    goto L_90277A5;
L_90277A5:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x90277ACu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x90277B6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90277F0;
    goto L_90277BA;
L_90277BA:
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x90277BCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(sub32(eax, ebx, &f));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90277FE;
    goto L_90277C2;
L_90277C2:
    esp -= 4; M32(esp) = 0x90277C7u; SPILL(); f_9027850(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x90277D1u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90277F0;
    goto L_90277D5;
L_90277D5:
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x90277D7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(sub32(eax, ebx, &f));
    (void)sub32(eax, esi, &f);
    if (!f.cf) goto L_90277FE;
    goto L_90277DD;
L_90277DD:
    esp -= 4; M32(esp) = 0x90277E2u; SPILL(); f_9027810(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9040004u)); esp -= 4; M32(esp) = 0x90277ECu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90277D5;
    goto L_90277F0;
L_90277F0:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_90277FE:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_9027810(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027810:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x9031050u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x902781Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x9027822u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9027828u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ebx = (uint32_t)(TL32((uint32_t)(0x9031040u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9027831u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x9027839u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(edi, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_9027847;
    goto L_9027841;
L_9027841:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = esi; esp -= 4; M32(esp) = 0x9027844u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x9027847u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_9027847:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9027850(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9027850:
    eax = (uint32_t)(TL32((uint32_t)(0x904000Cu)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if ((!f.cf && !f.zf)) goto L_9027891;
    goto L_902785A;
L_902785A:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027888;
    goto L_902785E;
L_902785E:
    { uint32_t v_ = 0x9041090u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9041014u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B0u)); esp -= 4; M32(esp) = 0x902786Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310A8u)); esp -= 4; M32(esp) = 0x9027875u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    TS32((uint32_t)(0x904000Cu), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9027891;
    goto L_902787E;
L_902787E:
    TS32((uint32_t)(0x904000Cu), (uint32_t)((uint32_t)0x1u));
L_9027888:
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x9027890u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp += 4; SPILL(); return;
L_9027891:
    { jt_ = eax; goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x9027850u: goto L_9027850; case 0x902785Au: goto L_902785A; case 0x902785Eu: goto L_902785E; case 0x902787Eu: goto L_902787E; case 0x9027888u: goto L_9027888; case 0x9027891u: goto L_9027891; default: SPILL(); rt_call(c, jt_); return; }
}

