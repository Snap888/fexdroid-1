#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9021200(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9021200:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    eax = (uint32_t)((uint32_t)(esi + esi));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)((uint32_t)(edx + ecx*4));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9021228u; SPILL(); f_9021B70(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((f.zf || f.sf != f.of)) goto L_902128D;
    goto L_9021233;
L_9021233:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021242u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(edi + esi*4));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021251u; SPILL(); f_90212B0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(edi + esi*8));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021260u; SPILL(); f_9021200(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    edi = (uint32_t)((uint32_t)(edi + eax*4));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    ecx = (uint32_t)((uint32_t)(eax + edx*4));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x9021282u; SPILL(); f_9021B70(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x38u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9021233;
    goto L_902128D;
L_902128D:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x902129Cu; SPILL(); f_9021350(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90212B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90212B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(sub32(eax, ebx, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(ecx + eax*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    esp -= 4; M32(esp) = 0x90212D5u; SPILL(); f_90220C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((f.zf || f.sf != f.of)) goto L_9021337;
    goto L_90212E0;
L_90212E0:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90212EFu; SPILL(); f_9021200(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(edi + esi*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90212FEu; SPILL(); f_90212B0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(edi + esi*8));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x902130Du; SPILL(); f_9021200(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ebx = (uint32_t)(esi);
    edx = (uint32_t)((uint32_t)(esi + esi*2));
    edi = (uint32_t)((uint32_t)(edi + edx*4));
    eax = (uint32_t)(sub32(eax, ebx, &f));
    edx = (uint32_t)((uint32_t)(ecx + eax*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    esp -= 4; M32(esp) = 0x902132Cu; SPILL(); f_90220C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x38u, &f));
    (void)sub32(ebx, (uint32_t)0x200u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_90212E0;
    goto L_9021337;
L_9021337:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9021347u; SPILL(); f_9021730(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9021350(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9021350:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esi = (uint32_t)(edi);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if ((f.zf || f.sf != f.of)) goto L_902144F;
    goto L_902136D;
L_902136D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9021370:
    (void)sub32(esi, edi, &f);
    eax = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    if ((f.sf == f.of)) goto L_902141D;
    goto L_902137D;
L_902137D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9021380:
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(sub32(ebx, esi, &f));
    (void)sub32(ebx, edi, &f);
    if ((f.sf == f.of)) goto L_902140E;
    goto L_902138C;
L_902138C:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(sub32(edi, esi, &f));
    edi = (uint32_t)((uint32_t)(ecx + edi*4));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    edi = (uint32_t)(esi);
    edi = (uint32_t)(sar32(edi, (uint8_t)0x1u, &f));
    edx = (uint32_t)(sub32(edx, edi, &f));
    ecx = (uint32_t)((uint32_t)(ecx + edx*4));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(ecx + ebx*4));
    edi = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ebx + eax*2));
    edi = (uint32_t)(shl32(edi, (uint8_t)0x4u, &f));
    edx = (uint32_t)((uint32_t)(ecx + edx*4));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ecx = (uint32_t)((uint32_t)(ecx + eax*4));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
L_90213C7:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90213D4u; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90213E1u; SPILL(); f_90220C0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90213EEu; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), edi, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), edi, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    ebx = (uint32_t)(add32(ebx, eax, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)sub32(ebx, M32((uint32_t)(ebp + 0x8u)), &f);
    if ((f.sf != f.of)) goto L_90213C7;
    goto L_9021408;
L_9021408:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
L_902140E:
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    (void)sub32(eax, edi, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    if ((f.sf != f.of)) goto L_9021380;
    goto L_902141D;
L_902141D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, (uint8_t)0x1u, &f));
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)((uint32_t)(ecx + eax*4));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(edi);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(sub32(eax, esi, &f));
    eax = (uint32_t)((uint32_t)(ecx + eax*4));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x902143Du; SPILL(); f_9021B70(c); RELOAD();
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9021370;
    goto L_902144F;
L_902144F:
    (void)sub32(esi, edi, &f);
    ecx = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(esi);
    if ((f.sf == f.of)) goto L_902168E;
    goto L_902145C;
L_902145C:
    esp = (uint32_t)((uint32_t)(esp));
L_9021460:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(sub32(eax, esi, &f));
    (void)sub32(eax, edi, &f);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    if ((f.sf == f.of)) goto L_902167F;
    goto L_902146F;
L_902146F:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)((uint32_t)(ebx + edx*4));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    edx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(edi);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)((uint32_t)(ebx + ecx*4));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)((uint32_t)(eax + edx*2 + 0x60u));
    edx = (uint32_t)((uint32_t)(ecx + edx*4));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, edx, &f));
    eax = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
L_90214C0:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90214D2u; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_9021518;
    goto L_90214E5;
L_90214E5:
    edx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90214F0u; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFF80u));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x9021501u; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF80u, &f));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x902150Eu; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp -= 4; M32(esp) = 0x9021516u; SPILL(); f_9022890(c); RELOAD();
    goto L_9021548;
L_9021518:
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x9021521u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x902152Eu; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x902153Bu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x9021548u; SPILL(); f_9023A80(c); RELOAD();
L_9021548:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x902155Au; SPILL(); f_90220C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_9021599;
    goto L_9021565;
L_9021565:
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    esp -= 4; M32(esp) = 0x902156Eu; SPILL(); f_9022890(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFF80u));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF00u));
    esp -= 4; M32(esp) = 0x9021580u; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF80u));
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    esp -= 4; M32(esp) = 0x902158Cu; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFF80u));
    eax = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9021597u; SPILL(); f_9023050(c); RELOAD();
    goto L_90215C9;
L_9021599:
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x90215A2u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x90215AFu; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x90215BCu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x90215C9u; SPILL(); f_9023D40(c); RELOAD();
L_90215C9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90215DBu; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_9021622;
    goto L_90215EE;
L_90215EE:
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    esp -= 4; M32(esp) = 0x90215F7u; SPILL(); f_9022890(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFF80u));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF00u));
    esp -= 4; M32(esp) = 0x9021609u; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF80u));
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    esp -= 4; M32(esp) = 0x9021615u; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFE0u));
    eax = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9021620u; SPILL(); f_9022890(c); RELOAD();
    goto L_9021655;
L_9021622:
    ecx = (uint32_t)((uint32_t)(ebx + edi*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x902162Bu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x9021638u; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x9021645u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x9021652u; SPILL(); f_9023A80(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
L_9021655:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), eax, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    (void)sub32(edx, M32((uint32_t)(ebp + 0x8u)), &f);
    if ((f.sf != f.of)) goto L_90214C0;
    goto L_9021679;
L_9021679:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
L_902167F:
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    (void)sub32(ecx, edi, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_9021460;
    goto L_902168E;
L_902168E:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(sub32(edi, esi, &f));
    edi = (uint32_t)((uint32_t)(eax + edi*4));
    edx = (uint32_t)(sub32(edx, ecx, &f));
    eax = (uint32_t)((uint32_t)(ebx + edx*4));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(edi);
    esp -= 4; M32(esp) = 0x90216AEu; SPILL(); f_9021B70(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(edi);
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_90216F7;
    goto L_90216BB;
L_90216BB:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)((uint32_t)(ebx + esi*4 + 0xFFFFFFE0u));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90216C9u; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(ebx + esi*4 + 0xFFFFFF80u));
    eax = (uint32_t)((uint32_t)(edi + 0x80u));
    esp -= 4; M32(esp) = 0x90216D8u; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edi + 0x100u));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90216E5u; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edi + 0x180u));
    esp -= 4; M32(esp) = 0x90216F0u; SPILL(); f_9022890(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90216F7:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)((uint32_t)(ebx + ecx*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x9021703u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edi + 0x40u));
    esp -= 4; M32(esp) = 0x902170Bu; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edi + 0x80u));
    esp -= 4; M32(esp) = 0x9021716u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edi + 0xC0u));
    esp -= 4; M32(esp) = 0x9021721u; SPILL(); f_9023A80(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9021730(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9021730:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x20u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    ebx = (uint32_t)(esi);
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x1u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    if ((f.zf || f.sf != f.of)) goto L_902184B;
    goto L_902174E;
L_902174E:
    edi = (uint32_t)(edi);
L_9021750:
    (void)sub32(esi, ebx, &f);
    eax = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    if ((f.sf == f.of)) goto L_902183C;
    goto L_902175D;
L_902175D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_9021760:
    edi = (uint32_t)(eax);
    edi = (uint32_t)(sub32(edi, esi, &f));
    (void)sub32(edi, ebx, &f);
    if ((f.sf == f.of)) goto L_90217C8;
    goto L_9021768;
L_9021768:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)((uint32_t)(edx + ecx*4));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)(eax + edi*4));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    eax = (uint32_t)((uint32_t)(eax + edx*4));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    esp = (uint32_t)((uint32_t)(esp));
L_9021790:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x902179Du; SPILL(); f_9021B70(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90217AAu; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)((uint32_t)(eax + eax));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), eax, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)sub32(edi, ebx, &f);
    if ((f.sf != f.of)) goto L_9021790;
    goto L_90217C5;
L_90217C5:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_90217C8:
    edi = (uint32_t)((uint32_t)(eax + eax));
    edi = (uint32_t)(sub32(edi, esi, &f));
    (void)sub32(edi, ebx, &f);
    if ((f.sf == f.of)) goto L_902182D;
    goto L_90217D1;
L_90217D1:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    ecx = (uint32_t)((uint32_t)(edx + ecx*4));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)((uint32_t)(eax + edi*4));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(edi + ebx));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(eax + ecx*4));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
L_90217F7:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021804u; SPILL(); f_90220C0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021811u; SPILL(); f_90220C0(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), eax, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    (void)sub32(edi, ebx, &f);
    if ((f.sf != f.of)) goto L_90217F7;
    goto L_902182A;
L_902182A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_902182D:
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    (void)sub32(eax, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    if ((f.sf != f.of)) goto L_9021760;
    goto L_902183C;
L_902183C:
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_9021750;
    goto L_902184B;
L_902184B:
    (void)sub32(esi, ebx, &f);
    ecx = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    if ((f.sf == f.of)) goto L_9021B63;
    goto L_9021858;
L_9021858:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(sub32(eax, esi, &f));
    (void)sub32(eax, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    if ((f.sf == f.of)) goto L_90219E0;
    goto L_902186A;
L_902186A:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)((uint32_t)(edi + ecx*4));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    eax = (uint32_t)(add32(eax, ebx, &f));
    eax = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
L_9021892:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x90218A4u; SPILL(); f_9021B70(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_90218F0;
    goto L_90218B7;
L_90218B7:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFE0u));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90218C5u; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(edi + eax*4 + 0xFFFFFF80u));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x90218D9u; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF80u, &f));
    ecx = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x90218E6u; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    esp -= 4; M32(esp) = 0x90218EEu; SPILL(); f_9022890(c); RELOAD();
    goto L_9021923;
L_90218F0:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(edi + ecx*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x90218FCu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x9021909u; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x9021916u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x9021923u; SPILL(); f_9023A80(c); RELOAD();
L_9021923:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021935u; SPILL(); f_9021B70(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_902197D;
    goto L_9021940;
L_9021940:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFE0u));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9021957u; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFF80u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF00u));
    esp -= 4; M32(esp) = 0x9021969u; SPILL(); f_9023050(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF80u));
    esp -= 4; M32(esp) = 0x9021974u; SPILL(); f_9022890(c); RELOAD();
    eax = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x902197Bu; SPILL(); f_9022890(c); RELOAD();
    goto L_90219BB;
L_902197D:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(edi + eax*4 + 0xFFFFFFC0u));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    esp -= 4; M32(esp) = 0x9021991u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x902199Eu; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x90219ABu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x90219B8u; SPILL(); f_9023A80(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
L_90219BB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), eax, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    if ((f.sf != f.of)) goto L_9021892;
    goto L_90219DD;
L_90219DD:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_90219E0:
    eax = (uint32_t)((uint32_t)(ecx + ecx));
    eax = (uint32_t)(sub32(eax, esi, &f));
    (void)sub32(eax, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    if ((f.sf == f.of)) goto L_9021B54;
    goto L_90219F0;
L_90219F0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)((uint32_t)(edi + edx*4));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    eax = (uint32_t)(add32(eax, ebx, &f));
    eax = (uint32_t)((uint32_t)(ecx + eax*4 + 0x180u));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    ebx = (uint32_t)((uint32_t)(ebx));
L_9021A20:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021A32u; SPILL(); f_90220C0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_9021A78;
    goto L_9021A40;
L_9021A40:
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFE0u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9021A4Cu; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFF80u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF00u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9021A61u; SPILL(); f_9023050(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF80u));
    esp -= 4; M32(esp) = 0x9021A6Cu; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9021A76u; SPILL(); f_9023050(c); RELOAD();
    goto L_9021AA8;
L_9021A78:
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x9021A81u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x9021A8Eu; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x9021A9Bu; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x9021AA8u; SPILL(); f_9023D40(c); RELOAD();
L_9021AA8:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFE80u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9021ABAu; SPILL(); f_90220C0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(esi, (uint32_t)0x80u, &f);
    if (!f.zf) goto L_9021B00;
    goto L_9021AC8;
L_9021AC8:
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFE0u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9021AD4u; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFF80u));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF00u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x9021AE9u; SPILL(); f_9023050(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)((uint32_t)(edx + 0xFFFFFF80u));
    esp -= 4; M32(esp) = 0x9021AF4u; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    eax = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x9021AFEu; SPILL(); f_9023050(c); RELOAD();
    goto L_9021B33;
L_9021B00:
    ecx = (uint32_t)((uint32_t)(edi + edx*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x9021B09u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFEC0u, &f));
    esp -= 4; M32(esp) = 0x9021B16u; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF00u, &f));
    esp -= 4; M32(esp) = 0x9021B23u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFF40u, &f));
    esp -= 4; M32(esp) = 0x9021B30u; SPILL(); f_9023D40(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
L_9021B33:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), eax, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    if ((f.sf != f.of)) goto L_9021A20;
    goto L_9021B51;
L_9021B51:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_9021B54:
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    (void)sub32(ecx, ebx, &f);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    if ((f.sf != f.of)) goto L_9021858;
    goto L_9021B63;
L_9021B63:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9021B70(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9021B70:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x48u, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x3u, &f));
    (void)sub32(ebx, (uint32_t)0x2u, &f);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(ebx + ebx));
    c->xmm[6].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(esi + esi));
    c->xmm[4].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[0] = c->xmm[2];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[4].f[0];
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    edx = (uint32_t)((uint32_t)(ecx + esi));
    c->xmm[7].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[4].u[0] = M32((uint32_t)(eax + esi*4)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[2].u[0];
    c->xmm[5] = c->xmm[4];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[2].f[0];
    edi = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    c->xmm[2] = c->xmm[6];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[7].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7] = c->xmm[5];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(eax)) = c->xmm[7].u[0];
    c->xmm[7] = c->xmm[2];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(eax + 0x4u)) = c->xmm[7].u[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[2].f[0];
    M32((uint32_t)(eax + esi*4 + 0x4u)) = c->xmm[1].u[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(eax + esi*4)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[1].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ecx)) = c->xmm[1].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[6].u[0];
    M32((uint32_t)(edi)) = c->xmm[3].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)((uint32_t)0x2u);
    if ((f.zf || f.sf != f.of)) goto L_9021F87;
    goto L_9021C6E;
L_9021C6E:
    ebx = (uint32_t)((uint32_t)(ecx + 0x8u));
    ecx = (uint32_t)((uint32_t)(eax + esi*4 + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(eax + esi*8 + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(esi + esi*2));
    edx = (uint32_t)((uint32_t)(eax + esi*4 + 0x8u));
    edi = (uint32_t)((uint32_t)(eax + ecx*4));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    edx = (uint32_t)((uint32_t)(eax + esi*8 + 0x8u));
    ecx = (uint32_t)((uint32_t)(edi + 0x8u));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFF8u, &f));
    esi = (uint32_t)(shl32(esi, (uint8_t)0x4u, &f));
    esi = (uint32_t)((uint32_t)(esi + eax + 0xFFFFFFF8u));
    goto L_9021CA3;
L_9021CA0:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFDCu)));
L_9021CA3:
    c->xmm[2].u[0] = M32((uint32_t)(ebx + 0x8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ebx + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ebx + 0x10u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(ebx + 0x14u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(edx)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(edx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    { Xmm s_ = (*(Xmm *)(MEM + (uint32_t)(0x9031300u))); c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[6].u[0] = M32((uint32_t)(eax + ebx*4)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[4] = c->xmm[6];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + ebx*4 + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(edx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(edx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ecx)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ecx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    M32((uint32_t)(eax + ebx*4)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(eax + ebx*4 + 0x4u)) = c->xmm[7].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebx)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFF0u));
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + MF32((uint32_t)(ebp + 0x8u));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[4].u[0];
    c->xmm[7] = c->xmm[2];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[4].f[0];
    c->xmm[4] = c->xmm[1];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[4].f[0];
    c->xmm[4] = c->xmm[2];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[5] = c->xmm[1];
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(edx + 0x4u)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    M32((uint32_t)(edx)) = c->xmm[7].u[0];
    c->xmm[5] = c->xmm[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[4].f[0];
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[6].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ecx)) = c->xmm[5].u[0];
    c->xmm[5] = c->xmm[3];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[4].f[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    c->xmm[4] = c->xmm[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[6].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(ecx + 0x4u)) = c->xmm[5].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(ebx)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(edi + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(edi)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(edi)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(edi + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFCCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(esi)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(esi)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x2u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    M32((uint32_t)(ebx)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[7].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebx)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[7] = c->xmm[1];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[5].u[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[5] = c->xmm[2];
    c->xmm[2].f[0] = c->xmm[2].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[6].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[2].f[0];
    M32((uint32_t)(edi + 0x4u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC0u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] + MF32((uint32_t)(ebp + 0x8u));
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[5].f[0];
    c->xmm[5] = c->xmm[0];
    c->xmm[2] = c->xmm[3];
    M32((uint32_t)(edi)) = c->xmm[7].u[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[4].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[1].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[4].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[5].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    M32((uint32_t)(esi)) = c->xmm[2].u[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[0].u[0];
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFBCu)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFECu)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), (uint32_t)0x8u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x8u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x8u, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), ebx, &f);
    if ((f.sf != f.of)) goto L_9021CA0;
    goto L_9021F82;
L_9021F82:
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFB8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_9021F87:
    c->xmm[3].u[0] = M32((uint32_t)(eax + ebx*4)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(ebx + ebx*2));
    edx = (uint32_t)((uint32_t)(ecx + ebx*2));
    c->xmm[5].u[0] = M32((uint32_t)(eax + edx*4)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    edi = (uint32_t)((uint32_t)(eax + ebx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edi);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[4].u[0] = M32((uint32_t)(edi)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    c->xmm[6].u[0] = M32((uint32_t)(edi)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    esi = (uint32_t)((uint32_t)(edx + ebx*2));
    c->xmm[7].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[0] = c->xmm[3];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    edi = (uint32_t)((uint32_t)(eax + esi*4 + 0x4u));
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[6].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + esi*4)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[6] = c->xmm[5];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(edi)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFB8u));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFBCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7] = c->xmm[6];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(eax + ebx*4)) = c->xmm[7].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(ebx)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[0].u[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(edi)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[5].f[0];
    c->xmm[7] = c->xmm[1];
    c->xmm[0] = c->xmm[6];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[7].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(edx)) = c->xmm[0].u[0];
    { Xmm s_ = (*(Xmm *)(MEM + (uint32_t)(0x9031300u))); c->xmm[2].q[0] ^= s_.q[0]; c->xmm[2].q[1] ^= s_.q[1]; }
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[6].f[0];
    c->xmm[0] = c->xmm[4];
    c->xmm[1] = c->xmm[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[3].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[5].f[0];
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(eax + esi*4)) = c->xmm[1].u[0];
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE0u)));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[5].f[0];
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(eax)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90220C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90220C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x64u, &f));
    c->xmm[4].u[0] = M32((uint32_t)(eax)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[5].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ebx = (uint32_t)(sar32(ebx, (uint8_t)0x3u, &f));
    (void)sub32(ebx, (uint32_t)0x2u, &f);
    edx = (uint32_t)((uint32_t)(ebx + ebx));
    c->xmm[7].u[0] = M32((uint32_t)(eax + edx*4)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(edx + edx));
    c->xmm[0].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[2] = c->xmm[3];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[0].u[0];
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(ecx + edx));
    c->xmm[4].u[0] = M32((uint32_t)(eax + edi*4 + 0x4u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(eax + edi*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = c->xmm[7].u[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFB4u));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(esi);
    c->xmm[6] = c->xmm[3];
    c->xmm[3].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    esi = (uint32_t)((uint32_t)(eax + edi*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[0].u[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[4].u[0];
    c->xmm[4] = c->xmm[7];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[7].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[5].f[0];
    c->xmm[7] = c->xmm[4];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    M32((uint32_t)(eax)) = c->xmm[7].u[0];
    c->xmm[7] = c->xmm[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[2].f[0];
    M32((uint32_t)(eax + 0x4u)) = c->xmm[7].u[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFC0u));
    M32((uint32_t)(eax + edx*4 + 0x4u)) = c->xmm[2].u[0];
    c->xmm[0] = c->xmm[1];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[1].f[0];
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[5].f[0];
    c->xmm[2] = c->xmm[1];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[3].f[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[2].u[0];
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFBCu)));
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[5].f[0];
    c->xmm[2] = c->xmm[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ecx)) = c->xmm[2].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[1].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = (uint32_t)(ebx);
    M32((uint32_t)(eax + edi*4)) = c->xmm[3].u[0];
    M32((uint32_t)(esi)) = c->xmm[6].u[0];
    ecx = (uint32_t)((uint32_t)(edx + edx));
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)((uint32_t)0x2u);
    if ((f.zf || f.sf != f.of)) goto L_902266C;
    goto L_90221F4;
L_90221F4:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)(esi + ecx*4 + 0x8u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(esi);
    esi = (uint32_t)((uint32_t)(eax + edx*8 + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(esi);
    esi = (uint32_t)((uint32_t)(edx + edx*2));
    ebx = (uint32_t)((uint32_t)(eax + esi*4));
    esi = (uint32_t)((uint32_t)(ebx + 0x8u));
    ebx = (uint32_t)(add32(ebx, (uint32_t)0xFFFFFFF8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(eax + edx*4 + 0xFFFFFFF8u));
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x4u, &f));
    ebx = (uint32_t)((uint32_t)(ebx + eax + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    edi = (uint32_t)((uint32_t)(eax + edx*4 + 0x8u));
    ecx = (uint32_t)((uint32_t)(eax + edx*8 + 0x8u));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(ebx);
    goto L_9022240;
L_9022240:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB8u)));
    c->xmm[0].u[0] = M32((uint32_t)(ebx + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(ebx + 0xCu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[5].u[0] = M32((uint32_t)(0x9031300u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebx)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB4u)));
    c->xmm[1].u[0] = M32((uint32_t)(ebx + 0xFFFFFFECu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ebx + 0xFFFFFFE8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(ebx + 0xFFFFFFF0u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    ebx = (uint32_t)(sub32(ebx, (uint32_t)0x10u, &f));
    { Xmm s_ = c->xmm[5]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = c->xmm[1].u[0];
    c->xmm[1].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    { Xmm s_ = c->xmm[5]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFC4u)));
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    ebx = (uint32_t)(add32(ebx, ebx, &f));
    c->xmm[6].u[0] = M32((uint32_t)(ebx + eax)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[5] = c->xmm[6];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx + eax + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ecx)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = c->xmm[7].u[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFB0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ecx)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(esi + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(edi)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(edi + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFA8u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(esi)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(edi)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFACu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(esi)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    c->xmm[6] = c->xmm[2];
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[7].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6] = c->xmm[2];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6] = c->xmm[3];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFCCu));
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFCCu));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFE8u));
    M32((uint32_t)(ebx + eax)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[6].u[0];
    c->xmm[7] = c->xmm[6];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFC0u));
    M32((uint32_t)(ebx + eax + 0x4u)) = c->xmm[7].u[0];
    M32((uint32_t)(edi + 0x4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFBCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0x8u));
    M32((uint32_t)(edi)) = c->xmm[5].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    c->xmm[5] = c->xmm[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFF0u));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFBCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6] = c->xmm[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0x8u));
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[7].u[0];
    c->xmm[6] = c->xmm[4];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFECu));
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6] = c->xmm[1];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[7].u[0];
    c->xmm[6] = c->xmm[1];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFECu));
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[6].u[0];
    c->xmm[7] = c->xmm[4];
    c->xmm[7].f[0] = c->xmm[7].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFE8u));
    M32((uint32_t)(ecx)) = c->xmm[7].u[0];
    c->xmm[7] = c->xmm[6];
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFC0u));
    M32((uint32_t)(ecx + 0x4u)) = c->xmm[7].u[0];
    M32((uint32_t)(esi + 0x4u)) = c->xmm[6].u[0];
    M32((uint32_t)(esi)) = c->xmm[5].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebx)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[5].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebx)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebx)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    c->xmm[5].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[6].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    c->xmm[6].u[0] = M32((uint32_t)(ebx + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebx)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebx)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    c->xmm[5] = c->xmm[3];
    c->xmm[5].f[0] = c->xmm[5].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFCCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[3].f[0];
    c->xmm[6] = c->xmm[2];
    c->xmm[6].f[0] = c->xmm[6].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * MF32((uint32_t)(ebp + 0xFFFFFFE0u));
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFC4u)), (uint32_t)0x2u, &f));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[3] = c->xmm[6];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(ebx)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[7] = c->xmm[2];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[7].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD4u)));
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[2].f[0];
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(ebx)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    c->xmm[2] = c->xmm[1];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[3].f[0];
    c->xmm[6] = c->xmm[4];
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFBCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[5].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[1].f[0];
    c->xmm[1] = c->xmm[3];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[5].f[0];
    c->xmm[7] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[6].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[5].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[7].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[6].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    c->xmm[3] = c->xmm[1];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[2].f[0];
    M32((uint32_t)(ebx)) = c->xmm[3].u[0];
    c->xmm[3] = c->xmm[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[4].f[0];
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[3].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[1].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[0].f[0];
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M32((uint32_t)(ebx)) = c->xmm[2].u[0];
    M32((uint32_t)(ebx + 0x4u)) = c->xmm[4].u[0];
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFF9Cu)));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFD8u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFD4u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFFF4u)), (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFC4u)), ebx, &f);
    if ((f.sf != f.of)) goto L_9022240;
    goto L_902266C;
L_902266C:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    c->xmm[0].u[0] = M32((uint32_t)(ecx + edx*4)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ecx + edx*4 + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(eax + ebx*4)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(eax + ebx*4 + 0x4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    ecx = (uint32_t)((uint32_t)(edx + ebx));
    esi = (uint32_t)((uint32_t)(ecx + edx));
    c->xmm[2].u[0] = M32((uint32_t)(eax + esi*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(eax + esi*4)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    edi = (uint32_t)((uint32_t)(eax + esi*4 + 0x4u));
    c->xmm[4] = c->xmm[6];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0x8u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ebx*4 + 0x4u));
    edx = (uint32_t)(add32(edx, esi, &f));
    c->xmm[2].u[0] = M32((uint32_t)(eax + edx*4 + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = (uint32_t)(edi);
    c->xmm[5] = c->xmm[7];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + ecx*4 + 0x4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + edx*4)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    edi = (uint32_t)((uint32_t)(eax + edx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xCu)) = c->xmm[6].u[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + MF32((uint32_t)(ebp + 0xCu));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = (uint32_t)(edi);
    edi = (uint32_t)((uint32_t)(eax + ecx*4 + 0x4u));
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = c->xmm[7].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFF9Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[3].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[2].u[0];
    c->xmm[2] = c->xmm[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[4].f[0];
    c->xmm[3] = c->xmm[1];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[5].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[3].f[0];
    c->xmm[3] = c->xmm[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[5].f[0];
    c->xmm[5] = c->xmm[1];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[4].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    c->xmm[4] = c->xmm[1];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[6].f[0];
    c->xmm[5] = c->xmm[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[7].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[5].f[0];
    c->xmm[5] = c->xmm[1];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[7].f[0];
    c->xmm[7] = c->xmm[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[6].f[0];
    c->xmm[6] = c->xmm[4];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[2].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    M32((uint32_t)(eax + ebx*4)) = c->xmm[6].u[0];
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFA0u)));
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[4].f[0];
    c->xmm[6] = c->xmm[5];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebx)) = c->xmm[6].u[0];
    M32((uint32_t)(edi)) = c->xmm[3].u[0];
    M32((uint32_t)(eax + ecx*4)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0x8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[3] = c->xmm[1];
    c->xmm[4] = c->xmm[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[4].f[0];
    c->xmm[4] = c->xmm[1];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[5].f[0];
    c->xmm[5] = c->xmm[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFBCu)));
    c->xmm[7] = c->xmm[1];
    c->xmm[2] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[5].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[6].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[5].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[6].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[7].f[0];
    c->xmm[1] = c->xmm[3];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[2].f[0];
    M32((uint32_t)(eax + esi*4)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    M32((uint32_t)(ecx)) = c->xmm[1].u[0];
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(eax + edx*4)) = c->xmm[2].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFA4u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    M32((uint32_t)(edx)) = c->xmm[0].u[0];
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9022810(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9022810:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), (uint32_t)0x80u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(edx);
    if (!f.zf) goto L_9022858;
    goto L_9022822;
L_9022822:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + ebx*4 + 0xFFFFFFE0u));
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x902282Eu; SPILL(); f_9022890(c); RELOAD();
    ecx = (uint32_t)((uint32_t)(edi + ebx*4 + 0xFFFFFF80u));
    eax = (uint32_t)((uint32_t)(edx + 0x80u));
    esp -= 4; M32(esp) = 0x902283Du; SPILL(); f_9023050(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0x100u));
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x902284Au; SPILL(); f_9022890(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)(edx + 0x180u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { SPILL(); f_9022890(c); return; }
L_9022858:
    ecx = (uint32_t)((uint32_t)(edi + ebx*4 + 0xFFFFFFC0u));
    esp -= 4; M32(esp) = 0x9022861u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0x40u));
    esp -= 4; M32(esp) = 0x9022869u; SPILL(); f_9023D40(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0x80u));
    esp -= 4; M32(esp) = 0x9022874u; SPILL(); f_9023A80(c); RELOAD();
    eax = (uint32_t)((uint32_t)(edx + 0xC0u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { SPILL(); f_9023A80(c); return; }
}

void f_9022890(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9022890:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x88u, &f));
    c->xmm[5].u[0] = M32((uint32_t)(eax)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(eax + 0x40u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x4u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x44u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[3] = c->xmm[5];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[4].f[0];
    c->xmm[4] = c->xmm[6];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x40u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x60u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x44u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x20u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x64u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x24u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x60u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x64u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    c->xmm[1].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFF7Cu)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = c->xmm[4].u[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFF90u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[3] = c->xmm[4];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[4].f[0];
    c->xmm[4].u[0] = M32((uint32_t)(eax + 0x48u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = c->xmm[3].u[0];
    c->xmm[3] = c->xmm[7];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x4Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = c->xmm[3].u[0];
    c->xmm[3] = c->xmm[5];
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0xCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[4].f[0];
    c->xmm[4] = c->xmm[6];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x48u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x68u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x4Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x28u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x6Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x2Cu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[0] = c->xmm[2];
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x68u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x6Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[5].u[0];
    c->xmm[5] = c->xmm[7];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    M32((uint32_t)(ebp + 0xFFFFFF80u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[4].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(ebp + 0xFFFFFF84u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFECu));
    M32((uint32_t)(ebp + 0xFFFFFF78u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFDCu));
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = c->xmm[4].u[0];
    c->xmm[4] = c->xmm[5];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    c->xmm[5] = c->xmm[3];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[2].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[7].f[0];
    c->xmm[7] = c->xmm[6];
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[0].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[2].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[0].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x54u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x10u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x50u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = c->xmm[3].u[0];
    c->xmm[3] = c->xmm[6];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x14u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x50u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x54u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x70u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x30u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[6].u[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x74u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(eax + 0x34u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[6].u[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x70u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x74u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFA8u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    c->xmm[3] = c->xmm[7];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFECu));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x5Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = c->xmm[5].u[0];
    c->xmm[5] = c->xmm[6];
    c->xmm[6] = c->xmm[3];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x58u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(eax + 0x18u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x1Cu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x58u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x5Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x78u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x38u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x7Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(eax + 0x3Cu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x78u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(eax + 0x7Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    M32((uint32_t)(ebp + 0xFFFFFF8Cu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFE4u));
    M32((uint32_t)(ebp + 0xFFFFFFA4u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFDCu));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[7].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[5].u[0];
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] * c->xmm[0].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] * c->xmm[1].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[5].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFF8u));
    c->xmm[5] = c->xmm[3];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFECu));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = c->xmm[5].u[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[2].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[3].u[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[0].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFDCu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[0].f[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFD0u));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFC8u));
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFD4u));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = c->xmm[3].u[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFC0u));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = c->xmm[5].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[3].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFCCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + MF32((uint32_t)(ebp + 0xFFFFFFCCu));
    M32((uint32_t)(eax + 0x60u)) = c->xmm[5].u[0];
    c->xmm[5] = c->xmm[3];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(eax + 0x68u)) = c->xmm[0].u[0];
    M32((uint32_t)(eax + 0x64u)) = c->xmm[5].u[0];
    c->xmm[0] = c->xmm[3];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(eax + 0x6Cu)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFECu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(eax + 0x70u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFF94u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[5] = c->xmm[2];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(eax + 0x74u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFB4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[2].f[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFC4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(eax + 0x78u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFBCu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(eax + 0x7Cu)) = c->xmm[0].u[0];
    c->xmm[0] = c->xmm[6];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFACu)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[5].u[0];
    c->xmm[5] = c->xmm[7];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[4].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFD8u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFC4u));
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFD8u));
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFFCu));
    M32((uint32_t)(eax + 0x40u)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + 0x48u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[7] = c->xmm[5];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA4u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    M32((uint32_t)(eax + 0x4Cu)) = c->xmm[2].u[0];
    c->xmm[2] = c->xmm[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(eax + 0x50u)) = c->xmm[2].u[0];
    c->xmm[2] = c->xmm[4];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[3].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(eax + 0x54u)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFF9Cu)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    M32((uint32_t)(eax + 0x44u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFF8Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(eax + 0x58u)) = c->xmm[6].u[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFF84u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[0] = c->xmm[7];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[7].f[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFF7Cu)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    M32((uint32_t)(eax + 0x5Cu)) = c->xmm[3].u[0];
    c->xmm[4] = c->xmm[6];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[6].f[0];
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFFB0u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[3] = c->xmm[4];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[1].f[0];
    c->xmm[4] = c->xmm[5];
    c->xmm[4].f[0] = c->xmm[4].f[0] - c->xmm[2].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[5].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFB8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[7];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[7].f[0];
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[3].f[0];
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA0u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    M32((uint32_t)(eax + 0x28u)) = c->xmm[1].u[0];
    c->xmm[5] = c->xmm[2];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFE8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFE8u));
    c->xmm[1] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(eax + 0x30u)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[4];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[6].f[0];
    M32((uint32_t)(eax + 0x20u)) = c->xmm[7].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[0].f[0];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[2].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF4u));
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[4].f[0];
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFA8u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    M32((uint32_t)(eax + 0x34u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0x38u)) = c->xmm[5].u[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFF98u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[0] = c->xmm[4];
    M32((uint32_t)(eax + 0x2Cu)) = c->xmm[2].u[0];
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFF90u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[3].f[0];
    c->xmm[1] = c->xmm[5];
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[4].f[0];
    M32((uint32_t)(eax + 0x24u)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + 0x3Cu)) = c->xmm[6].u[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[2].f[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[3].u[0];
    c->xmm[7].u[0] = M32((uint32_t)(ebp + 0xFFFFFF88u)); c->xmm[7].u[1] = c->xmm[7].u[2] = c->xmm[7].u[3] = 0;
    c->xmm[6].u[0] = M32((uint32_t)(ebp + 0xFFFFFF80u)); c->xmm[6].u[1] = c->xmm[6].u[2] = c->xmm[6].u[3] = 0;
    c->xmm[4].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[3] = c->xmm[7];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[5].f[0];
    c->xmm[5].u[0] = M32((uint32_t)(ebp + 0xFFFFFF78u)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[6].f[0];
    c->xmm[6].f[0] = c->xmm[6].f[0] - c->xmm[7].f[0];
    c->xmm[4].f[0] = c->xmm[4].f[0] + c->xmm[5].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] - MF32((uint32_t)(ebp + 0xFFFFFFF0u));
    c->xmm[7] = c->xmm[3];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[0].f[0];
    M32((uint32_t)(eax)) = c->xmm[7].u[0];
    c->xmm[7] = c->xmm[4];
    c->xmm[7].f[0] = c->xmm[7].f[0] + c->xmm[1].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[4].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[3].f[0];
    M32((uint32_t)(eax + 0xCu)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0x8u)) = c->xmm[0].u[0];
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1] = c->xmm[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[5].f[0];
    M32((uint32_t)(eax + 0x10u)) = c->xmm[1].u[0];
    c->xmm[1] = c->xmm[6];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[2].f[0];
    c->xmm[5].f[0] = c->xmm[5].f[0] + c->xmm[0].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[6].f[0];
    M32((uint32_t)(eax + 0x4u)) = c->xmm[7].u[0];
    M32((uint32_t)(eax + 0x14u)) = c->xmm[1].u[0];
    M32((uint32_t)(eax + 0x18u)) = c->xmm[5].u[0];
    M32((uint32_t)(eax + 0x1Cu)) = c->xmm[2].u[0];
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

