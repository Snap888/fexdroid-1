#include "funcs_bink.h"
#include "lift_prelude.h"

void f_900DDB0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DDB0:
    (void)sub32(TL32((uint32_t)(ecx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900DDE2;
    goto L_900DDB9;
L_900DDB9:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_900DDCB;
    goto L_900DDC6;
L_900DDC6:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900DDE2;
    goto L_900DDCB;
L_900DDCB:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x3B0u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x290u);
    ecx = (uint32_t)((uint32_t)0x90373B0u);
    esp -= 4; M32(esp) = 0x900DDE1u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
L_900DDE2:
    esp += 4; SPILL(); return;
}

void f_900DDF0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900DDF0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x124u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(eax + ecx + 0xFFFFFFDCu)), esi, &f);
    if (f.zf) goto L_900E02A;
    goto L_900DE19;
L_900DE19:
    (void)sub32(TL32((uint32_t)(ebx + 0x460u)), esi, &f);
    if (f.zf) goto L_900E02A;
    goto L_900DE25;
L_900DE25:
    ecx = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900DE2Cu; SPILL(); f_900DD30(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E02A;
    goto L_900DE34;
L_900DE34:
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(esi);
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), esi, &f);
    if ((f.cf || f.zf)) goto L_900DFF6;
    goto L_900DE43;
L_900DE43:
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(esi);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    goto L_900DE50;
L_900DE50:
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0xFFFFFFF0u)), &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x15Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900DE62u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DFDB;
    goto L_900DE6A;
L_900DE6A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_900DE70:
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    edi = (uint32_t)(sub32(edi, TL32((uint32_t)(esi + 0x18u)), &f));
    if (!f.sf) goto L_900DE7A;
    goto L_900DE77;
L_900DE77:
    edi = (uint32_t)(add32(edi, TL32((uint32_t)(esi + 0x8u)), &f));
L_900DE7A:
    (void)sub32(edi, TL32((uint32_t)(esi + 0x2Cu)), &f);
    if ((!f.zf && f.sf == f.of)) goto L_900DE93;
    goto L_900DE7F;
L_900DE7F:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(eax, TL32((uint32_t)(esi + 0x40u)), &f);
    if ((f.zf || f.sf != f.of)) goto L_900DFDB;
    goto L_900DE8B;
L_900DE8B:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900DFDB;
    goto L_900DE93;
L_900DE93:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x160u)));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900DEA4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DFDB;
    goto L_900DEAC;
L_900DEAC:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x54u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900DEBB;
    goto L_900DEB6;
L_900DEB6:
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
L_900DEBB:
    (void)sub32(edx, edi, &f);
    if ((f.cf || f.zf)) goto L_900DEC4;
    goto L_900DEBF;
L_900DEBF:
    edx = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
L_900DEC4:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ecx, TL32((uint32_t)(esi + 0x40u)), &f);
    if ((!f.zf && f.sf == f.of)) goto L_900DED8;
    goto L_900DECC;
L_900DECC:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ecx = (uint32_t)(eax);
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
L_900DED8:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edi = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    edi = (uint32_t)(sub32(edi, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edi);
    (void)sub32(edi, edx, &f);
    if (!f.cf) goto L_900DF84;
    goto L_900DEEB;
L_900DEEB:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900DF2D;
    goto L_900DEEF;
L_900DEEF:
    (void)logic32((uint32_t)(eax & eax), &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    if (f.zf) goto L_900DF1C;
    goto L_900DEF6;
L_900DEF6:
    ebx = (uint32_t)(edi);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x1u, &f));
    if (f.zf) goto L_900DF14;
    goto L_900DEFC;
L_900DEFC:
    esp = (uint32_t)((uint32_t)(esp));
L_900DF00:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)edx), (uint8_t)0x80u, &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x2u, &f));
    ebx = (uint32_t)(sub32(ebx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900DF00;
    goto L_900DF11;
L_900DF11:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_900DF14:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    goto L_900DF2D;
L_900DF1C:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900DF24u; SPILL(); f_9001FE0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), edi, &f));
L_900DF2D:
    (void)sub32(TL32((uint32_t)(esi + 0x54u)), (uint32_t)0x0u, &f);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    if (f.zf) goto L_900DF65;
    goto L_900DF36;
L_900DF36:
    edi = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    if (f.zf) goto L_900DF56;
    goto L_900DF42;
L_900DF42:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)edx), (uint8_t)0x80u, &f));
    TS8((uint32_t)(ecx), (uint8_t)(((uint8_t)edx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x2u, &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900DF42;
    goto L_900DF53;
L_900DF53:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_900DF56:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(sub32(eax, edi, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(eax));
    goto L_900DFB5;
L_900DF65:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(sub32(edx, edi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900DF72u; SPILL(); f_9001FE0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(sub32(eax, edi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(eax));
    goto L_900DFB5;
L_900DF84:
    (void)logic32((uint32_t)(eax & eax), &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    if (f.zf) goto L_900DFA4;
    goto L_900DF8B;
L_900DF8B:
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shr32(edi, (uint8_t)0x1u, &f));
    if (f.zf) goto L_900DFB2;
    goto L_900DF91;
L_900DF91:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ecx + 0x1u)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(sub8(((uint8_t)edx), (uint8_t)0x80u, &f));
    TS8((uint32_t)(eax), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x2u, &f));
    edi = (uint32_t)(sub32(edi, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900DF91;
    goto L_900DFA2;
L_900DFA2:
    goto L_900DFAF;
L_900DFA4:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900DFACu; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_900DFAF:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
L_900DFB2:
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(add32(TL32((uint32_t)(esi + 0x18u)), edx, &f)));
L_900DFB5:
    (void)sub32(TL32((uint32_t)(esi + 0x54u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900DFC0;
    goto L_900DFBB;
L_900DFBB:
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
L_900DFC0:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x164u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900DFCAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x15Cu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900DFD3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900DE70;
    goto L_900DFDB;
L_900DFDB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFF0u)), (uint32_t)0x180u, &f));
    eax = (uint32_t)(inc32(eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x124u)), &f);
    if (f.cf) goto L_900DE50;
    goto L_900DFF5;
L_900DFF5:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
L_900DFF6:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900E02A;
    goto L_900DFFF;
L_900DFFF:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_900E011;
    goto L_900E00C;
L_900E00C:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_900E02A;
    goto L_900E011;
L_900E011:
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x3B0u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x290u);
    ecx = (uint32_t)((uint32_t)0x90373B0u);
    esp -= 4; M32(esp) = 0x900E027u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900E02A:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900E040(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E040:
    (void)sub32(TL32((uint32_t)(esi + 0x474u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900E06B;
    goto L_900E049;
L_900E049:
    esp -= 4; M32(esp) = 0x900E04Eu; SPILL(); f_90159C0(c); RELOAD();
    TS32((uint32_t)(esi + 0x474u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x460u)));
    eax = (uint32_t)(dec32(eax, &f));
    TS32((uint32_t)(esi + 0x478u), (uint32_t)(eax));
    TS32((uint32_t)(esi + 0x4CCu), (uint32_t)((uint32_t)0x0u));
L_900E06B:
    esp += 4; SPILL(); return;
}

void f_900E070(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E070:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900E15B;
    goto L_900E07D;
L_900E07D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E0A7;
    goto L_900E086;
L_900E086:
    { uint32_t v_ = 0x9037408u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028468u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x30Bu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E0A4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900E0A7:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x30Eu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x2B0u));
    { uint32_t v_ = 0x9037428u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900E0BDu; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900E110;
    goto L_900E0C9;
L_900E0C9:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xE8u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x188u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x18Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x194u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E0F4u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(edi + 0x188u)), &f));
    TS32((uint32_t)(edi + 0x118u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(edi + 0x4D8u), (uint32_t)(ecx));
L_900E110:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x319u);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x900E120u; SPILL(); f_900D070(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E13F;
    goto L_900E12D;
L_900E12D:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x31Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900E13Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900E13F:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E15B;
    goto L_900E148;
L_900E148:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x900E15Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900E15B:
    esp += 4; SPILL(); return;
}

void f_900E160(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E160:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(ecx);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900E172;
    goto L_900E171;
L_900E171:
    esi = (uint32_t)(dec32(esi, &f));
L_900E172:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(edi + 0x4BCu), (uint32_t)((uint32_t)0x0u));
    if (f.zf) goto L_900E197;
    goto L_900E185;
L_900E185:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    (void)sub32(TL32((uint32_t)(eax + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_900E197;
    goto L_900E191;
L_900E191:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900E197u; SPILL(); f_900DDF0(c); RELOAD();
L_900E197:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x900E1A2u; SPILL(); f_900E070(c); RELOAD();
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900E1D9;
    goto L_900E1A6;
L_900E1A6:
    esp -= 4; M32(esp) = 0x900E1ABu; SPILL(); f_90159C0(c); RELOAD();
    (void)sub32(TL32((uint32_t)(edi + 0x4B4u)), esi, &f);
    if (!f.zf) goto L_900E1B9;
    goto L_900E1B3;
L_900E1B3:
    TS32((uint32_t)(edi + 0x4B4u), (uint32_t)(eax));
L_900E1B9:
    edx = (uint32_t)(eax);
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(edi + 0x4B4u)), &f));
    (void)sub32(edx, (uint32_t)0x493E0u, &f);
    if ((f.cf || f.zf)) goto L_900E1D9;
    goto L_900E1C9;
L_900E1C9:
    TS32((uint32_t)(edi + 0x4B4u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4B8u), (uint32_t)((uint32_t)0x1u));
L_900E1D9:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x158u)));
    ebx = (uint32_t)((uint32_t)(esi + 0x1u));
    TS32((uint32_t)(edi + 0x18Cu), (uint32_t)(ebx));
    ecx = (uint32_t)(TL32((uint32_t)(eax + esi*4)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFFEu), &f));
    TS32((uint32_t)(edi + 0x188u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(eax + esi*4)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    TS32((uint32_t)(edi + 0x120u), (uint32_t)(edx));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(eax + esi*4 + 0x4u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFFEu), &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    TS32((uint32_t)(edi + 0x11Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x17Cu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900E22C;
    goto L_900E21B;
L_900E21B:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(edi + 0xE8u), (uint32_t)(ecx));
    goto L_900E2A5;
L_900E22C:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4E0u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ edx), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x7Fu), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x100u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ eax), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFFFFF80u, &f));
    TS32((uint32_t)(edi + 0xE8u), (uint32_t)(ecx));
    (void)sub32(edx, TL32((uint32_t)(edi + 0x4D8u)), &f);
    if (f.cf) goto L_900E27E;
    goto L_900E251;
L_900E251:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x1FCu)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(edi + 0x4D8u)), &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(edi + 0x188u)), &f));
    (void)sub32(eax, edx, &f);
    if ((!f.cf && !f.zf)) goto L_900E27E;
    goto L_900E26D;
L_900E26D:
    TS32((uint32_t)(edi + 0x118u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x900E27Cu; SPILL(); f_900E070(c); RELOAD();
    goto L_900E2A5;
L_900E27E:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    TS32((uint32_t)(edi + 0x118u), (uint32_t)((uint32_t)0x1u));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900E2A5;
    goto L_900E292;
L_900E292:
    edx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x900E2A5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900E2A5:
    (void)sub32(TL32((uint32_t)(edi + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900E2C0;
    goto L_900E2AE;
L_900E2AE:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x154u)));
    (void)sub32(TL32((uint32_t)(ecx + 0x4Cu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_900E2C0;
    goto L_900E2BA;
L_900E2BA:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900E2C0u; SPILL(); f_900DDF0(c); RELOAD();
L_900E2C0:
    ecx = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900E48C;
    goto L_900E2CE;
L_900E2CE:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x450u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    esi = (uint32_t)(dec32(esi, &f));
    (void)sub32(esi, eax, &f);
    if ((f.cf || f.zf)) goto L_900E2DF;
    goto L_900E2DC;
L_900E2DC:
    esi = (uint32_t)((uint32_t)(eax + 0xFFFFFFFFu));
L_900E2DF:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900E2E8;
    goto L_900E2E3;
L_900E2E3:
    esi = (uint32_t)((uint32_t)0x1u);
L_900E2E8:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x12Cu)));
    { uint32_t v_ = 0x9037448u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037450u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037458u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ecx + 0x84u));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1F8u)));
    fpush(c, (double)(int32_t)M32((uint32_t)(edi + 0x1F8u)));
    { uint32_t v_ = 0x9037464u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028238u; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.sf == f.of)) goto L_900E324;
    goto L_900E31E;
L_900E31E:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_900E324:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E335u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E40A;
    goto L_900E345;
L_900E345:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x12Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x1FCu)));
    fpush(c, (double)(int32_t)M32((uint32_t)(edi + 0x1FCu)));
    { uint32_t v_ = 0x9037448u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037478u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037458u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(add32(eax, (uint32_t)0x84u, &f));
    { uint32_t v_ = 0x9037464u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028228u; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(edx & edx), &f);
    if ((f.sf == f.of)) goto L_900E380;
    goto L_900E37A;
L_900E37A:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_900E380:
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900E391u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x24u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E40A;
    goto L_900E39D;
L_900E39D:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1FCu)));
    fpush(c, (double)(int32_t)M32((uint32_t)(edi + 0x1FCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x84u, &f));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.sf == f.of)) goto L_900E3B8;
    goto L_900E3B2;
L_900E3B2:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_900E3B8:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x12Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1F8u)));
    fpush(c, (double)(int32_t)M32((uint32_t)(edi + 0x1F8u)));
    { uint32_t v_ = 0x9037480u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037458u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037490u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028480u; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.sf == f.of)) goto L_900E3E9;
    goto L_900E3E3;
L_900E3E3:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_900E3E9:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x903BD5Cu));
    edx = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ST(1) = ST(1) / ST(0); fpop(c);
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = 0x5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E402u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
L_900E40A:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    (void)sub32(ecx, esi, &f);
    if ((f.zf || f.sf != f.of)) goto L_900E48C;
    goto L_900E411;
L_900E411:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E48C;
    goto L_900E415;
L_900E415:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4A4u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x4A0u)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    edx = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x158u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(eax + edx*4)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x12Cu)));
    { uint32_t v_ = 0x9037448u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374A0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ACu; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    fpush(c, (double)(int32_t)M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    { uint32_t v_ = 0x9028230u; esp -= 4; M32(esp) = v_; }
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_900E475;
    goto L_900E46F;
L_900E46F:
    ST(0) = ST(0) + (double)MF32((uint32_t)(0x9031330u));
L_900E475:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    MF32((uint32_t)(esp)) = (float)ST(0); fpop(c);
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x84u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E489u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
L_900E48C:
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900E4A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E4A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(0x903FE10u), (uint32_t)(eax));
    TS32((uint32_t)(0x9028454u), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900E4C0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E4C0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(0x903FE08u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FE0Cu), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900E4E0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E4E0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(0x903FE14u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900E4F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E4F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(0x903FEA0u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900E500(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E500:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(0x903FE18u), (uint32_t)(eax));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900E510(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E510:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(ecx, (uint32_t)0x20u, &f);
    if ((f.cf || f.zf)) goto L_900E520;
    goto L_900E51B;
L_900E51B:
    ecx = (uint32_t)((uint32_t)0x20u);
L_900E520:
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FE1Cu), (uint32_t)(ecx));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if ((f.cf || f.zf)) goto L_900E554;
    goto L_900E52C;
L_900E52C:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x903FE20u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    goto L_900E540;
L_900E540:
    esi = (uint32_t)(TL32((uint32_t)(edx + eax*4 + 0x903FE20u)));
    TS32((uint32_t)(eax*4 + 0x903FE20u), (uint32_t)(esi));
    eax = (uint32_t)(inc32(eax, &f));
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_900E540;
    goto L_900E553;
L_900E553:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_900E554:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900E560(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E560:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(sub32(esi, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    ebx = (uint32_t)((uint32_t)(edx + 0x1u));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
    if (!f.sf) goto L_900E585;
    goto L_900E580;
L_900E580:
    esi = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(esi);
L_900E585:
    (void)sub32(esi, edx, &f);
    if ((f.zf || f.sf != f.of)) goto L_900E5C6;
    goto L_900E589;
L_900E589:
    eax = (uint32_t)((uint32_t)(edi + eax*4));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
L_900E590:
    ecx = (uint32_t)(TL32((uint32_t)(edi + edx*4)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esi = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    esi = (uint32_t)(sub32(esi, ecx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & eax), &f));
    (void)sub32(TL32((uint32_t)(edi + edx*4 + 0x4u)), ecx, &f);
    if ((f.cf || f.zf)) goto L_900E60E;
    goto L_900E5A7;
L_900E5A7:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    (void)sub32(esi, eax, &f);
    if ((f.cf || f.zf)) goto L_900E5B6;
    goto L_900E5AE;
L_900E5AE:
    eax = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
L_900E5B6:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x4u, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(edx, esi, &f);
    if ((f.sf != f.of)) goto L_900E590;
    goto L_900E5C2;
L_900E5C2:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900E5DE;
    goto L_900E5C6;
L_900E5C6:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(edi + ecx*4)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(edi)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
L_900E5DE:
    (void)sub32(esi, M32((uint32_t)(ebp + 0x8u)), &f);
    ecx = (uint32_t)(esi);
    if ((f.sf == f.of)) goto L_900E5FB;
    goto L_900E5E5;
L_900E5E5:
    edx = (uint32_t)(TL32((uint32_t)(edi + ecx*4)));
    esi = (uint32_t)(edx);
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0x1u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & esi), &f));
    (void)sub32(TL32((uint32_t)(edi + ecx*4 + 0x4u)), edx, &f);
    if ((f.cf || f.zf)) goto L_900E60E;
    goto L_900E5F5;
L_900E5F5:
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0x8u)), &f);
    if ((f.sf != f.of)) goto L_900E5E5;
    goto L_900E5FB;
L_900E5FB:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(ecx), (uint32_t)(ebx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900E60E:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900E620(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E620:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(sub32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E649;
    goto L_900E62F;
L_900E62F:
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028450u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x58u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E641u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_900E649:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    goto L_900E655;
L_900E650:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900E655:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x0u);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E681;
    goto L_900E660;
L_900E660:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90374C4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902822Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x44Fu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900E67Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900E681:
    edx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x900E692u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E6B0;
    goto L_900E69B;
L_900E69B:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x451u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900E6ADu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)((uint32_t)(ecx));
L_900E6B0:
    edx = (uint32_t)(TL32((uint32_t)(0x903FEB0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900EE17;
    goto L_900E6BE;
L_900E6BE:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EE17;
    goto L_900E6CB;
L_900E6CB:
    { uint32_t v_ = 0x45Bu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    esp -= 4; M32(esp) = 0x900E6E2u; SPILL(); f_900CE90(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900E86B;
    goto L_900E6F3;
L_900E6F3:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900E86B;
    goto L_900E700;
L_900E700:
    (void)logic32((uint32_t)(TL32((uint32_t)(edi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900E86B;
    goto L_900E70D;
L_900E70D:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x1u);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E73E;
    goto L_900E71D;
L_900E71D:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90374D0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028220u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x463u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900E73Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900E73E:
    { uint32_t v_ = 0x464u; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(edi + 0x2B0u));
    { uint32_t v_ = 0x9037428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900E757u; SPILL(); f_900CF80(c); RELOAD();
    esi = (uint32_t)(eax);
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900E793;
    goto L_900E760;
L_900E760:
    { uint32_t v_ = 0x467u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x330u));
    esp -= 4; M32(esp) = 0x900E777u; SPILL(); f_900CF80(c); RELOAD();
    esi = (uint32_t)(eax);
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900E793;
    goto L_900E780;
L_900E780:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x469u);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x900E790u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900E793:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E7AE;
    goto L_900E79C;
L_900E79C:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t v_ = 0x46Bu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900E7AEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900E7AE:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x46Fu);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900E7C2u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900E882;
    goto L_900E7CD;
L_900E7CD:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), esi, &f);
    if (f.zf) goto L_900E840;
    goto L_900E7D7;
L_900E7D7:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x1D0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900E83D;
    goto L_900E7E1;
L_900E7E1:
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), esi, &f);
    if (!f.zf) goto L_900E83D;
    goto L_900E7E9;
L_900E7E9:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), esi, &f);
    if (f.zf) goto L_900E83D;
    goto L_900E7F1;
L_900E7F1:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xE8u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x188u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x194u)));
    ecx = (uint32_t)(dec32(ecx, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E81Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x188u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(edi + 0x11Cu)), &f));
    TS32((uint32_t)(edi + 0x118u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0x4D8u), (uint32_t)(ecx));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_900E83D;
    goto L_900E836;
L_900E836:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x1u);
L_900E83D:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
L_900E840:
    edi = (uint32_t)(add32(edi, (uint32_t)0x330u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x47Cu);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900E856u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x47Fu);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x900E866u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_900E882;
L_900E86B:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x485u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900E87Fu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900E882:
    { uint32_t v_ = 0x489u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900E896u; SPILL(); f_900CE90(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900EA5E;
    goto L_900E8A7;
L_900E8A7:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    esp = (uint32_t)((uint32_t)(esp));
L_900E8B0:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900EA50;
    goto L_900E8BD;
L_900E8BD:
    (void)logic32((uint32_t)(TL32((uint32_t)(edi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900EA50;
    goto L_900E8CA;
L_900E8CA:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E8F2;
    goto L_900E8D1;
L_900E8D1:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x50u)));
    { uint32_t v_ = 0x90374D0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902844Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x494u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900E8EFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
L_900E8F2:
    { uint32_t v_ = 0x495u; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)((uint32_t)(edi + 0x2B0u));
    { uint32_t v_ = 0x9037428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900E90Bu; SPILL(); f_900CF80(c); RELOAD();
    esi = (uint32_t)(eax);
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900E947;
    goto L_900E914;
L_900E914:
    { uint32_t v_ = 0x498u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x330u));
    esp -= 4; M32(esp) = 0x900E92Bu; SPILL(); f_900CF80(c); RELOAD();
    esi = (uint32_t)(eax);
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900E947;
    goto L_900E934;
L_900E934:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x49Au);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x900E944u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900E947:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E967;
    goto L_900E950;
L_900E950:
    { uint32_t v_ = 0x49Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90372F4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x54u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900E962u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900E967:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900EA50;
    goto L_900E96F;
L_900E96F:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4A2u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900E983u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900EA02;
    goto L_900E98F;
L_900E98F:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1D0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_900E9FF;
    goto L_900E999;
L_900E999:
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), ecx, &f);
    if (!f.zf) goto L_900E9FF;
    goto L_900E9A1;
L_900E9A1:
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), ecx, &f);
    if (f.zf) goto L_900E9FF;
    goto L_900E9A9;
L_900E9A9:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x11Cu)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xE8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x188u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x194u)));
    edx = (uint32_t)(dec32(edx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900E9D2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x188u)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(edi + 0x11Cu)), &f));
    TS32((uint32_t)(edi + 0x118u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(edi + 0x4D8u), (uint32_t)(edx));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900E9FF;
    goto L_900E9F2;
L_900E9F2:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FEACu), (uint32_t)(edi));
L_900E9FF:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(dec32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), &f));
L_900EA02:
    { uint32_t v_ = 0x4AEu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900EA18u; SPILL(); f_900CF80(c); RELOAD();
    esi = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(edi + 0x330u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4B0u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900EA30u; SPILL(); f_900D070(c); RELOAD();
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4B3u);
    ecx = (uint32_t)((uint32_t)0x9037428u);
    esp -= 4; M32(esp) = 0x900EA40u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900E6B0;
    goto L_900EA4B;
L_900EA4B:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
L_900EA50:
    edi = (uint32_t)(TL32((uint32_t)(edi + 0xE4u)));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_900E8B0;
    goto L_900EA5E;
L_900EA5E:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4BDu);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900EA72u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EB64;
    goto L_900EA7F;
L_900EA7F:
    { uint32_t v_ = 0x4C4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    esp -= 4; M32(esp) = 0x900EA93u; SPILL(); f_900CE90(c); RELOAD();
    edi = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900EB4D;
    goto L_900EAA4;
L_900EAA4:
    (void)logic32((uint32_t)(TL32((uint32_t)(edi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900EB4D;
    goto L_900EAB1;
L_900EAB1:
    { uint32_t v_ = 0x4C8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x330u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900EAC8u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EB4D;
    goto L_900EACF;
L_900EACF:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4CBu);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900EAE3u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EDDB;
    goto L_900EAF3;
L_900EAF3:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1D0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (!f.zf) goto L_900EB40;
    goto L_900EAFD;
L_900EAFD:
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), ecx, &f);
    if (!f.zf) goto L_900EB40;
    goto L_900EB05;
L_900EB05:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EB1D;
    goto L_900EB0F;
L_900EB0F:
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900EB19u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_900EB40;
    goto L_900EB1D;
L_900EB1D:
    (void)sub32(TL32((uint32_t)(edi + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EB40;
    goto L_900EB26;
L_900EB26:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x1A0u)));
    eax = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900EB35u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EB40;
    goto L_900EB39;
L_900EB39:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x1u);
L_900EB40:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4D1u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    goto L_900EB5C;
L_900EB4D:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4DBu);
    ecx = (uint32_t)((uint32_t)0x9037358u);
L_900EB5C:
    esp -= 4; M32(esp) = 0x900EB61u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900EB64:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EDC3;
    goto L_900EB6E;
L_900EB6E:
    edi = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    { uint32_t v_ = 0x4E5u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037358u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028698u);
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0x81u);
    esp -= 4; M32(esp) = 0x900EB8Fu; SPILL(); f_900CE90(c); RELOAD();
    esi = (uint32_t)(TL32((uint32_t)(0x903FEACu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900EBA3;
    goto L_900EB9C;
L_900EB9C:
    ebx = (uint32_t)((uint32_t)0x81u);
    goto L_900EC21;
L_900EBA3:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900EBB4;
    goto L_900EBAD;
L_900EBAD:
    ebx = (uint32_t)((uint32_t)0x81u);
    goto L_900EC21;
L_900EBB4:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1D0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EBC5;
    goto L_900EBBE;
L_900EBBE:
    ebx = (uint32_t)((uint32_t)0x81u);
    goto L_900EC21;
L_900EBC5:
    (void)sub32(TL32((uint32_t)(esi + 0x164u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900EBD5;
    goto L_900EBCE;
L_900EBCE:
    ebx = (uint32_t)((uint32_t)0x81u);
    goto L_900EC21;
L_900EBD5:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EBF5;
    goto L_900EBDF;
L_900EBDF:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900EBEAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_900EBF5;
    goto L_900EBEE;
L_900EBEE:
    ebx = (uint32_t)((uint32_t)0x81u);
    goto L_900EC21;
L_900EBF5:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1FCu)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    (void)sub32(edx, eax, &f);
    if (f.cf) goto L_900EC0C;
    goto L_900EC05;
L_900EC05:
    ebx = (uint32_t)((uint32_t)0x80u);
    goto L_900EC21;
L_900EC0C:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1FCu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    ebx = (uint32_t)(eax);
L_900EC21:
    esi = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_900ECD5;
    goto L_900EC2F;
L_900EC2F:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900EC40;
    goto L_900EC39;
L_900EC39:
    eax = (uint32_t)((uint32_t)0x81u);
    goto L_900ECAB;
L_900EC40:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1D0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EC51;
    goto L_900EC4A;
L_900EC4A:
    eax = (uint32_t)((uint32_t)0x81u);
    goto L_900ECAB;
L_900EC51:
    (void)sub32(TL32((uint32_t)(esi + 0x164u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900EC61;
    goto L_900EC5A;
L_900EC5A:
    eax = (uint32_t)((uint32_t)0x81u);
    goto L_900ECAB;
L_900EC61:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EC81;
    goto L_900EC6B;
L_900EC6B:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900EC76u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_900EC81;
    goto L_900EC7A;
L_900EC7A:
    eax = (uint32_t)((uint32_t)0x81u);
    goto L_900ECAB;
L_900EC81:
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1FCu)));
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_900EC98;
    goto L_900EC91;
L_900EC91:
    eax = (uint32_t)((uint32_t)0x80u);
    goto L_900ECAB;
L_900EC98:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1FCu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x1F8u)));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x7u, &f));
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
L_900ECAB:
    (void)sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if ((f.sf == f.of)) goto L_900ECC7;
    goto L_900ECB0;
L_900ECB0:
    (void)logic32((uint32_t)(TL32((uint32_t)(esi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900ECC7;
    goto L_900ECB9;
L_900ECB9:
    (void)sub32(TL32((uint32_t)(esi + 0x118u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900ECC7;
    goto L_900ECC2;
L_900ECC2:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    edi = (uint32_t)(esi);
L_900ECC7:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0xE4u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900EC2F;
    goto L_900ECD5;
L_900ECD5:
    (void)sub32(ebx, (uint32_t)0x66u, &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    if ((f.zf || f.sf != f.of)) goto L_900ECE2;
    goto L_900ECDD;
L_900ECDD:
    (void)sub32(eax, (uint32_t)0x19u, &f);
    if ((f.sf != f.of)) goto L_900ECF5;
    goto L_900ECE2;
L_900ECE2:
    (void)sub32(ebx, (uint32_t)0x79u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900ECEC;
    goto L_900ECE7;
L_900ECE7:
    (void)sub32(eax, (uint32_t)0x40u, &f);
    if ((f.sf != f.of)) goto L_900ECF5;
    goto L_900ECEC;
L_900ECEC:
    (void)sub32(eax, (uint32_t)0xCu, &f);
    if ((f.sf == f.of)) goto L_900EDAC;
    goto L_900ECF5;
L_900ECF5:
    TS32((uint32_t)(0x903FEACu), (uint32_t)(edi));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_900EDAC;
    goto L_900ED03;
L_900ED03:
    (void)logic32((uint32_t)(TL32((uint32_t)(edi + 0x20u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900EDAC;
    goto L_900ED10;
L_900ED10:
    { uint32_t v_ = 0x500u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(edi + 0x330u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900ED27u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EDAC;
    goto L_900ED2E;
L_900ED2E:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x503u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
    esp -= 4; M32(esp) = 0x900ED42u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edi + 0x118u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EDF9;
    goto L_900ED52;
L_900ED52:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x1D0u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (!f.zf) goto L_900ED9F;
    goto L_900ED5C;
L_900ED5C:
    (void)sub32(TL32((uint32_t)(edi + 0x164u)), edx, &f);
    if (!f.zf) goto L_900ED9F;
    goto L_900ED64;
L_900ED64:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x1A8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900ED7C;
    goto L_900ED6E;
L_900ED6E:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900ED78u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x1u), &f);
    if (!f.zf) goto L_900ED9F;
    goto L_900ED7C;
L_900ED7C:
    (void)sub32(TL32((uint32_t)(edi + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900ED9F;
    goto L_900ED85;
L_900ED85:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x1A0u)));
    edx = (uint32_t)((uint32_t)(edi + 0x190u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900ED94u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900ED9F;
    goto L_900ED98;
L_900ED98:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x1u);
L_900ED9F:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x508u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    goto L_900EDBB;
L_900EDAC:
    { uint32_t v_ = 0x9028698u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x513u);
    ecx = (uint32_t)((uint32_t)0x9037358u);
L_900EDBB:
    esp -= 4; M32(esp) = 0x900EDC0u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900EDC3:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFF8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EDCF;
    goto L_900EDC9;
L_900EDC9:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFFCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900EE17;
    goto L_900EDCF;
L_900EDCF:
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)((uint32_t)0x0u);
    goto L_900E6B0;
L_900EDDB:
    edi = (uint32_t)(add32(edi, (uint32_t)0x330u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x4D5u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900EDF1u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_900E6B0;
L_900EDF9:
    edi = (uint32_t)(add32(edi, (uint32_t)0x330u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x50Cu);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900EE0Fu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    goto L_900E6B0;
L_900EE17:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FEB0u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900E650;
    goto L_900EE25;
L_900EE25:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900E64F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900E64F:
    { jt_ = TL32((uint32_t)(ecx + 0x9036AECu)); goto L_dispatch; }
L_dispatch:
    switch (jt_) { case 0x900E64Fu: goto L_900E64F; default: SPILL(); rt_call(c, jt_); return; }
}

void f_900EE40(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900EE40:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x526u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    edi = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x900EE58u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EE74;
    goto L_900EE64;
L_900EE64:
    edi = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FEA8u), (uint32_t)(add32(TL32((uint32_t)(0x903FEA8u)), edi, &f)));
    goto L_900EF3E;
L_900EE74:
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x4000u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x9028417u);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEB0u), (uint32_t)(edi));
    TS32((uint32_t)(0x9028444u), (uint32_t)(ecx));
    { uint32_t t_ = TL32((uint32_t)(0x9031044u)); esp -= 4; M32(esp) = 0x900EE96u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    TS32((uint32_t)(edx), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900EF3E;
    goto L_900EEAC;
L_900EEAC:
    { uint32_t v_ = 0x90374BCu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8000u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x900E620u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028720u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900EEC6u; SPILL(); f_9027170(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900EF1F;
    goto L_900EECA;
L_900EECA:
    edi = (uint32_t)((uint32_t)0x1u);
    TS32((uint32_t)(0x903FEA8u), (uint32_t)(add32(TL32((uint32_t)(0x903FEA8u)), edi, &f)));
    TS32((uint32_t)(0x903FEA4u), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x900EEE0u; SPILL(); f_90011C0(c); RELOAD();
    edx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)0x2u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = TL32((uint32_t)(0x9033028u)); eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    eax = (uint32_t)((uint32_t)0x9028720u);
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(edx + 0x9036AA0u)));
    esp -= 4; M32(esp) = 0x900EEFEu; SPILL(); f_9027400(c); RELOAD();
    esi = (uint32_t)(TL32((uint32_t)(0x902881Cu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x34u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x900EF11u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(add32(eax, edi, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031040u)); esp -= 4; M32(esp) = 0x900EF1Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_900EF3E;
L_900EF1F:
    eax = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900EF3E;
    goto L_900EF29;
L_900EF29:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x900EF32u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_900EF3E:
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x54Au);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x900EF52u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900EF60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900EF60:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x551u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x900EF75u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900F01F;
    goto L_900EF85;
L_900EF85:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(0x903FEB0u), (uint32_t)((uint32_t)0x1u));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x4u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x900EFA2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(0x902881Cu)));
    (void)sub32(TL32((uint32_t)(eax + 0x40u)), (uint32_t)0x0u, &f);
    esi = (uint32_t)((uint32_t)(eax + 0x40u));
    if (!f.zf) goto L_900EFCB;
    goto L_900EFB0;
L_900EFB0:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x34u)));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031054u)); esp -= 4; M32(esp) = 0x900EFBCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900EFC6;
    goto L_900EFC0;
L_900EFC0:
    TS32((uint32_t)(esi), (uint32_t)((uint32_t)0x80000000u));
L_900EFC6:
    eax = (uint32_t)(TL32((uint32_t)(0x902881Cu)));
L_900EFCB:
    ecx = (uint32_t)((uint32_t)(eax + 0x3Cu));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)0x3u);
    esi = (uint32_t)(ecx);
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t exp_ = (uint32_t)eax; __atomic_compare_exchange_n((uint32_t *)(MEM + (uint32_t)(esi)), &exp_, (uint32_t)edx, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); (void)sub32((uint32_t)eax, exp_, &f); if (!f.zf) { eax = (uint32_t)(exp_); } }
    (void)sub32(TL32((uint32_t)(ecx)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900EFEB;
    goto L_900EFE6;
L_900EFE6:
    esp -= 4; M32(esp) = 0x900EFEBu; SPILL(); f_90274F0(c); RELOAD();
L_900EFEB:
    eax = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    (void)sub32(TL32((uint32_t)(eax)), (uint32_t)0xFFFFFFFFu, &f);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    if (f.zf) goto L_900F00B;
    goto L_900EFF6;
L_900EFF6:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310E4u)); esp -= 4; M32(esp) = 0x900EFFFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_900F00B:
    TS32((uint32_t)(0x903FEA8u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(0x903FEA4u), (uint32_t)((uint32_t)0x0u));
L_900F01F:
    { uint32_t v_ = 0x9028498u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x561u);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x900F033u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900F040(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F040:
    eax = (uint32_t)(TL32((uint32_t)(0x903FEA4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900F05C;
    goto L_900F049;
L_900F049:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028444u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x900F05Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900F05C:
    esp += 4; SPILL(); return;
}

void f_900F060(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F060:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax + 0xFFFFFE90u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900F08C;
    goto L_900F072;
L_900F072:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x57Bu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(eax + 0x1A0u));
    esp -= 4; M32(esp) = 0x900F088u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_900F08C:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900F090(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F090:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax + 0xFFFFFE90u)) & (uint32_t)0x8000000u), &f);
    if (f.zf) goto L_900F0AB;
    goto L_900F0A2;
L_900F0A2:
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
L_900F0AB:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x584u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(eax + 0x1A0u));
    esp -= 4; M32(esp) = 0x900F0C3u; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900F0D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F0D0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax + 0xFFFFFE90u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900F0FA;
    goto L_900F0E2;
L_900F0E2:
    eax = (uint32_t)(add32(eax, (uint32_t)0x1A0u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x58Du);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900F0F7u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900F0FA:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900F100(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F100:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(eax + 0xFFFFFE90u)) & (uint32_t)0x8000000u), &f);
    if (!f.zf) goto L_900F145;
    goto L_900F112;
L_900F112:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x596u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)(eax + 0x1A0u));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F12Au; SPILL(); f_900CF80(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900F144;
    goto L_900F131;
L_900F131:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x597u);
    ecx = (uint32_t)((uint32_t)0x90374ECu);
    esp -= 4; M32(esp) = 0x900F141u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_900F144:
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_900F145:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_900F150(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F150:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(edi + 0xFFFFFFF0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.zf || f.sf != f.of)) goto L_900F1F2;
    goto L_900F168;
L_900F168:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    esi = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x900F183u; SPILL(); f_90159C0(c); RELOAD();
    esi = (uint32_t)(sub32(esi, eax, &f));
    esi = (uint32_t)(add32(esi, M32((uint32_t)(ebp + 0x10u)), &f));
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    TS32((uint32_t)(edi + 0xFFFFFFF4u), (uint32_t)(add32(TL32((uint32_t)(edi + 0xFFFFFFF4u)), esi, &f)));
    (void)sub32(TL32((uint32_t)(edi + 0xFFFFFFF4u)), (uint32_t)0x0u, &f);
    if ((f.zf || f.sf != f.of)) goto L_900F1F2;
    goto L_900F195;
L_900F195:
    edi = (uint32_t)(TL32((uint32_t)(0x9031050u)));
    ebx = (uint32_t)(TL32((uint32_t)(0x9031040u)));
L_900F1A1:
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900F1A3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9031068u)); esp -= 4; M32(esp) = 0x900F1AAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(eax);
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900F1B0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900F1B3u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x90310B4u)); esp -= 4; M32(esp) = 0x900F1BBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)sub32(esi, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_900F1C9;
    goto L_900F1C3;
L_900F1C3:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900F1C6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ebx; esp -= 4; M32(esp) = 0x900F1C9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900F1C9:
    esp -= 4; M32(esp) = 0x900F1CEu; SPILL(); f_90159C0(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sub32(ecx, M32((uint32_t)(esp + 0xCu)), &f));
    (void)sub32(ecx, TL32((uint32_t)(edx + 0xFFFFFFF4u)), &f);
    if ((f.sf != f.of)) goto L_900F1A1;
    goto L_900F1DC;
L_900F1DC:
    edx = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(sub32(edx, eax, &f));
    TS32((uint32_t)(ecx + 0xFFFFFFF4u), (uint32_t)(add32(TL32((uint32_t)(ecx + 0xFFFFFFF4u)), edx, &f)));
    (void)sub32(TL32((uint32_t)(ecx + 0xFFFFFFF4u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(eax);
    if ((!f.zf && f.sf == f.of)) goto L_900F1A1;
    goto L_900F1F2;
L_900F1F2:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 16; SPILL(); return;
}

void f_900F200(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F200:
    { SPILL(); f_90159C0(c); return; }
}

void f_900F210(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F210:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(ecx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900F230(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F230:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(ecx, edx, &f);
    if (f.zf) goto L_900F2E9;
    goto L_900F240;
L_900F240:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(eax, edx, &f);
    if (f.zf) goto L_900F2E9;
    goto L_900F24B;
L_900F24B:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(eax + 0x14u), (uint32_t)(edx));
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x168u)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x7u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF8u), &f));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x16Cu)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x7u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF8u), &f));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x168u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(add32(esi, edi, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x7u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF8u), &f));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(ecx + 0x16Cu)));
    esi = (uint32_t)(add32(esi, edi, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x7u, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF8u), &f));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(esi));
    esi = (uint32_t)((uint32_t)(eax + 0x18u));
    TS32((uint32_t)(esi), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0x24u), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0x30u), (uint32_t)(edi));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x14u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & edi), &f));
    TS32((uint32_t)(eax + 0x3Cu), (uint32_t)(ebx));
    TS32((uint32_t)(eax + 0x1Cu), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x28u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x34u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x40u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x20u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x2Cu), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x38u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x44u), (uint32_t)(edx));
    (void)sub32(TL32((uint32_t)(ecx + 0x8u)), edi, &f);
    if (!f.zf) goto L_900F2D6;
    goto L_900F2CD;
L_900F2CD:
    TS32((uint32_t)(eax), (uint32_t)(edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
L_900F2D6:
    edi = (uint32_t)((uint32_t)(eax + 0x48u));
    ecx = (uint32_t)((uint32_t)0xCu);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0x2u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
L_900F2E9:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900F2F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F2F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900F307;
    goto L_900F2FA;
L_900F2FA:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900F307;
    goto L_900F301;
L_900F301:
    TS32((uint32_t)(ecx + 0xD0u), (uint32_t)(eax));
L_900F307:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_900F310(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900F310:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    esp = (uint32_t)(sub32(esp, (uint32_t)0x78Cu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ esp), &f));
    M32((uint32_t)(esp + 0x788u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(esp + 0x60u));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(esp + 0x70Cu));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x60u)) = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)(esp + 0x68Cu));
    M32((uint32_t)(esp + 0x65Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x660u)) = (uint32_t)(eax);
    eax = (uint32_t)(ecx);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)((uint32_t)0x1u);
    edi = (uint32_t)((uint32_t)0x90166B0u);
    M32((uint32_t)(esp + 0x650u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x658u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x654u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x65Cu)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x668u)) = (uint32_t)((uint32_t)0x20u);
    (void)logic32((uint32_t)(ebx & (uint32_t)0x4000u), &f);
    if (f.zf) goto L_900F3B7;
    goto L_900F3A9;
L_900F3A9:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(edx);
L_900F3B7:
    { uint32_t v_ = 0x4F0u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x164u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F3CBu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    esp -= 4; M32(esp) = 0x900F3D3u; SPILL(); f_90159C0(c); RELOAD();
    M32((uint32_t)(esp + 0x5FCu)) = (uint32_t)(eax);
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x4000000u), &f));
    TS8((uint32_t)(0x9028598u), (uint8_t)((uint8_t)0x0u));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    if (f.zf) goto L_900F402;
    goto L_900F3EE;
L_900F3EE:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)((uint32_t)0xBu);
    edi = (uint32_t)((uint32_t)(esp + 0x38u));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    goto L_900F513;
L_900F402:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x2000000u), &f);
    if (f.zf) goto L_900F413;
    goto L_900F40A;
L_900F40A:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900F413;
    goto L_900F411;
L_900F411:
    edi = (uint32_t)(eax);
L_900F413:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_900F438;
    goto L_900F417;
L_900F417:
    { uint32_t v_ = 0x903751Cu; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F421u; SPILL(); f_900D100(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x788u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x900F434u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900F438:
    { uint32_t v_ = 0x120u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x2F4u));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F44Cu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    M32((uint32_t)(esp + 0x324u)) = (uint32_t)((uint32_t)0x900F200u);
    M32((uint32_t)(esp + 0x32Cu)) = (uint32_t)((uint32_t)0x900F210u);
    esp -= 4; M32(esp) = 0x900F46Au; SPILL(); f_900D230(c); RELOAD();
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x20u), &f);
    if (f.zf) goto L_900F482;
    goto L_900F46F;
L_900F46F:
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    M32((uint32_t)(esp + 0x220u)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x224u)) = (uint32_t)(eax);
L_900F482:
    { uint32_t v_ = 0x6DDu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x900F496u; SPILL(); f_900CE90(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(esp + 0x2F8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edi; esp -= 4; M32(esp) = 0x900F4A9u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)0x9037504u);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900F4EE;
    goto L_900F4B3;
L_900F4B3:
    edx = (uint32_t)((uint32_t)0x6EBu);
    esp -= 4; M32(esp) = 0x900F4BDu; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)sub8(TL8((uint32_t)(0x9028598u)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901066C;
    goto L_900F4CD;
L_900F4CD:
    { uint32_t v_ = 0x903753Cu; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F4D7u; SPILL(); f_900D100(c); RELOAD();
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x788u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x900F4EAu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_900F4EE:
    edx = (uint32_t)((uint32_t)0x6F4u);
    esp -= 4; M32(esp) = 0x900F4F8u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    { uint32_t v_ = 0x2Cu; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x3Cu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esp + 0x2FCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = M32((uint32_t)(esp + 0x300u)); esp -= 4; M32(esp) = 0x900F513u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900F513:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(eax, (uint32_t)0x664B4942u, &f);
    if (f.zf) goto L_900F533;
    goto L_900F51E;
L_900F51E:
    (void)sub32(eax, (uint32_t)0x674B4942u, &f);
    if (f.zf) goto L_900F533;
    goto L_900F525;
L_900F525:
    (void)sub32(eax, (uint32_t)0x684B4942u, &f);
    if (f.zf) goto L_900F533;
    goto L_900F52C;
L_900F52C:
    (void)sub32(eax, (uint32_t)0x694B4942u, &f);
    if (!f.zf) goto L_900F53E;
    goto L_900F533;
L_900F533:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x330u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_900F548;
    goto L_900F53E;
L_900F53E:
    { uint32_t v_ = 0x9037550u; esp -= 4; M32(esp) = v_; }
    goto L_9010626;
L_900F548:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900F55A;
    goto L_900F550;
L_900F550:
    { uint32_t v_ = 0x9037564u; esp -= 4; M32(esp) = v_; }
    goto L_9010626;
L_900F55A:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    (void)sub32(ecx, eax, &f);
    if (f.cf) goto L_9010621;
    goto L_900F566;
L_900F566:
    (void)sub32(ecx, (uint32_t)0xF4240u, &f);
    if ((!f.cf && !f.zf)) goto L_9010621;
    goto L_900F572;
L_900F572:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    (void)sub32(M32((uint32_t)(esp + 0x44u)), eax, &f);
    if ((!f.cf && !f.zf)) goto L_9010621;
    goto L_900F580;
L_900F580:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    (void)sub32(edx, (uint32_t)0x100u, &f);
    if ((!f.cf && !f.zf)) goto L_9010621;
    goto L_900F590;
L_900F590:
    edx = (uint32_t)(inc32(edx, &f));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    (void)sub32(eax, edx, &f);
    if (f.cf) goto L_9010621;
    goto L_900F5A0;
L_900F5A0:
    edi = (uint32_t)(M32((uint32_t)(esp + 0x4Cu)));
    (void)sub32(edi, (uint32_t)0x7FFFu, &f);
    if ((!f.cf && !f.zf)) goto L_9010621;
    goto L_900F5B0;
L_900F5B0:
    ebx = (uint32_t)(M32((uint32_t)(esp + 0x50u)));
    (void)sub32(ebx, (uint32_t)0x7FFFu, &f);
    if ((!f.cf && !f.zf)) goto L_901061E;
    goto L_900F5C0;
L_900F5C0:
    (void)sub32(M32((uint32_t)(esp + 0x54u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901061E;
    goto L_900F5CB;
L_900F5CB:
    (void)sub32(M32((uint32_t)(esp + 0x58u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901061E;
    goto L_900F5D6;
L_900F5D6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5Cu)));
    M32((uint32_t)(esp + 0x63Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x20000u), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | M32((uint32_t)(ebp + 0xCu))), &f));
    esi = (uint32_t)((uint32_t)(edi + 0xFu));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x4u, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0xFu, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF0u), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x8FFFFFFFu), &f));
    M32((uint32_t)(esp + 0x160u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x164u)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x2C8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0x2CCu)) = (uint32_t)(ebx);
    M32((uint32_t)(esp + 0x184u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x250u)) = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x180u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(ecx & (uint32_t)0x100000u), &f);
    if (!f.zf) goto L_900F645;
    goto L_900F639;
L_900F639:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFEFFFFFu), &f));
    M32((uint32_t)(esp + 0x180u)) = (uint32_t)(eax);
L_900F645:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x70000000u), &f));
    (void)sub32(edx, (uint32_t)0x70000000u, &f);
    if (f.zf) goto L_900F6CB;
    goto L_900F656;
L_900F656:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_900F65E;
    goto L_900F65A;
L_900F65A:
    eax = (uint32_t)(logic32((uint32_t)(eax | edx), &f));
    goto L_900F666;
L_900F65E:
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x70000000u), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
L_900F666:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x70000000u), &f));
    M32((uint32_t)(esp + 0x180u)) = (uint32_t)(eax);
    (void)sub32(ecx, (uint32_t)0x30000000u, &f);
    if ((!f.cf && !f.zf)) goto L_900F6A7;
    goto L_900F67D;
L_900F67D:
    if (f.zf) goto L_900F69B;
    goto L_900F67F;
L_900F67F:
    (void)sub32(ecx, (uint32_t)0x10000000u, &f);
    if (f.zf) goto L_900F68F;
    goto L_900F687;
L_900F687:
    (void)sub32(ecx, (uint32_t)0x20000000u, &f);
    if (!f.zf) goto L_900F6CB;
    goto L_900F68F;
L_900F68F:
    ecx = (uint32_t)((uint32_t)(ebx + ebx));
    M32((uint32_t)(esp + 0x164u)) = (uint32_t)(ecx);
    goto L_900F6CB;
L_900F69B:
    edx = (uint32_t)((uint32_t)(edi + edi));
    M32((uint32_t)(esp + 0x160u)) = (uint32_t)(edx);
    goto L_900F6CB;
L_900F6A7:
    (void)sub32(ecx, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_900F6B7;
    goto L_900F6AF;
L_900F6AF:
    (void)sub32(ecx, (uint32_t)0x50000000u, &f);
    if (!f.zf) goto L_900F6CB;
    goto L_900F6B7;
L_900F6B7:
    ecx = (uint32_t)((uint32_t)(edi + edi));
    edx = (uint32_t)((uint32_t)(ebx + ebx));
    M32((uint32_t)(esp + 0x160u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x164u)) = (uint32_t)(edx);
L_900F6CB:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x38u)));
    (void)sub32(ecx, (uint32_t)0x664B4942u, &f);
    if (f.zf) goto L_900F6EE;
    goto L_900F6D7;
L_900F6D7:
    (void)sub32(ecx, (uint32_t)0x674B4942u, &f);
    if (f.zf) goto L_900F6EE;
    goto L_900F6DF;
L_900F6DF:
    (void)sub32(ecx, (uint32_t)0x684B4942u, &f);
    if (!f.zf) goto L_900F6FA;
    goto L_900F6E7;
L_900F6E7:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x8000u), &f));
    goto L_900F6F3;
L_900F6EE:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x18000u), &f));
L_900F6F3:
    M32((uint32_t)(esp + 0x180u)) = (uint32_t)(eax);
L_900F6FA:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) & (uint32_t)0x1000u), &f);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x40u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x48u)));
    M32((uint32_t)(esp + 0x168u)) = (uint32_t)(eax);
    M32((uint32_t)(esp + 0x25Cu)) = (uint32_t)(ecx);
    if (f.zf) goto L_900F731;
    goto L_900F719;
L_900F719:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900F731;
    goto L_900F725;
L_900F725:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0xCu)));
    M32((uint32_t)(esp + 0x178u)) = (uint32_t)(edx);
    goto L_900F740;
L_900F731:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    M32((uint32_t)(esp + 0x178u)) = (uint32_t)(ecx);
L_900F740:
    M32((uint32_t)(esp + 0x174u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x3Cu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x58u)));
    M32((uint32_t)(esp + 0x188u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x60u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x54u)));
    M32((uint32_t)(esp + 0x198u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x44u)));
    M32((uint32_t)(esp + 0x258u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x164u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)esi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(esp + 0x254u)) = (uint32_t)(eax);
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(esp + 0x600u)) = (uint32_t)(edx);
    edx = (uint32_t)(logic32(0, &f));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    M32((uint32_t)(esp + 0x604u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x5B0u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900F7B6;
    goto L_900F7AA;
L_900F7AA:
    eax = (uint32_t)((uint32_t)0x1u);
    M32((uint32_t)(esp + 0x5B0u)) = (uint32_t)(eax);
L_900F7B6:
    edx = (uint32_t)((uint32_t)(esp + 0x594u));
    ecx = (uint32_t)((uint32_t)(eax*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F7D1u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    eax = (uint32_t)((uint32_t)(esp + 0x598u));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F7F0u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x59Cu));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F808u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    eax = (uint32_t)((uint32_t)(esp + 0x5A0u));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F827u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x5A4u));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F83Fu; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    eax = (uint32_t)((uint32_t)(esp + 0x5A8u));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F85Eu; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x5B0u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x5ACu));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F876u; SPILL(); f_901E260(c); RELOAD();
    esi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    eax = (uint32_t)(esi);
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_900F885;
    goto L_900F880;
L_900F880:
    eax = (uint32_t)((uint32_t)0x1u);
L_900F885:
    ecx = (uint32_t)((uint32_t)(eax + eax*2));
    eax = (uint32_t)((uint32_t)(esp + 0x2B4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x7u, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F89Fu; SPILL(); f_901E260(c); RELOAD();
    edx = (uint32_t)((uint32_t)(esp + 0x24Cu));
    ecx = (uint32_t)((uint32_t)(esi*4));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F8B3u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x160u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFF0u), &f));
    eax = (uint32_t)((uint32_t)(esp + 0x290u));
    esp -= 4; M32(esp) = 0x900F8CCu; SPILL(); f_901A490(c); RELOAD();
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_900F901;
    goto L_900F8D3;
L_900F8D3:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x198u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x25Cu)));
    ecx = (uint32_t)((uint32_t)(ecx + eax*2));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x2D0u));
    ecx = (uint32_t)((uint32_t)(ecx*4 + 0x104u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900F901u; SPILL(); f_901E260(c); RELOAD();
L_900F901:
    edx = (uint32_t)((uint32_t)0x4F0u);
    esi = (uint32_t)((uint32_t)(esp + 0x160u));
    eax = (uint32_t)((uint32_t)(esp + 0x650u));
    esp -= 4; M32(esp) = 0x900F919u; SPILL(); f_900D0D0(c); RELOAD();
    ebx = (uint32_t)(eax);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_900FDCB;
    goto L_900F923;
L_900F923:
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), (uint32_t)0x0u, &f);
    ecx = (uint32_t)((uint32_t)0x13Cu);
    edi = (uint32_t)(ebx);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x438u)));
    TS32((uint32_t)(ebx + 0x1ACu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0x0u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x43Cu)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0x0u));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x440u)));
    TS32((uint32_t)(edx), (uint32_t)((uint32_t)0x0u));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x444u)));
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0x0u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x448u)));
    TS32((uint32_t)(ecx), (uint32_t)((uint32_t)0x0u));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x44Cu)));
    TS32((uint32_t)(edx), (uint32_t)((uint32_t)0x0u));
    if (f.zf) goto L_900F9F7;
    goto L_900F981;
L_900F981:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)((uint32_t)(eax + 0x2Cu));
    TS32((uint32_t)(ebx + 0x170u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x38u)));
    edx = (uint32_t)((uint32_t)(eax + ecx*4 + 0x2Cu));
    TS32((uint32_t)(ebx + 0x174u), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(eax + ecx*8 + 0x2Cu));
    ecx = (uint32_t)((uint32_t)(ecx + ecx*2));
    TS32((uint32_t)(ebx + 0x178u), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(eax + ecx*4 + 0x2Cu));
    TS32((uint32_t)(ebx + 0x158u), (uint32_t)(edx));
L_900F9B2:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x450u)));
    edi = (uint32_t)(TL32((uint32_t)(ebx + 0x158u)));
    edx = (uint32_t)((uint32_t)(ebx + 0x4D4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    eax = (uint32_t)((uint32_t)(ebx + 0xCCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F9D6u; SPILL(); f_900E560(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    TS32((uint32_t)(ebx + 0xC8u), (uint32_t)(eax));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (!f.zf) goto L_900FA8E;
    goto L_900F9E8;
L_900F9E8:
    { uint32_t v_ = 0x90375D4u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900F9F2u; SPILL(); f_900D100(c); RELOAD();
    goto L_900FDC5;
L_900F9F7:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x170u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x100u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFF80u), &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFFFFFFACu, &f));
    TS32((uint32_t)(ebx + 0x170u), (uint32_t)(eax));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x198u)));
    esi = (uint32_t)(M32((uint32_t)(esp + 0x25Cu)));
    esi = (uint32_t)((uint32_t)(esi + edx*2));
    esi = (uint32_t)(add32(esi, edx, &f));
    edx = (uint32_t)((uint32_t)(esi*4 + 0x4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x190u)));
    ecx = (uint32_t)((uint32_t)(ebx + 0x190u));
    { uint32_t v_ = 0xFFFFFFFFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900FA3Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x198u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x170u)));
    eax = (uint32_t)((uint32_t)(ecx + edx*4));
    TS32((uint32_t)(ebx + 0x174u), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x198u)));
    eax = (uint32_t)((uint32_t)(eax + ecx*4));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x1D0u)));
    TS32((uint32_t)(ebx + 0x178u), (uint32_t)(eax));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x198u)));
    eax = (uint32_t)((uint32_t)(eax + edx*4));
    TS32((uint32_t)(ebx + 0x158u), (uint32_t)(eax));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900F9B2;
    goto L_900FA7F;
L_900FA7F:
    { uint32_t v_ = 0x90375B8u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FA89u; SPILL(); f_900D100(c); RELOAD();
    goto L_900FDC5;
L_900FA8E:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) & (uint32_t)0x400u), &f);
    if (!f.zf) goto L_900FBE8;
    goto L_900FA9B;
L_900FA9B:
    eax = (uint32_t)((uint32_t)(esp + 0x68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FAA6u; SPILL(); f_900F230(c); RELOAD();
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x68u)), ecx, &f);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    if ((f.zf || f.sf != f.of)) goto L_900FB82;
    goto L_900FAB6;
L_900FAB6:
    esi = (uint32_t)((uint32_t)(esp + 0x84u));
    ecx = (uint32_t)((uint32_t)(ecx));
L_900FAC0:
    edi = (uint32_t)(M32((uint32_t)(esp + 0x74u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFu, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFFFFFF0u), &f));
    (void)sub32(TL32((uint32_t)(esi + 0xFFFFFFFCu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900FAF2;
    goto L_900FAD0;
L_900FAD0:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x70u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)M32((uint32_t)(esp + 0x6Cu)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900FAE6u; SPILL(); f_901E260(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x6Cu)));
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)0x1u);
L_900FAF2:
    (void)sub32(TL32((uint32_t)(esi + 0x8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900FB17;
    goto L_900FAF8;
L_900FAF8:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x78u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)edi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)((uint32_t)(esi + 0xCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900FB0Fu; SPILL(); f_901E260(c); RELOAD();
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(edi));
    ecx = (uint32_t)((uint32_t)0x1u);
L_900FB17:
    (void)sub32(TL32((uint32_t)(esi + 0x14u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900FB3C;
    goto L_900FB1D;
L_900FB1D:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x78u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)edi; ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)((uint32_t)(esi + 0x18u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900FB34u; SPILL(); f_901E260(c); RELOAD();
    TS32((uint32_t)(esi + 0x1Cu), (uint32_t)(edi));
    ecx = (uint32_t)((uint32_t)0x1u);
L_900FB3C:
    (void)sub32(TL32((uint32_t)(esi + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900FB67;
    goto L_900FB42;
L_900FB42:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x70u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)M32((uint32_t)(esp + 0x6Cu)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)((uint32_t)(esi + 0x24u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900FB5Bu; SPILL(); f_901E260(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(esp + 0x6Cu)));
    TS32((uint32_t)(esi + 0x28u), (uint32_t)(eax));
    ecx = (uint32_t)((uint32_t)0x1u);
L_900FB67:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(inc32(eax, &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x30u, &f));
    (void)sub32(eax, M32((uint32_t)(esp + 0x68u)), &f);
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    if ((f.sf != f.of)) goto L_900FAC0;
    goto L_900FB7D;
L_900FB7D:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if ((f.sf == f.of)) goto L_900FBB0;
    goto L_900FB82;
L_900FB82:
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edx = (uint32_t)((uint32_t)0x2u);
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)((uint32_t)(esp + eax + 0x9Cu));
    edx = (uint32_t)(sub32(edx, esi, &f));
    esp = (uint32_t)((uint32_t)(esp));
L_900FBA0:
    TS32((uint32_t)(eax + 0xFFFFFFF4u), (uint32_t)(edi));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    TS32((uint32_t)(eax + 0xFFFFFFE8u), (uint32_t)(edi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x30u, &f));
    edx = (uint32_t)(sub32(edx, (uint32_t)0x1u, &f));
    if (!f.zf) goto L_900FBA0;
    goto L_900FBB0;
L_900FBB0:
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_900FBE8;
    goto L_900FBB4;
L_900FBB4:
    edx = (uint32_t)((uint32_t)0x78u);
    esi = (uint32_t)(ebx);
    eax = (uint32_t)((uint32_t)(esp + 0x650u));
    esp -= 4; M32(esp) = 0x900FBC7u; SPILL(); f_900D0D0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x4E4u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900FDC5;
    goto L_900FBD5;
L_900FBD5:
    ecx = (uint32_t)((uint32_t)0x1Eu);
    esi = (uint32_t)((uint32_t)(esp + 0x68u));
    edi = (uint32_t)(eax);
    TS32((uint32_t)(ebx + 0xD0u), (uint32_t)(eax));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
L_900FBE8:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)logic32((uint32_t)(ecx & (uint32_t)0x1000000u), &f);
    if (f.zf) goto L_900FC03;
    goto L_900FBF3;
L_900FBF3:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x10u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900FC03;
    goto L_900FBFF;
L_900FBFF:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900FC09;
    goto L_900FC03;
L_900FC03:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xC8u)));
L_900FC09:
    TS32((uint32_t)(ebx + 0x458u), (uint32_t)(eax));
    (void)logic32((uint32_t)(ecx & (uint32_t)0x400000u), &f);
    if (f.zf) goto L_900FC2B;
    goto L_900FC17;
L_900FC17:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    (void)sub32(eax, (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_900FC2B;
    goto L_900FC23;
L_900FC23:
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900FC33;
    goto L_900FC2B;
L_900FC2B:
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)((uint32_t)0x0u);
L_900FC33:
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), (uint32_t)0x0u, &f);
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(ebx + 0x180u), (uint32_t)(edx));
    if (f.zf) goto L_900FC65;
    goto L_900FC44;
L_900FC44:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x158u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFFFEu), &f));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(esp + 0x14u)), &f));
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) | (uint32_t)0x8000000u), &f)));
    TS32((uint32_t)(ebx + 0x17Cu), (uint32_t)(ecx));
    goto L_900FDFA;
L_900FC65:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x458u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x198u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)(ebx + 0x190u));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x900FC7Bu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    esi = (uint32_t)(eax);
    edx = (uint32_t)((uint32_t)(esi + 0x20000u));
    TS32((uint32_t)(ebx + 0x458u), (uint32_t)(esi));
    (void)sub32(edx, ecx, &f);
    if (f.cf) goto L_900FCA0;
    goto L_900FC90;
L_900FC90:
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) | (uint32_t)0x2000u), &f));
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) | (uint32_t)0x8002000u), &f)));
    goto L_900FCBA;
L_900FCA0:
    eax = (uint32_t)((uint32_t)0xCCCCCCCDu);
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    edx = (uint32_t)(shr32(edx, (uint8_t)0x3u, &f));
    eax = (uint32_t)((uint32_t)(edx + edx*8));
    (void)sub32(esi, eax, &f);
    if (f.cf) goto L_900FCBA;
    goto L_900FCB1;
L_900FCB1:
    edx = (uint32_t)((uint32_t)(ecx + 0x10u));
    TS32((uint32_t)(ebx + 0x458u), (uint32_t)(edx));
L_900FCBA:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) & (uint32_t)0x2000u), &f);
    if (f.zf) goto L_900FD7F;
    goto L_900FCC7;
L_900FCC7:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x158u)));
    edx = (uint32_t)(TL32((uint32_t)(eax)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFFEu), &f));
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    edx = (uint32_t)((uint32_t)(ecx + 0x400u));
    esi = (uint32_t)(ebx);
    eax = (uint32_t)((uint32_t)(esp + 0x650u));
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x900FCEFu; SPILL(); f_900D0D0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x17Cu), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900FDB5;
    goto L_900FCFD;
L_900FCFD:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x19Cu)));
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) | (uint32_t)0x8000000u), &f)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x8u, &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900FD1Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x158u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x17Cu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(edx)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x194u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x900FD40u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x831u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x900FD54u; SPILL(); f_900CE90(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x1A4u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900FD60u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x837u);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x900FD70u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebx + 0x1E4u), (uint32_t)((uint32_t)0x0u));
    goto L_900FDFA;
L_900FD7F:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xF8u)));
    eax = (uint32_t)((uint32_t)(ebx + 0x4E0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x500u, &f));
    eax = (uint32_t)((uint32_t)(esp + 0x654u));
    esp -= 4; M32(esp) = 0x900FD9Eu; SPILL(); f_901E260(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x458u)));
    esi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x900FDABu; SPILL(); f_900D0D0(c); RELOAD();
    TS32((uint32_t)(ebx + 0x430u), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900FDDD;
    goto L_900FDB5;
L_900FDB5:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xD0u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_900FDC5;
    goto L_900FDBF;
L_900FDBF:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FDC5u; SPILL(); f_9001100(c); RELOAD();
L_900FDC5:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FDCBu; SPILL(); f_9001100(c); RELOAD();
L_900FDCB:
    { uint32_t v_ = 0x9037164u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FDD5u; SPILL(); f_900D100(c); RELOAD();
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    goto L_901062B;
L_900FDDD:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x458u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x19Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x900FDFAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_900FDFA:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x14u)));
    esi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebx + 0xCu), (uint32_t)((uint32_t)0xFFFFFFFFu));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_900FE2E;
    goto L_900FE0A;
L_900FE0A:
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x18u)));
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)0x7D0u);
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    TS32((uint32_t)(ebx + 0x47Cu), (uint32_t)(eax));
    goto L_900FE38;
L_900FE2E:
    TS32((uint32_t)(ebx + 0x47Cu), (uint32_t)((uint32_t)0x7D0u));
L_900FE38:
    TS32((uint32_t)(ebx + 0x114u), (uint32_t)((uint32_t)0x1u));
    esp -= 4; M32(esp) = 0x900FE47u; SPILL(); f_90159C0(c); RELOAD();
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebx + 0x49Cu)), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(ebx + 0x49Cu), (uint32_t)(eax));
    TS32((uint32_t)(ecx + 0x3Cu), (uint32_t)((uint32_t)0x10000u));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(esi);
    TS32((uint32_t)(ebx + 0x124u), (uint32_t)(esi));
    (void)sub32(TL32((uint32_t)(ebx + 0x38u)), esi, &f);
    if (f.zf) goto L_900FF7A;
    goto L_900FE73;
L_900FE73:
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    (void)sub32(edi, esi, &f);
    if (f.zf) goto L_900FF7A;
    goto L_900FE7F;
L_900FE7F:
    ecx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    (void)sub32(edi, esi, &f);
    if ((f.cf || f.zf)) goto L_900FF7A;
    goto L_900FE8D;
L_900FE8D:
    ecx = (uint32_t)((uint32_t)(ecx));
L_900FE90:
    esi = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(ebx + 0x38u)), esi, &f);
    if ((f.zf || f.sf != f.of)) goto L_900FF40;
    goto L_900FE9B;
L_900FE9B:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + ecx*4)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x178u)));
L_900FEA8:
    (void)sub32(TL32((uint32_t)(eax)), edx, &f);
    if (f.zf) goto L_900FEBA;
    goto L_900FEAC;
L_900FEAC:
    esi = (uint32_t)(inc32(esi, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    (void)sub32(esi, TL32((uint32_t)(ebx + 0x38u)), &f);
    if ((f.sf != f.of)) goto L_900FEA8;
    goto L_900FEB5;
L_900FEB5:
    goto L_900FF40;
L_900FEBA:
    edi = (uint32_t)(TL32((uint32_t)(ebx + 0x124u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xECu)));
    eax = (uint32_t)((uint32_t)(edi + 0x1u));
    TS32((uint32_t)(ebx + 0x124u), (uint32_t)(eax));
    TS32((uint32_t)(ecx + edi*4), (uint32_t)(esi));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x174u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + esi*4)));
    eax = (uint32_t)((uint32_t)(edx + esi*4));
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.sf) goto L_900FEF1;
    goto L_900FEE2;
L_900FEE2:
    (void)logic32((uint32_t)(ecx & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_900FEF1;
    goto L_900FEEA;
L_900FEEA:
    ecx = (uint32_t)((uint32_t)0x1u);
    goto L_900FEF3;
L_900FEF1:
    ecx = (uint32_t)(logic32(0, &f));
L_900FEF3:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1Du, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    eax = (uint32_t)(((uint16_t)eax));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x900FF08u; SPILL(); f_9018800(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x170u)));
    esi = (uint32_t)(TL32((uint32_t)(edx + esi*4)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)((uint32_t)(esi + esi*4));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    M32((uint32_t)(esp + edi*4 + 0xE0u)) = (uint32_t)(eax);
    edi = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    eax = (uint32_t)((uint32_t)(edx + ecx + 0x10u));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x14u)) = (uint32_t)(eax);
L_900FF40:
    ecx = (uint32_t)(inc32(ecx, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ecx);
    (void)sub32(ecx, edi, &f);
    if (f.cf) goto L_900FE90;
    goto L_900FF4D;
L_900FF4D:
    (void)sub32(M32((uint32_t)(esp + 0x14u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_900FF7A;
    goto L_900FF54;
L_900FF54:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    esi = (uint32_t)(ebx);
    eax = (uint32_t)((uint32_t)(esp + 0x650u));
    esp -= 4; M32(esp) = 0x900FF66u; SPILL(); f_900D0D0(c); RELOAD();
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(eax);
    TS32((uint32_t)(ebx + 0x15Cu), (uint32_t)(eax));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_900FF7A;
    goto L_900FF74;
L_900FF74:
    TS32((uint32_t)(ebx + 0x124u), (uint32_t)(eax));
L_900FF7A:
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FE1Cu), (uint32_t)((uint32_t)0x1u));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), eax, &f);
    if ((f.cf || f.zf)) goto L_9010357;
    goto L_900FF9B;
L_900FF9B:
    edi = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)((uint32_t)(ecx));
L_900FFA0:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(edi + ecx + 0xCu), (uint32_t)((uint32_t)0x0u));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0xECu)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + eax*4)));
    eax = (uint32_t)((uint32_t)(edx + eax*4));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x174u)));
    ecx = (uint32_t)(TL32((uint32_t)(edx + ecx*4)));
    (void)logic32((uint32_t)(ecx & (uint32_t)0x90000000u), &f);
    if (f.zf) goto L_90102ED;
    goto L_900FFD3;
L_900FFD3:
    (void)sub32(TL32((uint32_t)(0x903FDF0u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90102ED;
    goto L_900FFE0;
L_900FFE0:
    esi = (uint32_t)(((uint16_t)ecx));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(esi);
    (void)sub32(esi, (uint32_t)0x3E800u, &f);
    if ((!f.cf && !f.zf)) goto L_90102ED;
    goto L_900FFF3;
L_900FFF3:
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x170u)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)(TL32((uint32_t)(eax + ecx)));
    eax = (uint32_t)(TL32((uint32_t)(eax + edx)));
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Du, &f));
    ecx = (uint32_t)((uint32_t)(ecx + ecx*4));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1Bu, &f));
    eax = (uint32_t)(inc32(eax, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFu, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x8u), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    (void)sub32(M32((uint32_t)(esp + 0x174u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(esp + 0x18u)) = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(ecx);
    M32((uint32_t)(esp + 0x1Cu)) = (uint32_t)(edx);
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    if (f.zf) goto L_9010097;
    goto L_9010045;
L_9010045:
    (void)sub32(M32((uint32_t)(esp + 0x178u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010097;
    goto L_901004F;
L_901004F:
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x20u)));
    M16((uint32_t)(esp + 0x14u)) = c->fpu_cw;
    ST(0) = ST(0) * (double)(int32_t)M32((uint32_t)(esp + 0x604u));
    eax = (uint32_t)(M16((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xC00u), &f));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    ST(0) = ST(0) * (double)(int32_t)M32((uint32_t)(esp + 0x174u));
    fpush(c, (double)(int32_t)M32((uint32_t)(esp + 0x600u)));
    ST(0) = ST(0) * (double)(int32_t)M32((uint32_t)(esp + 0x178u));
    ST(1) = ST(1) / ST(0); fpop(c);
    c->fpu_cw = M16((uint32_t)(esp + 0x28u));
    M64((uint32_t)(esp + 0x28u)) = (uint64_t)fist64(c, ST(0)); fpop(c);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(eax);
    c->fpu_cw = M16((uint32_t)(esp + 0x14u));
L_9010097:
    (void)sub32(eax, (uint32_t)0x3E800u, &f);
    if ((f.cf || f.zf)) goto L_90100A6;
    goto L_901009E;
L_901009E:
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)((uint32_t)0x3E800u);
L_90100A6:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)esi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x3u, &f));
    (void)sub32(ecx, eax, &f);
    if ((!f.cf && !f.zf)) goto L_90102ED;
    goto L_90100BD;
L_90100BD:
    { uint32_t v_ = 0x8BAu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    esp -= 4; M32(esp) = 0x90100D1u; SPILL(); f_900CE90(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, edi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903FDF0u)); esp -= 4; M32(esp) = 0x90100F7u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x8C2u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esi = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x901010Du; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_90102ED;
    goto L_9010118;
L_9010118:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    TS32((uint32_t)(edi + eax + 0x1Cu), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    (void)sub32(TL32((uint32_t)(edi + edx + 0x30u)), (uint32_t)0x0u, &f);
    eax = (uint32_t)((uint32_t)(edi + edx + 0x30u));
    if (!f.zf) goto L_901013D;
    goto L_9010137;
L_9010137:
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0xFFFFFFFFu));
L_901013D:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x10u, &f));
    TS32((uint32_t)(edi + ecx + 0x8u), (uint32_t)(eax));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(edi + edx + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(eax + edi + 0x8u)), &f));
    eax = (uint32_t)(add32(eax, edi, &f));
    M32((uint32_t)(esp + 0x24u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)0x2EEu);
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(eax + 0x38u)), &f));
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)(ecx);
    if (!f.sf) goto L_9010182;
    goto L_901017A;
L_901017A:
    M32((uint32_t)(esp + 0x20u)) = (uint32_t)((uint32_t)0x0u);
L_9010182:
    edx = (uint32_t)(logic32(0, &f));
    (void)sub32(M32((uint32_t)(esp + 0x1Cu)), (uint32_t)0x8u, &f);
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(f.zf);
    TS32((uint32_t)(eax + 0x54u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + edi + 0xCu)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(eax + edi + 0x8u)), &f));
    eax = (uint32_t)(add32(eax, edi, &f));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + edx + 0xCu)));
    eax = (uint32_t)((uint32_t)(edi + edx));
    TS32((uint32_t)(eax), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + edx + 0xCu)));
    eax = (uint32_t)((uint32_t)(edi + edx));
    TS32((uint32_t)(eax + 0x18u), (uint32_t)(ecx));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x28u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(esp + 0x18u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, eax, &f));
    M32((uint32_t)(esp + 0x34u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x20u)));
    { uint64_t r_ = (uint64_t)eax * ecx; eax = (uint32_t)r_; edx = (uint32_t)(r_ >> 32); f.cf = f.of = edx != 0; }
    ecx = (uint32_t)((uint32_t)0x3E8u);
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFCu), &f));
    TS32((uint32_t)(edi + edx + 0x48u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + edi + 0x8u)));
    eax = (uint32_t)(add32(eax, edi, &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(eax + 0x48u)), &f));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if ((f.sf == f.of)) goto L_901020A;
    goto L_9010204;
L_9010204:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0xFFFFFFF0u, &f));
    TS32((uint32_t)(eax + 0x48u), (uint32_t)(ecx));
L_901020A:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0xECu)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(eax + ecx*4)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x174u)));
    eax = (uint32_t)(TL32((uint32_t)(eax + edx*4)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.sf) goto L_9010232;
    goto L_9010224;
L_9010224:
    (void)logic32((uint32_t)(eax & (uint32_t)0x10000000u), &f);
    if (f.zf) goto L_9010232;
    goto L_901022B;
L_901022B:
    ecx = (uint32_t)((uint32_t)0x1u);
    goto L_9010234;
L_9010232:
    ecx = (uint32_t)(logic32(0, &f));
L_9010234:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x24u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x1Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(((uint16_t)eax));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9010247u; SPILL(); f_9018860(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    { uint32_t v_ = 0x8EBu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    TS32((uint32_t)(edi + ecx + 0x14u), (uint32_t)(eax));
    esp -= 4; M32(esp) = 0x9010265u; SPILL(); f_900CE90(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)((uint32_t)(edi + edx));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    (void)sub32(TL32((uint32_t)(eax + 0x14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901028E;
    goto L_9010277;
L_9010277:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x178u)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9010280u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(edi + ecx + 0xCu), (uint32_t)((uint32_t)0x0u));
L_901028E:
    { uint32_t v_ = 0x9028240u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x8F6u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x90102A2u; SPILL(); f_900D070(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    eax = (uint32_t)(M32((uint32_t)(esp + edx*4 + 0xE4u)));
    M32((uint32_t)(esp + 0x28u)) = (uint32_t)(add32(M32((uint32_t)(esp + 0x28u)), eax, &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    edx = (uint32_t)(TL32((uint32_t)(edi + ecx + 0x14u)));
    eax = (uint32_t)((uint32_t)(edi + ecx));
    ecx = (uint32_t)(TL32((uint32_t)(edx + 0x30u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x4A4u)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x4A0u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
    edx = (uint32_t)(sub32(edx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(edi + eax + 0x40u), (uint32_t)(edx));
L_90102ED:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    (void)sub32(TL32((uint32_t)(edi + ecx + 0x3Cu)), (uint32_t)0x0u, &f);
    eax = (uint32_t)((uint32_t)(edi + ecx + 0x3Cu));
    if (!f.zf) goto L_9010304;
    goto L_90102FE;
L_90102FE:
    TS32((uint32_t)(eax), (uint32_t)((uint32_t)0x10000u));
L_9010304:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    (void)sub32(TL32((uint32_t)(edi + edx + 0xCu)), (uint32_t)0x0u, &f);
    esi = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    if (!f.zf) goto L_9010340;
    goto L_9010315;
L_9010315:
    TS32((uint32_t)(ebx + 0x124u), (uint32_t)(dec32(TL32((uint32_t)(ebx + 0x124u)), &f)));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x124u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0xECu)));
    eax = (uint32_t)(sub32(eax, esi, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)((uint32_t)(ecx + esi*4));
    eax = (uint32_t)(add32(eax, eax, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ecx + 0x4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901033Bu; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    goto L_901034B;
L_9010340:
    esi = (uint32_t)(inc32(esi, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(esi);
    edi = (uint32_t)(add32(edi, (uint32_t)0x180u, &f));
L_901034B:
    (void)sub32(esi, TL32((uint32_t)(ebx + 0x124u)), &f);
    if (f.cf) goto L_900FFA0;
    goto L_9010357;
L_9010357:
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9010492;
    goto L_9010364;
L_9010364:
    { uint32_t v_ = 0x91Au; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = 0x9037368u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028240u);
    TS32((uint32_t)(ebx + 0x110u), (uint32_t)(edi));
    esp -= 4; M32(esp) = 0x9010383u; SPILL(); f_900CE90(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x124u)));
    TS32((uint32_t)(0x903FDF4u), (uint32_t)(add32(TL32((uint32_t)(0x903FDF4u)), eax, &f)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x920u);
    ecx = (uint32_t)((uint32_t)0x9037368u);
    esp -= 4; M32(esp) = 0x901039Fu; SPILL(); f_900D070(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x4Cu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((!f.zf && f.sf == f.of)) goto L_901044C;
    goto L_90103B3;
L_90103B3:
    esi = (uint32_t)((uint32_t)(ebx + 0x3B0u));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x90103C1u; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010441;
    goto L_90103C5;
L_90103C5:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90103E2;
    goto L_90103CE;
L_90103CE:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028474u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x90103DFu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_90103E2:
    eax = (uint32_t)(TL32((uint32_t)(0x903FDE4u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90103F5;
    goto L_90103EB;
L_90103EB:
    TS32((uint32_t)(0x903FE04u), (uint32_t)((uint32_t)0xDu));
L_90103F5:
    esp -= 4; M32(esp) = 0x90103FAu; SPILL(); f_900DAA0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9010410;
    goto L_90103FE;
L_90103FE:
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9010405u; SPILL(); f_90276E0(c); RELOAD();
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(ecx + 0x4Cu), (uint32_t)(edi));
    goto L_9010421;
L_9010410:
    edi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9010417u; SPILL(); f_900D490(c); RELOAD();
    TS32((uint32_t)(ebx + 0x160u), (uint32_t)((uint32_t)0x1u));
L_9010421:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    eax = (uint32_t)(TL32((uint32_t)(edx + 0x4Cu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.sf == f.of)) goto L_9010492;
    goto L_901042E;
L_901042E:
    ecx = (uint32_t)(TL32((uint32_t)(0x903FE04u)));
    eax = (uint32_t)(neg32(eax, &f));
    (void)sub32(eax, ecx, &f);
    if (!f.cf) goto L_9010492;
    goto L_901043A;
L_901043A:
    TS32((uint32_t)(0x903FE04u), (uint32_t)(eax));
    goto L_9010492;
L_9010441:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    TS32((uint32_t)(edx + 0x4Cu), (uint32_t)(edi));
    goto L_9010492;
L_901044C:
    (void)sub32(eax, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_9010492;
    goto L_9010451;
L_9010451:
    esi = (uint32_t)((uint32_t)(ebx + 0x3B0u));
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9010460u; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010481;
    goto L_9010464;
L_9010464:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010481;
    goto L_901046D;
L_901046D:
    { uint32_t v_ = 0x90373B0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902847Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x901047Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_9010481:
    edi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x9010488u; SPILL(); f_900D490(c); RELOAD();
    TS32((uint32_t)(ebx + 0x160u), (uint32_t)((uint32_t)0x1u));
L_9010492:
    edi = (uint32_t)((uint32_t)0x8000000u);
    TS32((uint32_t)(ebx + 0x1B4u), (uint32_t)((uint32_t)0x900F090u));
    TS32((uint32_t)(ebx + 0x1C0u), (uint32_t)((uint32_t)0x900F150u));
    TS32((uint32_t)(ebx + 0x1B0u), (uint32_t)((uint32_t)0x900F060u));
    TS32((uint32_t)(ebx + 0x1B8u), (uint32_t)((uint32_t)0x900F0D0u));
    TS32((uint32_t)(ebx + 0x1BCu), (uint32_t)((uint32_t)0x900F100u));
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & edi), &f);
    if (!f.zf) goto L_9010517;
    goto L_90104CE;
L_90104CE:
    (void)sub32(TL32((uint32_t)(ebx + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010517;
    goto L_90104D7;
L_90104D7:
    esi = (uint32_t)((uint32_t)(ebx + 0x330u));
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x90104E6u; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_90104FE;
    goto L_90104EA;
L_90104EA:
    esp -= 4; M32(esp) = 0x90104EFu; SPILL(); f_900EE40(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_90105F8;
    goto L_90104F7;
L_90104F7:
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x90104FEu; SPILL(); f_90276E0(c); RELOAD();
L_90104FE:
    TS32((uint32_t)(ebx + 0x20u), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) | edi), &f)));
L_9010501:
    (void)logic32((uint32_t)(TL32((uint32_t)(ebx + 0x20u)) & edi), &f);
    if (!f.zf) goto L_9010517;
    goto L_9010506;
L_9010506:
    edi = (uint32_t)(ebx);
    esp -= 4; M32(esp) = 0x901050Du; SPILL(); f_900D490(c); RELOAD();
    TS32((uint32_t)(ebx + 0x160u), (uint32_t)((uint32_t)0x1u));
L_9010517:
    esi = (uint32_t)((uint32_t)(ebx + 0x2B0u));
    { uint32_t v_ = 0x2u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x9010526u; SPILL(); f_90275A0(c); RELOAD();
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901052B;
    goto L_901052A;
L_901052A:
    SPILL(); rt_int3(c, 0x901052Au);
L_901052B:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010548;
    goto L_9010534;
L_9010534:
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t v_ = 0x9037428u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9028458u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = edx; esp -= 4; M32(esp) = 0x9010545u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
L_9010548:
    (void)sub32(TL32((uint32_t)(ebx + 0x17Cu)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_9010585;
    goto L_9010551;
L_9010551:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0xCu)) & (uint32_t)0x200000u), &f);
    if (!f.zf) goto L_9010580;
    goto L_901055A;
L_901055A:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x1A0u)));
    esi = (uint32_t)((uint32_t)(ebx + 0x190u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0x9010569u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010580;
    goto L_901056D;
L_901056D:
    TS32((uint32_t)(0x903FEACu), (uint32_t)(ebx));
L_9010573:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x1A0u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x901057Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_9010573;
    goto L_9010580;
L_9010580:
    esp -= 4; M32(esp) = 0x9010585u; SPILL(); f_900F040(c); RELOAD();
L_9010585:
    eax = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)(ebx);
    TS32((uint32_t)(ebx + 0x4D8u), (uint32_t)((uint32_t)0xF0000000u));
    esp -= 4; M32(esp) = 0x901059Bu; SPILL(); f_900E160(c); RELOAD();
    (void)sub32(TL32((uint32_t)(ebx + 0x124u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_90105CD;
    goto L_90105A4;
L_90105A4:
    edx = (uint32_t)(TL32((uint32_t)(0x903FDF8u)));
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90105CD;
    goto L_90105AE;
L_90105AE:
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x154u)));
    (void)sub32(TL32((uint32_t)(eax + 0x4Cu)), (uint32_t)0x0u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_90105CD;
    goto L_90105BA;
L_90105BA:
    ecx = (uint32_t)(TL32((uint32_t)(0x9028404u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x903103Cu)); esp -= 4; M32(esp) = 0x90105CDu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
L_90105CD:
    eax = (uint32_t)((uint32_t)0x1u);
    ecx = (uint32_t)((uint32_t)0x903FDDCu);
    { uint32_t s_ = eax; uint32_t o_ = __atomic_fetch_add((uint32_t *)(MEM + (uint32_t)(ecx)), s_, __ATOMIC_SEQ_CST); (void)add32(o_, s_, &f); eax = (uint32_t)(o_); }
    TS32((uint32_t)(ebx + 0x12Cu), (uint32_t)(eax));
    eax = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x788u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    esp -= 4; M32(esp) = 0x90105F4u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_90105F8:
    eax = (uint32_t)(TL32((uint32_t)(0x9036AECu)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_9010501;
    goto L_9010605;
L_9010605:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x5Cu)));
    { uint32_t v_ = 0x90374ECu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902846Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0x9010616u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    goto L_9010501;
L_901061E:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
L_9010621:
    { uint32_t v_ = 0x9037598u; esp -= 4; M32(esp) = v_; }
L_9010626:
    esp -= 4; M32(esp) = 0x901062Bu; SPILL(); f_900D100(c); RELOAD();
L_901062B:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x4000000u), &f);
    if (!f.zf) goto L_901066C;
    goto L_9010633;
L_9010633:
    { uint32_t v_ = 0x705u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9037504u; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)((uint32_t)0x9028498u);
    esp -= 4; M32(esp) = 0x9010647u; SPILL(); f_900CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    edx = (uint32_t)((uint32_t)(esp + 0x2F0u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = M32((uint32_t)(esp + 0x308u)); esp -= 4; M32(esp) = 0x9010659u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)0x70Bu);
    ecx = (uint32_t)((uint32_t)0x9037504u);
    esp -= 4; M32(esp) = 0x9010669u; SPILL(); f_900D070(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x4u, &f));
L_901066C:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x794u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ esp), &f));
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x901067Fu; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

