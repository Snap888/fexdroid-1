#include "funcs_bink.h"
#include "lift_prelude.h"

void f_9008000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_9008038;
    goto L_9008028;
L_9008028:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9008048;
    goto L_900802D;
L_900802D:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_9008048;
L_9008038:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_90081B9;
    goto L_9008048;
L_9008048:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    c->mm[5] ^= c->mm[5];
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[7] = M64((uint32_t)(0x903F800u));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9008110;
    goto L_900806B;
L_900806B:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_pslld(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    c->mm[1] |= c->mm[0];
    (void)logic32((uint32_t)(ebp & ebp), &f);
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[1]));
    if (f.zf) goto L_90081B9;
    goto L_900810A;
L_900810A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9008110:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    c->mm[1] |= c->mm[0];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[1];
    if (!f.zf) goto L_9008110;
    goto L_90081B9;
L_90081B9:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_9008382;
    goto L_90081C7;
L_90081C7:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
L_90081D0:
    c->mm[5] ^= c->mm[5];
    c->mm[6] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[0] = M64((uint32_t)(edx));
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[5]);
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[6] = mmx_psllw(c->mm[6], (uint64_t)4u);
    c->mm[1] = c->mm[0];
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[6] = mmx_pmulhw(c->mm[6], c->mm[3]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)5u);
    c->mm[4] = c->mm[6];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[7] = M64((uint32_t)(0x903F800u));
    c->mm[1] = mmx_punpckhbw(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[6]);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)6u);
    c->mm[6] = mmx_paddw(c->mm[6], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[2]);
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[5] = c->mm[4];
    c->mm[3] = c->mm[2];
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[4]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[7]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[3]);
    c->mm[2] = mmx_paddsw(c->mm[2], M64((uint32_t)(0x902FE20u)));
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[5] = mmx_paddw(c->mm[5], c->mm[1]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[3] = mmx_paddw(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_psubusw(c->mm[2], c->mm[6]);
    c->mm[1] = mmx_psubw(c->mm[1], c->mm[7]);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[2] = mmx_psrlw(c->mm[2], (uint64_t)4u);
    c->mm[5] = mmx_paddsw(c->mm[5], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[3] = mmx_paddsw(c->mm[3], M64((uint32_t)(0x902FE20u)));
    c->mm[5] = mmx_psubusw(c->mm[5], c->mm[6]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE30u)));
    c->mm[5] = mmx_psrlw(c->mm[5], (uint64_t)4u);
    c->mm[3] = mmx_psubusw(c->mm[3], c->mm[6]);
    c->mm[3] = mmx_psrlw(c->mm[3], (uint64_t)4u);
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[6] = c->mm[2];
    c->mm[2] = mmx_punpcklwd(c->mm[2], M64((uint32_t)(0x903F818u)));
    c->mm[7] = c->mm[0];
    c->mm[0] = mmx_punpcklwd(c->mm[0], M64((uint32_t)(0x903F818u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    c->mm[2] = mmx_pslld(c->mm[2], M64((uint32_t)(0x902FDE0u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    c->mm[2] |= c->mm[0];
    c->mm[0] = c->mm[4];
    c->mm[4] = mmx_punpcklwd(c->mm[4], M64((uint32_t)(0x903F818u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[2] |= c->mm[4];
    c->mm[4] ^= c->mm[4];
    c->mm[6] = mmx_punpckhwd(c->mm[6], c->mm[4]);
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[4]);
    c->mm[0] = mmx_punpckhwd(c->mm[0], c->mm[4]);
    c->mm[6] = mmx_pslld(c->mm[6], M64((uint32_t)(0x902FDE0u)));
    c->mm[7] = mmx_pslld(c->mm[7], (uint64_t)8u);
    c->mm[0] = mmx_pslld(c->mm[0], M64((uint32_t)(0x902FDF0u)));
    c->mm[6] |= c->mm[7];
    c->mm[7] = c->mm[3];
    c->mm[6] |= c->mm[0];
    c->mm[3] = mmx_punpcklwd(c->mm[3], c->mm[4]);
    c->mm[0] = c->mm[1];
    c->mm[3] = mmx_pslld(c->mm[3], M64((uint32_t)(0x902FDE0u)));
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[4]);
    c->mm[4] = c->mm[5];
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)8u);
    c->mm[5] = mmx_punpcklwd(c->mm[5], M64((uint32_t)(0x903F818u)));
    c->mm[5] = mmx_pslld(c->mm[5], M64((uint32_t)(0x902FDF0u)));
    c->mm[3] |= c->mm[1];
    c->mm[7] = mmx_punpckhwd(c->mm[7], M64((uint32_t)(0x903F818u)));
    c->mm[1] ^= c->mm[1];
    c->mm[7] = mmx_pslld(c->mm[7], M64((uint32_t)(0x902FDE0u)));
    c->mm[3] |= c->mm[5];
    c->mm[0] = mmx_punpckhwd(c->mm[0], c->mm[1]);
    c->mm[4] = mmx_punpckhwd(c->mm[4], c->mm[1]);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    M64((uint32_t)(edi + 0xFFFFFFE0u)) = c->mm[2];
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    M64((uint32_t)(edi + 0xFFFFFFE8u)) = c->mm[6];
    c->mm[7] |= c->mm[0];
    M64((uint32_t)(edi + 0xFFFFFFF0u)) = c->mm[3];
    c->mm[7] |= c->mm[4];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[7];
    if (!f.zf) goto L_90081D0;
    goto L_9008382;
L_9008382:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90083B0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90083B0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    if (f.zf) goto L_9008417;
    goto L_90083CA;
L_90083CA:
    ebx = (uint32_t)((uint32_t)(ebx));
L_90083D0:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    c->mm[4] = M64((uint32_t)(esi + 0x20u));
    c->mm[5] = M64((uint32_t)(esi + 0x28u));
    c->mm[6] = M64((uint32_t)(esi + 0x30u));
    c->mm[7] = M64((uint32_t)(esi + 0x38u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x40u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[2];
    M64((uint32_t)(edi + 0x18u)) = c->mm[3];
    M64((uint32_t)(edi + 0x20u)) = c->mm[4];
    M64((uint32_t)(edi + 0x28u)) = c->mm[5];
    M64((uint32_t)(edi + 0x30u)) = c->mm[6];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90083D0;
    goto L_9008417;
L_9008417:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_9008430;
    goto L_9008421;
L_9008421:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008421;
    goto L_9008430;
L_9008430:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_900843E;
    goto L_9008434;
L_9008434:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
L_900843E:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008450(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008450:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    if (f.zf) goto L_90084CB;
    goto L_900846A;
L_900846A:
    ebx = (uint32_t)((uint32_t)(ebx));
L_9008470:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    esi = (uint32_t)(add32(esi, (uint32_t)0x20u, &f));
    c->mm[4] = c->mm[0];
    c->mm[5] = c->mm[1];
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[0] = mmx_punpckldq(c->mm[0], c->mm[0]);
    c->mm[1] = mmx_punpckldq(c->mm[1], c->mm[1]);
    c->mm[2] = mmx_punpckldq(c->mm[2], c->mm[2]);
    c->mm[3] = mmx_punpckldq(c->mm[3], c->mm[3]);
    c->mm[4] = mmx_punpckhdq(c->mm[4], c->mm[4]);
    c->mm[5] = mmx_punpckhdq(c->mm[5], c->mm[5]);
    c->mm[6] = mmx_punpckhdq(c->mm[6], c->mm[6]);
    c->mm[7] = mmx_punpckhdq(c->mm[7], c->mm[7]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    M64((uint32_t)(edi + 0x10u)) = c->mm[1];
    M64((uint32_t)(edi + 0x18u)) = c->mm[5];
    M64((uint32_t)(edi + 0x20u)) = c->mm[2];
    M64((uint32_t)(edi + 0x28u)) = c->mm[6];
    M64((uint32_t)(edi + 0x30u)) = c->mm[3];
    M64((uint32_t)(edi + 0x38u)) = c->mm[7];
    edi = (uint32_t)(add32(edi, (uint32_t)0x40u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008470;
    goto L_90084CB;
L_90084CB:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90084F1;
    goto L_90084D5;
L_90084D5:
    c->mm[0] = M64((uint32_t)(esi));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[4] = c->mm[0];
    c->mm[0] = mmx_punpckldq(c->mm[0], c->mm[0]);
    c->mm[4] = mmx_punpckhdq(c->mm[4], c->mm[4]);
    M64((uint32_t)(edi)) = c->mm[0];
    M64((uint32_t)(edi + 0x8u)) = c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90084D5;
    goto L_90084F1;
L_90084F1:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_9008502;
    goto L_90084F5;
L_90084F5:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_9008502:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008510(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008510:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1Fu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x5u, &f));
    if (f.zf) goto L_90085A2;
    goto L_900852B;
L_900852B:
    goto L_9008530;
L_9008530:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[1] = M64((uint32_t)(esi + 0x8u));
    c->mm[2] = M64((uint32_t)(esi + 0x10u));
    c->mm[3] = M64((uint32_t)(esi + 0x18u));
    c->mm[4] = c->mm[0];
    c->mm[5] = c->mm[1];
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[0] = mmx_psllq(c->mm[0], (uint64_t)40u);
    c->mm[5] = mmx_psllq(c->mm[5], (uint64_t)40u);
    c->mm[2] = mmx_psllq(c->mm[2], (uint64_t)40u);
    c->mm[3] = mmx_psllq(c->mm[3], (uint64_t)40u);
    c->mm[0] = mmx_punpckhdq(c->mm[0], c->mm[4]);
    c->mm[5] = mmx_punpckhdq(c->mm[5], c->mm[1]);
    c->mm[2] = mmx_punpckhdq(c->mm[2], c->mm[6]);
    c->mm[3] = mmx_punpckhdq(c->mm[3], c->mm[7]);
    c->mm[0] = mmx_psrlq(c->mm[0], (uint64_t)8u);
    c->mm[1] = c->mm[5];
    c->mm[5] = mmx_psllq(c->mm[5], (uint64_t)40u);
    c->mm[1] = mmx_psrlq(c->mm[1], (uint64_t)24u);
    c->mm[6] = c->mm[2];
    c->mm[0] |= c->mm[5];
    c->mm[2] = mmx_psrlq(c->mm[2], (uint64_t)8u);
    c->mm[6] = mmx_psrlq(c->mm[6], (uint64_t)40u);
    c->mm[3] = mmx_psllq(c->mm[3], (uint64_t)8u);
    c->mm[1] = mmx_punpckldq(c->mm[1], c->mm[2]);
    esi = (uint32_t)(add32(esi, (uint32_t)0x20u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    c->mm[6] |= c->mm[3];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[6];
    edi = (uint32_t)(add32(edi, (uint32_t)0x18u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008530;
    goto L_90085A2;
L_90085A2:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90085CC;
    goto L_90085AC;
L_90085AC:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
L_90085AD:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebp = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x18u, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS16((uint32_t)(edi + 0x4u), (uint16_t)(((uint16_t)ebp)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x6u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_90085AD;
    goto L_90085CB;
L_90085CB:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
L_90085CC:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90085E1;
    goto L_90085D0;
L_90085D0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x10u, &f));
    TS8((uint32_t)(edi + 0x2u), (uint8_t)(((uint8_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x3u, &f));
L_90085E1:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90085F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90085F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_900868C;
    goto L_900860F;
L_900860F:
L_9008610:
    c->mm[0] = M64((uint32_t)(esi));
    c->mm[2] = M64((uint32_t)(esi + 0x8u));
    c->mm[1] = c->mm[0];
    c->mm[3] = c->mm[2];
    c->mm[0] = mmx_punpckldq(c->mm[0], c->mm[0]);
    c->mm[2] = mmx_punpckldq(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpckhdq(c->mm[1], c->mm[1]);
    c->mm[3] = mmx_punpckhdq(c->mm[3], c->mm[3]);
    c->mm[4] = c->mm[0];
    c->mm[5] = c->mm[1];
    c->mm[6] = c->mm[2];
    c->mm[7] = c->mm[3];
    c->mm[0] = mmx_psllq(c->mm[0], (uint64_t)40u);
    c->mm[5] = mmx_psllq(c->mm[5], (uint64_t)40u);
    c->mm[2] = mmx_psllq(c->mm[2], (uint64_t)40u);
    c->mm[3] = mmx_psllq(c->mm[3], (uint64_t)40u);
    c->mm[0] = mmx_punpckhdq(c->mm[0], c->mm[4]);
    c->mm[5] = mmx_punpckhdq(c->mm[5], c->mm[1]);
    c->mm[2] = mmx_punpckhdq(c->mm[2], c->mm[6]);
    c->mm[3] = mmx_punpckhdq(c->mm[3], c->mm[7]);
    c->mm[0] = mmx_psrlq(c->mm[0], (uint64_t)8u);
    c->mm[1] = c->mm[5];
    c->mm[5] = mmx_psllq(c->mm[5], (uint64_t)40u);
    c->mm[1] = mmx_psrlq(c->mm[1], (uint64_t)24u);
    c->mm[6] = c->mm[2];
    c->mm[0] |= c->mm[5];
    c->mm[2] = mmx_psrlq(c->mm[2], (uint64_t)8u);
    c->mm[6] = mmx_psrlq(c->mm[6], (uint64_t)40u);
    c->mm[3] = mmx_psllq(c->mm[3], (uint64_t)8u);
    c->mm[1] = mmx_punpckldq(c->mm[1], c->mm[2]);
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    M64((uint32_t)(edi)) = c->mm[0];
    c->mm[6] |= c->mm[3];
    M64((uint32_t)(edi + 0x8u)) = c->mm[1];
    M64((uint32_t)(edi + 0x10u)) = c->mm[6];
    edi = (uint32_t)(add32(edi, (uint32_t)0x18u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008610;
    goto L_900868C;
L_900868C:
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x7u), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x3u, &f));
    if (f.zf) goto L_90086CD;
    goto L_9008696;
L_9008696:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
L_9008698:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebp = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    ebx = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    ebx = (uint32_t)(ebp);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    eax = (uint32_t)(ebp);
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008698;
    goto L_90086CB;
L_90086CB:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_90086CD:
    (void)logic32((uint32_t)(edx & edx), &f);
    if (f.zf) goto L_90086E9;
    goto L_90086D1;
L_90086D1:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x8u, &f));
    TS16((uint32_t)(edi + 0x4u), (uint16_t)(((uint16_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x6u, &f));
L_90086E9:
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_90086F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_90086F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(ebp);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)(ebp);
    esi = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edi = (uint32_t)(TL32((uint32_t)(ebx)));
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebx + 0xCu)));
    (void)sub32(ebp, (uint32_t)0x8u, &f);
    if (!f.cf) goto L_900872C;
    goto L_900871C;
L_900871C:
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_900873C;
    goto L_9008721;
L_9008721:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
    goto L_900873C;
L_900872C:
    ebp = (uint32_t)((uint32_t)0x8u);
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    ebp = (uint32_t)(logic32((uint32_t)(ebp & (uint32_t)0x7u), &f));
    if (f.zf) goto L_90088D2;
    goto L_900873C;
L_900873C:
    M32((uint32_t)(esp)) = (uint32_t)(sub32(M32((uint32_t)(esp)), ebp, &f));
    c->mm[5] ^= c->mm[5];
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[7] = M64((uint32_t)(0x903F800u));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    if (!f.cf) goto L_9008810;
    goto L_900875F;
L_900875F:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_pslld(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    eax = (uint32_t)(TL8((uint32_t)(esi)));
    esi = (uint32_t)(inc32(esi, &f));
    c->mm[2] = (uint64_t)eax;
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    c->mm[2] = mmx_pslld(c->mm[2], M64((uint32_t)(0x902FDF8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x4u, &f));
    c->mm[1] |= c->mm[2];
    c->mm[1] |= c->mm[0];
    (void)logic32((uint32_t)(ebp & ebp), &f);
    TS32((uint32_t)(edi + 0xFFFFFFFCu), (uint32_t)((uint32_t)c->mm[1]));
    if (f.zf) goto L_90088D2;
    goto L_900880F;
L_900880F:
L_9008810:
    eax = (uint32_t)(TL8((uint32_t)(ebx)));
    ebx = (uint32_t)(inc32(ebx, &f));
    c->mm[2] = (uint64_t)eax;
    eax = (uint32_t)(TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(inc32(ecx, &f));
    c->mm[1] = (uint64_t)eax;
    eax = (uint32_t)(TL16((uint32_t)(edx)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x2u, &f));
    c->mm[0] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[1]);
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)4u);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)5u);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[3]);
    c->mm[4] = c->mm[2];
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[1]);
    c->mm[1] = mmx_paddw(c->mm[1], c->mm[0]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[2]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE20u)));
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    eax = (uint32_t)(TL16((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x2u, &f));
    c->mm[2] = (uint64_t)eax;
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[5]);
    c->mm[0] = mmx_punpcklwd(c->mm[0], c->mm[5]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[5]);
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDE0u)));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    c->mm[2] = mmx_pslld(c->mm[2], M64((uint32_t)(0x902FDF8u)));
    c->mm[1] |= c->mm[4];
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    c->mm[1] |= c->mm[2];
    c->mm[1] |= c->mm[0];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[1];
    if (!f.zf) goto L_9008810;
    goto L_90088D2;
L_90088D2:
    eax = (uint32_t)(M32((uint32_t)(esp)));
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF8u), &f);
    if (f.zf) goto L_9008B12;
    goto L_90088E0;
L_90088E0:
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7u), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x3u, &f));
    goto L_90088F0;
L_90088F0:
    c->mm[5] ^= c->mm[5];
    c->mm[6] = (uint64_t)TL32((uint32_t)(ebx));
    c->mm[2] = (uint64_t)TL32((uint32_t)(ecx));
    c->mm[0] = M64((uint32_t)(edx));
    c->mm[6] = mmx_punpcklbw(c->mm[6], c->mm[5]);
    c->mm[3] = M64((uint32_t)(0x903F808u));
    c->mm[6] = mmx_psllw(c->mm[6], (uint64_t)4u);
    c->mm[1] = c->mm[0];
    c->mm[2] = mmx_punpcklbw(c->mm[2], c->mm[5]);
    c->mm[6] = mmx_pmulhw(c->mm[6], c->mm[3]);
    c->mm[2] = mmx_psllw(c->mm[2], (uint64_t)5u);
    c->mm[4] = c->mm[6];
    c->mm[0] = mmx_punpcklbw(c->mm[0], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[0] = mmx_psllw(c->mm[0], (uint64_t)6u);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[4]);
    c->mm[2] = mmx_pmulhw(c->mm[2], c->mm[3]);
    c->mm[7] = M64((uint32_t)(0x903F800u));
    c->mm[1] = mmx_punpckhbw(c->mm[1], c->mm[5]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[6]);
    c->mm[1] = mmx_psllw(c->mm[1], (uint64_t)6u);
    c->mm[6] = mmx_paddw(c->mm[6], c->mm[2]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[2]);
    c->mm[0] = mmx_pmulhw(c->mm[0], c->mm[7]);
    c->mm[5] = c->mm[4];
    c->mm[3] = c->mm[2];
    c->mm[4] = mmx_punpcklwd(c->mm[4], c->mm[4]);
    c->mm[1] = mmx_pmulhw(c->mm[1], c->mm[7]);
    c->mm[2] = mmx_punpcklwd(c->mm[2], c->mm[2]);
    c->mm[7] = c->mm[6];
    c->mm[6] = mmx_punpcklwd(c->mm[6], c->mm[6]);
    c->mm[4] = mmx_paddw(c->mm[4], c->mm[0]);
    c->mm[2] = mmx_paddw(c->mm[2], c->mm[0]);
    c->mm[0] = mmx_psubw(c->mm[0], c->mm[6]);
    c->mm[5] = mmx_punpckhwd(c->mm[5], c->mm[5]);
    c->mm[4] = mmx_paddsw(c->mm[4], M64((uint32_t)(0x902FE40u)));
    c->mm[3] = mmx_punpckhwd(c->mm[3], c->mm[3]);
    c->mm[2] = mmx_paddsw(c->mm[2], M64((uint32_t)(0x902FE20u)));
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[7]);
    c->mm[0] = mmx_paddsw(c->mm[0], M64((uint32_t)(0x902FE30u)));
    c->mm[6] = M64((uint32_t)(0x903F810u));
    c->mm[5] = mmx_paddw(c->mm[5], c->mm[1]);
    c->mm[4] = mmx_psubusw(c->mm[4], c->mm[6]);
    c->mm[3] = mmx_paddw(c->mm[3], c->mm[1]);
    c->mm[2] = mmx_psubusw(c->mm[2], c->mm[6]);
    c->mm[1] = mmx_psubw(c->mm[1], c->mm[7]);
    c->mm[4] = mmx_psrlw(c->mm[4], (uint64_t)4u);
    c->mm[0] = mmx_psubusw(c->mm[0], c->mm[6]);
    c->mm[2] = mmx_psrlw(c->mm[2], (uint64_t)4u);
    c->mm[5] = mmx_paddsw(c->mm[5], M64((uint32_t)(0x902FE40u)));
    c->mm[0] = mmx_psrlw(c->mm[0], (uint64_t)4u);
    c->mm[3] = mmx_paddsw(c->mm[3], M64((uint32_t)(0x902FE20u)));
    c->mm[5] = mmx_psubusw(c->mm[5], c->mm[6]);
    c->mm[1] = mmx_paddsw(c->mm[1], M64((uint32_t)(0x902FE30u)));
    c->mm[5] = mmx_psrlw(c->mm[5], (uint64_t)4u);
    c->mm[3] = mmx_psubusw(c->mm[3], c->mm[6]);
    c->mm[3] = mmx_psrlw(c->mm[3], (uint64_t)4u);
    c->mm[1] = mmx_psubusw(c->mm[1], c->mm[6]);
    c->mm[1] = mmx_psrlw(c->mm[1], (uint64_t)4u);
    c->mm[6] = c->mm[2];
    c->mm[2] = mmx_punpcklwd(c->mm[2], M64((uint32_t)(0x903F818u)));
    c->mm[7] = c->mm[0];
    c->mm[0] = mmx_punpcklwd(c->mm[0], M64((uint32_t)(0x903F818u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x8u, &f));
    c->mm[2] = mmx_pslld(c->mm[2], M64((uint32_t)(0x902FDE0u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    ebx = (uint32_t)(add32(ebx, (uint32_t)0x4u, &f));
    c->mm[2] |= c->mm[0];
    c->mm[0] = c->mm[4];
    c->mm[4] = mmx_punpcklwd(c->mm[4], M64((uint32_t)(0x903F818u)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    c->mm[2] |= c->mm[4];
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    c->mm[4] ^= c->mm[4];
    c->mm[6] = mmx_punpckhwd(c->mm[6], c->mm[4]);
    c->mm[7] = mmx_punpckhwd(c->mm[7], c->mm[4]);
    c->mm[0] = mmx_punpckhwd(c->mm[0], c->mm[4]);
    c->mm[6] = mmx_pslld(c->mm[6], M64((uint32_t)(0x902FDE0u)));
    c->mm[7] = mmx_pslld(c->mm[7], (uint64_t)8u);
    c->mm[0] = mmx_pslld(c->mm[0], M64((uint32_t)(0x902FDF0u)));
    c->mm[6] |= c->mm[7];
    c->mm[7] = c->mm[3];
    c->mm[6] |= c->mm[0];
    c->mm[3] = mmx_punpcklwd(c->mm[3], c->mm[4]);
    c->mm[0] = c->mm[1];
    c->mm[3] = mmx_pslld(c->mm[3], M64((uint32_t)(0x902FDE0u)));
    c->mm[1] = mmx_punpcklwd(c->mm[1], c->mm[4]);
    c->mm[4] = c->mm[5];
    c->mm[1] = mmx_pslld(c->mm[1], (uint64_t)8u);
    c->mm[5] = mmx_punpcklwd(c->mm[5], M64((uint32_t)(0x903F818u)));
    c->mm[5] = mmx_pslld(c->mm[5], M64((uint32_t)(0x902FDF0u)));
    c->mm[3] |= c->mm[1];
    c->mm[7] = mmx_punpckhwd(c->mm[7], M64((uint32_t)(0x903F818u)));
    c->mm[1] ^= c->mm[1];
    c->mm[7] = mmx_pslld(c->mm[7], M64((uint32_t)(0x902FDE0u)));
    c->mm[3] |= c->mm[5];
    c->mm[0] = mmx_punpckhwd(c->mm[0], c->mm[1]);
    c->mm[4] = mmx_punpckhwd(c->mm[4], c->mm[1]);
    c->mm[1] = M64((uint32_t)(esi + 0xFFFFFFF8u));
    c->mm[5] = c->mm[1];
    c->mm[1] = mmx_punpcklbw(c->mm[1], M64((uint32_t)(0x903F818u)));
    c->mm[1] = mmx_punpcklwd(c->mm[1], M64((uint32_t)(0x903F818u)));
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDF8u)));
    c->mm[2] |= c->mm[1];
    c->mm[0] = mmx_pslld(c->mm[0], (uint64_t)8u);
    M64((uint32_t)(edi + 0xFFFFFFE0u)) = c->mm[2];
    c->mm[1] = c->mm[5];
    c->mm[2] = c->mm[5];
    c->mm[1] = mmx_punpcklbw(c->mm[1], M64((uint32_t)(0x903F818u)));
    c->mm[2] = mmx_punpckhbw(c->mm[2], M64((uint32_t)(0x903F818u)));
    c->mm[5] = mmx_punpckhbw(c->mm[5], M64((uint32_t)(0x903F818u)));
    c->mm[1] = mmx_punpckhwd(c->mm[1], M64((uint32_t)(0x903F818u)));
    c->mm[2] = mmx_punpcklwd(c->mm[2], M64((uint32_t)(0x903F818u)));
    c->mm[5] = mmx_punpckhwd(c->mm[5], M64((uint32_t)(0x903F818u)));
    c->mm[1] = mmx_pslld(c->mm[1], M64((uint32_t)(0x902FDF8u)));
    c->mm[2] = mmx_pslld(c->mm[2], M64((uint32_t)(0x902FDF8u)));
    c->mm[5] = mmx_pslld(c->mm[5], M64((uint32_t)(0x902FDF8u)));
    c->mm[6] |= c->mm[1];
    c->mm[4] = mmx_pslld(c->mm[4], M64((uint32_t)(0x902FDF0u)));
    M64((uint32_t)(edi + 0xFFFFFFE8u)) = c->mm[6];
    c->mm[3] |= c->mm[2];
    c->mm[7] |= c->mm[5];
    c->mm[7] |= c->mm[0];
    M64((uint32_t)(edi + 0xFFFFFFF0u)) = c->mm[3];
    c->mm[7] |= c->mm[4];
    ebp = (uint32_t)(dec32(ebp, &f));
    M64((uint32_t)(edi + 0xFFFFFFF8u)) = c->mm[7];
    if (!f.zf) goto L_90088F0;
    goto L_9008B12;
L_9008B12:
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    TS32((uint32_t)(eax + 0x4u), (uint32_t)(edx));
    TS32((uint32_t)(eax + 0x10u), (uint32_t)(esi));
    TS32((uint32_t)(eax + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(eax), (uint32_t)(edi));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008B40(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008B40:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp = (uint32_t)(sub32(esp, (uint32_t)0x14u, &f));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ebp = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(esp)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(edi);
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(ebp);
    (void)sub32(ebp, (uint32_t)0x1u, &f);
    if (f.zf) goto L_9008B73;
    goto L_9008B6A;
L_9008B6A:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ebp = (uint32_t)(sub32(ebp, eax, &f));
    { uint32_t v_ = M32(esp); esp += 4; eax = (uint32_t)(v_); }
L_9008B73:
    M32((uint32_t)(esp + 0xCu)) = (uint32_t)(sub32(M32((uint32_t)(esp + 0xCu)), ebp, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x1u, &f));
    M32((uint32_t)(esp + 0x4u)) = (uint32_t)(ebp);
    if (!f.cf) goto L_9008BF2;
    goto L_9008B7F;
L_9008B7F:
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(TL8((uint32_t)(edx + 0xFFFFFFFFu)));
    esi = (uint32_t)(TL8((uint32_t)(esi)));
    ebp = (uint32_t)(M8((uint32_t)(ebp)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903026Eu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(edx*4 + 0x9030274u))), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    ebp = (uint32_t)(rol32(ebp, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(eax*4 + 0x903027Bu))), &f));
    TS32((uint32_t)(edi), (uint32_t)(esi));
    TS32((uint32_t)(esi + 0xFFFFFFFCu), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(add32(TL32((uint32_t)(edi + 0x8u)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(add32(TL32((uint32_t)(edi + 0xCu)), (uint32_t)0x1u, &f)));
L_9008BF2:
    (void)sub32(M32((uint32_t)(esp + 0x4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_9008CD0;
    goto L_9008BFD;
L_9008BFD:
    edx = (uint32_t)(logic32(0, &f));
L_9008C00:
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(M16((uint32_t)(ebp + edx*2 + 0xFFFFFFFEu)));
    esi = (uint32_t)(TL8((uint32_t)(edx + ecx + 0xFFFFFFFFu)));
    ebp = (uint32_t)(TL8((uint32_t)(edx + ebx + 0xFFFFFFFFu)));
    M32((uint32_t)(esp)) = (uint32_t)(edx);
    ebx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(esi + 0x903F838u)));
    ebx = (ebx & 0xFFFFFF00u) | (uint8_t)(((uint8_t)(eax >> 8)));
    ebp = (uint32_t)((uint32_t)(int8_t)M8((uint32_t)(ebp + 0x903F838u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFu), &f));
    ebx = (uint32_t)(TL8((uint32_t)(ebx + 0x903F938u)));
    esi = (uint32_t)(add32(esi, esi, &f));
    eax = (uint32_t)(TL8((uint32_t)(eax + 0x903F938u)));
    edi = (uint32_t)((uint32_t)(ebp + ebp*4));
    ebp = (uint32_t)(add32(ebp, esi, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edx = (uint32_t)((uint32_t)(edi + ebx));
    edi = (uint32_t)(add32(edi, eax, &f));
    ecx = (uint32_t)((uint32_t)(esi + eax));
    esi = (uint32_t)(add32(esi, ebx, &f));
    eax = (uint32_t)(sub32(eax, ebp, &f));
    ebx = (uint32_t)(sub32(ebx, ebp, &f));
    ebp = (uint32_t)(TL32((uint32_t)(ecx*4 + 0x903026Eu)));
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A8Cu)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(edi*4 + 0x9030274u))), &f));
    ebp = (uint32_t)(rol32(ebp, ((uint8_t)ecx), &f));
    edi = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(logic32((uint32_t)(ebp | TL32((uint32_t)(eax*4 + 0x903027Bu))), &f));
    eax = (uint32_t)(TL32((uint32_t)(esi*4 + 0x903026Eu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(edx*4 + 0x9030274u))), &f));
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(rol32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(M32((uint32_t)(esp)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebx*4 + 0x903027Bu))), &f));
    (void)sub32(M32((uint32_t)(esp + 0x4u)), edx, &f);
    TS32((uint32_t)(esi + edx*8 + 0xFFFFFFF8u), (uint32_t)(ebp));
    TS32((uint32_t)(esi + edx*8 + 0xFFFFFFFCu), (uint32_t)(eax));
    if (!f.zf) goto L_9008C00;
    goto L_9008CAA;
L_9008CAA:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    ebp = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    ebx = (uint32_t)(TL32((uint32_t)(edi)));
    esi = (uint32_t)(add32(esi, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebp = (uint32_t)(add32(ebp, edx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(esi));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebp));
    TS32((uint32_t)(edi), (uint32_t)(ebx));
L_9008CD0:
    eax = (uint32_t)(M32((uint32_t)(esp + 0xCu)));
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x14u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008CE0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008CE0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(sub32(esi, eax, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x9008CF8u; SPILL(); f_9001FE0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)((uint32_t)(esi + edi));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008D10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008D10:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_9008D5C;
    goto L_9008D2C;
L_9008D2C:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_9008D30:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x14u), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0x18u), (uint32_t)(ebp));
    TS32((uint32_t)(edi + 0x1Cu), (uint32_t)(ebp));
    edi = (uint32_t)(add32(edi, (uint32_t)0x20u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008D30;
    goto L_9008D5B;
L_9008D5B:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9008D5C:
    (void)logic32((uint32_t)(edx & (uint32_t)0x8u), &f);
    if (f.zf) goto L_9008D7A;
    goto L_9008D64;
L_9008D64:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ebx));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x10u, &f));
L_9008D7A:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9008D8F;
    goto L_9008D82;
L_9008D82:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(eax));
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
L_9008D8F:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008DA0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008DA0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_9008DFA;
    goto L_9008DBC;
L_9008DBC:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_9008DC0:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebp = (uint32_t)(ebx);
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x8u, &f));
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x18u, &f));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebp), &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x10u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFF000000u), &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ebp), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(esi + 0xCu))), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    edx = (uint32_t)(rol32(edx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xCu, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008DC0;
    goto L_9008DF9;
L_9008DF9:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9008DFA:
    (void)logic32((uint32_t)(edx & (uint32_t)0x8u), &f);
    if (f.zf) goto L_9008E1D;
    goto L_9008E02;
L_9008E02:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebp = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x18u, &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x8u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS16((uint32_t)(edi + 0x4u), (uint16_t)(((uint16_t)ebp)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x6u, &f));
L_9008E1D:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9008E36;
    goto L_9008E25;
L_9008E25:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    TS16((uint32_t)(edi), (uint16_t)(((uint16_t)eax)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x10u, &f));
    TS8((uint32_t)(edi + 0x2u), (uint8_t)(((uint8_t)eax)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x3u, &f));
L_9008E36:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008E40(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008E40:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edx = (uint32_t)(sub32(edx, esi, &f));
    ecx = (uint32_t)(edx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    if (f.zf) goto L_9008EBC;
    goto L_9008E5C;
L_9008E5C:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ecx));
L_9008E60:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebp), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ebp), &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebp), &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebp), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ebp), &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebp), &f));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x10u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x14u), (uint32_t)(edx));
    esi = (uint32_t)(add32(esi, (uint32_t)0x10u, &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x18u, &f));
    ecx = (uint32_t)(dec32(ecx, &f));
    if (!f.zf) goto L_9008E60;
    goto L_9008EBB;
L_9008EBB:
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9008EBC:
    (void)logic32((uint32_t)(edx & (uint32_t)0x8u), &f);
    if (f.zf) goto L_9008EF4;
    goto L_9008EC4;
L_9008EC4:
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebp = (uint32_t)(eax);
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebp), &f));
    ebp = (uint32_t)(shr32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(ebx);
    ebx = (uint32_t)(shl32(ebx, (uint8_t)0x10u, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ebp), &f));
    ebp = (uint32_t)(edx);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    ebp = (uint32_t)(shl32(ebp, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ebp), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; edx = (uint32_t)(v_); }
L_9008EF4:
    (void)logic32((uint32_t)(edx & (uint32_t)0x4u), &f);
    if (f.zf) goto L_9008F14;
    goto L_9008EFC;
L_9008EFC:
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(eax);
    esi = (uint32_t)(add32(esi, (uint32_t)0x4u, &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS16((uint32_t)(edi + 0x4u), (uint16_t)(((uint16_t)ebx)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x6u, &f));
L_9008F14:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(edi);
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008F20(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008F20:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    eax = (uint32_t)(dec32(eax, &f));
    (void)sub32(eax, (uint32_t)0x5u, &f);
    if ((!f.cf && !f.zf)) goto L_9009052;
    goto L_9008F3A;
L_9008F3A:
    { jt_ = TL32((uint32_t)(eax*4 + 0x900905Cu)); goto L_dispatch; }
L_9008F41:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
L_9008F4B:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008F56u; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008CE0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008D10u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    goto L_9008FD5;
L_9008F80:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    goto L_9008F4B;
L_9008F8C:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    goto L_9008FA2;
L_9008F98:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
L_9008FA2:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008FADu; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008E40u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008DA0u));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x3u));
L_9008FD5:
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008B40u));
    esp -= 4; M32(esp) = 0x9009043u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009048u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_9009052:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x9008F20u: goto L_9008F20; case 0x9008F3Au: goto L_9008F3A; case 0x9008F41u: goto L_9008F41; case 0x9008F4Bu: goto L_9008F4B; case 0x9008F80u: goto L_9008F80; case 0x9008F8Cu: goto L_9008F8C; case 0x9008F98u: goto L_9008F98; case 0x9008FA2u: goto L_9008FA2; case 0x9008FD5u: goto L_9008FD5; case 0x9009052u: goto L_9009052; default: SPILL(); rt_call(c, jt_); return; }
}

void f_9008F41(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008F41:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008F56u; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008CE0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008D10u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    goto L_9008FD5;
L_9008FD5:
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008B40u));
    esp -= 4; M32(esp) = 0x9009043u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009048u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008F80(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_9008F80;
L_9008F4B:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008F56u; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x4u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008CE0u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008D10u));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x0u));
    goto L_9008FD5;
L_9008F80:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    goto L_9008F4B;
L_9008FD5:
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008B40u));
    esp -= 4; M32(esp) = 0x9009043u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009048u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008F8C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008F8C:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    goto L_9008FA2;
L_9008FA2:
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008FADu; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008E40u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008DA0u));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x3u));
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008B40u));
    esp -= 4; M32(esp) = 0x9009043u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009048u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_9008F98(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_9008F98:
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x10u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x18u; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32(0, &f));
    ecx = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0x9008FADu; SPILL(); f_901CE90(c); RELOAD();
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x9030AA0u), (uint32_t)((uint32_t)0x9008E40u));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x9008DA0u));
    TS32((uint32_t)(0x9030AACu), (uint32_t)((uint32_t)0x3u));
    eax = (uint32_t)((uint32_t)0x61D061D0u);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x78A778A7u);
    TS32((uint32_t)(0x902FE30u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x5E8D5E8Du);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(eax));
    eax = (uint32_t)(esi);
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x70000000u), &f));
    TS32((uint32_t)(0x9030AB0u), (uint32_t)((uint32_t)0x2u));
    TS32((uint32_t)(0x9030AA4u), (uint32_t)((uint32_t)0x9008B40u));
    esp -= 4; M32(esp) = 0x9009043u; SPILL(); f_901D550(c); RELOAD();
    esp -= 4; M32(esp) = 0x9009048u; SPILL(); f_901D170(c); RELOAD();
    eax = (uint32_t)((uint32_t)0x1u);
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_900905C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_900905C:
    TS16((uint32_t)(edi + 0x8F980900u), (uint16_t)(((uint16_t)0x23)));
    TS8((uint32_t)(ecx), (uint8_t)(add8(TL8((uint32_t)(ecx)), ((uint8_t)ecx), &f)));
    ecx = (uint32_t)(inc32(ecx, &f));
    { uint32_t v_ = M32(esp); esp += 4; TS32((uint32_t)(eax), (uint32_t)(v_)); }
    TS32((uint32_t)(eax + 0x4109008Fu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0x4109008Fu)) | eax), &f)));
    { uint32_t v_ = M32(esp); esp += 4; TS32((uint32_t)(eax), (uint32_t)(v_)); }
    TS32((uint32_t)(eax + 0xCC09008Fu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(eax + 0xCC09008Fu)) | eax), &f)));
    SPILL(); rt_int3(c, 0x9009075u);
    { SPILL(); rt_call(c, 0x9009076u); return; }
}

