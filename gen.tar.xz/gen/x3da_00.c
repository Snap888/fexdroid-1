#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A00102C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00102C:
    esp += 62; SPILL(); return;
}

void f_A001030(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001030:
    esp += 62; SPILL(); return;
}

void f_A00112C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00112C:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(edi), (uint8_t)(add8(TL8((uint32_t)(edi)), ((uint8_t)(ebx >> 8)), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xC0490FDBu), (uint8_t)(add8(TL8((uint32_t)(eax + 0xC0490FDBu)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0xE4u, &f));
    esp += 4; SPILL(); return;
}

void f_A001130(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001130:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax + 0xC0490FDBu), (uint8_t)(add8(TL8((uint32_t)(eax + 0xC0490FDBu)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0xE4u, &f));
    esp += 4; SPILL(); return;
}

void f_A001134(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001134:
    M32((uint32_t)(edi)) = (uint32_t)fistt32(ST(0)); fpop(c);
    ecx = (uint32_t)(dec32(ecx, &f));
    TS8((uint32_t)(eax), (uint8_t)(rol8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0xE4u, &f));
    esp += 4; SPILL(); return;
}

void f_A001138(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001138:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), (uint8_t)0x0u, &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0xE4u, &f));
    esp += 4; SPILL(); return;
}

void f_A00113C(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00113C:
    TS8((uint32_t)(eax), (uint8_t)(add8(TL8((uint32_t)(eax)), ((uint8_t)eax), &f)));
    eax = (eax & 0xFFFFFF00u) | (uint8_t)(add8(((uint8_t)eax), (uint8_t)0xE4u, &f));
    esp += 4; SPILL(); return;
}

void f_A001159(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001159:
    esp += 4; SPILL(); return;
}

