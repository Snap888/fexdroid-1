#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A0034F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0034F0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x3Cu)));
    ecx = (uint32_t)(add32(ecx, eax, &f));
    eax = (uint32_t)(TL16((uint32_t)(ecx + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL16((uint32_t)(ecx + 0x6u)));
    edx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(esi & esi), &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(eax + ecx + 0x18u));
    if ((f.cf || f.zf)) goto L_A00352F;
    goto L_A003512;
L_A003512:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
L_A003515:
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    (void)sub32(edi, ecx, &f);
    if (f.cf) goto L_A003525;
    goto L_A00351C;
L_A00351C:
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    (void)sub32(edi, ebx, &f);
    if (f.cf) goto L_A003531;
    goto L_A003525;
L_A003525:
    edx = (uint32_t)(add32(edx, (uint32_t)0x1u, &f));
    eax = (uint32_t)(add32(eax, (uint32_t)0x28u, &f));
    (void)sub32(edx, esi, &f);
    if (f.cf) goto L_A003515;
    goto L_A00352F;
L_A00352F:
    eax = (uint32_t)(logic32(0, &f));
L_A003531:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A00353B(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00353B:
    { uint32_t v_ = 0x8u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA003960u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003547u; SPILL(); f_A0035D0(c); RELOAD();
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)) & (uint32_t)0x0u), &f)));
    edx = (uint32_t)((uint32_t)0xA000000u);
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003556u; SPILL(); f_A0034B0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A003598;
    goto L_A00355B;
L_A00355B:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(sub32(eax, edx, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003567u; SPILL(); f_A0034F0(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A003598;
    goto L_A00356D;
L_A00356D:
    eax = (uint32_t)(TL32((uint32_t)(eax + 0x24u)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1Fu, &f));
    eax = (uint32_t)(~eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    goto L_A0035A1;
L_A003598:
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    eax = (uint32_t)(logic32(0, &f));
L_A0035A1:
    esp -= 4; M32(esp) = 0xA0035A6u; SPILL(); f_A003615(c); RELOAD();
    esp += 4; SPILL(); return;
}

void f_A003581(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003581:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(logic32(0, &f));
    (void)sub32(eax, (uint32_t)0xC0000005u, &f);
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(f.zf);
    eax = (uint32_t)(ecx);
    esp += 4; SPILL(); return;
}

void f_A003595(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003595:
    esp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFE8u)));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    eax = (uint32_t)(logic32(0, &f));
    esp -= 4; M32(esp) = 0xA0035A6u; SPILL(); f_A003615(c); RELOAD();
    esp += 4; SPILL(); return;
}

void f_A0035AC(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0035AC:
    { SPILL(); rt_call(c, M32(0xA00104Cu)); return; }
}

void f_A0035B8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0035B8:
    { SPILL(); rt_call(c, M32(0xA001048u)); return; }
}

void f_A0035C3(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0035C3:
    eax = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(inc32(eax, &f));
    esp += 16; SPILL(); return;
}

void f_A0035D0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0035D0:
    { uint32_t v_ = 0xA00362Eu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(0x0u + c->fs_base)); esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    M32((uint32_t)(esp + 0x10u)) = (uint32_t)(ebp);
    ebp = (uint32_t)((uint32_t)(esp + 0x10u));
    esp = (uint32_t)(sub32(esp, eax, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0xA004000u)));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)) ^ eax), &f)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebp + 0xFFFFFFE8u), (uint32_t)(esp));
    { uint32_t v_ = TL32((uint32_t)(ebp + 0xFFFFFFF8u)); esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(ebp + 0xFFFFFFFCu), (uint32_t)((uint32_t)0xFFFFFFFEu));
    TS32((uint32_t)(ebp + 0xFFFFFFF8u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    M32((uint32_t)(0x0u + c->fs_base)) = (uint32_t)(eax);
    esp += 4; SPILL(); return;
}

void f_A003615(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003615:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF0u)));
    M32((uint32_t)(0x0u + c->fs_base)) = (uint32_t)(ecx);
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp += 4; SPILL(); return;
}

void f_A00362E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00362E:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x14u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA0031A1u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA004000u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00364Eu; SPILL(); f_A003310(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A003658(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003658:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x10u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0xA004000u)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)) & (uint32_t)0x0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(logic32((uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)) & (uint32_t)0x0u), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)((uint32_t)0xBB40E64Eu);
    (void)sub32(eax, edi, &f);
    if (f.zf) goto L_A003687;
    goto L_A003677;
L_A003677:
    (void)logic32((uint32_t)(eax & (uint32_t)0xFFFF0000u), &f);
    if (f.zf) goto L_A003687;
    goto L_A00367E;
L_A00367E:
    eax = (uint32_t)(~eax);
    TS32((uint32_t)(0xA004004u), (uint32_t)(eax));
    goto L_A0036DA;
L_A003687:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001014u)); esp -= 4; M32(esp) = 0xA003692u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    esi = (uint32_t)(logic32((uint32_t)(esi ^ M32((uint32_t)(ebp + 0xFFFFFFF8u))), &f));
    { uint32_t t_ = TL32((uint32_t)(0xA001018u)); esp -= 4; M32(esp) = 0xA00369Eu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(logic32((uint32_t)(esi ^ eax), &f));
    { uint32_t t_ = TL32((uint32_t)(0xA001000u)); esp -= 4; M32(esp) = 0xA0036A6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(logic32((uint32_t)(esi ^ eax), &f));
    { uint32_t t_ = TL32((uint32_t)(0xA001020u)); esp -= 4; M32(esp) = 0xA0036AEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(logic32((uint32_t)(esi ^ eax), &f));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001024u)); esp -= 4; M32(esp) = 0xA0036BAu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ M32((uint32_t)(ebp + 0xFFFFFFF0u))), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi ^ eax), &f));
    (void)sub32(esi, edi, &f);
    if (!f.zf) goto L_A0036CB;
    goto L_A0036C6;
L_A0036C6:
    esi = (uint32_t)((uint32_t)0xBB40E64Fu);
L_A0036CB:
    TS32((uint32_t)(0xA004000u), (uint32_t)(esi));
    esi = (uint32_t)(~esi);
    TS32((uint32_t)(0xA004004u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
L_A0036DA:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    esp = ebp; ebp = M32(esp); esp += 4;
    esp += 4; SPILL(); return;
}

