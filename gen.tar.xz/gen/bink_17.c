#include "funcs_bink.h"
#include "lift_prelude.h"

void f_901C4B6(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_901C4B6;
L_901AA9D:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE90u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAB7u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAD4u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFB68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(ebp + 0xFFFFFDCCu)); esp -= 4; M32(esp) = 0x901AAF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB0Du; SPILL(); f_9019D10(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF2Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB2Au; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB47u; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFF90u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB79u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB96u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901ABB3u; SPILL(); f_9019AF0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901ABC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDDCu)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABD7;
L_901ABD7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE90u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE94u)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABE9;
L_901ABE9:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE90u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFE90u)), &f)));
    (void)sub32(edx, (uint32_t)0x9u, &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901ABFB;
L_901ABFB:
    { jt_ = TL32((uint32_t)(edx*4 + 0x901CAB8u)); goto L_dispatch; }
L_901AC02:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(TL32((uint32_t)(ebx + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901ACB4;
    goto L_901ACA0;
L_901ACA0:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    (void)sub8(TL8((uint32_t)(ecx + edx)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901ACBA;
    goto L_901ACB4;
L_901ACB4:
    TS32((uint32_t)(ebp + 0xFFFFFDD0u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFDD0u)), &f)));
L_901ACBA:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901ACC6:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
L_901ACC9:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    ecx = (uint32_t)((uint32_t)0x8u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
L_901ACE5:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    if (!f.zf) goto L_901ABC5;
    goto L_901ACF8;
L_901ACF8:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDBCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), eax, &f)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD13;
L_901AD13:
    (void)sub32(TL32((uint32_t)(ebx + 0x24u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901AD22;
    goto L_901AD19;
L_901AD19:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD22;
L_901AD22:
    TS32((uint32_t)(ebp + 0xFFFFFDECu), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDECu)), eax, &f)));
L_901AD28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)(eax));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x10u)), &f);
    if (f.cf) goto L_901AA9D;
    goto L_901AD4A;
L_901AD4A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDC0u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    goto L_901CA9E;
L_901AD5D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901AD6A;
L_901AD6A:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (!f.zf) goto L_901BE76;
    goto L_901AD77;
L_901AD77:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE5Cu)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE60u)), &f);
    if (!f.cf) goto L_901BE76;
    goto L_901AD89;
L_901AD89:
    ecx = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE5Cu), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_901BE76;
    goto L_901AD9F;
L_901AD9F:
    { jt_ = TL32((uint32_t)(ecx*4 + 0x901CAE0u)); goto L_dispatch; }
L_901ADA6:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901ADB8;
L_901ADB8:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901AE19;
    goto L_901ADCF;
L_901ADCF:
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Cu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    goto L_901AE36;
L_901AE19:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
L_901AE36:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901AE53;
    goto L_901AE4A;
L_901AE4A:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AE53:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901AE6A;
    goto L_901AE61;
L_901AE61:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
L_901AE6A:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)((uint32_t)0x40u));
    goto L_901AE86;
L_901AE80:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901AE86:
    edi = (uint32_t)(TL8((uint32_t)(ecx)));
    edi = (uint32_t)(inc32(edi, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(edi, TL32((uint32_t)(ebp + 0xFFFFFDF8u)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(ecx));
    if ((!f.zf && f.sf == f.of)) goto L_901AF6B;
    goto L_901AE9D;
L_901AE9D:
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), edi, &f)));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901AED5;
    goto L_901AEAC;
L_901AEAC:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE10u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901AEED;
L_901AED5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(shr32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
L_901AEED:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFE1Cu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901AF31;
    goto L_901AEF6;
L_901AEF6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + 0xFFFFFDDBu), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF06;
L_901AF06:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDDBu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF06;
    goto L_901AF2F;
L_901AF2F:
    goto L_901AF5E;
L_901AF31:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF35;
L_901AF35:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF35;
    goto L_901AF5E;
L_901AF5E:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901AE80;
    goto L_901AF6B;
L_901AF6B:
    (void)sub32(edx, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901AF87;
    goto L_901AF70;
L_901AF70:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AF87:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFD74u));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901AFAB:
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFCu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x2u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x6u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x8u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xAu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xCu)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x10u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x12u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x14u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x16u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x18u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x1Au)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901AFAB;
    goto L_901B2D6;
L_901B2D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(ecx));
    goto L_901BE70;
L_901B2FF:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B311;
L_901B311:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901B328;
    goto L_901B31F;
L_901B31F:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901B328:
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)ecx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    esp -= 4; M32(esp) = 0x901B34Du; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901B398;
    goto L_901B358;
L_901B358:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901B3B5;
L_901B398:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901B3B5:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901B3CDu; SPILL(); f_90247D0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901BE76;
L_901B3D8:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B3EA;
L_901B3EA:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B3F8;
    goto L_901B3EF;
L_901B3EF:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B3F8:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    goto L_901BE70;
L_901B51B:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B52D;
L_901B52D:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B53B;
    goto L_901B532;
L_901B532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B53B:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901B579;
    goto L_901B573;
L_901B573:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901B579:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
    goto L_901B5A3;
L_901B5A0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
L_901B5A3:
    edi = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    if (!f.zf) goto L_901B5A0;
    goto L_901BA3B;
L_901BA3B:
    goto L_901BE70;
L_901BA40:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BA52;
L_901BA52:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    edx = (uint32_t)((uint32_t)(esi + ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901BA6F;
    goto L_901BA66;
L_901BA66:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901BA6F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f);
    if (f.zf) goto L_901BB72;
    goto L_901BA77;
L_901BA77:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x8u));
    esp = (uint32_t)((uint32_t)(esp));
L_901BA90:
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x3u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x5u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x7u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    if (!f.zf) goto L_901BA90;
    goto L_901BB6D;
L_901BB6D:
    goto L_901BE70;
L_901BB72:
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901BB7C:
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901BB7C;
    goto L_901BE70;
L_901BE70:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901BE76:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebx + 0x24u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    goto L_901ACE5;
L_901BEBE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901BEF9;
    goto L_901BEDE;
L_901BEDE:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901BEF9:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BF2E;
L_901BF2E:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901BF3A;
L_901BF3A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    goto L_901ACBA;
L_901BFCB:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C010;
    goto L_901BFDC;
L_901BFDC:
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    edx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    goto L_901C027;
L_901C010:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
L_901C027:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C04A;
    goto L_901C041;
L_901C041:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C04A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901C061;
    goto L_901C058;
L_901C058:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901C061:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(logic32(0, &f));
    TS8((uint32_t)(ecx + esi), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)((uint32_t)(edi + 0x40u));
    goto L_901C086;
L_901C080:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901C086:
    esi = (uint32_t)(TL8((uint32_t)(edx)));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(esi, ecx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(edx));
    if ((!f.zf && f.sf == f.of)) goto L_901C139;
    goto L_901C099;
L_901C099:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    if (!f.zf) goto L_901C0CB;
    goto L_901C0AA;
L_901C0AA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901C0DB;
L_901C0CB:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), &f)));
L_901C0DB:
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901C109;
    goto L_901C0E6;
L_901C0E6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C0F0;
L_901C0F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + edx)));
    esi = (uint32_t)(dec32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C0F0;
    goto L_901C107;
L_901C107:
    goto L_901C12A;
L_901C109:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C10D;
L_901C10D:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C10D;
    goto L_901C12A;
L_901C12A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901C080;
    goto L_901C139;
L_901C139:
    (void)sub32(edi, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901C155;
    goto L_901C13E;
L_901C13E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C155:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD70u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD74u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD78u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD7Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD80u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD84u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD88u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD8Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD90u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD94u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD98u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD9Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA0u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA8u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDACu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(edx));
    goto L_901ACBA;
L_901C229:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C264;
    goto L_901C249;
L_901C249:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C264:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C299;
L_901C299:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C2A5;
L_901C2A5:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(edx, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_901C2F0;
    goto L_901C2B0;
L_901C2B0:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x19u, &f)));
    ecx = (uint32_t)(edx);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x7u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    goto L_901C305;
L_901C2F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x7u, &f)));
L_901C305:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x901C31Cu; SPILL(); f_9025E00(c); RELOAD();
    goto L_901ACBA;
L_901C321:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901C34A;
    goto L_901C341;
L_901C341:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C34A:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C36Fu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C3BA;
    goto L_901C37A;
L_901C37A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901C3D7;
L_901C3BA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901C3D7:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C3EDu; SPILL(); f_90244C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901ACC6;
L_901C3F5:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C403;
    goto L_901C3FA;
L_901C3FA:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C403:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    eax = (uint32_t)(inc32(eax, &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    goto L_901ACC9;
L_901C4B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C4F1;
    goto L_901C4D6;
L_901C4D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C4F1:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C526;
L_901C526:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C532;
L_901C532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE28u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFE2Cu)), &f);
    if (f.cf) goto L_901C549;
    goto L_901C540;
L_901C540:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE58u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C549:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE28u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C56Eu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C5D1;
    goto L_901C579;
L_901C579:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C5CCu; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C5D1:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(ecx);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x901C603u; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C608:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C616;
    goto L_901C60D;
L_901C60D:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C616:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + edi), (uint8_t)((uint8_t)0x1u));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901C675;
    goto L_901C66C;
L_901C66C:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
L_901C675:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi), (uint32_t)(edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x3u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x5u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x7u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(esi + edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFF94u)), (uint32_t)0x8u, &f)));
    TS32((uint32_t)(esi + ecx + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    goto L_901ACC9;
L_901C9CE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C9F4;
    goto L_901C9EB;
L_901C9EB:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(edx));
L_901C9F4:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x40u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    goto L_901ACC9;
L_901CA9E:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901CAB0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x901AA9Du: goto L_901AA9D; case 0x901ABC5u: goto L_901ABC5; case 0x901ABD7u: goto L_901ABD7; case 0x901ABE9u: goto L_901ABE9; case 0x901ABFBu: goto L_901ABFB; case 0x901AC02u: goto L_901AC02; case 0x901ACA0u: goto L_901ACA0; case 0x901ACB4u: goto L_901ACB4; case 0x901ACBAu: goto L_901ACBA; case 0x901ACC6u: goto L_901ACC6; case 0x901ACC9u: goto L_901ACC9; case 0x901ACE5u: goto L_901ACE5; case 0x901ACF8u: goto L_901ACF8; case 0x901AD13u: goto L_901AD13; case 0x901AD19u: goto L_901AD19; case 0x901AD22u: goto L_901AD22; case 0x901AD28u: goto L_901AD28; case 0x901AD4Au: goto L_901AD4A; case 0x901AD5Du: goto L_901AD5D; case 0x901AD6Au: goto L_901AD6A; case 0x901AD77u: goto L_901AD77; case 0x901AD89u: goto L_901AD89; case 0x901AD9Fu: goto L_901AD9F; case 0x901ADA6u: goto L_901ADA6; case 0x901ADB8u: goto L_901ADB8; case 0x901ADCFu: goto L_901ADCF; case 0x901AE19u: goto L_901AE19; case 0x901AE36u: goto L_901AE36; case 0x901AE4Au: goto L_901AE4A; case 0x901AE53u: goto L_901AE53; case 0x901AE61u: goto L_901AE61; case 0x901AE6Au: goto L_901AE6A; case 0x901AE80u: goto L_901AE80; case 0x901AE86u: goto L_901AE86; case 0x901AE9Du: goto L_901AE9D; case 0x901AEACu: goto L_901AEAC; case 0x901AED5u: goto L_901AED5; case 0x901AEEDu: goto L_901AEED; case 0x901AEF6u: goto L_901AEF6; case 0x901AF06u: goto L_901AF06; case 0x901AF2Fu: goto L_901AF2F; case 0x901AF31u: goto L_901AF31; case 0x901AF35u: goto L_901AF35; case 0x901AF5Eu: goto L_901AF5E; case 0x901AF6Bu: goto L_901AF6B; case 0x901AF70u: goto L_901AF70; case 0x901AF87u: goto L_901AF87; case 0x901AFABu: goto L_901AFAB; case 0x901B2D6u: goto L_901B2D6; case 0x901B2FFu: goto L_901B2FF; case 0x901B311u: goto L_901B311; case 0x901B31Fu: goto L_901B31F; case 0x901B328u: goto L_901B328; case 0x901B358u: goto L_901B358; case 0x901B398u: goto L_901B398; case 0x901B3B5u: goto L_901B3B5; case 0x901B3D8u: goto L_901B3D8; case 0x901B3EAu: goto L_901B3EA; case 0x901B3EFu: goto L_901B3EF; case 0x901B3F8u: goto L_901B3F8; case 0x901B51Bu: goto L_901B51B; case 0x901B52Du: goto L_901B52D; case 0x901B532u: goto L_901B532; case 0x901B53Bu: goto L_901B53B; case 0x901B573u: goto L_901B573; case 0x901B579u: goto L_901B579; case 0x901B5A0u: goto L_901B5A0; case 0x901B5A3u: goto L_901B5A3; case 0x901BA3Bu: goto L_901BA3B; case 0x901BA40u: goto L_901BA40; case 0x901BA52u: goto L_901BA52; case 0x901BA66u: goto L_901BA66; case 0x901BA6Fu: goto L_901BA6F; case 0x901BA77u: goto L_901BA77; case 0x901BA90u: goto L_901BA90; case 0x901BB6Du: goto L_901BB6D; case 0x901BB72u: goto L_901BB72; case 0x901BB7Cu: goto L_901BB7C; case 0x901BE70u: goto L_901BE70; case 0x901BE76u: goto L_901BE76; case 0x901BEBEu: goto L_901BEBE; case 0x901BEDEu: goto L_901BEDE; case 0x901BEF9u: goto L_901BEF9; case 0x901BF2Eu: goto L_901BF2E; case 0x901BF3Au: goto L_901BF3A; case 0x901BFCBu: goto L_901BFCB; case 0x901BFDCu: goto L_901BFDC; case 0x901C010u: goto L_901C010; case 0x901C027u: goto L_901C027; case 0x901C041u: goto L_901C041; case 0x901C04Au: goto L_901C04A; case 0x901C058u: goto L_901C058; case 0x901C061u: goto L_901C061; case 0x901C080u: goto L_901C080; case 0x901C086u: goto L_901C086; case 0x901C099u: goto L_901C099; case 0x901C0AAu: goto L_901C0AA; case 0x901C0CBu: goto L_901C0CB; case 0x901C0DBu: goto L_901C0DB; case 0x901C0E6u: goto L_901C0E6; case 0x901C0F0u: goto L_901C0F0; case 0x901C107u: goto L_901C107; case 0x901C109u: goto L_901C109; case 0x901C10Du: goto L_901C10D; case 0x901C12Au: goto L_901C12A; case 0x901C139u: goto L_901C139; case 0x901C13Eu: goto L_901C13E; case 0x901C155u: goto L_901C155; case 0x901C229u: goto L_901C229; case 0x901C249u: goto L_901C249; case 0x901C264u: goto L_901C264; case 0x901C299u: goto L_901C299; case 0x901C2A5u: goto L_901C2A5; case 0x901C2B0u: goto L_901C2B0; case 0x901C2F0u: goto L_901C2F0; case 0x901C305u: goto L_901C305; case 0x901C321u: goto L_901C321; case 0x901C341u: goto L_901C341; case 0x901C34Au: goto L_901C34A; case 0x901C37Au: goto L_901C37A; case 0x901C3BAu: goto L_901C3BA; case 0x901C3D7u: goto L_901C3D7; case 0x901C3F5u: goto L_901C3F5; case 0x901C3FAu: goto L_901C3FA; case 0x901C403u: goto L_901C403; case 0x901C4B6u: goto L_901C4B6; case 0x901C4D6u: goto L_901C4D6; case 0x901C4F1u: goto L_901C4F1; case 0x901C526u: goto L_901C526; case 0x901C532u: goto L_901C532; case 0x901C540u: goto L_901C540; case 0x901C549u: goto L_901C549; case 0x901C579u: goto L_901C579; case 0x901C5D1u: goto L_901C5D1; case 0x901C608u: goto L_901C608; case 0x901C60Du: goto L_901C60D; case 0x901C616u: goto L_901C616; case 0x901C66Cu: goto L_901C66C; case 0x901C675u: goto L_901C675; case 0x901C9CEu: goto L_901C9CE; case 0x901C9EBu: goto L_901C9EB; case 0x901C9F4u: goto L_901C9F4; case 0x901CA9Eu: goto L_901CA9E; default: SPILL(); rt_call(c, jt_); return; }
}

void f_901C608(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_901C608;
L_901AA9D:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE90u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAB7u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAD4u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFB68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(ebp + 0xFFFFFDCCu)); esp -= 4; M32(esp) = 0x901AAF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB0Du; SPILL(); f_9019D10(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF2Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB2Au; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB47u; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFF90u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB79u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB96u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901ABB3u; SPILL(); f_9019AF0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901ABC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDDCu)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABD7;
L_901ABD7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE90u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE94u)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABE9;
L_901ABE9:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE90u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFE90u)), &f)));
    (void)sub32(edx, (uint32_t)0x9u, &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901ABFB;
L_901ABFB:
    { jt_ = TL32((uint32_t)(edx*4 + 0x901CAB8u)); goto L_dispatch; }
L_901AC02:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(TL32((uint32_t)(ebx + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901ACB4;
    goto L_901ACA0;
L_901ACA0:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    (void)sub8(TL8((uint32_t)(ecx + edx)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901ACBA;
    goto L_901ACB4;
L_901ACB4:
    TS32((uint32_t)(ebp + 0xFFFFFDD0u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFDD0u)), &f)));
L_901ACBA:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901ACC6:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
L_901ACC9:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    ecx = (uint32_t)((uint32_t)0x8u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
L_901ACE5:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    if (!f.zf) goto L_901ABC5;
    goto L_901ACF8;
L_901ACF8:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDBCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), eax, &f)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD13;
L_901AD13:
    (void)sub32(TL32((uint32_t)(ebx + 0x24u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901AD22;
    goto L_901AD19;
L_901AD19:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD22;
L_901AD22:
    TS32((uint32_t)(ebp + 0xFFFFFDECu), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDECu)), eax, &f)));
L_901AD28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)(eax));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x10u)), &f);
    if (f.cf) goto L_901AA9D;
    goto L_901AD4A;
L_901AD4A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDC0u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    goto L_901CA9E;
L_901AD5D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901AD6A;
L_901AD6A:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (!f.zf) goto L_901BE76;
    goto L_901AD77;
L_901AD77:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE5Cu)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE60u)), &f);
    if (!f.cf) goto L_901BE76;
    goto L_901AD89;
L_901AD89:
    ecx = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE5Cu), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_901BE76;
    goto L_901AD9F;
L_901AD9F:
    { jt_ = TL32((uint32_t)(ecx*4 + 0x901CAE0u)); goto L_dispatch; }
L_901ADA6:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901ADB8;
L_901ADB8:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901AE19;
    goto L_901ADCF;
L_901ADCF:
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Cu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    goto L_901AE36;
L_901AE19:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
L_901AE36:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901AE53;
    goto L_901AE4A;
L_901AE4A:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AE53:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901AE6A;
    goto L_901AE61;
L_901AE61:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
L_901AE6A:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)((uint32_t)0x40u));
    goto L_901AE86;
L_901AE80:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901AE86:
    edi = (uint32_t)(TL8((uint32_t)(ecx)));
    edi = (uint32_t)(inc32(edi, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(edi, TL32((uint32_t)(ebp + 0xFFFFFDF8u)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(ecx));
    if ((!f.zf && f.sf == f.of)) goto L_901AF6B;
    goto L_901AE9D;
L_901AE9D:
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), edi, &f)));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901AED5;
    goto L_901AEAC;
L_901AEAC:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE10u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901AEED;
L_901AED5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(shr32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
L_901AEED:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFE1Cu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901AF31;
    goto L_901AEF6;
L_901AEF6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + 0xFFFFFDDBu), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF06;
L_901AF06:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDDBu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF06;
    goto L_901AF2F;
L_901AF2F:
    goto L_901AF5E;
L_901AF31:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF35;
L_901AF35:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF35;
    goto L_901AF5E;
L_901AF5E:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901AE80;
    goto L_901AF6B;
L_901AF6B:
    (void)sub32(edx, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901AF87;
    goto L_901AF70;
L_901AF70:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AF87:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFD74u));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901AFAB:
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFCu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x2u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x6u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x8u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xAu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xCu)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x10u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x12u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x14u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x16u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x18u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x1Au)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901AFAB;
    goto L_901B2D6;
L_901B2D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(ecx));
    goto L_901BE70;
L_901B2FF:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B311;
L_901B311:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901B328;
    goto L_901B31F;
L_901B31F:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901B328:
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)ecx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    esp -= 4; M32(esp) = 0x901B34Du; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901B398;
    goto L_901B358;
L_901B358:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901B3B5;
L_901B398:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901B3B5:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901B3CDu; SPILL(); f_90247D0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901BE76;
L_901B3D8:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B3EA;
L_901B3EA:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B3F8;
    goto L_901B3EF;
L_901B3EF:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B3F8:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    goto L_901BE70;
L_901B51B:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B52D;
L_901B52D:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B53B;
    goto L_901B532;
L_901B532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B53B:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901B579;
    goto L_901B573;
L_901B573:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901B579:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
    goto L_901B5A3;
L_901B5A0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
L_901B5A3:
    edi = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    if (!f.zf) goto L_901B5A0;
    goto L_901BA3B;
L_901BA3B:
    goto L_901BE70;
L_901BA40:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BA52;
L_901BA52:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    edx = (uint32_t)((uint32_t)(esi + ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901BA6F;
    goto L_901BA66;
L_901BA66:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901BA6F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f);
    if (f.zf) goto L_901BB72;
    goto L_901BA77;
L_901BA77:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x8u));
    esp = (uint32_t)((uint32_t)(esp));
L_901BA90:
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x3u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x5u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x7u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    if (!f.zf) goto L_901BA90;
    goto L_901BB6D;
L_901BB6D:
    goto L_901BE70;
L_901BB72:
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901BB7C:
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901BB7C;
    goto L_901BE70;
L_901BE70:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901BE76:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebx + 0x24u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    goto L_901ACE5;
L_901BEBE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901BEF9;
    goto L_901BEDE;
L_901BEDE:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901BEF9:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BF2E;
L_901BF2E:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901BF3A;
L_901BF3A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    goto L_901ACBA;
L_901BFCB:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C010;
    goto L_901BFDC;
L_901BFDC:
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    edx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    goto L_901C027;
L_901C010:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
L_901C027:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C04A;
    goto L_901C041;
L_901C041:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C04A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901C061;
    goto L_901C058;
L_901C058:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901C061:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(logic32(0, &f));
    TS8((uint32_t)(ecx + esi), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)((uint32_t)(edi + 0x40u));
    goto L_901C086;
L_901C080:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901C086:
    esi = (uint32_t)(TL8((uint32_t)(edx)));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(esi, ecx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(edx));
    if ((!f.zf && f.sf == f.of)) goto L_901C139;
    goto L_901C099;
L_901C099:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    if (!f.zf) goto L_901C0CB;
    goto L_901C0AA;
L_901C0AA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901C0DB;
L_901C0CB:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), &f)));
L_901C0DB:
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901C109;
    goto L_901C0E6;
L_901C0E6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C0F0;
L_901C0F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + edx)));
    esi = (uint32_t)(dec32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C0F0;
    goto L_901C107;
L_901C107:
    goto L_901C12A;
L_901C109:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C10D;
L_901C10D:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C10D;
    goto L_901C12A;
L_901C12A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901C080;
    goto L_901C139;
L_901C139:
    (void)sub32(edi, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901C155;
    goto L_901C13E;
L_901C13E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C155:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD70u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD74u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD78u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD7Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD80u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD84u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD88u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD8Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD90u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD94u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD98u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD9Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA0u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA8u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDACu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(edx));
    goto L_901ACBA;
L_901C229:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C264;
    goto L_901C249;
L_901C249:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C264:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C299;
L_901C299:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C2A5;
L_901C2A5:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(edx, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_901C2F0;
    goto L_901C2B0;
L_901C2B0:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x19u, &f)));
    ecx = (uint32_t)(edx);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x7u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    goto L_901C305;
L_901C2F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x7u, &f)));
L_901C305:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x901C31Cu; SPILL(); f_9025E00(c); RELOAD();
    goto L_901ACBA;
L_901C321:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901C34A;
    goto L_901C341;
L_901C341:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C34A:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C36Fu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C3BA;
    goto L_901C37A;
L_901C37A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901C3D7;
L_901C3BA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901C3D7:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C3EDu; SPILL(); f_90244C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901ACC6;
L_901C3F5:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C403;
    goto L_901C3FA;
L_901C3FA:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C403:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    eax = (uint32_t)(inc32(eax, &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    goto L_901ACC9;
L_901C4B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C4F1;
    goto L_901C4D6;
L_901C4D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C4F1:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C526;
L_901C526:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C532;
L_901C532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE28u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFE2Cu)), &f);
    if (f.cf) goto L_901C549;
    goto L_901C540;
L_901C540:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE58u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C549:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE28u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C56Eu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C5D1;
    goto L_901C579;
L_901C579:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C5CCu; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C5D1:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(ecx);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x901C603u; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C608:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C616;
    goto L_901C60D;
L_901C60D:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C616:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + edi), (uint8_t)((uint8_t)0x1u));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901C675;
    goto L_901C66C;
L_901C66C:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
L_901C675:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi), (uint32_t)(edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x3u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x5u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x7u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(esi + edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFF94u)), (uint32_t)0x8u, &f)));
    TS32((uint32_t)(esi + ecx + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    goto L_901ACC9;
L_901C9CE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C9F4;
    goto L_901C9EB;
L_901C9EB:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(edx));
L_901C9F4:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x40u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    goto L_901ACC9;
L_901CA9E:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901CAB0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x901AA9Du: goto L_901AA9D; case 0x901ABC5u: goto L_901ABC5; case 0x901ABD7u: goto L_901ABD7; case 0x901ABE9u: goto L_901ABE9; case 0x901ABFBu: goto L_901ABFB; case 0x901AC02u: goto L_901AC02; case 0x901ACA0u: goto L_901ACA0; case 0x901ACB4u: goto L_901ACB4; case 0x901ACBAu: goto L_901ACBA; case 0x901ACC6u: goto L_901ACC6; case 0x901ACC9u: goto L_901ACC9; case 0x901ACE5u: goto L_901ACE5; case 0x901ACF8u: goto L_901ACF8; case 0x901AD13u: goto L_901AD13; case 0x901AD19u: goto L_901AD19; case 0x901AD22u: goto L_901AD22; case 0x901AD28u: goto L_901AD28; case 0x901AD4Au: goto L_901AD4A; case 0x901AD5Du: goto L_901AD5D; case 0x901AD6Au: goto L_901AD6A; case 0x901AD77u: goto L_901AD77; case 0x901AD89u: goto L_901AD89; case 0x901AD9Fu: goto L_901AD9F; case 0x901ADA6u: goto L_901ADA6; case 0x901ADB8u: goto L_901ADB8; case 0x901ADCFu: goto L_901ADCF; case 0x901AE19u: goto L_901AE19; case 0x901AE36u: goto L_901AE36; case 0x901AE4Au: goto L_901AE4A; case 0x901AE53u: goto L_901AE53; case 0x901AE61u: goto L_901AE61; case 0x901AE6Au: goto L_901AE6A; case 0x901AE80u: goto L_901AE80; case 0x901AE86u: goto L_901AE86; case 0x901AE9Du: goto L_901AE9D; case 0x901AEACu: goto L_901AEAC; case 0x901AED5u: goto L_901AED5; case 0x901AEEDu: goto L_901AEED; case 0x901AEF6u: goto L_901AEF6; case 0x901AF06u: goto L_901AF06; case 0x901AF2Fu: goto L_901AF2F; case 0x901AF31u: goto L_901AF31; case 0x901AF35u: goto L_901AF35; case 0x901AF5Eu: goto L_901AF5E; case 0x901AF6Bu: goto L_901AF6B; case 0x901AF70u: goto L_901AF70; case 0x901AF87u: goto L_901AF87; case 0x901AFABu: goto L_901AFAB; case 0x901B2D6u: goto L_901B2D6; case 0x901B2FFu: goto L_901B2FF; case 0x901B311u: goto L_901B311; case 0x901B31Fu: goto L_901B31F; case 0x901B328u: goto L_901B328; case 0x901B358u: goto L_901B358; case 0x901B398u: goto L_901B398; case 0x901B3B5u: goto L_901B3B5; case 0x901B3D8u: goto L_901B3D8; case 0x901B3EAu: goto L_901B3EA; case 0x901B3EFu: goto L_901B3EF; case 0x901B3F8u: goto L_901B3F8; case 0x901B51Bu: goto L_901B51B; case 0x901B52Du: goto L_901B52D; case 0x901B532u: goto L_901B532; case 0x901B53Bu: goto L_901B53B; case 0x901B573u: goto L_901B573; case 0x901B579u: goto L_901B579; case 0x901B5A0u: goto L_901B5A0; case 0x901B5A3u: goto L_901B5A3; case 0x901BA3Bu: goto L_901BA3B; case 0x901BA40u: goto L_901BA40; case 0x901BA52u: goto L_901BA52; case 0x901BA66u: goto L_901BA66; case 0x901BA6Fu: goto L_901BA6F; case 0x901BA77u: goto L_901BA77; case 0x901BA90u: goto L_901BA90; case 0x901BB6Du: goto L_901BB6D; case 0x901BB72u: goto L_901BB72; case 0x901BB7Cu: goto L_901BB7C; case 0x901BE70u: goto L_901BE70; case 0x901BE76u: goto L_901BE76; case 0x901BEBEu: goto L_901BEBE; case 0x901BEDEu: goto L_901BEDE; case 0x901BEF9u: goto L_901BEF9; case 0x901BF2Eu: goto L_901BF2E; case 0x901BF3Au: goto L_901BF3A; case 0x901BFCBu: goto L_901BFCB; case 0x901BFDCu: goto L_901BFDC; case 0x901C010u: goto L_901C010; case 0x901C027u: goto L_901C027; case 0x901C041u: goto L_901C041; case 0x901C04Au: goto L_901C04A; case 0x901C058u: goto L_901C058; case 0x901C061u: goto L_901C061; case 0x901C080u: goto L_901C080; case 0x901C086u: goto L_901C086; case 0x901C099u: goto L_901C099; case 0x901C0AAu: goto L_901C0AA; case 0x901C0CBu: goto L_901C0CB; case 0x901C0DBu: goto L_901C0DB; case 0x901C0E6u: goto L_901C0E6; case 0x901C0F0u: goto L_901C0F0; case 0x901C107u: goto L_901C107; case 0x901C109u: goto L_901C109; case 0x901C10Du: goto L_901C10D; case 0x901C12Au: goto L_901C12A; case 0x901C139u: goto L_901C139; case 0x901C13Eu: goto L_901C13E; case 0x901C155u: goto L_901C155; case 0x901C229u: goto L_901C229; case 0x901C249u: goto L_901C249; case 0x901C264u: goto L_901C264; case 0x901C299u: goto L_901C299; case 0x901C2A5u: goto L_901C2A5; case 0x901C2B0u: goto L_901C2B0; case 0x901C2F0u: goto L_901C2F0; case 0x901C305u: goto L_901C305; case 0x901C321u: goto L_901C321; case 0x901C341u: goto L_901C341; case 0x901C34Au: goto L_901C34A; case 0x901C37Au: goto L_901C37A; case 0x901C3BAu: goto L_901C3BA; case 0x901C3D7u: goto L_901C3D7; case 0x901C3F5u: goto L_901C3F5; case 0x901C3FAu: goto L_901C3FA; case 0x901C403u: goto L_901C403; case 0x901C4B6u: goto L_901C4B6; case 0x901C4D6u: goto L_901C4D6; case 0x901C4F1u: goto L_901C4F1; case 0x901C526u: goto L_901C526; case 0x901C532u: goto L_901C532; case 0x901C540u: goto L_901C540; case 0x901C549u: goto L_901C549; case 0x901C579u: goto L_901C579; case 0x901C5D1u: goto L_901C5D1; case 0x901C608u: goto L_901C608; case 0x901C60Du: goto L_901C60D; case 0x901C616u: goto L_901C616; case 0x901C66Cu: goto L_901C66C; case 0x901C675u: goto L_901C675; case 0x901C9CEu: goto L_901C9CE; case 0x901C9EBu: goto L_901C9EB; case 0x901C9F4u: goto L_901C9F4; case 0x901CA9Eu: goto L_901CA9E; default: SPILL(); rt_call(c, jt_); return; }
}

void f_901C9CE(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_901C9CE;
L_901AA9D:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE90u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAB7u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE5Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AAD4u; SPILL(); f_9019360(c); RELOAD();
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFB68u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(ebp + 0xFFFFFDCCu)); esp -= 4; M32(esp) = 0x901AAF6u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF94u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB0Du; SPILL(); f_9019D10(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF2Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB2Au; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFF60u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB47u; SPILL(); f_9019F00(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    eax = (uint32_t)(sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFF90u)), &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(add32(eax, TL32((uint32_t)(ebp + 0xFFFFFF5Cu)), &f));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB79u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFE28u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901AB96u; SPILL(); f_901A160(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDDCu)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901ABB3u; SPILL(); f_9019AF0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD4u)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
L_901ABC5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDDCu)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABD7;
L_901ABD7:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE90u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE94u)), &f);
    if (!f.cf) goto L_901ACC9;
    goto L_901ABE9;
L_901ABE9:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE90u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFE90u)), &f)));
    (void)sub32(edx, (uint32_t)0x9u, &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901ABFB;
L_901ABFB:
    { jt_ = TL32((uint32_t)(edx*4 + 0x901CAB8u)); goto L_dispatch; }
L_901AC02:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    (void)sub32(TL32((uint32_t)(ebx + 0x20u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901ACB4;
    goto L_901ACA0;
L_901ACA0:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    (void)sub8(TL8((uint32_t)(ecx + edx)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901ACBA;
    goto L_901ACB4;
L_901ACB4:
    TS32((uint32_t)(ebp + 0xFFFFFDD0u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFDD0u)), &f)));
L_901ACBA:
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901ACC6:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
L_901ACC9:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    ecx = (uint32_t)((uint32_t)0x8u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
L_901ACE5:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    if (!f.zf) goto L_901ABC5;
    goto L_901ACF8;
L_901ACF8:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDBCu)));
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), eax, &f)));
    edi = (uint32_t)(add32(edi, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x20u)));
    TS32((uint32_t)(ebp + 0xFFFFFE0Cu), (uint32_t)(edi));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD13;
L_901AD13:
    (void)sub32(TL32((uint32_t)(ebx + 0x24u)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_901AD22;
    goto L_901AD19;
L_901AD19:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_901AD28;
    goto L_901AD22;
L_901AD22:
    TS32((uint32_t)(ebp + 0xFFFFFDECu), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDECu)), eax, &f)));
L_901AD28:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF0u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)((uint32_t)0x0u));
    TS32((uint32_t)(ebp + 0xFFFFFDF0u), (uint32_t)(eax));
    (void)sub32(eax, TL32((uint32_t)(ebx + 0x10u)), &f);
    if (f.cf) goto L_901AA9D;
    goto L_901AD4A;
L_901AD4A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDD0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDC0u)));
    TS32((uint32_t)(eax), (uint32_t)(edx));
    goto L_901CA9E;
L_901AD5D:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901AD6A;
L_901AD6A:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDF0u)) & (uint8_t)0x8u), &f);
    if (!f.zf) goto L_901BE76;
    goto L_901AD77;
L_901AD77:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE5Cu)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFE60u)), &f);
    if (!f.cf) goto L_901BE76;
    goto L_901AD89;
L_901AD89:
    ecx = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    ecx = (uint32_t)(sub32(ecx, (uint32_t)0x3u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE5Cu), (uint32_t)(edx));
    (void)sub32(ecx, (uint32_t)0x6u, &f);
    if ((!f.cf && !f.zf)) goto L_901BE76;
    goto L_901AD9F;
L_901AD9F:
    { jt_ = TL32((uint32_t)(ecx*4 + 0x901CAE0u)); goto L_dispatch; }
L_901ADA6:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901ADB8;
L_901ADB8:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901AE19;
    goto L_901ADCF;
L_901ADCF:
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edi = (uint32_t)(shr32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1Cu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    goto L_901AE36;
L_901AE19:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
L_901AE36:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901AE53;
    goto L_901AE4A;
L_901AE4A:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AE53:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901AE6A;
    goto L_901AE61;
L_901AE61:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
L_901AE6A:
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)((uint32_t)0x40u));
    goto L_901AE86;
L_901AE80:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901AE86:
    edi = (uint32_t)(TL8((uint32_t)(ecx)));
    edi = (uint32_t)(inc32(edi, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(edi, TL32((uint32_t)(ebp + 0xFFFFFDF8u)), &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(ecx));
    if ((!f.zf && f.sf == f.of)) goto L_901AF6B;
    goto L_901AE9D;
L_901AE9D:
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), edi, &f)));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901AED5;
    goto L_901AEAC;
L_901AEAC:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE10u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901AEED;
L_901AED5:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(shr32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint8_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE14u)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
L_901AEED:
    (void)logic8((uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFE1Cu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901AF31;
    goto L_901AEF6;
L_901AEF6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + 0xFFFFFDDBu), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF06;
L_901AF06:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(ebp + 0xFFFFFDDBu)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF06;
    goto L_901AF2F;
L_901AF2F:
    goto L_901AF5E;
L_901AF31:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901AF5E;
    goto L_901AF35;
L_901AF35:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edi = (uint32_t)(dec32(edi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901AF35;
    goto L_901AF5E;
L_901AF5E:
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFDF8u)), (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901AE80;
    goto L_901AF6B;
L_901AF6B:
    (void)sub32(edx, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901AF87;
    goto L_901AF70;
L_901AF70:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901AF87:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(add32(ecx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFD74u));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901AFAB:
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFCu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xFFFFFFFEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x2u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x6u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x8u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xAu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xCu)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0xEu)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x10u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x12u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x14u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x16u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x18u)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL16((uint32_t)(ecx + 0x1Au)));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFF00u), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0xFFu), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x20u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901AFAB;
    goto L_901B2D6;
L_901B2D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(ecx));
    goto L_901BE70;
L_901B2FF:
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    edx = (uint32_t)(sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(edx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B311;
L_901B311:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901B328;
    goto L_901B31F;
L_901B31F:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901B328:
    ecx = (ecx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)ecx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    esp -= 4; M32(esp) = 0x901B34Du; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901B398;
    goto L_901B358;
L_901B358:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901B3B5;
L_901B398:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901B3B5:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901B3CDu; SPILL(); f_90247D0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901BE76;
L_901B3D8:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B3EA;
L_901B3EA:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B3F8;
    goto L_901B3EF;
L_901B3EF:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B3F8:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)((uint32_t)(esi + edx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0xCu), (uint32_t)(ecx));
    goto L_901BE70;
L_901B51B:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901B52D;
L_901B52D:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901B53B;
    goto L_901B532;
L_901B532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901B53B:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(ecx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edi), &f));
    edi = (uint32_t)(edx);
    edi = (uint32_t)(shl32(edi, (uint8_t)0x10u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901B579;
    goto L_901B573;
L_901B573:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901B579:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
    goto L_901B5A3;
L_901B5A0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
L_901B5A3:
    edi = (uint32_t)(TL8((uint32_t)(edx)));
    edx = (uint32_t)(inc32(edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(inc32(edi, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL8((uint32_t)(edi)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x2u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x3u), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C130u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & TL32((uint32_t)(ebp + 0xFFFFFE10u))), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C200u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(edx));
    edx = (uint32_t)((uint32_t)(esi + edi));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    if (!f.zf) goto L_901B5A0;
    goto L_901BA3B;
L_901BA3B:
    goto L_901BE70;
L_901BA40:
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x10u)));
    ecx = (uint32_t)(sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDF0u)), &f));
    (void)sub32(ecx, (uint32_t)0x10u, &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BA52;
L_901BA52:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    edx = (uint32_t)((uint32_t)(esi + ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901BA6F;
    goto L_901BA66;
L_901BA66:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901BA6F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x3u), &f);
    if (f.zf) goto L_901BB72;
    goto L_901BA77;
L_901BA77:
    edx = (uint32_t)(sub32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x8u));
    esp = (uint32_t)((uint32_t)(esp));
L_901BA90:
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x3u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x5u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + edx + 0x8u), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(ecx));
    ecx = (uint32_t)(TL8((uint32_t)(eax + 0x7u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE20u)));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | ecx), &f));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    if (!f.zf) goto L_901BA90;
    goto L_901BB6D;
L_901BB6D:
    goto L_901BE70;
L_901BB72:
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)((uint32_t)0x2u));
L_901BB7C:
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL16((uint32_t)(eax)));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x2u)));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x4u)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edx + 0x8u), (uint32_t)(ecx));
    edx = (uint32_t)(TL16((uint32_t)(eax + 0x6u)));
    TS32((uint32_t)(edi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFFFFFF00u), &f));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE20u), (uint32_t)(edx));
    edx = (uint32_t)(((uint8_t)edx));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    TS32((uint32_t)(edi + 0xCu), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0xCu), (uint32_t)(ecx));
    ecx = (uint32_t)((uint32_t)(esi + esi));
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    edx = (uint32_t)(add32(edx, ecx, &f));
    edi = (uint32_t)(add32(edi, ecx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)), (uint32_t)0x1u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    if (!f.zf) goto L_901BB7C;
    goto L_901BE70;
L_901BE70:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
L_901BE76:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)((uint32_t)0x10u);
    TS32((uint32_t)(ebp + 0xFFFFFDE4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDE4u)), ecx, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDE8u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFDE8u)), ecx, &f)));
    edi = (uint32_t)(add32(edi, ecx, &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(add32(ecx, TL32((uint32_t)(ebx + 0x24u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(ecx));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx + 0x24u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF4u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFDF4u)), ecx, &f)));
    goto L_901ACE5;
L_901BEBE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901BEF9;
    goto L_901BEDE;
L_901BEDE:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901BEF9:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901BF2E;
L_901BF2E:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901BF3A;
L_901BF3A:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    esi = (uint32_t)((uint32_t)(esi + ebp*2));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + ebp)));
    edx = (uint32_t)(TL32((uint32_t)(esi + ebp + 0x4u)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    goto L_901ACBA;
L_901BFCB:
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(edi, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C010;
    goto L_901BFDC;
L_901BFDC:
    esi = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(edi);
    edx = (uint32_t)(esi);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, edi, &f));
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edi = (uint32_t)(add32(edi, (uint32_t)0x1Cu, &f));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(esi));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    goto L_901C027;
L_901C010:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    edi = (uint32_t)(add32(edi, (uint32_t)0xFFFFFFFCu, &f));
L_901C027:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x6u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x90378C0u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C04A;
    goto L_901C041;
L_901C041:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C04A:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFEFCu)), &f);
    if (f.cf) goto L_901C061;
    goto L_901C058;
L_901C058:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF28u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
L_901C061:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edi = (uint32_t)(logic32(0, &f));
    TS8((uint32_t)(ecx + esi), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)((uint32_t)(edi + 0x40u));
    goto L_901C086;
L_901C080:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF8u)));
L_901C086:
    esi = (uint32_t)(TL8((uint32_t)(edx)));
    esi = (uint32_t)(inc32(esi, &f));
    edx = (uint32_t)(inc32(edx, &f));
    (void)sub32(esi, ecx, &f);
    TS32((uint32_t)(ebp + 0xFFFFFEF8u), (uint32_t)(edx));
    if ((!f.zf && f.sf == f.of)) goto L_901C139;
    goto L_901C099;
L_901C099:
    ecx = (uint32_t)(sub32(ecx, esi, &f));
    (void)sub32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), (uint32_t)0x0u, &f);
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(ecx));
    if (!f.zf) goto L_901C0CB;
    goto L_901C0AA;
L_901C0AA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)((uint32_t)0x1Fu));
    goto L_901C0DB;
L_901C0CB:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(dec32(TL32((uint32_t)(ebp + 0xFFFFFE18u)), &f)));
L_901C0DB:
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(ecx));
    (void)logic8((uint8_t)(((uint8_t)edx) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901C109;
    goto L_901C0E6;
L_901C0E6:
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C0F0;
L_901C0F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + edx)));
    esi = (uint32_t)(dec32(esi, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C0F0;
    goto L_901C107;
L_901C107:
    goto L_901C12A;
L_901C109:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901C12A;
    goto L_901C10D;
L_901C10D:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(TL8((uint32_t)(edi + ecx)));
    ecx = (ecx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    esi = (uint32_t)(dec32(esi, &f));
    eax = (uint32_t)(inc32(eax, &f));
    edi = (uint32_t)(inc32(edi, &f));
    TS8((uint32_t)(ebp + edx + 0xFFFFFD70u), (uint8_t)(((uint8_t)ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (!f.zf) goto L_901C10D;
    goto L_901C12A;
L_901C12A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    (void)sub32(ecx, (uint32_t)0x1u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901C080;
    goto L_901C139;
L_901C139:
    (void)sub32(edi, (uint32_t)0x3Fu, &f);
    if (!f.zf) goto L_901C155;
    goto L_901C13E;
L_901C13E:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    ecx = (uint32_t)(TL8((uint32_t)(edx + 0x3Fu)));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(eax)));
    eax = (uint32_t)(inc32(eax, &f));
    TS8((uint32_t)(ebp + ecx + 0xFFFFFD70u), (uint8_t)(((uint8_t)edx)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C155:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD70u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD74u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD78u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD7Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD80u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD84u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD88u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD8Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD90u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD94u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD98u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFD9Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + esi*2));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA0u)));
    ebx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDA8u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDACu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + esi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + esi + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(edx));
    goto L_901ACBA;
L_901C229:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C264;
    goto L_901C249;
L_901C249:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C264:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C299;
L_901C299:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C2A5;
L_901C2A5:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(edx, (uint32_t)0x7u, &f);
    if (!f.cf) goto L_901C2F0;
    goto L_901C2B0;
L_901C2B0:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    eax = (uint32_t)(TL32((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x19u, &f)));
    ecx = (uint32_t)(edx);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x7u);
    ecx = (uint32_t)(sub32(ecx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    eax = (uint32_t)(logic32((uint32_t)(eax | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    edx = (uint32_t)(shr32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    goto L_901C305;
L_901C2F0:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x7Fu), &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x7u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(sub32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x7u, &f)));
L_901C305:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(edx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    esp -= 4; M32(esp) = 0x901C31Cu; SPILL(); f_9025E00(c); RELOAD();
    goto L_901ACBA;
L_901C321:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    TS8((uint32_t)(eax + ecx), (uint8_t)((uint8_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEC4u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFEC8u)), &f);
    if (f.cf) goto L_901C34A;
    goto L_901C341;
L_901C341:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFEF4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C34A:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFEC4u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C36Fu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C3BA;
    goto L_901C37A;
L_901C37A:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    goto L_901C3D7;
L_901C3BA:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    edx = (uint32_t)(ecx);
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
L_901C3D7:
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x9037CC0u, &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C3EDu; SPILL(); f_90244C0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x8u, &f));
    goto L_901ACC6;
L_901C3F5:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C403;
    goto L_901C3FA;
L_901C3FA:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C403:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)((uint32_t)(esi + edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(esi + edi), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    eax = (uint32_t)(inc32(eax, &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(edi), (uint32_t)(ecx));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(edx), (uint32_t)(ecx));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx), (uint32_t)(ecx));
    TS32((uint32_t)(esi + edx + 0x4u), (uint32_t)(ecx));
    goto L_901ACC9;
L_901C4B6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(ecx + edx), (uint8_t)((uint8_t)0x1u));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF60u)));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFF64u)), &f);
    if (f.cf) goto L_901C4F1;
    goto L_901C4D6;
L_901C4D6:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF90u)));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF5Cu)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(ecx));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(edx));
L_901C4F1:
    edx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)esi; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)((uint32_t)(int8_t)TL8((uint32_t)(ecx)));
    edx = (uint32_t)(add32(edx, TL32((uint32_t)(ebp + 0xFFFFFDE4u)), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF2Cu), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF2Cu)), &f)));
    TS32((uint32_t)(ebp + 0xFFFFFF60u), (uint32_t)(inc32(TL32((uint32_t)(ebp + 0xFFFFFF60u)), &f)));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFDF8u), (uint32_t)(ecx));
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC8u)), &f);
    if (f.cf) goto L_901ACC9;
    goto L_901C526;
L_901C526:
    (void)sub32(ecx, TL32((uint32_t)(ebp + 0xFFFFFDC4u)), &f);
    if ((!f.cf && !f.zf)) goto L_901ACC9;
    goto L_901C532;
L_901C532:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE28u)));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFE2Cu)), &f);
    if (f.cf) goto L_901C549;
    goto L_901C540;
L_901C540:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE58u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
L_901C549:
    edx = (edx & 0xFFFF0000u) | (uint16_t)(TL16((uint32_t)(eax)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x2u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE28u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFDFCu));
    TS16((uint32_t)(ebp + 0xFFFFFCF0u), (uint16_t)(((uint16_t)edx)));
    esp -= 4; M32(esp) = 0x901C56Eu; SPILL(); f_9024EB0(c); RELOAD();
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE04u)));
    (void)sub32(eax, (uint32_t)0x4u, &f);
    if (!f.cf) goto L_901C5D1;
    goto L_901C579;
L_901C579:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    edx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE04u)), (uint32_t)0x1Cu, &f)));
    TS32((uint32_t)(ebp + 0xFFFFFE00u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFE00u)), (uint32_t)0x4u, &f)));
    ecx = (uint32_t)(eax);
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x4u);
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edx = (uint32_t)(logic32((uint32_t)(edx | TL32((uint32_t)(ebp + 0xFFFFFDFCu))), &f));
    eax = (uint32_t)(shr32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    esp -= 4; M32(esp) = 0x901C5CCu; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C5D1:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDFCu)));
    eax = (uint32_t)(sub32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE04u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF8u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(ecx);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCF0u));
    TS32((uint32_t)(ebp + 0xFFFFFDFCu), (uint32_t)(ecx));
    esp -= 4; M32(esp) = 0x901C603u; SPILL(); f_9024B50(c); RELOAD();
    goto L_901ACC6;
L_901C608:
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C616;
    goto L_901C60D;
L_901C60D:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
L_901C616:
    ecx = (uint32_t)(TL8((uint32_t)(eax)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    edx = (uint32_t)(TL8((uint32_t)(eax)));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS8((uint32_t)(edx + edi), (uint8_t)((uint8_t)0x1u));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE24u)));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(ecx);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x8u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    TS32((uint32_t)(ebp + 0xFFFFFE24u), (uint32_t)(edi));
    (void)sub32(edx, TL32((uint32_t)(ebp + 0xFFFFFF98u)), &f);
    if (f.cf) goto L_901C675;
    goto L_901C66C;
L_901C66C:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC4u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(edx));
L_901C675:
    edx = (uint32_t)(TL8((uint32_t)(edx)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(edi + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & ecx), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | edi), &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(edi);
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x1u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi), (uint32_t)(edi));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    TS32((uint32_t)(edx + esi + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edx = (uint32_t)(add32(edx, esi, &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x2u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x3u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x4u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE18u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x5u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(add32(edi, esi, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE10u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(edx + 0x903C180u)));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE18u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x6u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(edx + 0x4u), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFF94u)));
    edx = (uint32_t)(TL8((uint32_t)(edx + 0x7u)));
    TS32((uint32_t)(ebp + 0xFFFFFE14u), (uint32_t)(edx));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFu), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    TS32((uint32_t)(esi + edx), (uint32_t)(edi));
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE14u)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edi = (uint32_t)(TL32((uint32_t)(edx + edx + 0x903C180u)));
    edi = (uint32_t)(logic32((uint32_t)(edi & TL32((uint32_t)(ebp + 0xFFFFFE24u))), &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x903C1C0u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & ecx), &f));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE10u)));
    edi = (uint32_t)(logic32((uint32_t)(edi | edx), &f));
    TS32((uint32_t)(ebp + 0xFFFFFF94u), (uint32_t)(add32(TL32((uint32_t)(ebp + 0xFFFFFF94u)), (uint32_t)0x8u, &f)));
    TS32((uint32_t)(esi + ecx + 0x4u), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    goto L_901ACC9;
L_901C9CE:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDF4u)));
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDECu)));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFE1Cu), (uint32_t)(eax));
    TS8((uint32_t)(edx + ecx), (uint8_t)((uint8_t)0x1u));
    (void)sub32(eax, TL32((uint32_t)(ebp + 0xFFFFFFCCu)), &f);
    if (f.cf) goto L_901C9F4;
    goto L_901C9EB;
L_901C9EB:
    edx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(add32(edx, (uint32_t)0x4u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(edx));
L_901C9F4:
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE1Cu)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    ebp = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    edi = (uint32_t)((uint32_t)(edi + ebp*2));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    TS32((uint32_t)(edi), (uint32_t)(eax));
    TS32((uint32_t)(edi + 0x4u), (uint32_t)(ebx));
    TS32((uint32_t)(edi + ebp), (uint32_t)(ecx));
    TS32((uint32_t)(edi + ebp + 0x4u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFC8u)));
    esi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFDE0u)));
    edi = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE0Cu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x40u, &f));
    TS32((uint32_t)(ebp + 0xFFFFFFC8u), (uint32_t)(eax));
    goto L_901ACC9;
L_901CA9E:
    ecx = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFFCu)));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFE00u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901CAB0u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp = (uint32_t)(ebx);
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_dispatch:
    switch (jt_) { case 0x901AA9Du: goto L_901AA9D; case 0x901ABC5u: goto L_901ABC5; case 0x901ABD7u: goto L_901ABD7; case 0x901ABE9u: goto L_901ABE9; case 0x901ABFBu: goto L_901ABFB; case 0x901AC02u: goto L_901AC02; case 0x901ACA0u: goto L_901ACA0; case 0x901ACB4u: goto L_901ACB4; case 0x901ACBAu: goto L_901ACBA; case 0x901ACC6u: goto L_901ACC6; case 0x901ACC9u: goto L_901ACC9; case 0x901ACE5u: goto L_901ACE5; case 0x901ACF8u: goto L_901ACF8; case 0x901AD13u: goto L_901AD13; case 0x901AD19u: goto L_901AD19; case 0x901AD22u: goto L_901AD22; case 0x901AD28u: goto L_901AD28; case 0x901AD4Au: goto L_901AD4A; case 0x901AD5Du: goto L_901AD5D; case 0x901AD6Au: goto L_901AD6A; case 0x901AD77u: goto L_901AD77; case 0x901AD89u: goto L_901AD89; case 0x901AD9Fu: goto L_901AD9F; case 0x901ADA6u: goto L_901ADA6; case 0x901ADB8u: goto L_901ADB8; case 0x901ADCFu: goto L_901ADCF; case 0x901AE19u: goto L_901AE19; case 0x901AE36u: goto L_901AE36; case 0x901AE4Au: goto L_901AE4A; case 0x901AE53u: goto L_901AE53; case 0x901AE61u: goto L_901AE61; case 0x901AE6Au: goto L_901AE6A; case 0x901AE80u: goto L_901AE80; case 0x901AE86u: goto L_901AE86; case 0x901AE9Du: goto L_901AE9D; case 0x901AEACu: goto L_901AEAC; case 0x901AED5u: goto L_901AED5; case 0x901AEEDu: goto L_901AEED; case 0x901AEF6u: goto L_901AEF6; case 0x901AF06u: goto L_901AF06; case 0x901AF2Fu: goto L_901AF2F; case 0x901AF31u: goto L_901AF31; case 0x901AF35u: goto L_901AF35; case 0x901AF5Eu: goto L_901AF5E; case 0x901AF6Bu: goto L_901AF6B; case 0x901AF70u: goto L_901AF70; case 0x901AF87u: goto L_901AF87; case 0x901AFABu: goto L_901AFAB; case 0x901B2D6u: goto L_901B2D6; case 0x901B2FFu: goto L_901B2FF; case 0x901B311u: goto L_901B311; case 0x901B31Fu: goto L_901B31F; case 0x901B328u: goto L_901B328; case 0x901B358u: goto L_901B358; case 0x901B398u: goto L_901B398; case 0x901B3B5u: goto L_901B3B5; case 0x901B3D8u: goto L_901B3D8; case 0x901B3EAu: goto L_901B3EA; case 0x901B3EFu: goto L_901B3EF; case 0x901B3F8u: goto L_901B3F8; case 0x901B51Bu: goto L_901B51B; case 0x901B52Du: goto L_901B52D; case 0x901B532u: goto L_901B532; case 0x901B53Bu: goto L_901B53B; case 0x901B573u: goto L_901B573; case 0x901B579u: goto L_901B579; case 0x901B5A0u: goto L_901B5A0; case 0x901B5A3u: goto L_901B5A3; case 0x901BA3Bu: goto L_901BA3B; case 0x901BA40u: goto L_901BA40; case 0x901BA52u: goto L_901BA52; case 0x901BA66u: goto L_901BA66; case 0x901BA6Fu: goto L_901BA6F; case 0x901BA77u: goto L_901BA77; case 0x901BA90u: goto L_901BA90; case 0x901BB6Du: goto L_901BB6D; case 0x901BB72u: goto L_901BB72; case 0x901BB7Cu: goto L_901BB7C; case 0x901BE70u: goto L_901BE70; case 0x901BE76u: goto L_901BE76; case 0x901BEBEu: goto L_901BEBE; case 0x901BEDEu: goto L_901BEDE; case 0x901BEF9u: goto L_901BEF9; case 0x901BF2Eu: goto L_901BF2E; case 0x901BF3Au: goto L_901BF3A; case 0x901BFCBu: goto L_901BFCB; case 0x901BFDCu: goto L_901BFDC; case 0x901C010u: goto L_901C010; case 0x901C027u: goto L_901C027; case 0x901C041u: goto L_901C041; case 0x901C04Au: goto L_901C04A; case 0x901C058u: goto L_901C058; case 0x901C061u: goto L_901C061; case 0x901C080u: goto L_901C080; case 0x901C086u: goto L_901C086; case 0x901C099u: goto L_901C099; case 0x901C0AAu: goto L_901C0AA; case 0x901C0CBu: goto L_901C0CB; case 0x901C0DBu: goto L_901C0DB; case 0x901C0E6u: goto L_901C0E6; case 0x901C0F0u: goto L_901C0F0; case 0x901C107u: goto L_901C107; case 0x901C109u: goto L_901C109; case 0x901C10Du: goto L_901C10D; case 0x901C12Au: goto L_901C12A; case 0x901C139u: goto L_901C139; case 0x901C13Eu: goto L_901C13E; case 0x901C155u: goto L_901C155; case 0x901C229u: goto L_901C229; case 0x901C249u: goto L_901C249; case 0x901C264u: goto L_901C264; case 0x901C299u: goto L_901C299; case 0x901C2A5u: goto L_901C2A5; case 0x901C2B0u: goto L_901C2B0; case 0x901C2F0u: goto L_901C2F0; case 0x901C305u: goto L_901C305; case 0x901C321u: goto L_901C321; case 0x901C341u: goto L_901C341; case 0x901C34Au: goto L_901C34A; case 0x901C37Au: goto L_901C37A; case 0x901C3BAu: goto L_901C3BA; case 0x901C3D7u: goto L_901C3D7; case 0x901C3F5u: goto L_901C3F5; case 0x901C3FAu: goto L_901C3FA; case 0x901C403u: goto L_901C403; case 0x901C4B6u: goto L_901C4B6; case 0x901C4D6u: goto L_901C4D6; case 0x901C4F1u: goto L_901C4F1; case 0x901C526u: goto L_901C526; case 0x901C532u: goto L_901C532; case 0x901C540u: goto L_901C540; case 0x901C549u: goto L_901C549; case 0x901C579u: goto L_901C579; case 0x901C5D1u: goto L_901C5D1; case 0x901C608u: goto L_901C608; case 0x901C60Du: goto L_901C60D; case 0x901C616u: goto L_901C616; case 0x901C66Cu: goto L_901C66C; case 0x901C675u: goto L_901C675; case 0x901C9CEu: goto L_901C9CE; case 0x901C9EBu: goto L_901C9EB; case 0x901C9F4u: goto L_901C9F4; case 0x901CA9Eu: goto L_901CA9E; default: SPILL(); rt_call(c, jt_); return; }
}

void f_901CAB8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901CAB8:
    ecx = (ecx & 0xFFFF00FFu) | ((uint32_t)(uint8_t)(add8(((uint8_t)(ecx >> 8)), TL8((uint32_t)(ecx + eax + 0x1AD5D09u)), &f)) << 8);
    TS32((uint32_t)(esi + 0xCB0901BEu), (uint32_t)(logic32((uint32_t)(TL32((uint32_t)(esi + 0xCB0901BEu)) | edi), &f)));
    edi = (uint32_t)((uint32_t)0xC2290901u);
    TS32((uint32_t)(ecx), (uint32_t)(add32(TL32((uint32_t)(ecx)), ecx, &f)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & eax), &f));
    TS32((uint32_t)(ecx), (uint32_t)(add32(TL32((uint32_t)(ecx)), ecx, &f)));
    f.cf = !f.cf;
    esp += 4; SPILL(); return;
}

void f_901CB00(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901CB00:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x40u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(ecx);
    eax = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)((uint32_t)0xFFFFFFFFu);
    esp -= 4; M32(esp) = 0x901CB25u; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CB3Bu; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CB51u; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CB67u; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CB7Du; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CB93u; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CBA9u; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x1Cu)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CBBFu; SPILL(); f_9001E50(c); RELOAD();
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x20u)));
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    esp -= 4; M32(esp) = 0x901CBD5u; SPILL(); f_9001E50(c); RELOAD();
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0x14u)), (uint32_t)0x4u, &f));
    eax = (uint32_t)(esp);
    eax = (uint32_t)(add32(eax, (uint32_t)0xFu, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)((uint32_t)0x1u);
    (void)sub32(M32((uint32_t)(ebp + 0x8u)), eax, &f);
    if (!f.zf) goto L_901CBFE;
    goto L_901CBF2;
L_901CBF2:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC0u));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xCu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
L_901CBFE:
    esi = (uint32_t)(TL32((uint32_t)(edi + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax ^ (uint32_t)0x1u), &f));
    edx = (uint32_t)((uint32_t)(eax + eax*2));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    (void)sub32(TL32((uint32_t)(edx + edi + 0x1Cu)), (uint32_t)0x0u, &f);
    ebx = (uint32_t)(esi);
    if (!f.zf) { ebx = (uint32_t)(eax); }
    (void)sub32(TL32((uint32_t)(0x9036AF8u)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    if (!f.zf) goto L_901CC3C;
    goto L_901CC25;
L_901CC25:
    esp -= 4; M32(esp) = 0x901CC2Au; SPILL(); f_9001550(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x80000000u), &f));
    TS32((uint32_t)(0x9036AF8u), (uint32_t)(eax));
    TS32((uint32_t)(0x9036AFCu), (uint32_t)(eax));
L_901CC3C:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0x1Cu)) & (uint32_t)0x100000u), &f);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    if (f.zf) goto L_901CCB5;
    goto L_901CC48;
L_901CC48:
    (void)logic32((uint32_t)(edx & (uint32_t)0x100000u), &f);
    if (f.zf) goto L_901CCA6;
    goto L_901CC50;
L_901CC50:
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(esi + esi*2));
    eax = (uint32_t)(shl32(eax, (uint8_t)0x4u, &f));
    edx = (uint32_t)(TL32((uint32_t)(eax + edi + 0x44u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    eax = (uint32_t)(add32(eax, edi, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebx + ebx*2));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    edx = (uint32_t)(TL32((uint32_t)(edx + edi + 0x40u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x40u)));
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x4u, &f));
    esp -= 4; M32(esp) = 0x901CC97u; SPILL(); f_901A530(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x2Cu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
L_901CCA6:
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    (void)sub32(eax, ecx, &f);
    if (f.cf) goto L_901CE12;
    goto L_901CCB5;
L_901CCB5:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    (void)sub32(eax, M32((uint32_t)(ebp + 0x14u)), &f);
    if (!f.cf) goto L_901CE12;
    goto L_901CCC1;
L_901CCC1:
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x8000u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(ecx);
    if (!f.zf) goto L_901CCD4;
    goto L_901CCCE;
L_901CCCE:
    eax = (uint32_t)(add32(eax, (uint32_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
L_901CCD4:
    (void)logic32((uint32_t)(edx & (uint32_t)0x200u), &f);
    if (!f.zf) goto L_901CD31;
    goto L_901CCDC;
L_901CCDC:
    ecx = (uint32_t)((uint32_t)(esi + esi*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    eax = (uint32_t)((uint32_t)(ecx + edi));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x20u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x4u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebx + ebx*2));
    edx = (uint32_t)(shl32(edx, (uint8_t)0x4u, &f));
    ecx = (uint32_t)(TL32((uint32_t)(edx + edi + 0x1Cu)));
    edx = (uint32_t)(TL32((uint32_t)(eax + 0x1Cu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    esp -= 4; M32(esp) = 0x901CD20u; SPILL(); f_901A530(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x2Cu, &f));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if (!f.cf) goto L_901CD31;
    goto L_901CD2E;
L_901CD2E:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(ecx);
L_901CD31:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE8u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901CD41;
    goto L_901CD37;
L_901CD37:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0xFFFFFFFCu)));
    eax = (uint32_t)((uint32_t)(ecx + eax + 0xFFFFFFFCu));
L_901CD41:
    (void)logic32((uint32_t)(edx & (uint32_t)0x20000u), &f);
    if (!f.zf) goto L_901CE12;
    goto L_901CD4D;
L_901CD4D:
    (void)sub32(eax, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_901CE12;
    goto L_901CD56;
L_901CD56:
    (void)sub32(eax, M32((uint32_t)(ebp + 0x14u)), &f);
    if (!f.cf) goto L_901CE12;
    goto L_901CD5F;
L_901CD5F:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ecx = (uint32_t)(add32(ecx, ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(esi + esi*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    esi = (uint32_t)((uint32_t)(ecx + edi));
    ecx = (uint32_t)((uint32_t)(ebx + ebx*2));
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    ebx = (uint32_t)((uint32_t)(ecx + edi));
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x2Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x28u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x28u)));
    ecx = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x901CDACu; SPILL(); f_901A530(c); RELOAD();
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    edx = (uint32_t)(add32(edx, edx, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x2Cu, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    (void)sub32(edx, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if (!f.cf) goto L_901CDC1;
    goto L_901CDBE;
L_901CDBE:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(edx);
L_901CDC1:
    (void)sub32(eax, M32((uint32_t)(ebp + 0x10u)), &f);
    if (f.cf) goto L_901CE12;
    goto L_901CDC6;
L_901CDC6:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)sub32(eax, ecx, &f);
    if (!f.cf) goto L_901CE12;
    goto L_901CDCD;
L_901CDCD:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFF8u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFC4u));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(edi + 0x10u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x38u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(ebx + 0x34u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x34u)));
    ecx = (uint32_t)(eax);
    esp -= 4; M32(esp) = 0x901CE00u; SPILL(); f_901A530(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x2Cu, &f));
    (void)sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f);
    if (!f.cf) goto L_901CE12;
    goto L_901CE0F;
L_901CE0F:
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
L_901CE12:
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901CE1D;
    goto L_901CE1B;
L_901CE1B:
    c->top = 0;
L_901CE1D:
    ecx = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)TL32((uint32_t)(edi + 0x4u)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x6u, &f));
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(sub32(eax, M32((uint32_t)(ebp + 0xFFFFFFF4u)), &f));
    edx = (uint32_t)(logic32(0, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0x64u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { uint64_t n_ = ((uint64_t)edx << 32) | eax; uint32_t d_ = ecx; eax = (uint32_t)(n_ / d_); edx = (uint32_t)(n_ % d_); }
    esp = (uint32_t)((uint32_t)(ebp + 0xFFFFFFB8u));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    esp -= 4; M32(esp) = 0x901CE42u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 28; SPILL(); return;
}

void f_901CE50(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901CE50:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(TL32((uint32_t)(0x9036AF8u)));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (!f.zf) goto L_901CE6F;
    goto L_901CE5C;
L_901CE5C:
    esp -= 4; M32(esp) = 0x901CE61u; SPILL(); f_9001550(c); RELOAD();
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0x80000000u), &f));
    TS32((uint32_t)(0x9036AF8u), (uint32_t)(eax));
    edx = (uint32_t)(eax);
    goto L_901CE75;
L_901CE6F:
    edx = (uint32_t)(TL32((uint32_t)(0x9036AFCu)));
L_901CE75:
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(logic32((uint32_t)(eax & M32((uint32_t)(ebp + 0xCu))), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & M32((uint32_t)(ebp + 0x8u))), &f));
    eax = (uint32_t)(~eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx | edx), &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & eax), &f));
    TS32((uint32_t)(0x9036AFCu), (uint32_t)(ecx));
    eax = (uint32_t)(ecx);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

void f_901CE90(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901CE90:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    (void)sub32(eax, TL32((uint32_t)(0x902FDF8u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEA7;
L_901CEA7:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    (void)sub32(ebx, TL32((uint32_t)(0x902FDE0u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEB2;
L_901CEB2:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    (void)sub32(ebx, TL32((uint32_t)(0x902FDE8u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEBD;
L_901CEBD:
    (void)sub32(edi, TL32((uint32_t)(0x902FDF0u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEC5;
L_901CEC5:
    (void)sub32(ecx, TL32((uint32_t)(0x902FE18u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CECD;
L_901CECD:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    (void)sub32(ebx, TL32((uint32_t)(0x902FE00u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CED8;
L_901CED8:
    (void)sub32(esi, TL32((uint32_t)(0x902FE08u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEE0;
L_901CEE0:
    (void)sub32(edx, TL32((uint32_t)(0x902FE10u)), &f);
    if (!f.zf) goto L_901CEEF;
    goto L_901CEE8;
L_901CEE8:
    eax = (uint32_t)(logic32(0, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901CEEF:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    TS32((uint32_t)(0x902FDE0u), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(0x902FDE8u), (uint32_t)(ebx));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    TS32((uint32_t)(0x902FE00u), (uint32_t)(ebx));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(sub32(ebx, ecx, &f));
    TS32((uint32_t)(0x9030A90u), (uint32_t)(ebx));
    TS32((uint32_t)(0x902FE18u), (uint32_t)(ecx));
    TS32((uint32_t)(0x902FDF8u), (uint32_t)(eax));
    ebx = (uint32_t)((uint32_t)0xFF00FFu);
    ebx = (uint32_t)(sar32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)0xFFu);
    TS32((uint32_t)(0x902FDF0u), (uint32_t)(edi));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFF00FFu), &f));
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(0x9030A94u), (uint32_t)(ebx));
    ebx = (uint32_t)((uint32_t)0xFFu);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    edi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE10u), (uint32_t)(edx));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    ebx = (uint32_t)((uint32_t)0xFFu);
    ebx = (uint32_t)(shl32(ebx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE08u), (uint32_t)(esi));
    eax = (uint32_t)(logic32((uint32_t)(eax | ebx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | eax), &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x902FE50u), (uint32_t)(edi));
    edi = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE54u), (uint32_t)(ebx));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | eax), &f));
    ecx = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    ecx = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE58u), (uint32_t)(edi));
    TS32((uint32_t)(0x902FE5Cu), (uint32_t)(ebx));
    edx = (uint32_t)(eax);
    edx = (uint32_t)(shl32(edx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edx), &f));
    edi = (uint32_t)(eax);
    edi = (uint32_t)(logic32((uint32_t)(edi | ecx), &f));
    edx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | eax), &f));
    ecx = (uint32_t)(esi);
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x902FE68u), (uint32_t)(edx));
    edx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE6Cu), (uint32_t)(edi));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x10u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx | eax), &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | ecx), &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(0x902FE64u), (uint32_t)(esi));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    TS32((uint32_t)(0x902FE60u), (uint32_t)(edx));
    eax = (uint32_t)((uint32_t)(ecx + 0x1u));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D000(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D000:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(logic32((uint32_t)(esp & (uint32_t)0xFFFFFFF8u), &f));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D027u; SPILL(); f_901CE90(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901D164;
    goto L_901D032;
L_901D032:
    ecx = (uint32_t)(esi);
    esi = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)((uint32_t)0x1u);
    edx = (uint32_t)(shl32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0xFu, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi | eax), &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x61D061D0u, &f));
    ebx = (uint32_t)(adc32(ebx, (uint32_t)0x61D061D0u, &f));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    ecx = (uint32_t)(edi);
    esi = (uint32_t)((uint32_t)0x1u);
    esi = (uint32_t)(shl32(esi, ((uint8_t)ecx), &f));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ebx));
    ecx = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(logic32(0, &f));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0xFu, &f));
    edi = (uint32_t)(logic32((uint32_t)(edi | eax), &f));
    ebx = (uint32_t)(eax);
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    edi = (uint32_t)(add32(edi, (uint32_t)0x78A778A7u, &f));
    ebx = (uint32_t)(adc32(ebx, (uint32_t)0x78A778A7u, &f));
    TS32((uint32_t)(0x902FE30u), (uint32_t)(edi));
    edi = (uint32_t)((uint32_t)0x1u);
    edi = (uint32_t)(shl32(edi, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(ebx));
    eax = (uint32_t)(edi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFFEu), &f));
    eax = (uint32_t)(shl32(eax, (uint8_t)0xFu, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx | eax), &f));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | eax), &f));
    eax = (uint32_t)(edx);
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x5E8D5E8Du, &f));
    ebx = (uint32_t)(adc32(ebx, (uint32_t)0x5E8D5E8Du, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0xC000u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFF0000u), &f));
    edx = (uint32_t)(sar32(edx, (uint8_t)0x2u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edx), &f));
    edx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | eax), &f));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(ebx));
    ebx = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    TS32((uint32_t)(0x902FE40u), (uint32_t)(ecx));
    ecx = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx | ecx), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x61D061D0u, &f));
    ebx = (uint32_t)(adc32(ebx, (uint32_t)0x61D061D0u, &f));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0xC000u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFF0000u), &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x2u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | esi), &f));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    edx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx | eax), &f));
    esi = (uint32_t)(eax);
    esi = (uint32_t)(logic32((uint32_t)(esi | ecx), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x78A778A7u, &f));
    esi = (uint32_t)(adc32(esi, (uint32_t)0x78A778A7u, &f));
    eax = (uint32_t)(edi);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)(uint32_t)0xC000u; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFF0000u), &f));
    edi = (uint32_t)(sar32(edi, (uint8_t)0x2u, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax | edi), &f));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(edx));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(esi));
    edx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(eax);
    edx = (uint32_t)(logic32((uint32_t)(edx | eax), &f));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(ebx));
    esi = (uint32_t)(logic32((uint32_t)(esi | ecx), &f));
    edx = (uint32_t)(add32(edx, (uint32_t)0x5E8D5E8Du, &f));
    esi = (uint32_t)(adc32(esi, (uint32_t)0x5E8D5E8Du, &f));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(edx));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(esi));
L_901D164:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D170(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D170:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    (void)sub32(TL32((uint32_t)(0x903FA38u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901D1FB;
    goto L_901D17D;
L_901D17D:
    eax = (uint32_t)(logic32(0, &f));
    TS32((uint32_t)(0x903FA38u), (uint32_t)((uint32_t)0x1u));
    TS32((uint32_t)(0x903F938u), (uint32_t)(eax));
    TS32((uint32_t)(0x903F93Cu), (uint32_t)(eax));
    TS32((uint32_t)(0x903F940u), (uint32_t)(eax));
    TS32((uint32_t)(0x903F944u), (uint32_t)(eax));
    ecx = (uint32_t)(logic32(0, &f));
L_901D1A0:
    edx = (uint32_t)(eax);
    edx = (uint32_t)(shr32(edx, (uint8_t)0x10u, &f));
    TS8((uint32_t)(ecx + 0x903F948u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x12A68u, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(eax, (uint32_t)0xFF46F8u, &f);
    if (f.cf) goto L_901D1A0;
    goto L_901D1B8;
L_901D1B8:
    eax = (uint32_t)(logic32((uint32_t)(eax | (uint32_t)0xFFFFFFFFu), &f));
    TS32((uint32_t)(0x903FA23u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FA27u), (uint32_t)(eax));
    TS32((uint32_t)(0x903FA2Bu), (uint32_t)(eax));
    TS32((uint32_t)(0x903FA2Fu), (uint32_t)(eax));
    TS32((uint32_t)(0x903FA33u), (uint32_t)(eax));
    TS8((uint32_t)(0x903FA37u), (uint8_t)(((uint8_t)eax)));
    ecx = (uint32_t)((uint32_t)0xFFFFFF80u);
    eax = (uint32_t)((uint32_t)0xFFCC1A00u);
L_901D1E3:
    edx = (uint32_t)(eax);
    edx = (uint32_t)(sar32(edx, (uint8_t)0x10u, &f));
    TS8((uint32_t)(ecx + 0x903F8B8u), (uint8_t)(((uint8_t)edx)));
    eax = (uint32_t)(add32(eax, (uint32_t)0x67CCu, &f));
    ecx = (uint32_t)(inc32(ecx, &f));
    (void)sub32(eax, (uint32_t)0x337E34u, &f);
    if ((f.sf != f.of)) goto L_901D1E3;
    goto L_901D1FB;
L_901D1FB:
    eax = (uint32_t)(TL32((uint32_t)(0x902FE08u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE10u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(TL32((uint32_t)(0x902FDE0u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(0x902FE00u)));
    edx = (uint32_t)(edi);
    (void)sub32(eax, edx, &f);
    if ((!f.zf && f.sf == f.of)) { edx = (uint32_t)(eax); }
    (void)sub32(ecx, edx, &f);
    if ((!f.zf && f.sf == f.of)) { edx = (uint32_t)(ecx); }
    esi = (uint32_t)(sub32(esi, edi, &f));
    edi = (uint32_t)(TL32((uint32_t)(0x902FDE8u)));
    edi = (uint32_t)(sub32(edi, eax, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x902FDF0u)));
    eax = (uint32_t)(sub32(eax, ecx, &f));
    ebx = (uint32_t)((uint32_t)(esi + edx));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    eax = (uint32_t)(add32(eax, edx, &f));
    (void)sub32(ebx, TL32((uint32_t)(0x9030A84u)), &f);
    if (!f.zf) goto L_901D259;
    goto L_901D242;
L_901D242:
    ecx = (uint32_t)((uint32_t)(edi + edx));
    (void)sub32(ecx, TL32((uint32_t)(0x9030A88u)), &f);
    if (!f.zf) goto L_901D259;
    goto L_901D24D;
L_901D24D:
    (void)sub32(eax, TL32((uint32_t)(0x9030A8Cu)), &f);
    if (f.zf) goto L_901D40C;
    goto L_901D259;
L_901D259:
    ecx = (uint32_t)(edx);
    eax = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    esi = (uint32_t)(add32(esi, (uint32_t)0x8u, &f));
    TS32((uint32_t)(0x9030A84u), (uint32_t)(ebx));
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x1u, &f));
    TS32((uint32_t)(0x9030A78u), (uint32_t)(ecx));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(eax + eax*2));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x2u, &f));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x2u, &f));
    (void)sub32(esi, (uint32_t)0x8u, &f);
    TS32((uint32_t)(0x9030A80u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(edi + edx));
    TS32((uint32_t)(0x9030A7Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(0x9030A88u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ecx + edx));
    TS32((uint32_t)(0x9030A8Cu), (uint32_t)(eax));
    if ((!f.zf && f.sf == f.of)) goto L_901D3D6;
    goto L_901D2A7;
L_901D2A7:
    edi = (uint32_t)(add32(edi, (uint32_t)0x8u, &f));
    (void)sub32(edi, (uint32_t)0x8u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901D3D6;
    goto L_901D2B3;
L_901D2B3:
    eax = (uint32_t)(ecx);
    eax = (uint32_t)(add32(eax, (uint32_t)0x8u, &f));
    (void)sub32(eax, (uint32_t)0x8u, &f);
    if ((!f.zf && f.sf == f.of)) goto L_901D3D6;
    goto L_901D2C1;
L_901D2C1:
    esi = (uint32_t)(TL32((uint32_t)(0x902FE00u)));
    edi = (uint32_t)(TL32((uint32_t)(0x902FDE0u)));
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x902FE78u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D2DEu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    eax = (uint32_t)(logic32(0, &f));
L_901D2E3:
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(inc32(eax, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), ((uint8_t)ecx), &f));
    (void)sub32(eax, (uint32_t)0x100u, &f);
    TS8((uint32_t)(eax + 0x902FF77u), (uint8_t)(((uint8_t)edx)));
    if ((f.sf != f.of)) goto L_901D2E3;
    goto L_901D2FB;
L_901D2FB:
    ecx = (uint32_t)(esi);
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9030078u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D318u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(TL32((uint32_t)(0x902FE08u)));
    edi = (uint32_t)(TL32((uint32_t)(0x902FDE8u)));
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9030178u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D335u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)((uint32_t)(ebx));
L_901D340:
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(inc32(eax, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), ((uint8_t)ecx), &f));
    (void)sub32(eax, (uint32_t)0x100u, &f);
    TS8((uint32_t)(eax + 0x9030277u), (uint8_t)(((uint8_t)edx)));
    if ((f.sf != f.of)) goto L_901D340;
    goto L_901D358;
L_901D358:
    ecx = (uint32_t)(esi);
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9030378u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D375u; SPILL(); f_9001EB0(c); RELOAD();
    esi = (uint32_t)(TL32((uint32_t)(0x902FE10u)));
    edi = (uint32_t)(TL32((uint32_t)(0x902FDF0u)));
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9030478u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D392u; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    eax = (uint32_t)(logic32(0, &f));
L_901D397:
    edx = (uint32_t)(eax);
    ecx = (uint32_t)(esi);
    edx = (uint32_t)(sar32(edx, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    eax = (uint32_t)(inc32(eax, &f));
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(shl8(((uint8_t)edx), ((uint8_t)ecx), &f));
    (void)sub32(eax, (uint32_t)0x100u, &f);
    TS8((uint32_t)(eax + 0x9030577u), (uint8_t)(((uint8_t)edx)));
    if ((f.sf != f.of)) goto L_901D397;
    goto L_901D3AF;
L_901D3AF:
    ecx = (uint32_t)(esi);
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)(edi);
    { uint32_t v_ = 0x100u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(shl32(eax, ((uint8_t)ecx), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x9030678u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D3CCu; SPILL(); f_9001EB0(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901D3D6:
    ecx = (uint32_t)((uint32_t)0x100u);
    eax = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)((uint32_t)0x902FE78u);
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
L_901D3E4:
    esi = (uint32_t)(eax);
    ecx = (uint32_t)(edx);
    esi = (uint32_t)(shr32(esi, ((uint8_t)ecx), &f));
    eax = (uint32_t)(inc32(eax, &f));
    TS32((uint32_t)(eax*4 + 0x9030274u), (uint32_t)(esi));
    (void)sub32(eax, (uint32_t)0x100u, &f);
    if (f.cf) goto L_901D3E4;
    goto L_901D3F9;
L_901D3F9:
    eax = (uint32_t)((uint32_t)0xFFu);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    ecx = (uint32_t)((uint32_t)0x100u);
    edi = (uint32_t)((uint32_t)0x9030678u);
    while (ecx) { M32(edi) = (uint32_t)eax; edi += (c->df ? -4 : 4); ecx--; }
L_901D40C:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D420(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D420:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030AA0u)); esp -= 4; M32(esp) = 0x901D43Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xCu)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9030AA0u)); esp -= 4; M32(esp) = 0x901D44Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D460(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D460:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030AA8u)); esp -= 4; M32(esp) = 0x901D47Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xCu)), &f));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    { uint32_t t_ = TL32((uint32_t)(0x9030AA8u)); esp -= 4; M32(esp) = 0x901D48Fu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x20u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D4A0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D4A0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x10u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x4u)));
    ebx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    M32((uint32_t)(ebp + 0x8u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x8u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(ecx);
    { uint32_t t_ = TL32((uint32_t)(0x9030AA4u)); esp -= 4; M32(esp) = 0x901D4DEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x18u)));
    edx = (uint32_t)(TL32((uint32_t)(esi + 0x14u)));
    ecx = (uint32_t)(TL32((uint32_t)(esi)));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x50u)));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(ecx);
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edx);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    ecx = (uint32_t)(add32(ecx, edi, &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    TS32((uint32_t)(esi), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    edx = (uint32_t)((uint32_t)(eax + ebx));
    eax = (uint32_t)(add32(eax, ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF4u)));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    TS32((uint32_t)(esi + 0x10u), (uint32_t)(eax));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    TS32((uint32_t)(esi + 0x8u), (uint32_t)(ecx));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0x4u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    TS32((uint32_t)(esi + 0xCu), (uint32_t)(edx));
    { uint32_t t_ = TL32((uint32_t)(0x9030AA4u)); esp -= 4; M32(esp) = 0x901D533u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE8u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    TS32((uint32_t)(esi), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    TS32((uint32_t)(esi + 0x14u), (uint32_t)(ecx));
    TS32((uint32_t)(esi + 0x18u), (uint32_t)(edx));
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D550(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D550:
    (void)sub32(eax, (uint32_t)0x50000000u, &f);
    if (f.zf) goto L_901D56D;
    goto L_901D557;
L_901D557:
    (void)sub32(eax, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_901D56D;
    goto L_901D55E;
L_901D55E:
    (void)sub32(eax, (uint32_t)0x30000000u, &f);
    if (f.zf) goto L_901D56D;
    goto L_901D565;
L_901D565:
    ecx = (uint32_t)(TL32((uint32_t)(0x9030AACu)));
    goto L_901D58C;
L_901D56D:
    edx = (uint32_t)(TL32((uint32_t)(0x9030AACu)));
    ecx = (uint32_t)((uint32_t)(edx + edx));
    edx = (uint32_t)(TL32((uint32_t)(0x9030AA0u)));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)(edx));
    TS32((uint32_t)(0x9030AB4u), (uint32_t)((uint32_t)0x1u));
L_901D58C:
    TS32((uint32_t)(0x9030AB8u), (uint32_t)(ecx));
    (void)sub32(eax, (uint32_t)0x40000000u, &f);
    if (!f.zf) goto L_901D5B0;
    goto L_901D599;
L_901D599:
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x901D420u));
L_901D5A3:
    edx = (uint32_t)(TL32((uint32_t)(0x9030AA4u)));
    TS32((uint32_t)(0x9030A98u), (uint32_t)(edx));
    esp += 4; SPILL(); return;
L_901D5B0:
    (void)sub32(eax, (uint32_t)0x10000000u, &f);
    if (!f.zf) goto L_901D5A3;
    goto L_901D5B7;
L_901D5B7:
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901D5CB;
    goto L_901D5C0;
L_901D5C0:
    TS32((uint32_t)(0x9030A98u), (uint32_t)((uint32_t)0x901D4A0u));
    esp += 4; SPILL(); return;
L_901D5CB:
    ecx = (uint32_t)(TL32((uint32_t)(0x9030A9Cu)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030AA4u)));
    TS32((uint32_t)(0x9030A98u), (uint32_t)(eax));
    TS32((uint32_t)(0x9030AA8u), (uint32_t)(ecx));
    TS32((uint32_t)(0x9030A9Cu), (uint32_t)((uint32_t)0x901D460u));
    esp += 4; SPILL(); return;
}

void f_901D5F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D5F0:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x7Cu, &f));
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x14u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(edx);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x70000000u), &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    M32((uint32_t)(ebp + 0xFFFFFFE0u)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    (void)sub32(edx, (uint32_t)0x60000000u, &f);
    if (!f.zf) goto L_901D667;
    goto L_901D63C;
L_901D63C:
    M32((uint32_t)(ebp + 0x2Cu)) = (uint32_t)(shr32(M32((uint32_t)(ebp + 0x2Cu)), (uint8_t)0x1u, &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)((uint32_t)(ebx + ebx));
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, esi, &f));
    edi = (uint32_t)(add32(edi, edi, &f));
    edx = (uint32_t)(add32(edx, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFB0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(edx);
L_901D667:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    eax = (uint32_t)(add32(eax, edx, &f));
    edx = (uint32_t)(TL32((uint32_t)(0x9030AACu)));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)M32((uint32_t)(ebp + 0x10u)); edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xCu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFFB4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ebx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF88u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(eax, (uint32_t)0x20000000u, &f);
    if (f.zf) goto L_901D69E;
    goto L_901D697;
L_901D697:
    (void)sub32(eax, (uint32_t)0x50000000u, &f);
    if (!f.zf) goto L_901D6A7;
    goto L_901D69E;
L_901D69E:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFACu)));
    eax = (uint32_t)((uint32_t)(edx + edx));
    M32((uint32_t)(ebp + 0xFFFFFFACu)) = (uint32_t)(eax);
L_901D6A7:
    (void)logic32((uint32_t)(M32((uint32_t)(ebp + 0x30u)) & (uint32_t)0x800u), &f);
    if (f.zf) goto L_901D6C7;
    goto L_901D6B0;
L_901D6B0:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)(edx);
    edx = (uint32_t)(esi);
    esi = (uint32_t)(edi);
    edi = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFE8u)) = (uint32_t)(edi);
    goto L_901D6D0;
L_901D6C7:
    edx = (uint32_t)(TL32((uint32_t)(ecx + 0x28u)));
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x4u)));
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)(edx);
L_901D6D0:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB0u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)esi; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(add32(ebx, edx, &f));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    M32((uint32_t)(ebp + 0xFFFFFF8Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB0u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edi; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF98u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFF98u)), eax, &f));
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x20000u), &f));
    M32((uint32_t)(ebp + 0x2Cu)) = (uint32_t)(eax);
    if (f.zf) goto L_901D704;
    goto L_901D6FA;
L_901D6FA:
    eax = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(eax);
    goto L_901D752;
L_901D704:
    (void)logic32((uint32_t)(ebx & (uint32_t)0x10000u), &f);
    if (f.zf) goto L_901D723;
    goto L_901D70C;
L_901D70C:
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x1Cu)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFECu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = (uint32_t)(eax);
    goto L_901D72C;
L_901D723:
    eax = (uint32_t)(TL32((uint32_t)(ecx + 0x1Cu)));
    ebx = (uint32_t)(TL32((uint32_t)(ecx + 0x10u)));
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)(eax);
L_901D72C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFB0u)));
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(eax);
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)M32((uint32_t)(ebp + 0xFFFFFFF0u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    { int64_t r_ = (int64_t)(int32_t)ecx * (int32_t)M32((uint32_t)(ebp + 0xFFFFFFECu)); ecx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    ebx = (uint32_t)(add32(ebx, ecx, &f));
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFF94u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFF94u)), eax, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFF90u)) = (uint32_t)(ebx);
L_901D752:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    eax = (uint32_t)(TL32((uint32_t)(0x9030AB8u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFACu)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ebx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    esi = (uint32_t)(sub32(esi, ebx, &f));
    edi = (uint32_t)(sub32(edi, ebx, &f));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFC0u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFC4u)) = (uint32_t)(edi);
    (void)sub8(((uint8_t)eax), (uint8_t)0xFu, &f);
    if (!f.zf) goto L_901D7CE;
    goto L_901D779;
L_901D779:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    eax = (uint32_t)(esi);
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    ecx = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFACu)));
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    edi = (uint32_t)(eax);
    eax = (uint32_t)(esi);
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)edx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0xCu)), &f));
    ecx = (uint32_t)(sar32(ecx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(shr32(edx, (uint8_t)0x1u, &f));
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    { int64_t r_ = (int64_t)(int32_t)esi * (int32_t)ecx; esi = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    esi = (uint32_t)(add32(esi, ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFBCu)));
    edx = (uint32_t)(add32(edx, eax, &f));
    eax = (uint32_t)(add32(eax, esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFF9Cu)) = (uint32_t)(eax);
    edi = (uint32_t)(sar32(edi, (uint8_t)0x1u, &f));
    edx = (uint32_t)(add32(edx, esi, &f));
    eax = (uint32_t)((uint32_t)(ebx + 0x1u));
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edi);
    M32((uint32_t)(ebp + 0xFFFFFFDCu)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFFA0u)) = (uint32_t)(edx);
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    goto L_901D7E1;
L_901D7CE:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFD8u)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    eax = (uint32_t)(add32(eax, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x1u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    eax = (uint32_t)(add32(eax, edx, &f));
L_901D7E1:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFECu)));
    eax = (uint32_t)(neg32(eax, &f));
    edx = (uint32_t)(add32(edx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFCCu)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF0u)));
    M32((uint32_t)(ebp + 0xFFFFFFC8u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFFD0u)) = (uint32_t)(eax);
    eax = (uint32_t)(add32(eax, edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFD4u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    (void)sub32(eax, (uint32_t)0x40000000u, &f);
    if (f.zf) goto L_901D80A;
    goto L_901D803;
L_901D803:
    (void)sub32(eax, (uint32_t)0x10000000u, &f);
    if (!f.zf) goto L_901D81D;
    goto L_901D80A;
L_901D80A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFFACu)), &f));
    edx = (uint32_t)((int32_t)eax >> 31);
    eax = (uint32_t)(sub32(eax, edx, &f));
    eax = (uint32_t)(sar32(eax, (uint8_t)0x1u, &f));
    edi = (uint32_t)(add32(edi, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFFBCu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFFD8u)) = (uint32_t)(edi);
L_901D81D:
    (void)logic8((uint8_t)(M8((uint32_t)(ebp + 0xFFFFFFB0u)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901D8B1;
    goto L_901D827;
L_901D827:
    edx = (uint32_t)(TL32((uint32_t)(0x902FE28u)));
    eax = (uint32_t)(TL32((uint32_t)(0x902FE20u)));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE24u)));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE2Cu)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE38u)));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x902FE30u)));
    TS32((uint32_t)(0x902FE30u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE3Cu)));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE34u)));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE48u)));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0x902FE40u)));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(ecx));
    ecx = (uint32_t)(TL32((uint32_t)(0x902FE44u)));
    TS32((uint32_t)(0x902FE40u), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE4Cu)));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(edx));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(eax));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(ecx));
L_901D8B1:
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901D8E4;
    goto L_901D8BA;
L_901D8BA:
    ecx = (uint32_t)(TL32((uint32_t)(0x9030AB0u)));
    eax = (uint32_t)((uint32_t)0x200u);
    eax = (uint32_t)(sar32(eax, ((uint8_t)ecx), &f));
    (void)sub32(M32((uint32_t)(ebp + 0x2Cu)), (uint32_t)0x0u, &f);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(eax);
    if (!f.zf) goto L_901D8F2;
    goto L_901D8D0;
L_901D8D0:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)0x1Cu);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901D8E4:
    (void)sub32(M32((uint32_t)(ebp + 0x2Cu)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901D92D;
    goto L_901D8EA;
L_901D8EA:
    eax = (uint32_t)((uint32_t)0x100u);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(eax);
L_901D8F2:
    (void)sub32(eax, ebx, &f);
    if ((f.cf || f.zf)) goto L_901D8FB;
    goto L_901D8F6;
L_901D8F6:
    eax = (uint32_t)(ebx);
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)(eax);
L_901D8FB:
    (void)sub32(eax, (uint32_t)0x100u, &f);
    if ((f.cf || f.zf)) goto L_901D907;
    goto L_901D902;
L_901D902:
    eax = (uint32_t)((uint32_t)0x100u);
L_901D907:
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x34u)));
    { uint32_t v_ = 0x80u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901D916u; SPILL(); f_9001EB0(c); RELOAD();
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)0x1Cu);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
L_901D92D:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    ecx = (uint32_t)((uint32_t)0x1Cu);
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFF88u));
    M32((uint32_t)(ebp + 0xFFFFFFB8u)) = (uint32_t)((uint32_t)0xFFFFFFFFu);
    if (!c->df) { rt_movsd(ecx, edi, esi); edi += ecx * 4; esi += ecx * 4; ecx = 0; } else while (ecx) { M32(edi) = M32(esi); esi += (c->df ? -4 : 4); edi += (c->df ? -4 : 4); ecx--; }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_901D950(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901D950:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x3ACu, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(0x9030A98u)), (uint32_t)0x0u, &f);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    if (f.zf) goto L_901DBF9;
    goto L_901D97C;
L_901D97C:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901DBF9;
    goto L_901D984;
L_901D984:
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_901DBF9;
    goto L_901D98C;
L_901D98C:
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFCE7u));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    esi = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF7u));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFC58u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFCCCu)) = (uint32_t)(esi);
    esp -= 4; M32(esp) = 0x901D9D6u; SPILL(); f_901D5F0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC80u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x30u, &f));
    (void)sub32(ecx, M32((uint32_t)(ebp + 0xFFFFFC84u)), &f);
    if ((f.sf == f.of)) goto L_901DBEE;
    goto L_901D9EB;
L_901D9EB:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC70u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x20000u), &f));
    M32((uint32_t)(ebp + 0xFFFFFCC8u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC6Cu)));
    goto L_901DA19;
L_901DA10:
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCCCu)));
L_901DA19:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    ebx = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFCD4u)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFC74u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC78u)) = (uint32_t)(ecx);
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), ebx, &f);
    if (f.zf) goto L_901DA56;
    goto L_901DA38;
L_901DA38:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCD0u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC58u)));
    M32((uint32_t)(ebp + 0xFFFFFC58u)) = (uint32_t)(eax);
    goto L_901DA56;
L_901DA50:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCCCu)));
L_901DA56:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFCC8u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DA6B;
    goto L_901DA5F;
L_901DA5F:
    M32((uint32_t)(ebp + 0xFFFFFC60u)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFC64u)) = (uint32_t)(esi);
L_901DA6B:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC88u)));
    (void)sub32(edi, esi, &f);
    if ((!f.cf && !f.zf)) goto L_901DA77;
    goto L_901DA75;
L_901DA75:
    esi = (uint32_t)(edi);
L_901DA77:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCD4u)));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFC58u));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030A98u)); esp -= 4; M32(esp) = 0x901DA8Cu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esi = (uint32_t)(sub32(esi, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFCD4u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFCD4u)), esi, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    edi = (uint32_t)(sub32(edi, esi, &f));
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DAC9;
    goto L_901DAA2;
L_901DAA2:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC58u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCD0u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFC58u));
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030A9Cu)); esp -= 4; M32(esp) = 0x901DABEu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    ebx = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC58u)) = (uint32_t)(esi);
L_901DAC9:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (!f.zf) goto L_901DA50;
    goto L_901DACD;
L_901DACD:
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), edi, &f);
    if (f.zf) goto L_901DADB;
    goto L_901DAD5;
L_901DAD5:
    M32((uint32_t)(ebp + 0xFFFFFC58u)) = (uint32_t)(ebx);
L_901DADB:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC90u)));
    M32((uint32_t)(ebp + 0xFFFFFC5Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC5Cu)), edx, &f));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC94u)));
    M32((uint32_t)(ebp + 0xFFFFFC68u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC68u)), eax, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC80u)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC8Cu)));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE28u)));
    edi = (uint32_t)(TL32((uint32_t)(0x902FE24u)));
    eax = (uint32_t)(edx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + eax + 0xFFFFFC98u)));
    M32((uint32_t)(ebp + 0xFFFFFC60u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC60u)), ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + eax + 0xFFFFFCA0u)));
    M32((uint32_t)(ebp + 0xFFFFFC64u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC64u)), ecx, &f));
    ecx = (uint32_t)((uint32_t)(ebp + eax + 0xFFFFFCA8u));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0xFFFFFC74u)), &f));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFC6Cu)) = (uint32_t)(eax);
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    M32((uint32_t)(ebp + 0xFFFFFC58u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC58u)), esi, &f));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE20u)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFC78u)), &f));
    (void)sub32(edx, M32((uint32_t)(ebp + 0xFFFFFC84u)), &f);
    TS32((uint32_t)(0x902FE20u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE2Cu)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE38u)));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE30u)));
    TS32((uint32_t)(0x902FE30u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE3Cu)));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(0x902FE34u)));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE48u)));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE40u)));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(edi));
    edi = (uint32_t)(TL32((uint32_t)(0x902FE44u)));
    TS32((uint32_t)(0x902FE40u), (uint32_t)(ebx));
    ebx = (uint32_t)(TL32((uint32_t)(0x902FE4Cu)));
    M32((uint32_t)(ebp + 0xFFFFFC70u)) = (uint32_t)(ecx);
    TS32((uint32_t)(0x902FE44u), (uint32_t)(ebx));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(esi));
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(edi));
    M32((uint32_t)(ebp + 0xFFFFFC80u)) = (uint32_t)(edx);
    if ((f.sf != f.of)) goto L_901DA10;
    goto L_901DBEE;
L_901DBEE:
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901DBF9;
    goto L_901DBF7;
L_901DBF7:
    c->top = 0;
L_901DBF9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFFCu)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901DC06u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 44; SPILL(); return;
}

void f_901DC10(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_901DC10:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x3E8u, &f));
    eax = (uint32_t)(TL32((uint32_t)(0x9033000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ ebp), &f));
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = (uint32_t)(eax);
    (void)sub32(TL32((uint32_t)(0x9030A98u)), (uint32_t)0x0u, &f);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x24u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x2Cu)));
    if (f.zf) goto L_901E153;
    goto L_901DC39;
L_901DC39:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901E153;
    goto L_901DC44;
L_901DC44:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_901E153;
    goto L_901DC4C;
L_901DC4C:
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFCE3u));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    M32((uint32_t)(ebp + 0xFFFFFCC0u)) = (uint32_t)(eax);
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFEF3u));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFFFFFFF0u), &f));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFC30u)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFC3Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0x901DC93u; SPILL(); f_901D5F0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0x1Cu)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    ebx = (uint32_t)(shr32(ebx, (uint8_t)0x4u, &f));
    { int64_t r_ = (int64_t)(int32_t)ebx * (int32_t)ecx; ebx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ebx = (uint32_t)(add32(ebx, M32((uint32_t)(ebp + 0x18u)), &f));
    edi = (uint32_t)(shr32(edi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, ebx, &f));
    ebx = (uint32_t)(edx);
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    eax = (uint32_t)((uint32_t)(ebx + esi + 0xFu));
    eax = (uint32_t)(shr32(eax, (uint8_t)0x4u, &f));
    eax = (uint32_t)(neg32(eax, &f));
    ebx = (uint32_t)(neg32(ebx, &f));
    ebx = (uint32_t)(logic32((uint32_t)(ebx & (uint32_t)0xFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFC18u)) = (uint32_t)(eax);
    eax = (uint32_t)(add32(eax, ecx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0x30u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC1Cu)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFCC8u)) = (uint32_t)(ebx);
    (void)sub32(ebx, esi, &f);
    if ((f.cf || f.zf)) goto L_901DCDD;
    goto L_901DCD5;
L_901DCD5:
    ebx = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFCC8u)) = (uint32_t)(esi);
L_901DCDD:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0xFu), &f));
    (void)sub8(((uint8_t)eax), (uint8_t)0xFu, &f);
    if (!f.zf) goto L_901DCEE;
    goto L_901DCE7;
L_901DCE7:
    ecx = (uint32_t)((uint32_t)(ebx + 0x1u));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    goto L_901DCFE;
L_901DCEE:
    ecx = (uint32_t)(edx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x1u), &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    edx = (uint32_t)(add32(edx, ebx, &f));
    ecx = (uint32_t)(shr32(ecx, (uint8_t)0x1u, &f));
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x1u), &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
L_901DCFE:
    eax = (uint32_t)(TL32((uint32_t)(0x9030AB8u)));
    edx = (uint32_t)(eax);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ebx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    M32((uint32_t)(ebp + 0xFFFFFCB0u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFC34u)) = (uint32_t)(edx);
    edx = (uint32_t)(eax);
    { int64_t r_ = (int64_t)(int32_t)edx * (int32_t)ecx; edx = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(shl32(ecx, (uint8_t)0x4u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC20u)) = (uint32_t)(ecx);
    ecx = (uint32_t)((uint32_t)(eax*8));
    M32((uint32_t)(ebp + 0xFFFFFC38u)) = (uint32_t)(ecx);
    ecx = (uint32_t)(esi);
    ecx = (uint32_t)(sub32(ecx, ebx, &f));
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0xFu), &f));
    M32((uint32_t)(ebp + 0xFFFFFC28u)) = (uint32_t)(edx);
    if (!f.zf) goto L_901DD45;
    goto L_901DD40;
L_901DD40:
    ecx = (uint32_t)((uint32_t)0x10u);
L_901DD45:
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)ecx; eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC54u)));
    M32((uint32_t)(ebp + 0xFFFFFC2Cu)) = (uint32_t)(eax);
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC50u)));
    ebx = (uint32_t)((uint32_t)(ebx));
L_901DD60:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC64u)));
    (void)sub32(edx, M32((uint32_t)(ebp + 0xFFFFFC68u)), &f);
    if ((f.sf == f.of)) goto L_901E148;
    goto L_901DD72;
L_901DD72:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    M32((uint32_t)(ebp + 0xFFFFFCC4u)) = (uint32_t)((uint32_t)0x0u);
    M32((uint32_t)(ebp + 0xFFFFFCCCu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFC58u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC5Cu)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)(ebx);
    (void)logic32((uint32_t)(ebx & ebx), &f);
    if (f.zf) goto L_901DE3E;
    goto L_901DD9F;
L_901DD9F:
    edx = (edx & 0xFFFFFF00u) | (uint8_t)(TL8((uint32_t)(edi)));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    edi = (uint32_t)(inc32(edi, &f));
    (void)logic8((uint8_t)(((uint8_t)edx) & ((uint8_t)edx)), &f);
    if (!f.zf) goto L_901DE0E;
    goto L_901DDA9;
L_901DDA9:
    M32((uint32_t)(ebp + 0xFFFFFC40u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC40u)), ebx, &f));
    M32((uint32_t)(ebp + 0xFFFFFC4Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC4Cu)), ebx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x20u)));
    esi = (uint32_t)(sub32(esi, ebx, &f));
    ebx = (uint32_t)(add32(ebx, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCB0u)));
    M32((uint32_t)(ebp + 0xFFFFFC44u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC44u)), edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFC48u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC48u)), edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC28u)));
    eax = (uint32_t)(add32(eax, edx, &f));
    ecx = (uint32_t)(add32(ecx, edx, &f));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC3Cu)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFC34u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFCCCu)) = (uint32_t)(ebx);
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC8u)));
    M32((uint32_t)(ebp + 0xFFFFFC50u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC54u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)((uint32_t)0x0u);
    goto L_901DE44;
L_901DE0E:
    esi = (uint32_t)(sub32(esi, ebx, &f));
    if (f.zf) goto L_901DEBB;
    goto L_901DE16;
L_901DE16:
    (void)sub8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f);
    if (f.zf) goto L_901DEBB;
    goto L_901DE1F;
L_901DE1F:
L_901DE20:
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(esi, (uint32_t)0x10u, &f);
    if ((f.cf || f.zf)) goto L_901DEB3;
    goto L_901DE2A;
L_901DE2A:
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFCD0u)), (uint32_t)0x10u, &f));
    esi = (uint32_t)(sub32(esi, (uint32_t)0x10u, &f));
    (void)sub8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901DE20;
    goto L_901DE39;
L_901DE39:
    goto L_901DEBB;
L_901DE3E:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC3Cu)));
L_901DE44:
    (void)logic32((uint32_t)(esi & esi), &f);
    if (f.zf) goto L_901E008;
    goto L_901DE4C;
L_901DE4C:
    (void)sub8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f);
    if (!f.zf) goto L_901DE20;
    goto L_901DE51;
L_901DE51:
    edi = (uint32_t)(inc32(edi, &f));
    (void)sub32(esi, (uint32_t)0x10u, &f);
    if ((f.cf || f.zf)) goto L_901DFE1;
    goto L_901DE5B;
L_901DE5B:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC38u)));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFC20u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFC40u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC40u)), (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC4Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC4Cu)), (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC44u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC44u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC48u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC48u)), (uint32_t)0x8u, &f));
    M32((uint32_t)(ebp + 0xFFFFFCCCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFCCCu)), (uint32_t)0x10u, &f));
    eax = (uint32_t)(add32(eax, ebx, &f));
    ecx = (uint32_t)(add32(ecx, ebx, &f));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC8u)));
    M32((uint32_t)(ebp + 0xFFFFFC50u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC54u)) = (uint32_t)(ecx);
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
    esi = (uint32_t)(sub32(esi, (uint32_t)0x10u, &f));
    (void)sub8(TL8((uint32_t)(edi)), (uint8_t)0x0u, &f);
    if (f.zf) goto L_901DE51;
    goto L_901DEAE;
L_901DEAE:
    goto L_901DE20;
L_901DEB3:
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFCD0u)), esi, &f));
    esi = (uint32_t)(logic32(0, &f));
L_901DEBB:
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DEDC;
    goto L_901DEC4;
L_901DEC4:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC3Cu)));
    M32((uint32_t)(ebp + 0xFFFFFCC4u)) = (uint32_t)(edx);
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC0u)));
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
L_901DEDC:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFCD0u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DFC3;
    goto L_901DEE9;
L_901DEE9:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x30u)));
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x20000u), &f));
    M32((uint32_t)(ebp + 0xFFFFFC24u)) = (uint32_t)(eax);
    goto L_901DF06;
L_901DF00:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC24u)));
L_901DF06:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_901DF1C;
    goto L_901DF0A;
L_901DF0A:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC30u)));
    M32((uint32_t)(ebp + 0xFFFFFC44u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC48u)) = (uint32_t)(eax);
L_901DF1C:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC6Cu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCD0u)));
    M32((uint32_t)(ebp + 0xFFFFFCBCu)) = (uint32_t)(eax);
    (void)sub32(ecx, eax, &f);
    if ((!f.cf && !f.zf)) goto L_901DF38;
    goto L_901DF32;
L_901DF32:
    M32((uint32_t)(ebp + 0xFFFFFCBCu)) = (uint32_t)(ecx);
L_901DF38:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCCCu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCBCu)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)((uint32_t)(ebp + 0xFFFFFC3Cu));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030A98u)); esp -= 4; M32(esp) = 0x901DF53u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCBCu)));
    ecx = (uint32_t)(sub32(ecx, eax, &f));
    M32((uint32_t)(ebp + 0xFFFFFCD0u)) = (uint32_t)(sub32(M32((uint32_t)(ebp + 0xFFFFFCD0u)), ecx, &f));
    M32((uint32_t)(ebp + 0xFFFFFCCCu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFCCCu)), ecx, &f));
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DFAA;
    goto L_901DF73;
L_901DF73:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC3Cu)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC0u)));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC4u)));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFC3Cu));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0x9030A9Cu)); esp -= 4; M32(esp) = 0x901DF95u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC0u)));
    esp = (uint32_t)(add32(esp, (uint32_t)0x10u, &f));
    M32((uint32_t)(ebp + 0xFFFFFCC4u)) = (uint32_t)(eax);
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(ecx);
L_901DFAA:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFCD0u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_901DF00;
    goto L_901DFB7;
L_901DFB7:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC54u)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC50u)));
L_901DFC3:
    (void)sub32(TL32((uint32_t)(0x9030AB4u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_901DE3E;
    goto L_901DFD0;
L_901DFD0:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCC4u)));
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
    goto L_901DE44;
L_901DFE1:
    M32((uint32_t)(ebp + 0xFFFFFC40u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC40u)), esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFC4Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC4Cu)), esi, &f));
    esi = (uint32_t)(inc32(esi, &f));
    esi = (uint32_t)(shr32(esi, (uint8_t)0x1u, &f));
    M32((uint32_t)(ebp + 0xFFFFFC44u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC44u)), esi, &f));
    M32((uint32_t)(ebp + 0xFFFFFC48u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC48u)), esi, &f));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFC2Cu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
L_901E008:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC74u)));
    M32((uint32_t)(ebp + 0xFFFFFC40u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC40u)), eax, &f));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC64u)));
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFC78u)));
    M32((uint32_t)(ebp + 0xFFFFFC4Cu)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC4Cu)), ecx, &f));
    edx = (uint32_t)(add32(edx, M32((uint32_t)(ebp + 0xFFFFFC70u)), &f));
    eax = (uint32_t)(esi);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    eax = (uint32_t)(add32(eax, eax, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + eax + 0xFFFFFC7Cu)));
    M32((uint32_t)(ebp + 0xFFFFFC44u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC44u)), ecx, &f));
    ecx = (uint32_t)(M32((uint32_t)(ebp + eax + 0xFFFFFC84u)));
    M32((uint32_t)(ebp + 0xFFFFFC48u)) = (uint32_t)(add32(M32((uint32_t)(ebp + 0xFFFFFC48u)), ecx, &f));
    esi = (uint32_t)(logic32((uint32_t)(esi & (uint32_t)0xFu), &f));
    esi = (uint32_t)(inc32(esi, &f));
    esi = (uint32_t)(sar32(esi, (uint8_t)0x4u, &f));
    edi = (uint32_t)(add32(edi, M32((uint32_t)(ebp + esi*4 + 0xFFFFFC18u)), &f));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE24u)));
    ecx = (uint32_t)((uint32_t)(ebp + eax + 0xFFFFFC8Cu));
    eax = (uint32_t)(TL32((uint32_t)(ecx)));
    eax = (uint32_t)(add32(eax, M32((uint32_t)(ebp + 0xFFFFFC58u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFCB8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(0x902FE28u)));
    M32((uint32_t)(ebp + 0xFFFFFC50u)) = (uint32_t)(eax);
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    ecx = (uint32_t)(add32(ecx, M32((uint32_t)(ebp + 0xFFFFFC5Cu)), &f));
    M32((uint32_t)(ebp + 0xFFFFFC64u)) = (uint32_t)(inc32(M32((uint32_t)(ebp + 0xFFFFFC64u)), &f));
    M32((uint32_t)(ebp + 0xFFFFFC3Cu)) = (uint32_t)(edx);
    edx = (uint32_t)(TL32((uint32_t)(0x902FE20u)));
    TS32((uint32_t)(0x902FE20u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE2Cu)));
    TS32((uint32_t)(0x902FE24u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE34u)));
    TS32((uint32_t)(0x902FE28u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCB8u)));
    M32((uint32_t)(ebp + 0xFFFFFCB8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(0x902FE38u)));
    TS32((uint32_t)(0x902FE2Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE30u)));
    TS32((uint32_t)(0x902FE30u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE3Cu)));
    TS32((uint32_t)(0x902FE34u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE44u)));
    TS32((uint32_t)(0x902FE38u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCB8u)));
    M32((uint32_t)(ebp + 0xFFFFFCB8u)) = (uint32_t)(esi);
    esi = (uint32_t)(TL32((uint32_t)(0x902FE48u)));
    TS32((uint32_t)(0x902FE3Cu), (uint32_t)(edx));
    edx = (uint32_t)(TL32((uint32_t)(0x902FE40u)));
    TS32((uint32_t)(0x902FE40u), (uint32_t)(esi));
    esi = (uint32_t)(TL32((uint32_t)(0x902FE4Cu)));
    TS32((uint32_t)(0x902FE48u), (uint32_t)(edx));
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFCB8u)));
    TS32((uint32_t)(0x902FE44u), (uint32_t)(esi));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x28u)));
    M32((uint32_t)(ebp + 0xFFFFFC54u)) = (uint32_t)(ecx);
    TS32((uint32_t)(0x902FE4Cu), (uint32_t)(edx));
    goto L_901DD60;
L_901E148:
    (void)logic8((uint8_t)(TL8((uint32_t)(0x9036AFCu)) & (uint8_t)0x1u), &f);
    if (f.zf) goto L_901E153;
    goto L_901E151;
L_901E151:
    c->top = 0;
L_901E153:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFF8u)));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ ebp), &f));
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp -= 4; M32(esp) = 0x901E160u; SPILL(); f_9001D50(c); RELOAD();
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 48; SPILL(); return;
}

