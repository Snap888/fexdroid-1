#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A003168(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003168:
    TS32((uint32_t)(0xA004008u), (uint32_t)((uint32_t)0xFFFFFFFFu));
    esp += 4; SPILL(); return;
}

void f_A003178(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
    goto L_A003178;
L_A002F24:
    { uint32_t v_ = 0x2Cu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA0038E0u; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002F30u; SPILL(); f_A0035D0(c); RELOAD();
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    edx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(inc32(edx, &f));
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(edx);
    esi = (uint32_t)(logic32(0, &f));
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    TS32((uint32_t)(0xA004008u), (uint32_t)(ecx));
    (void)sub32(ecx, esi, &f);
    if (!f.zf) goto L_A002F58;
    goto L_A002F48;
L_A002F48:
    (void)sub32(TL32((uint32_t)(0xA004310u)), esi, &f);
    if (!f.zf) goto L_A002F58;
    goto L_A002F50;
L_A002F50:
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(esi);
    goto L_A003151;
L_A002F58:
    (void)sub32(ecx, edx, &f);
    if (f.zf) goto L_A002F65;
    goto L_A002F5C;
L_A002F5C:
    (void)sub32(ecx, (uint32_t)0x2u, &f);
    if (!f.zf) goto L_A002FEC;
    goto L_A002F65;
L_A002F65:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A002F9E;
    goto L_A002F6E;
L_A002F6E:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(edx);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA002F7Au; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_A002F9B;
L_A002F9B:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
L_A002F9E:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A002FA7;
L_A002FA7:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x2u);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FBCu; SPILL(); f_A002D7E(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_A002FDD;
L_A002FDD:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A002FE9;
L_A002FE9:
    ecx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
L_A002FEC:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x3u);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002FFFu; SPILL(); f_A0035C3(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_A003020;
L_A003020:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A00302D;
L_A00302D:
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (!f.zf) goto L_A0030C9;
    goto L_A003036;
L_A003036:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x4u);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003047u; SPILL(); f_A0035C3(c); RELOAD();
    goto L_A003062;
L_A003062:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x5u);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003076u; SPILL(); f_A002D7E(c); RELOAD();
    goto L_A003091;
L_A003091:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A0030C9;
    goto L_A00309D;
L_A00309D:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x6u);
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA0030ABu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    goto L_A0030C6;
L_A0030C6:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
L_A0030C9:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), esi, &f);
    if (f.zf) goto L_A0030D4;
    goto L_A0030CE;
L_A0030CE:
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x3u, &f);
    if (!f.zf) goto L_A003151;
    goto L_A0030D4;
L_A0030D4:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x7u);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0030E9u; SPILL(); f_A002D7E(c); RELOAD();
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_A00310A;
L_A00310A:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
    (void)sub32(M32((uint32_t)(ebp + 0xFFFFFFE4u)), esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A003112;
L_A003112:
    eax = (uint32_t)(TL32((uint32_t)(0xA00464Cu)));
    (void)sub32(eax, esi, &f);
    if (f.zf) goto L_A003151;
    goto L_A00311B;
L_A00311B:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0x8u);
    { uint32_t v_ = M32((uint32_t)(ebp + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(ebp + 0x8u)); esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = eax; esp -= 4; M32(esp) = 0xA00312Du; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    M32((uint32_t)(ebp + 0xFFFFFFE4u)) = (uint32_t)(eax);
    goto L_A00314E;
L_A00314E:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)(esi);
L_A003151:
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = (uint32_t)((uint32_t)0xFFFFFFFEu);
    esp -= 4; M32(esp) = 0xA00315Du; SPILL(); f_A003168(c); RELOAD();
    eax = (uint32_t)(M32((uint32_t)(ebp + 0xFFFFFFE4u)));
    esp -= 4; M32(esp) = 0xA003165u; SPILL(); f_A003615(c); RELOAD();
    esp += 16; SPILL(); return;
L_A003178:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    (void)sub32(M32((uint32_t)(ebp + 0xCu)), (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A003188;
    goto L_A003183;
L_A003183:
    esp -= 4; M32(esp) = 0xA003188u; SPILL(); f_A003658(c); RELOAD();
L_A003188:
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    goto L_A002F24;
}

void f_A003196(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003196:
    { SPILL(); rt_call(c, M32(0xA00105Cu)); return; }
}

void f_A0031A1(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0031A1:
    (void)sub32(ecx, TL32((uint32_t)(0xA004000u)), &f);
    if (!f.zf) goto L_A0031AB;
    goto L_A0031A9;
L_A0031A9:
    esp += 4; SPILL(); return;
L_A0031AB:
    goto L_A0036E2;
L_A0036E2:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x328u, &f));
    TS32((uint32_t)(0xA004418u), (uint32_t)(eax));
    TS32((uint32_t)(0xA004414u), (uint32_t)(ecx));
    TS32((uint32_t)(0xA004410u), (uint32_t)(edx));
    TS32((uint32_t)(0xA00440Cu), (uint32_t)(ebx));
    TS32((uint32_t)(0xA004408u), (uint32_t)(esi));
    TS32((uint32_t)(0xA004404u), (uint32_t)(edi));
    TS16((uint32_t)(0xA004430u), (uint16_t)(((uint16_t)0x2B)));
    TS16((uint32_t)(0xA004424u), (uint16_t)(((uint16_t)0x23)));
    TS16((uint32_t)(0xA004400u), (uint16_t)(((uint16_t)0x2B)));
    TS16((uint32_t)(0xA0043FCu), (uint16_t)(((uint16_t)0x2B)));
    TS16((uint32_t)(0xA0043F8u), (uint16_t)(((uint16_t)0x53)));
    TS16((uint32_t)(0xA0043F4u), (uint16_t)(((uint16_t)0x2B)));
    esp -= 4; M32(esp) = f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7) | (c->df << 10) | (f.of << 11) | 0x200 | c->eflags_hi;
    { uint32_t v_ = M32(esp); esp += 4; TS32((uint32_t)(0xA004428u), (uint32_t)(v_)); }
    eax = (uint32_t)(TL32((uint32_t)(ebp)));
    TS32((uint32_t)(0xA00441Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0x4u)));
    TS32((uint32_t)(0xA004420u), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)(ebp + 0x8u));
    TS32((uint32_t)(0xA00442Cu), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFCE0u)));
    TS32((uint32_t)(0xA004368u), (uint32_t)((uint32_t)0x10001u));
    eax = (uint32_t)(TL32((uint32_t)(0xA004420u)));
    TS32((uint32_t)(0xA004324u), (uint32_t)(eax));
    TS32((uint32_t)(0xA004318u), (uint32_t)((uint32_t)0xC0000409u));
    TS32((uint32_t)(0xA00431Cu), (uint32_t)((uint32_t)0x1u));
    eax = (uint32_t)(TL32((uint32_t)(0xA004000u)));
    TS32((uint32_t)(ebp + 0xFFFFFCD8u), (uint32_t)(eax));
    eax = (uint32_t)(TL32((uint32_t)(0xA004004u)));
    TS32((uint32_t)(ebp + 0xFFFFFCDCu), (uint32_t)(eax));
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001004u)); esp -= 4; M32(esp) = 0xA0037A5u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xA001190u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001008u)); esp -= 4; M32(esp) = 0xA0037B0u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = 0xC0000409u; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA00100Cu)); esp -= 4; M32(esp) = 0xA0037BBu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t t_ = TL32((uint32_t)(0xA001010u)); esp -= 4; M32(esp) = 0xA0037C2u; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    esp = ebp; ebp = M32(esp); esp += 4;
    esp += 4; SPILL(); return;
}

void f_A0031B8(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0031B8:
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    eax = (uint32_t)(M32((uint32_t)(esp + 0x14u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x18u)));
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA003248u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(0x0u + c->fs_base)); esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(0xA004000u)));
    eax = (uint32_t)(logic32((uint32_t)(eax ^ esp), &f));
    M32((uint32_t)(esp + 0x8u)) = (uint32_t)(eax);
    M32((uint32_t)(0x0u + c->fs_base)) = (uint32_t)(esp);
L_A0031EA:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x30u)));
    ebx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x2Cu)));
    ebx = (uint32_t)(logic32((uint32_t)(ebx ^ TL32((uint32_t)(ecx))), &f));
    esi = (uint32_t)(TL32((uint32_t)(eax + 0xCu)));
    (void)sub32(esi, (uint32_t)0xFFFFFFFEu, &f);
    if (f.zf) goto L_A00323A;
    goto L_A0031FF;
L_A0031FF:
    edx = (uint32_t)(M32((uint32_t)(esp + 0x34u)));
    (void)sub32(edx, (uint32_t)0xFFFFFFFEu, &f);
    if (f.zf) goto L_A00320C;
    goto L_A003208;
L_A003208:
    (void)sub32(esi, edx, &f);
    if ((f.cf || f.zf)) goto L_A00323A;
    goto L_A00320C;
L_A00320C:
    esi = (uint32_t)((uint32_t)(esi + esi*2));
    ebx = (uint32_t)((uint32_t)(ebx + esi*4 + 0x10u));
    ecx = (uint32_t)(TL32((uint32_t)(ebx)));
    TS32((uint32_t)(eax + 0xCu), (uint32_t)(ecx));
    (void)sub32(TL32((uint32_t)(ebx + 0x4u)), (uint32_t)0x0u, &f);
    if (!f.zf) goto L_A0031EA;
    goto L_A00321E;
L_A00321E:
    { uint32_t v_ = 0x101u; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    esp -= 4; M32(esp) = 0xA00322Bu; SPILL(); f_A003875(c); RELOAD();
    ecx = (uint32_t)((uint32_t)0x1u);
    eax = (uint32_t)(TL32((uint32_t)(ebx + 0x8u)));
    esp -= 4; M32(esp) = 0xA003238u; SPILL(); f_A003894(c); RELOAD();
    goto L_A0031EA;
L_A00323A:
    { uint32_t v_ = M32(esp); esp += 4; M32((uint32_t)(0x0u + c->fs_base)) = (uint32_t)(v_); }
    esp = (uint32_t)(add32(esp, (uint32_t)0x18u, &f));
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A003248(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A003248:
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x4u)));
    (void)logic32((uint32_t)(TL32((uint32_t)(ecx + 0x4u)) & (uint32_t)0x6u), &f);
    eax = (uint32_t)((uint32_t)0x1u);
    if (f.zf) goto L_A00328D;
    goto L_A00325A;
L_A00325A:
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ecx = (uint32_t)(TL32((uint32_t)(eax + 0x8u)));
    ecx = (uint32_t)(logic32((uint32_t)(ecx ^ eax), &f));
    esp -= 4; M32(esp) = 0xA003268u; SPILL(); f_A0031A1(c); RELOAD();
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(TL32((uint32_t)(eax + 0x18u)));
    { uint32_t v_ = TL32((uint32_t)(eax + 0xCu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(eax + 0x10u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(eax + 0x14u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00327Au; SPILL(); f_A0031B8(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    eax = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    edx = (uint32_t)(M32((uint32_t)(esp + 0x10u)));
    TS32((uint32_t)(edx), (uint32_t)(eax));
    eax = (uint32_t)((uint32_t)0x3u);
L_A00328D:
    esp += 4; SPILL(); return;
}

void f_A00328E(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A00328E:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    ebp = (uint32_t)(TL32((uint32_t)(ecx)));
    { uint32_t v_ = TL32((uint32_t)(ecx + 0x1Cu)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ecx + 0x18u)); esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = TL32((uint32_t)(ecx + 0x28u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0032A3u; SPILL(); f_A0031B8(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 8; SPILL(); return;
}

void f_A0032AA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0032AA:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(edx);
    eax = (uint32_t)(logic32(0, &f));
    ebx = (uint32_t)(logic32(0, &f));
    edx = (uint32_t)(logic32(0, &f));
    esi = (uint32_t)(logic32(0, &f));
    edi = (uint32_t)(logic32(0, &f));
    { uint32_t t_ = ecx; esp -= 4; M32(esp) = 0xA0032BCu; SPILL(); { static const FnEntry *ic_; const FnEntry *e_ = __atomic_load_n(&ic_, __ATOMIC_RELAXED); if (e_ && e_->addr == t_) e_->fn(c); else rt_call_ic(c, t_, &ic_); } RELOAD(); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A0032DA(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0032DA:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0x0u; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = 0xA0032EFu; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA0032EFu; SPILL(); f_A0038DA(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A0032EF(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0032EF:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

void f_A0032F4(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0032F4:
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(M32((uint32_t)(esp + 0x8u)));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = M32((uint32_t)(esp + 0x14u)); esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA003304u; SPILL(); f_A0031B8(c); RELOAD();
    esp = (uint32_t)(add32(esp, (uint32_t)0xCu, &f));
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 12; SPILL(); return;
}

