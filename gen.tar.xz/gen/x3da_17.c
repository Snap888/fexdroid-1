#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A002F7F(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A002F7F:
    eax = (uint32_t)(TL32((uint32_t)(ebp + 0xFFFFFFECu)));
    ecx = (uint32_t)(TL32((uint32_t)(eax)));
    ecx = (uint32_t)(TL32((uint32_t)(ecx)));
    TS32((uint32_t)(ebp + 0xFFFFFFE0u), (uint32_t)(ecx));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA002F90u; SPILL(); f_A002D09(c); RELOAD();
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ecx = (uint32_t)(v_); }
    esp += 4; SPILL(); return;
}

