#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A0017F0(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A0017F0:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x18u, &f));
    { Xmm s_ = c->xmm[0]; c->xmm[0].q[0] ^= s_.q[0]; c->xmm[0].q[1] ^= s_.q[1]; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    edx = (uint32_t)(TL32((uint32_t)(esi)));
    c->xmm[2].u[0] = M32((uint32_t)(edx + 0x4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { float a_ = c->xmm[2].f[0], b_ = c->xmm[0].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    c->xmm[3] = c->xmm[0];
    c->xmm[1] = c->xmm[0];
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[1].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF4u)) = c->xmm[0].u[0];
    if (f.pf) goto L_A001856;
    goto L_A001829;
L_A001829:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edi = (uint32_t)(eax);
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A001838;
    goto L_A001833;
L_A001833:
    c->xmm[3].u[0] = M32((uint32_t)(edx + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001838:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001841;
    goto L_A00183C;
L_A00183C:
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0x14u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
L_A001841:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    if (f.zf) goto L_A0019EA;
    goto L_A00184C;
L_A00184C:
    c->xmm[0].u[0] = M32((uint32_t)(edx + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A0019EA;
L_A001856:
    c->xmm[2].u[0] = M32((uint32_t)(edx)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { float a_ = c->xmm[2].f[0], b_ = MF32((uint32_t)(0xA001124u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (!f.pf) goto L_A0019BF;
    goto L_A00186B;
L_A00186B:
    c->xmm[2].u[0] = M32((uint32_t)(0xA001118u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    { float a_ = c->xmm[2].f[0], b_ = MF32((uint32_t)(ebx + 0x24u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (!f.cf) goto L_A0019BF;
    goto L_A00187D;
L_A00187D:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x1Cu));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x18u, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001891u; SPILL(); f_A002C50(c); RELOAD();
    eax = (uint32_t)((uint32_t)(esi + 0x4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE8u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA00189Eu; SPILL(); f_A002C20(c); RELOAD();
    ST(0) = ST(0) / (double)MF32((uint32_t)(ebx + 0x24u));
    esi = (uint32_t)(TL32((uint32_t)(esi)));
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edi = (uint32_t)(eax);
    MF32((uint32_t)(ebp + 0x10u)) = (float)ST(0);
    fpush(c, (double)MF32((uint32_t)(esi)));
    fpush(c, (double)MF32((uint32_t)(0xA00112Cu)));
    ST(1) = ST(1) * ST(0);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0);
    { double v_ = ST(0); ST(0) = ST(2); ST(2) = v_; }
    { double a_ = ST(0), b_ = ST(2); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    ST(2) = ST(0); fpop(c);
    if (f.cf) goto L_A0018FE;
    goto L_A0018C4;
L_A0018C4:
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    ST(1) = ST(0); fpop(c);
    ST(0) = ST(0); fpop(c);
    if (f.zf) goto L_A0018D4;
    goto L_A0018CD;
L_A0018CD:
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    goto L_A0018D9;
L_A0018D4:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A0018D9:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A0018E4;
    goto L_A0018DD;
L_A0018DD:
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0x10u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    goto L_A0018E9;
L_A0018E4:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
L_A0018E9:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    if (f.zf) goto L_A0019E5;
    goto L_A0018F4;
L_A0018F4:
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A0019EA;
L_A0018FE:
    ST(0) = ST(0) * (double)MF32((uint32_t)(esi + 0x4u));
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0);
    { double a_ = ST(0), b_ = ST(1); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; fpop(c); }
    ST(0) = ST(0); fpop(c);
    if (f.cf) goto L_A001942;
    goto L_A00190C;
L_A00190C:
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A001918;
    goto L_A001911;
L_A001911:
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    goto L_A00191D;
L_A001918:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A00191D:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001928;
    goto L_A001921;
L_A001921:
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0x14u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    goto L_A00192D;
L_A001928:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
L_A00192D:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    if (f.zf) goto L_A0019E5;
    goto L_A001938;
L_A001938:
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A0019EA;
L_A001942:
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] / c->xmm[1].f[0];
    if (f.zf) goto L_A00197A;
    goto L_A001962;
L_A001962:
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(esi + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[2].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[0].f[0];
    goto L_A00197F;
L_A00197A:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A00197F:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A00199B;
    goto L_A001983;
L_A001983:
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x10u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(esi + 0x14u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[2].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] + c->xmm[0].f[0];
    goto L_A0019A0;
L_A00199B:
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
L_A0019A0:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    if (f.zf) goto L_A0019E5;
    goto L_A0019A7;
L_A0019A7:
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[4].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[2].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    goto L_A0019EA;
L_A0019BF:
    eax = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    edi = (uint32_t)(eax);
    edi = (uint32_t)(logic32((uint32_t)(edi & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A0019CE;
    goto L_A0019C9;
L_A0019C9:
    c->xmm[3].u[0] = M32((uint32_t)(edx + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A0019CE:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A0019D7;
    goto L_A0019D2;
L_A0019D2:
    c->xmm[1].u[0] = M32((uint32_t)(edx + 0x10u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
L_A0019D7:
    ecx = (uint32_t)(eax);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    if (f.zf) goto L_A0019EA;
    goto L_A0019DE;
L_A0019DE:
    c->xmm[0].u[0] = M32((uint32_t)(edx + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A0019EA;
L_A0019E5:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
L_A0019EA:
    (void)logic32((uint32_t)(edi & edi), &f);
    if (f.zf) goto L_A001A19;
    goto L_A0019EE;
L_A0019EE:
    edx = (uint32_t)(TL32((uint32_t)(ebx)));
    c->xmm[2] = c->xmm[3];
    c->xmm[2].f[0] = c->xmm[2].f[0] * MF32((uint32_t)(edx));
    M32((uint32_t)(edx)) = c->xmm[2].u[0];
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_A001A19;
    goto L_A001A04;
L_A001A04:
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    esi = (uint32_t)(TL32((uint32_t)(ebx)));
    c->xmm[2].u[0] = M32((uint32_t)(esi + edx*4)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    edx = (uint32_t)((uint32_t)(esi + edx*4));
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[3].f[0];
    M32((uint32_t)(edx)) = c->xmm[2].u[0];
L_A001A19:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x4u), &f);
    if (f.zf) goto L_A001A2B;
    goto L_A001A1D;
L_A001A1D:
    c->xmm[2].u[0] = M32((uint32_t)(ebx + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebx + 0x10u)) = c->xmm[2].u[0];
L_A001A2B:
    (void)logic8((uint8_t)(((uint8_t)eax) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_A001A3D;
    goto L_A001A2F;
L_A001A2F:
    c->xmm[2].u[0] = M32((uint32_t)(ebx + 0x14u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    M32((uint32_t)(ebx + 0x14u)) = c->xmm[2].u[0];
L_A001A3D:
    (void)logic32((uint32_t)(ecx & ecx), &f);
    if (f.zf) goto L_A001A4F;
    goto L_A001A41;
L_A001A41:
    c->xmm[1].u[0] = M32((uint32_t)(ebx + 0x18u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(ebx + 0x18u)) = c->xmm[1].u[0];
L_A001A4F:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

