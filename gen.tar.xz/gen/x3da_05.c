#include "funcs_x3da.h"
#include "lift_prelude.h"

void f_A001A60(CPU *c) {
    uint32_t eax = c->r[0], ecx = c->r[1], edx = c->r[2], ebx = c->r[3], esp = c->r[4], ebp = c->r[5], esi = c->r[6], edi = c->r[7];
    Flags f = {0};
    uint32_t jt_ = 0;
    (void)f; (void)jt_;
L_A001A60:
    edi = (uint32_t)(edi);
    { uint32_t v_ = ebp; esp -= 4; M32(esp) = v_; }
    ebp = (uint32_t)(esp);
    esp = (uint32_t)(sub32(esp, (uint32_t)0x1Cu, &f));
    { Xmm s_ = c->xmm[1]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
    { uint32_t v_ = ebx; esp -= 4; M32(esp) = v_; }
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    esi = (uint32_t)(M32((uint32_t)(ebp + 0xCu)));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    c->xmm[4].u[0] = M32((uint32_t)(ecx + 0x4u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { float a_ = c->xmm[4].f[0], b_ = c->xmm[1].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    { uint32_t v_ = edi; esp -= 4; M32(esp) = v_; }
    edi = (uint32_t)(M32((uint32_t)(ebp + 0x18u)));
    c->xmm[3] = c->xmm[1];
    c->xmm[2] = c->xmm[1];
    c->xmm[0] = c->xmm[1];
    M32((uint32_t)(ebp + 0xFFFFFFFCu)) = c->xmm[3].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF8u)) = c->xmm[2].u[0];
    M32((uint32_t)(ebp + 0xFFFFFFF0u)) = c->xmm[0].u[0];
    if (f.pf) goto L_A001ACE;
    goto L_A001A9D;
L_A001A9D:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A001AAC;
    goto L_A001AA7;
L_A001AA7:
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001AAC:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001AB6;
    goto L_A001AB1;
L_A001AB1:
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x14u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_A001AB6:
    edx = (uint32_t)(ebx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10u), &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(edx);
    if (f.zf) goto L_A001C79;
    goto L_A001AC4;
L_A001AC4:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A001C79;
L_A001ACE:
    c->xmm[4].u[0] = M32((uint32_t)(ecx)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { float a_ = c->xmm[4].f[0], b_ = MF32((uint32_t)(0xA001124u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (!f.pf) goto L_A001C47;
    goto L_A001AE3;
L_A001AE3:
    c->xmm[4].u[0] = M32((uint32_t)(0xA001118u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    { float a_ = c->xmm[4].f[0], b_ = MF32((uint32_t)(edi + 0x24u)); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    if (!f.cf) goto L_A001C47;
    goto L_A001AF5;
L_A001AF5:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    ecx = (uint32_t)((uint32_t)(esi + 0x18u));
    { uint32_t v_ = ecx; esp -= 4; M32(esp) = v_; }
    edx = (uint32_t)(add32(edx, (uint32_t)0x1Cu, &f));
    { uint32_t v_ = edx; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001B09u; SPILL(); f_A002C50(c); RELOAD();
    { uint32_t v_ = esi; esp -= 4; M32(esp) = v_; }
    eax = (uint32_t)((uint32_t)(ebp + 0xFFFFFFE4u));
    { uint32_t v_ = eax; esp -= 4; M32(esp) = v_; }
    esp -= 4; M32(esp) = 0xA001B13u; SPILL(); f_A002C20(c); RELOAD();
    ST(0) = ST(0) / (double)MF32((uint32_t)(edi + 0x24u));
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(ebx);
    MF32((uint32_t)(ebp + 0xCu)) = (float)ST(0);
    fpush(c, (double)MF32((uint32_t)(ecx)));
    fpush(c, (double)MF32((uint32_t)(0xA00112Cu)));
    ST(1) = ST(1) * ST(0);
    { double v_ = ST(0); ST(0) = ST(1); ST(1) = v_; }
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0x18u)) = (float)ST(0);
    { double v_ = ST(0); ST(0) = ST(2); ST(2) = v_; }
    { double a_ = ST(0), b_ = ST(2); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    ST(2) = ST(0); fpop(c);
    if (f.cf) goto L_A001B78;
    goto L_A001B3A;
L_A001B3A:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    ST(1) = ST(0); fpop(c);
    ST(0) = ST(0); fpop(c);
    if (f.zf) goto L_A001B4A;
    goto L_A001B43;
L_A001B43:
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    goto L_A001B4F;
L_A001B4A:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001B4F:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001B5B;
    goto L_A001B54;
L_A001B54:
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    goto L_A001B60;
L_A001B5B:
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_A001B60:
    edx = (uint32_t)(ebx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10u), &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(edx);
    if (f.zf) goto L_A001C71;
    goto L_A001B6E;
L_A001B6E:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A001C76;
L_A001B78:
    ST(0) = ST(0) * (double)MF32((uint32_t)(ecx + 0x4u));
    ST(0) = cos(ST(0)); c->c2 = 0;
    MF32((uint32_t)(ebp + 0xFFFFFFF4u)) = (float)ST(0);
    { double a_ = ST(0), b_ = ST(1); if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; fpop(c); }
    ST(0) = ST(0); fpop(c);
    if (f.cf) goto L_A001BC0;
    goto L_A001B86;
L_A001B86:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A001B92;
    goto L_A001B8B;
L_A001B8B:
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    goto L_A001B97;
L_A001B92:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001B97:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001BA3;
    goto L_A001B9C;
L_A001B9C:
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x14u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    goto L_A001BA8;
L_A001BA3:
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_A001BA8:
    edx = (uint32_t)(ebx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10u), &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(edx);
    if (f.zf) goto L_A001C71;
    goto L_A001BB6;
L_A001BB6:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A001C76;
L_A001BC0:
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[1].u[0] = M32((uint32_t)(ebp + 0xCu)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF4u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] - c->xmm[0].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[1].f[0] = c->xmm[1].f[0] / c->xmm[2].f[0];
    if (f.zf) goto L_A001BF8;
    goto L_A001BE0;
L_A001BE0:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0xCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[0].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] * c->xmm[1].f[0];
    c->xmm[3].f[0] = c->xmm[3].f[0] + c->xmm[0].f[0];
    goto L_A001BFD;
L_A001BF8:
    c->xmm[3].u[0] = M32((uint32_t)(ebp + 0xFFFFFFFCu)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001BFD:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001C1D;
    goto L_A001C02;
L_A001C02:
    ecx = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x10u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x14u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
    c->xmm[2].f[0] = c->xmm[2].f[0] - c->xmm[0].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] * c->xmm[1].f[0];
    c->xmm[2].f[0] = c->xmm[2].f[0] + c->xmm[0].f[0];
    goto L_A001C22;
L_A001C1D:
    c->xmm[2].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF8u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_A001C22:
    ecx = (uint32_t)(ebx);
    ecx = (uint32_t)(logic32((uint32_t)(ecx & (uint32_t)0x10u), &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(ecx);
    if (f.zf) goto L_A001C71;
    goto L_A001C2C;
L_A001C2C:
    esi = (uint32_t)(TL32((uint32_t)(esi + 0x30u)));
    c->xmm[4].u[0] = M32((uint32_t)(esi + 0x18u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    c->xmm[0].u[0] = M32((uint32_t)(esi + 0x1Cu)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    c->xmm[0].f[0] = c->xmm[0].f[0] - c->xmm[4].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] * c->xmm[1].f[0];
    c->xmm[0].f[0] = c->xmm[0].f[0] + c->xmm[4].f[0];
    goto L_A001C76;
L_A001C47:
    ebx = (uint32_t)(M32((uint32_t)(ebp + 0x14u)));
    eax = (uint32_t)(ebx);
    eax = (uint32_t)(logic32((uint32_t)(eax & (uint32_t)0x1u), &f));
    if (f.zf) goto L_A001C56;
    goto L_A001C51;
L_A001C51:
    c->xmm[3].u[0] = M32((uint32_t)(ecx + 0x8u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
L_A001C56:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0xCu), &f);
    if (f.zf) goto L_A001C60;
    goto L_A001C5B;
L_A001C5B:
    c->xmm[2].u[0] = M32((uint32_t)(ecx + 0x10u)); c->xmm[2].u[1] = c->xmm[2].u[2] = c->xmm[2].u[3] = 0;
L_A001C60:
    edx = (uint32_t)(ebx);
    edx = (uint32_t)(logic32((uint32_t)(edx & (uint32_t)0x10u), &f));
    M32((uint32_t)(ebp + 0x14u)) = (uint32_t)(edx);
    if (f.zf) goto L_A001C79;
    goto L_A001C6A;
L_A001C6A:
    c->xmm[0].u[0] = M32((uint32_t)(ecx + 0x18u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
    goto L_A001C79;
L_A001C71:
    c->xmm[0].u[0] = M32((uint32_t)(ebp + 0xFFFFFFF0u)); c->xmm[0].u[1] = c->xmm[0].u[2] = c->xmm[0].u[3] = 0;
L_A001C76:
    { Xmm s_ = c->xmm[1]; c->xmm[1].q[0] ^= s_.q[0]; c->xmm[1].q[1] ^= s_.q[1]; }
L_A001C79:
    (void)logic32((uint32_t)(eax & eax), &f);
    if (f.zf) goto L_A001D17;
    goto L_A001C81;
L_A001C81:
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    eax = (uint32_t)(logic32(0, &f));
    (void)sub32(TL32((uint32_t)(esi + 0x3Cu)), eax, &f);
    if ((f.cf || f.zf)) goto L_A001CA8;
    goto L_A001C8B;
L_A001C8B:
    goto L_A001C90;
L_A001C90:
    ecx = (uint32_t)(TL32((uint32_t)(edi)));
    ecx = (uint32_t)((uint32_t)(ecx + eax*4));
    c->xmm[4] = c->xmm[3];
    c->xmm[4].f[0] = c->xmm[4].f[0] * MF32((uint32_t)(ecx));
    eax = (uint32_t)(add32(eax, (uint32_t)0x1u, &f));
    M32((uint32_t)(ecx)) = c->xmm[4].u[0];
    (void)sub32(eax, TL32((uint32_t)(esi + 0x3Cu)), &f);
    if (f.cf) goto L_A001C90;
    goto L_A001CA8;
L_A001CA8:
    edx = (uint32_t)(M32((uint32_t)(ebp + 0x8u)));
    (void)sub32(TL32((uint32_t)(edx + 0x8u)), (uint32_t)0xFFFFFFFFu, &f);
    if (f.zf) goto L_A001D17;
    goto L_A001CB1;
L_A001CB1:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x3Cu)));
    (void)sub32(eax, (uint32_t)0x1u, &f);
    if (!f.zf) goto L_A001CD0;
    goto L_A001CB9;
L_A001CB9:
    edx = (uint32_t)(TL32((uint32_t)(edx + 0x8u)));
    eax = (uint32_t)(TL32((uint32_t)(edi)));
    c->xmm[4].u[0] = M32((uint32_t)(eax + edx*4)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    eax = (uint32_t)((uint32_t)(eax + edx*4));
    c->xmm[4].f[0] = c->xmm[4].f[0] * c->xmm[3].f[0];
    M32((uint32_t)(eax)) = c->xmm[4].u[0];
    goto L_A001D17;
L_A001CD0:
    ecx = (uint32_t)(logic32(0, &f));
    (void)logic32((uint32_t)(eax & eax), &f);
    if ((f.cf || f.zf)) goto L_A001D17;
    goto L_A001CD6;
L_A001CD6:
    c->xmm[4].u[0] = M32((uint32_t)(0xA001124u)); c->xmm[4].u[1] = c->xmm[4].u[2] = c->xmm[4].u[3] = 0;
    edi = (uint32_t)(edi);
L_A001CE0:
    eax = (uint32_t)(TL32((uint32_t)(esi + 0x44u)));
    c->xmm[5].u[0] = M32((uint32_t)(eax + ecx*4)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    { float a_ = c->xmm[5].f[0], b_ = c->xmm[4].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    eax = (eax & 0xFFFF00FFu) | ((uint32_t)(uint8_t)((f.cf | 2 | (f.pf << 2) | (f.zf << 6) | (f.sf << 7))) << 8);
    (void)logic8((uint8_t)(((uint8_t)(eax >> 8)) & (uint8_t)0x44u), &f);
    if (f.pf) goto L_A001D0F;
    goto L_A001CF1;
L_A001CF1:
    eax = (uint32_t)(TL32((uint32_t)(edi + 0x8u)));
    { int64_t r_ = (int64_t)(int32_t)eax * (int32_t)TL32((uint32_t)(edx + 0x8u)); eax = (uint32_t)(r_); f.cf = f.of = r_ != (int32_t)r_; }
    esi = (uint32_t)(TL32((uint32_t)(edi)));
    eax = (uint32_t)(add32(eax, ecx, &f));
    c->xmm[5].u[0] = M32((uint32_t)(esi + eax*4)); c->xmm[5].u[1] = c->xmm[5].u[2] = c->xmm[5].u[3] = 0;
    eax = (uint32_t)((uint32_t)(esi + eax*4));
    esi = (uint32_t)(M32((uint32_t)(ebp + 0x10u)));
    c->xmm[5].f[0] = c->xmm[5].f[0] * c->xmm[3].f[0];
    M32((uint32_t)(eax)) = c->xmm[5].u[0];
L_A001D0F:
    ecx = (uint32_t)(add32(ecx, (uint32_t)0x1u, &f));
    (void)sub32(ecx, TL32((uint32_t)(esi + 0x3Cu)), &f);
    if (f.cf) goto L_A001CE0;
    goto L_A001D17;
L_A001D17:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x4u), &f);
    if (f.zf) goto L_A001D34;
    goto L_A001D1C;
L_A001D1C:
    c->xmm[3].u[0] = M32((uint32_t)(edi + 0x10u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[2].f[0];
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[3].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    M32((uint32_t)(edi + 0x10u)) = c->xmm[3].u[0];
    if ((f.cf || f.zf)) goto L_A001D34;
    goto L_A001D2F;
L_A001D2F:
    M32((uint32_t)(edi + 0x10u)) = c->xmm[1].u[0];
L_A001D34:
    (void)logic8((uint8_t)(((uint8_t)ebx) & (uint8_t)0x8u), &f);
    if (f.zf) goto L_A001D51;
    goto L_A001D39;
L_A001D39:
    c->xmm[3].u[0] = M32((uint32_t)(edi + 0x14u)); c->xmm[3].u[1] = c->xmm[3].u[2] = c->xmm[3].u[3] = 0;
    c->xmm[3].f[0] = c->xmm[3].f[0] - c->xmm[2].f[0];
    { float a_ = c->xmm[1].f[0], b_ = c->xmm[3].f[0]; if (a_ != a_ || b_ != b_) { f.zf = f.pf = f.cf = 1; } else { f.zf = a_ == b_; f.pf = 0; f.cf = a_ < b_; } f.of = f.sf = 0; }
    M32((uint32_t)(edi + 0x14u)) = c->xmm[3].u[0];
    if ((f.cf || f.zf)) goto L_A001D51;
    goto L_A001D4C;
L_A001D4C:
    M32((uint32_t)(edi + 0x14u)) = c->xmm[1].u[0];
L_A001D51:
    (void)sub32(M32((uint32_t)(ebp + 0x14u)), (uint32_t)0x0u, &f);
    if (f.zf) goto L_A001D65;
    goto L_A001D57;
L_A001D57:
    c->xmm[1].u[0] = M32((uint32_t)(edi + 0x18u)); c->xmm[1].u[1] = c->xmm[1].u[2] = c->xmm[1].u[3] = 0;
    c->xmm[1].f[0] = c->xmm[1].f[0] * c->xmm[0].f[0];
    M32((uint32_t)(edi + 0x18u)) = c->xmm[1].u[0];
L_A001D65:
    { uint32_t v_ = M32(esp); esp += 4; edi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; esi = (uint32_t)(v_); }
    { uint32_t v_ = M32(esp); esp += 4; ebx = (uint32_t)(v_); }
    esp = (uint32_t)(ebp);
    { uint32_t v_ = M32(esp); esp += 4; ebp = (uint32_t)(v_); }
    esp += 24; SPILL(); return;
}

